package com.shipsign.app.core.github

import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.SourceProjectMetadata

/**
 * Generates validated, single-job GitHub Actions workflows from on-device
 * [SourceProjectMetadata] detected by [com.shipsign.app.core.engine.ZipInspectorEngine].
 *
 * Container routing on `ghcr.io/zaibixrumi1/shipsign-builder`:
 * - [ProjectFramework.NATIVE_ANDROID], [ProjectFramework.GODOT] -> `:android`
 * - [ProjectFramework.FLUTTER] -> `:flutter`
 * - [ProjectFramework.REACT_NATIVE], [ProjectFramework.CAPACITOR_CORDOVA] -> `:web`
 *
 * Dedicated workflow mapping:
 * - [BuildOutputFormat.APK_ONLY] -> `.github/workflows/shipsign-build-apk.yml` (`ShipSign-APK`)
 * - [BuildOutputFormat.AAB_ONLY] -> `.github/workflows/shipsign-build-aab.yml` (`ShipSign-AAB`)
 * - [BuildOutputFormat.BOTH] -> `.github/workflows/shipsign-build-both.yml` (`ShipSign-Bundle`)
 *
 * Security Guarantee:
 * - Zero user keystores or signing passwords ever touch GitHub.
 * - Produces unsigned binaries only for offline on-device signing.
 */
object WorkflowTemplateGenerator {

  const val CONTAINER_IMAGE_BASE = "ghcr.io/zaibixrumi1/shipsign-builder"

  private const val GRADLE_COMMON_FLAGS =
    "--init-script /tmp/shipsign-init.gradle -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\" -Dorg.gradle.workers.max=2"

  private const val GRADLE_ARM64_FLAGS =
    "--init-script /tmp/shipsign-init.gradle -PSHIPSIGN_ARM64_ONLY=true -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\" -Dorg.gradle.workers.max=2"

  private const val DETERMINISTIC_DEBUG_KEYSTORE_BASE64 =
    "/u3+7QAAAAIAAAABAAAAAQAPYW5kcm9pZGRlYnVna2V5AAABof8StX8AAAUBMIIE/TAOBgorBgEEASoCEQEBBQAEggTpL9o2ZLzKZNT0xEKA2DU6NpfHxtJcu/osIu4Q3RHNS/Th69sHd6dkG5MWFNDYHkgTEwd1WnBJ1/hWJTnxhraaNz+s+/eUwCI/XUFQjjpuTuVjL8iaZ0eDiQ838E6ELW6KkRtITSYVDWtfi5G6ZOt5lBe3rXhn8seyRox9QtqJSdP/LRkWUzspY6gSu47EBauWsOBxqxYML5jxQ5KMGj/SC2SnQXANvOo1pVIwkaR9Q2A4XJLw5/vxUKeKdRV/lazqMN0GOHXbEBI1QDvztBgu6q7g/cc+CC+Bzqonq9kSDAy9upgf0Ivba3tmRCOBlMX+MlTZ1n5Jyanh6/0HfXS5Pd8MOF8xleTCFVI9R1Ci5V1QkRGfq1svch5We5ulADYvgpTe4O8XN3LiPz0cZPZXXyGKxQGt3ieosUgtpjNTD/UNdtcrBI5RL2XvzOeJ7sk2qerPTMgLAFoh0EHHVtV6bQ7jiil94zXcyvaPwnbmKA5PtBqLiqO0NSlBzuwAiVEvGJosdw90CPZQz3PXHIg1lftwQggmAz0/T6/P76hVcQCA29zgGHmL5vO/EJocuIDRtkfBz3s/5UCSW9BYKEP2TPpiS2KWS5cFKWEJb5qNXj0ELeDsI/ABjMHPlUDWZdMpSdb71L56vA8Jn3BMjjVLQJSR9Mk6RTUpg+fEb2SNtk6RibCkHkLva1KmhxltCzCEYOexYEwxz0mcUTNaslDw1xf+FnK/dNWsdkKR9y76RJmiBwqElCvdZJaMsxovzYL6C3wwpZwOIMdyn2GEh7gF85uy/fFrxhthpAglvU+abRxBOpxR+eTYAFX08wMYMBQOQj8ibwjDhWOK1+aUU6KABtHyvAJltuvzMrtKBfkbkT7MKZUkj1HcM01LPXiEpJXVmqvfOLerduatbnaoWtT4oo3Aqir1VIdHQgIni9/qmgMHhB9n/2ebEJmCPSDttACAGFmjv4bfz3w96eNm8npPo5u74FaZ5mqpRffnLQUKpW1nSlfpsgyvvaSPC06a0l4fOUlErLo3I+G1+hDN1SjQ4OYv/nXznXNyKt7Vwq6f0ulzZE18KBj7dpFhLYcqIf5wwE/bAunY+timg3dEQkmDQR1HqbVMkAMwlX3cDmN2iCmLVzH1WrUmX23TQ6EddB7wPo0CpFIcAete2YF9pGozUhIZ9WYB4pvPiwsZL8YqI8tWwVtqc8d+mRHyXYMDXitXH1uuh49uxiMhNLDuSikZJmFsUq2zAujUifr9CG0d0QW5llM23x6BM5bK7Se2qAgTtL/H5vvSxS3Ul5rKEu2DxbYOG2IFKoJCvRbesrznMPcKb7FU+qz340oX8gEpSwZTmwwblLf4zXiJBLIeDtgDDSAwFjQlZwxsjehoEd5Fpku0TdD8TjAil3VBlrGxN6/CmkneUJevG2s5JpqsDKdNRH1HcGOgdA+MvIlXeCtinputuocVAcPPQy9fna+bK2d/Lcar/va5ytzqXK0gw/PgIlrd3D0qfng8qYu1M4HQ+7UlTbOVchHRBqBTrO48pS5wiFA8+wXyKvblad9+HsAnqZ7YO+jyVB6/lEN8g62l9fwuZGM3dlxRxJAvFa1wlnT09c57im8H2In+OEIsNsGbQa/LhTZWxJG019F9Qkcc4EYvWe6GRxmGSymkuRauShTHSTMfLCGBI6ryAAAAAQAFWC41MDkAAAMVMIIDETCCAfmgAwIBAgIIHzxI1rVgDkgwDQYJKoZIhvcNAQELBQAwNjELMAkGA1UEBhMCVVMxETAPBgNVBAoTCFNoaXBTaWduMRQwEgYDVQQDEwtTaGlwU2lnbiBDSTAgFw0yNjExMjExNzA2MThaGA8yMDU0MDQwODE3MDYxOFowNjELMAkGA1UEBhMCVVMxETAPBgNVBAoTCFNoaXBTaWduMRQwEgYDVQQDEwtTaGlwU2lnbiBDSTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAMybZX99DQB+i2flc3NmXbwhez8FORc1NjBjKak3aeoVGIIffGiDH6qF17/INiuNJTdw3ZDLjG+WbT/BnlK9tShAD5CxQFFXRiZ2c67pa6IIVUNKXJj3dZsMTAL92j0oV3ML+9CG6RERlb9iAT78CdOpkP2ji14P1HpLneqtSSQfs8D70b0rsyxkLNAucXjJABX4/VatpYQGMJidXYwVVXp64m42wuCvB7eb4BjMBga5WeNMTpmWt8kH4BRPBYehdie0b5bzRq7T+0Mz/fVvOfdzS71h17DFxIcZmqNtSJioVHSR3HnxRnBPqnwlE7kOV870RufjG5/i0v6WGglCIn0CAwEAAaMhMB8wHQYDVR0OBBYEFGbe6P/r+y1jtoCXT/66rqaD5z0HMA0GCSqGSIb3DQEBCwUAA4IBAQDHiuR7up6ewGe94BO4vHrzabQ1Jny6fXFIKFur7WF6ag8rLiFcqF6v/uhWNGDP6sBQY7kfv2gY9AD0QVBHQ8AnYbnBHYHFKzn9guo8IJf/jJblx82fR7ggHzlf1sp8zXP+Gsf7ogaSMGRPnvnJSFn2kdSYqkrod0nRQx+chISDnJXXoFVMzJV4VFqsPBXzxorsiGAKlIx0J9T5Lv5BQ1iju0gA1zvWQwCajyyFtFfPjBzm6xE6HmW9uaFCYdWEunoeigO4YLxeOHkc06z5jvAK01j+eIrtrFtDLd7ApInMfDjlGjt8KTMtbTjMb9PCWd9ZWPo6aECuFMCLTApk0KgnhBEOqeu0tY2h8DTS8hcpasifi3M="

  fun containerImageFor(framework: ProjectFramework): String =
    "$CONTAINER_IMAGE_BASE:${framework.containerTag}"

  fun workflowPathFor(format: BuildOutputFormat): String =
    ".github/workflows/${format.workflowFileName}"

  fun generateWorkflow(
    metadata: SourceProjectMetadata,
    format: BuildOutputFormat,
  ): String {
    require(metadata.framework != ProjectFramework.UNKNOWN) {
      "Cannot generate GitHub workflow for an unclassified project framework."
    }
    return when (format) {
      BuildOutputFormat.APK_ONLY -> generateApkWorkflow(metadata)
      BuildOutputFormat.AAB_ONLY -> generateAabWorkflow(metadata)
      BuildOutputFormat.BOTH -> generateBothWorkflow(metadata)
    }
  }

  fun generateApkWorkflow(metadata: SourceProjectMetadata): String =
    assembleWorkflow(
      metadata = metadata,
      workflowName = "ShipSign Build (${metadata.framework.displayName} · APK)",
      format = BuildOutputFormat.APK_ONLY,
    )

  fun generateAabWorkflow(metadata: SourceProjectMetadata): String =
    assembleWorkflow(
      metadata = metadata,
      workflowName = "ShipSign Build (${metadata.framework.displayName} · AAB)",
      format = BuildOutputFormat.AAB_ONLY,
    )

  fun generateBothWorkflow(metadata: SourceProjectMetadata): String =
    assembleWorkflow(
      metadata = metadata,
      workflowName = "ShipSign Build (${metadata.framework.displayName} · APK + AAB)",
      format = BuildOutputFormat.BOTH,
    )

  fun generateApkOnlyWorkflow(metadata: SourceProjectMetadata): String =
    generateApkWorkflow(metadata)

  fun generateAabOnlyWorkflow(metadata: SourceProjectMetadata): String =
    generateAabWorkflow(metadata)

  private fun assembleWorkflow(
    metadata: SourceProjectMetadata,
    workflowName: String,
    format: BuildOutputFormat,
  ): String {
    require(metadata.framework != ProjectFramework.UNKNOWN) {
      "Cannot generate GitHub workflow for an unclassified project framework."
    }

    val buildSteps = when {
      metadata.framework == ProjectFramework.GODOT -> godotSteps(format)
      metadata.containerTag == "flutter" -> flutterSteps(format)
      metadata.containerTag == "web" -> webGradleSteps(format)
      else -> nativeAndroidSteps(format)
    }

    val artifactStep = uploadArtifactStep(format)

    return """
name: $workflowName
on:
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    container:
      image: $CONTAINER_IMAGE_BASE:${metadata.containerTag}
    steps:
      - uses: actions/checkout@v6

$buildSteps

$artifactStep
""".trimIndent() + "\n"
  }

  private fun commonExtractAndCleanCommands(): String = """
          ZIP_FILE=${'$'}(find . -maxdepth 2 -name "*.zip" | head -n 1)
          [ -n "${'$'}ZIP_FILE" ] && unzip -q "${'$'}ZIP_FILE" -d extracted_project
          find . \( -name "metadata.json" -o -name "applet_access_history.json" -o -name ".DS_Store" \) -delete
  """.trimStart('\n').trimEnd()

  private fun androidGradleSelfHealCommands(): String = """
          SDK_DIR="${'$'}{ANDROID_HOME:-/opt/android-sdk-linux}"
          GRADLE_FILE=${'$'}(find . -maxdepth 4 -not -path '*/.*' -not -path '*/node_modules/*' \( -name 'settings.gradle' -o -name 'settings.gradle.kts' -o -name 'build.gradle' -o -name 'build.gradle.kts' \) | head -n 1)
          PROJECT_DIR="."
          if [ -n "${'$'}GRADLE_FILE" ]; then
            PROJECT_DIR=${'$'}(dirname "${'$'}GRADLE_FILE")
            [ "${'$'}(basename "${'$'}PROJECT_DIR")" = "app" ] && PROJECT_DIR=${'$'}(dirname "${'$'}PROJECT_DIR")
          fi
          ABS_PROJECT_DIR=${'$'}(cd "${'$'}PROJECT_DIR" && pwd)
          echo "PROJECT_DIR=${'$'}ABS_PROJECT_DIR" >> "${'$'}GITHUB_ENV"
          cd "${'$'}ABS_PROJECT_DIR"
          sed -i '/foojay-resolver-convention/d' settings.gradle settings.gradle.kts 2>/dev/null || true
          [ -f ".env.example" ] && [ ! -f ".env" ] && cp .env.example .env
          printf "sdk.dir=%s\n" "${'$'}SDK_DIR" > local.properties
          if [ ! -f "debug.keystore" ]; then
            printf "%s" "$DETERMINISTIC_DEBUG_KEYSTORE_BASE64" | base64 -d > debug.keystore
          fi
          printf '%s\n' \
            'allprojects {' \
            '    afterEvaluate { project ->' \
            '        if (project.extensions.findByName("android") != null) {' \
            '            def androidExt = project.extensions.getByName("android")' \
            '            androidExt.signingConfigs.all { sc ->' \
            '                if (sc.storeFile == null || !sc.storeFile.exists()) {' \
            '                    sc.storeFile = new File(System.getenv("PROJECT_DIR") + "/debug.keystore")' \
            '                    sc.storePassword = "android"' \
            '                    sc.keyAlias = "androiddebugkey"' \
            '                    sc.keyPassword = "android"' \
            '                }' \
            '            }' \
            '            if (project.hasProperty("SHIPSIGN_ARM64_ONLY")) {' \
            '                try {' \
            '                    if (!androidExt.splits.abi.isEnable) {' \
            '                        androidExt.defaultConfig.ndk.abiFilters.clear()' \
            '                        androidExt.defaultConfig.ndk.abiFilters.add("arm64-v8a")' \
            '                    }' \
            '                } catch (Exception ignored) {}' \
            '            }' \
            '            try {' \
            '                androidExt.lint.checkReleaseBuilds = false' \
            '                androidExt.lint.abortOnError = false' \
            '            } catch (Exception ignored) {}' \
            '        }' \
            '    }' \
            '}' > /tmp/shipsign-init.gradle
          if grep -rq "google-services" . 2>/dev/null && [ ! -f "app/google-services.json" ] && [ -d "app" ]; then
            APP_ID=${'$'}(grep -oE 'applicationId\s*=?\s*"[^"]+"' app/build.gradle* 2>/dev/null | head -n 1 | cut -d'"' -f2)
            APP_ID=${'$'}{APP_ID:-com.shipsign.placeholder}
            printf '%s\n' \
              '{' \
              '  "project_info": { "project_number": "100000000000", "project_id": "shipsign-ci", "storage_bucket": "shipsign-ci.appspot.com" },' \
              "  \"client\": [{ \"client_info\": { \"mobilesdk_app_id\": \"1:100000000000:android:0000000000000000\", \"android_client_info\": { \"package_name\": \"${'$'}APP_ID\" } }, \"oauth_client\": [], \"api_key\": [{ \"current_key\": \"AIzaSyDummyKeyForCiCompilationOnly00000\" }] }]" \
              '}' > app/google-services.json
          fi
          if [ -n "${'$'}SHIPSIGN_ID" ]; then
            sed -i '/^GITHUB_CLIENT_ID=/d' .env local.properties 2>/dev/null || true
            printf 'GITHUB_CLIENT_ID=%s\n' "${'$'}SHIPSIGN_ID" >> .env
            printf 'GITHUB_CLIENT_ID=%s\n' "${'$'}SHIPSIGN_ID" >> local.properties
          fi
          if [ -n "${'$'}SHIPSIGN_SECRET" ]; then
            sed -i '/^GITHUB_CLIENT_SECRET=/d' .env local.properties 2>/dev/null || true
            printf 'GITHUB_CLIENT_SECRET=%s\n' "${'$'}SHIPSIGN_SECRET" >> .env
            printf 'GITHUB_CLIENT_SECRET=%s\n' "${'$'}SHIPSIGN_SECRET" >> local.properties
          fi
          if [ -f "./gradlew" ]; then
            sed -i 's/\r$//' gradlew && chmod +x gradlew
            echo "GRADLE_BIN=./gradlew" >> "${'$'}GITHUB_ENV"
          else
            echo "GRADLE_BIN=gradle" >> "${'$'}GITHUB_ENV"
          fi
  """.trimEnd()

  private fun step2EnvBlock(): String = """
        env:
          SHIPSIGN_ID: ${'$'}{{ secrets.SHIPSIGN_CLIENT_ID }}
          SHIPSIGN_SECRET: ${'$'}{{ secrets.SHIPSIGN_CLIENT_SECRET }}
  """.trimStart('\n').trimEnd()

  private fun nativeAndroidSteps(format: BuildOutputFormat): String {
    val envBlock = step2EnvBlock()
    val extractClean = commonExtractAndCleanCommands()
    val selfHeal = androidGradleSelfHealCommands()
    val cascade = gradleCascadeSteps(format)
    return """
      - id: prepare
        name: Extract & Self-Heal Configuration
$envBlock
        run: |
          set -e
$extractClean
$selfHeal

$cascade
    """.trimEnd()
  }

  private fun webGradleSteps(format: BuildOutputFormat): String {
    val envBlock = step2EnvBlock()
    val extractClean = commonExtractAndCleanCommands()
    val selfHeal = androidGradleSelfHealCommands()
    val cascade = gradleCascadeSteps(format)
    return """
      - id: prepare
        name: Extract & Self-Heal Configuration
$envBlock
        run: |
          set -e
          ROOT_DIR=${'$'}(pwd)
$extractClean
          PKG_JSON=${'$'}(find . -maxdepth 4 -not -path '*/.*' -not -path '*/node_modules/*' -name 'package.json' | head -n 1)
          if [ -n "${'$'}PKG_JSON" ]; then
            cd "${'$'}(dirname "${'$'}PKG_JSON")"
            [ -f ".env.example" ] && [ ! -f ".env" ] && cp .env.example .env
            npm install --legacy-peer-deps
            if grep -q '"@capacitor/core"' package.json 2>/dev/null; then
              npm run build || true
              npx cap sync android
            fi
          fi
          cd "${'$'}ROOT_DIR"
$selfHeal

$cascade
    """.trimEnd()
  }

  private fun gradleCascadeSteps(format: BuildOutputFormat): String {
    val pathACommands = when (format) {
      BuildOutputFormat.APK_ONLY ->
        "          ${'$'}GRADLE_BIN assembleRelease $GRADLE_ARM64_FLAGS"
      BuildOutputFormat.AAB_ONLY ->
        "          ${'$'}GRADLE_BIN bundleRelease $GRADLE_COMMON_FLAGS"
      BuildOutputFormat.BOTH ->
        "          ${'$'}GRADLE_BIN assembleRelease $GRADLE_ARM64_FLAGS\n" +
          "          ${'$'}GRADLE_BIN bundleRelease $GRADLE_COMMON_FLAGS"
    }

    val pathBCommands = when (format) {
      BuildOutputFormat.APK_ONLY ->
        "          ${'$'}GRADLE_BIN assembleDebug $GRADLE_ARM64_FLAGS"
      BuildOutputFormat.AAB_ONLY ->
        "          ${'$'}GRADLE_BIN bundleDebug $GRADLE_COMMON_FLAGS"
      BuildOutputFormat.BOTH ->
        "          ${'$'}GRADLE_BIN assembleDebug $GRADLE_ARM64_FLAGS\n" +
          "          ${'$'}GRADLE_BIN bundleDebug $GRADLE_COMMON_FLAGS"
    }

    val debugTasks = when (format) {
      BuildOutputFormat.APK_ONLY -> "assembleDebug"
      BuildOutputFormat.AAB_ONLY -> "bundleDebug"
      BuildOutputFormat.BOTH -> "assembleDebug bundleDebug"
    }

    return """
      - id: path_a
        name: Path A — Fast Release Build
        continue-on-error: true
        run: |
          set -e
          cd "${'$'}PROJECT_DIR"
$pathACommands

      - id: path_b
        name: Path B — Fallback ARM64 Debug Build
        if: steps.path_a.outcome != 'success'
        continue-on-error: true
        run: |
          set -e
          cd "${'$'}PROJECT_DIR"
$pathBCommands

      - id: path_c
        name: Path C — Universal Fallback Build
        if: steps.path_a.outcome != 'success' && steps.path_b.outcome != 'success'
        run: |
          set -e
          cd "${'$'}PROJECT_DIR"
          ${'$'}GRADLE_BIN $debugTasks $GRADLE_COMMON_FLAGS
    """.trimEnd()
  }

  private fun flutterSteps(format: BuildOutputFormat): String {
    val extractClean = commonExtractAndCleanCommands()
    val pathACmd = when (format) {
      BuildOutputFormat.APK_ONLY ->
        "flutter pub get && flutter build apk --release --target-platform android-arm64"
      BuildOutputFormat.AAB_ONLY ->
        "flutter pub get && flutter build appbundle --release"
      BuildOutputFormat.BOTH ->
        "flutter pub get && flutter build apk --release --target-platform android-arm64 && flutter build appbundle --release"
    }
    val pathBCmd = when (format) {
      BuildOutputFormat.APK_ONLY ->
        "flutter pub get && flutter build apk --debug --target-platform android-arm64"
      BuildOutputFormat.AAB_ONLY ->
        "flutter pub get && flutter build appbundle --debug"
      BuildOutputFormat.BOTH ->
        "flutter pub get && flutter build apk --debug --target-platform android-arm64 && flutter build appbundle --debug"
    }
    val pathCCmd = when (format) {
      BuildOutputFormat.APK_ONLY ->
        "flutter pub get && flutter build apk --debug"
      BuildOutputFormat.AAB_ONLY ->
        "flutter pub get && flutter build appbundle --debug"
      BuildOutputFormat.BOTH ->
        "flutter pub get && flutter build apk --debug && flutter build appbundle --debug"
    }

    val envBlock = step2EnvBlock()
    return """
      - id: prepare
        name: Extract & Self-Heal Configuration
$envBlock
        run: |
          set -e
          export PATH="/opt/flutter/bin:${'$'}PATH"
          SDK_DIR="${'$'}{ANDROID_HOME:-/opt/android-sdk-linux}"
$extractClean
          PUBSPEC=${'$'}(find . -maxdepth 4 -not -path '*/.*' -name 'pubspec.yaml' | head -n 1)
          PROJECT_DIR=${'$'}(dirname "${'$'}{PUBSPEC:-./pubspec.yaml}")
          PROJECT_DIR=${'$'}(cd "${'$'}PROJECT_DIR" && pwd)
          echo "PROJECT_DIR=${'$'}PROJECT_DIR" >> "${'$'}GITHUB_ENV"
          cd "${'$'}PROJECT_DIR"
          [ -f ".env.example" ] && [ ! -f ".env" ] && cp .env.example .env
          mkdir -p "${'$'}PROJECT_DIR/android"
          printf "sdk.dir=%s\n" "${'$'}SDK_DIR" > "${'$'}PROJECT_DIR/android/local.properties"
          if [ -n "${'$'}SHIPSIGN_ID" ]; then
            sed -i '/^GITHUB_CLIENT_ID=/d' .env "${'$'}PROJECT_DIR/android/local.properties" 2>/dev/null || true
            printf 'GITHUB_CLIENT_ID=%s\n' "${'$'}SHIPSIGN_ID" >> .env
            printf 'GITHUB_CLIENT_ID=%s\n' "${'$'}SHIPSIGN_ID" >> "${'$'}PROJECT_DIR/android/local.properties"
          fi
          if [ -n "${'$'}SHIPSIGN_SECRET" ]; then
            sed -i '/^GITHUB_CLIENT_SECRET=/d' .env "${'$'}PROJECT_DIR/android/local.properties" 2>/dev/null || true
            printf 'GITHUB_CLIENT_SECRET=%s\n' "${'$'}SHIPSIGN_SECRET" >> .env
            printf 'GITHUB_CLIENT_SECRET=%s\n' "${'$'}SHIPSIGN_SECRET" >> "${'$'}PROJECT_DIR/android/local.properties"
          fi

      - id: path_a
        name: Path A — Fast Release Build
        continue-on-error: true
        run: |
          set -e
          export PATH="/opt/flutter/bin:${'$'}PATH"
          cd "${'$'}PROJECT_DIR"
          $pathACmd

      - id: path_b
        name: Path B — Fallback ARM64 Debug Build
        if: steps.path_a.outcome != 'success'
        continue-on-error: true
        run: |
          set -e
          export PATH="/opt/flutter/bin:${'$'}PATH"
          cd "${'$'}PROJECT_DIR"
          $pathBCmd

      - id: path_c
        name: Path C — Universal Fallback Build
        if: steps.path_a.outcome != 'success' && steps.path_b.outcome != 'success'
        run: |
          set -e
          export PATH="/opt/flutter/bin:${'$'}PATH"
          cd "${'$'}PROJECT_DIR"
          $pathCCmd
    """.trimEnd()
  }

  private fun godotSteps(format: BuildOutputFormat): String {
    val extractClean = commonExtractAndCleanCommands()
    val exportCommands = when (format) {
      BuildOutputFormat.APK_ONLY -> """
          mkdir -p build/outputs/apk/release
          set_godot_export_format 0
          godot --headless --export-release "Android" build/outputs/apk/release/app-release-unsigned.apk
      """.trimEnd()
      BuildOutputFormat.AAB_ONLY -> """
          mkdir -p build/outputs/bundle/release
          set_godot_export_format 1
          godot --headless --export-release "Android" build/outputs/bundle/release/app-release.aab
      """.trimEnd()
      BuildOutputFormat.BOTH -> """
          mkdir -p build/outputs/apk/release build/outputs/bundle/release
          set_godot_export_format 0
          godot --headless --export-release "Android" build/outputs/apk/release/app-release-unsigned.apk
          set_godot_export_format 1
          godot --headless --export-release "Android" build/outputs/bundle/release/app-release.aab
      """.trimEnd()
    }

    val envBlock = step2EnvBlock()
    return """
      - id: prepare
        name: Extract & Self-Heal Configuration
$envBlock
        run: |
          set -e
$extractClean
          GODOT_FILE=${'$'}(find . -maxdepth 4 -not -path '*/.*' -name 'project.godot' | head -n 1)
          PROJECT_DIR=${'$'}(dirname "${'$'}{GODOT_FILE:-./project.godot}")
          ABS_PROJECT_DIR=${'$'}(cd "${'$'}PROJECT_DIR" && pwd)
          echo "PROJECT_DIR=${'$'}ABS_PROJECT_DIR" >> "${'$'}GITHUB_ENV"
          cd "${'$'}ABS_PROJECT_DIR"
          [ -f ".env.example" ] && [ ! -f ".env" ] && cp .env.example .env
          printf "sdk.dir=%s\n" "${'$'}{ANDROID_HOME:-/opt/android-sdk-linux}" > local.properties
          if [ -n "${'$'}SHIPSIGN_ID" ]; then
            sed -i '/^GITHUB_CLIENT_ID=/d' .env local.properties 2>/dev/null || true
            printf 'GITHUB_CLIENT_ID=%s\n' "${'$'}SHIPSIGN_ID" >> .env
            printf 'GITHUB_CLIENT_ID=%s\n' "${'$'}SHIPSIGN_ID" >> local.properties
          fi
          if [ -n "${'$'}SHIPSIGN_SECRET" ]; then
            sed -i '/^GITHUB_CLIENT_SECRET=/d' .env local.properties 2>/dev/null || true
            printf 'GITHUB_CLIENT_SECRET=%s\n' "${'$'}SHIPSIGN_SECRET" >> .env
            printf 'GITHUB_CLIENT_SECRET=%s\n' "${'$'}SHIPSIGN_SECRET" >> local.properties
          fi
          if [ ! -f "debug.keystore" ]; then
            printf "%s" "$DETERMINISTIC_DEBUG_KEYSTORE_BASE64" | base64 -d > debug.keystore
          fi
          if [ ! -f "export_presets.cfg" ]; then
            printf '%s\n' \
              '[preset.0]' \
              'name="Android"' \
              'platform="Android"' \
              'runnable=true' \
              'export_filter="all_resources"' \
              '[preset.0.options]' \
              'architectures/arm64-v8a=true' \
              'architectures/armeabi-v7a=true' \
              'package/unique_name="com.shipsign.godotapp"' \
              'package/export_format=0' > export_presets.cfg
          fi

      - id: path_a
        name: Path A — Fast Release Build
        run: |
          set -e
          cd "${'$'}PROJECT_DIR"
          set_godot_export_format() {
            if grep -q '^package/export_format=' export_presets.cfg; then
              sed -i "s|^package/export_format=.*|package/export_format=${'$'}1|" export_presets.cfg
            else
              printf "\npackage/export_format=%s\n" "${'$'}1" >> export_presets.cfg
            fi
          }
$exportCommands
    """.trimEnd()
  }

  private fun uploadArtifactStep(format: BuildOutputFormat): String = when (format) {
    BuildOutputFormat.APK_ONLY -> """
      - name: Upload Built Packages
        uses: actions/upload-artifact@v7
        with:
          name: ShipSign-APK
          compression-level: 0
          path: "**/outputs/apk/**/*.apk"
    """.trimEnd()
    BuildOutputFormat.AAB_ONLY -> """
      - name: Upload Built Packages
        uses: actions/upload-artifact@v7
        with:
          name: ShipSign-AAB
          compression-level: 0
          path: "**/outputs/bundle/**/*.aab"
    """.trimEnd()
    BuildOutputFormat.BOTH -> """
      - name: Upload Built Packages
        uses: actions/upload-artifact@v7
        with:
          name: ShipSign-Bundle
          compression-level: 0
          path: |
            **/outputs/apk/**/*.apk
            **/outputs/bundle/**/*.aab
    """.trimEnd()
  }
}
