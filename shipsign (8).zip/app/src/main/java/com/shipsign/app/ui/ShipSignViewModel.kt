package com.shipsign.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shipsign.app.core.engine.ErrorTranslator
import com.shipsign.app.core.engine.FormatConverterEngine
import com.shipsign.app.core.engine.KeystoreGenerator
import com.shipsign.app.core.engine.PackageCustomizationRequest
import com.shipsign.app.core.engine.PackageCustomizerEngine
import com.shipsign.app.core.engine.PackageInfoInspector
import com.shipsign.app.core.engine.SignatureScanner
import com.shipsign.app.core.engine.SigningEngine
import com.shipsign.app.core.engine.SigningProgressEvent
import com.shipsign.app.core.engine.TranslatedError
import com.shipsign.app.core.engine.ZipInspectorEngine
import com.shipsign.app.core.github.BuildOutputFormat
import com.shipsign.app.core.github.BuildSessionStatus
import com.shipsign.app.core.github.BuildSessionStore
import com.shipsign.app.core.github.CloudBuildStage
import com.shipsign.app.core.github.CloudBuildState
import com.shipsign.app.core.github.GitHubBuildModule
import com.shipsign.app.core.github.GitHubOAuthManager
import com.shipsign.app.core.github.PersistedBuildSession
import com.shipsign.app.core.github.ServiceSigningEvent
import com.shipsign.app.core.github.ShipSignBuildService
import com.shipsign.app.core.security.AppPreferences
import com.shipsign.app.core.security.KeystoreDetector
import com.shipsign.app.core.security.KeystoreVaultManager
import com.shipsign.app.core.security.VaultKeystoreEntry
import com.shipsign.app.core.security.ZeroTraceAuditResult
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.core.security.ZeroTraceSnapshot
import com.shipsign.app.core.storage.ProjectHistoryRepository
import com.shipsign.app.core.storage.SafFileBridge
import com.shipsign.app.core.storage.SavedProjectEntry
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ImportedKeystoreConfig
import com.shipsign.app.domain.model.InputCategory
import com.shipsign.app.domain.model.InputKind
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ProjectStack
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.domain.model.SigningOptions
import com.shipsign.app.domain.model.SigningResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.File
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Security
import java.util.Locale

data class SecurityProviderInfo(
  val slot: Int,
  val name: String,
  val version: String,
  val info: String,
  val isBouncyCastle: Boolean,
)

data class CryptoDiagnosticsState(
  val bouncyCastleSlot: Int = -1,
  val bouncyCastleVersion: String = "",
  val providers: List<SecurityProviderInfo> = emptyList(),
  val selfTestPassed: Boolean? = null,
  val isTesting: Boolean = false,
)

data class InspectorUiState(
  val selectedCategory: InputCategory = InputCategory.BUILT_APK,
  val selectedOutputFormat: BuildOutputFormat = BuildOutputFormat.APK_ONLY,
  val targetFile: AppTargetFile? = null,
  val availableBuildTargets: List<AppTargetFile> = emptyList(),
  val pendingAdvanceToKeystore: Boolean = false,
  val isProcessing: Boolean = false,
  val signatureJustStripped: Boolean = false,
  val lastExportedFileName: String? = null,
  val errorMessage: String? = null,
)

data class VerifiedKeystoreSummary(
  val format: KeystoreFormat,
  val alias: String,
  val subjectDn: String,
  val sha256Fingerprint: String,
)

data class KeystoreStudioUiState(
  val tempKeystoreFile: File? = null,
  val importedFileName: String? = null,
  val detectedFormat: KeystoreFormat = KeystoreFormat.UNKNOWN,
  val verifiedSummary: VerifiedKeystoreSummary? = null,
  val hasUnlockedCredentials: Boolean = false,
  val generatedKeystoreFile: File? = null,
  val generatedFileName: String? = null,
  val generatedFormat: KeystoreFormat? = null,
  val generatedDownloaded: Boolean = false,
  val isBusy: Boolean = false,
  val errorMessage: String? = null,
)

data class SigningStudioUiState(
  val options: SigningOptions = SigningOptions(),
  val isSigning: Boolean = false,
  val logs: List<String> = emptyList(),
  val result: SigningResult? = null,
  val translatedError: TranslatedError? = null,
)

data class CloudBuildUiState(
  val isConnected: Boolean = false,
  val isAuthorizing: Boolean = false,
  val connectedUsername: String? = null,
  val connectedAvatarUrl: String? = null,
  val installationId: String? = null,
  val isActive: Boolean = false,
  val currentStage: CloudBuildStage? = null,
  val statusText: String = "",
  val elapsedSeconds: Int = 0,
  val buildState: CloudBuildState = CloudBuildState.Idle,
  val persistedSession: PersistedBuildSession? = null,
  val isClearingCloudTrace: Boolean = false,
  val clearedCloudRepoName: String? = null,
  val pendingResumeNavigation: Boolean = false,
  val needsRepoAccessGrant: Boolean = false,
  val repoAccessMessage: String? = null,
  val translatedError: TranslatedError? = null,
)

data class OfflinePipelineUiState(
  val isCustomizing: Boolean = false,
  val isConverting: Boolean = false,
  val isFinalizing: Boolean = false,
  val errorMessage: String? = null,
  val completedProject: SavedProjectEntry? = null,
  val completedExportUri: Uri? = null,
  val pendingNavigateToComplete: Boolean = false,
)

data class KeystoreVaultUiState(
  val entries: List<VaultKeystoreEntry> = emptyList(),
  val isBusy: Boolean = false,
  val errorMessage: String? = null,
  val statusMessage: String? = null,
  val importedTempFile: File? = null,
  val importedFileName: String? = null,
  val detectedFormat: KeystoreFormat = KeystoreFormat.UNKNOWN,
)

data class ProjectHistoryUiState(
  val projects: List<SavedProjectEntry> = emptyList(),
  val isBusy: Boolean = false,
  val clearingRepoName: String? = null,
  val errorMessage: String? = null,
)

data class FoundationUiState(
  val hasAcceptedGitHubDisclosure: Boolean = false,
  val showGitHubDisclosureDialog: Boolean = false,
  val wipeTimeoutSec: Int = AppPreferences.DEFAULT_WIPE_TIMEOUT_SEC,
  val lastAuditResult: ZeroTraceAuditResult? = null,
  val isAuditing: Boolean = false,
  val cryptoDiagnostics: CryptoDiagnosticsState = CryptoDiagnosticsState(),
  val inspector: InspectorUiState = InspectorUiState(),
  val keystoreStudio: KeystoreStudioUiState = KeystoreStudioUiState(),
  val signingStudio: SigningStudioUiState = SigningStudioUiState(),
  val cloudBuild: CloudBuildUiState = CloudBuildUiState(),
  val pipeline: OfflinePipelineUiState = OfflinePipelineUiState(),
  val keystoreVault: KeystoreVaultUiState = KeystoreVaultUiState(),
  val projectHistory: ProjectHistoryUiState = ProjectHistoryUiState(),
)

class ShipSignViewModel(application: Application) : AndroidViewModel(application) {

  val zeroTraceSnapshot: StateFlow<ZeroTraceSnapshot> = ZeroTraceManager.snapshot

  private val _uiState = MutableStateFlow(FoundationUiState())
  val uiState: StateFlow<FoundationUiState> = _uiState.asStateFlow()

  @Volatile private var activeStorePassChars: CharArray? = null
  @Volatile private var activeKeyPassChars: CharArray? = null
  @Volatile private var activeKeyAlias: String? = null
  @Volatile private var generatedStorePassChars: CharArray? = null
  @Volatile private var generatedKeyPassChars: CharArray? = null
  @Volatile private var generatedKeyAlias: String? = null

  private var cloudBuildJob: Job? = null
  private var elapsedTimerJob: Job? = null

  init {
    viewModelScope.launch(Dispatchers.IO) {
      ZeroTraceManager.createOrGetSessionDir(application)
      val hasDisclosure = AppPreferences.hasAcceptedGitHubDisclosure(application)
      val wipeTimeout = AppPreferences.getBackgroundWipeTimeoutSec(application)
      val storedSession = GitHubOAuthManager.getSavedSession(application)
      val persistedBuild = BuildSessionStore.loadSession(application)
      val vaultEntries = KeystoreVaultManager.listKeystores(application)
      val savedProjects = ProjectHistoryRepository.listProjects(application)
      _uiState.update { state ->
        state.copy(
          hasAcceptedGitHubDisclosure = hasDisclosure,
          wipeTimeoutSec = wipeTimeout,
          cloudBuild = state.cloudBuild.copy(
            isConnected = storedSession != null,
            connectedUsername = storedSession?.username,
            connectedAvatarUrl = storedSession?.avatarUrl,
            installationId = storedSession?.installationId,
            persistedSession = persistedBuild,
          ),
          keystoreVault = state.keystoreVault.copy(entries = vaultEntries),
          projectHistory = state.projectHistory.copy(projects = savedProjects),
        )
      }
      refreshCryptoProviders()
      syncAndResumePersistedSessionInternal(application, triggerNavigation = true)
    }

    viewModelScope.launch {
      KeystoreVaultManager.vaultFlow.collect { entries ->
        _uiState.update { it.copy(keystoreVault = it.keystoreVault.copy(entries = entries)) }
      }
    }

    viewModelScope.launch {
      ProjectHistoryRepository.projectsFlow.collect { projects ->
        _uiState.update { it.copy(projectHistory = it.projectHistory.copy(projects = projects)) }
      }
    }

    viewModelScope.launch {
      BuildSessionStore.sessionFlow.collect { session ->
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              persistedSession = session,
            )
          )
        }
      }
    }

    viewModelScope.launch {
      ShipSignBuildService.buildState.collect { buildState ->
        if (buildState != CloudBuildState.Idle) {
          val sourceFile = _uiState.value.inspector.targetFile
            ?.takeIf { it.binaryType == ResolvedBinaryType.SOURCE_CODE_PROJECT }
            ?.sessionFile
          handleCloudBuildState(buildState, previousSourceFile = sourceFile)
        }
      }
    }

    viewModelScope.launch {
      ShipSignBuildService.signingEvent.collect { event ->
        handleServiceSigningEvent(event)
      }
    }
  }

  override fun onCleared() {
    elapsedTimerJob?.cancel()
    wipeActiveSigningCredentials()
    wipeGeneratedCredentials()
    super.onCleared()
  }

  fun onAppResumed() {
    val appCtx = getApplication<Application>()
    viewModelScope.launch(Dispatchers.IO) {
      syncAndResumePersistedSessionInternal(appCtx, triggerNavigation = true)
    }
  }

  fun consumePendingResumeNavigation() {
    _uiState.update { it.copy(cloudBuild = it.cloudBuild.copy(pendingResumeNavigation = false)) }
  }

  private fun syncAndResumePersistedSessionInternal(
    appCtx: Application,
    triggerNavigation: Boolean,
  ) {
    val session = BuildSessionStore.loadSession(appCtx) ?: return
    when {
      session.status.isActiveInCloud -> {
        val elapsed = ((System.currentTimeMillis() - session.startedAtEpochMs) / 1_000L)
          .toInt()
          .coerceAtLeast(0)
        val stage = when (session.status) {
          BuildSessionStatus.UPLOADING -> CloudBuildStage.PUSHING_SOURCES
          BuildSessionStatus.QUEUED, BuildSessionStatus.IN_PROGRESS -> CloudBuildStage.POLLING_BUILD
          BuildSessionStatus.DOWNLOADING_SIGNING -> CloudBuildStage.DOWNLOADING_AND_WIPING
          else -> CloudBuildStage.POLLING_BUILD
        }
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = true,
              currentStage = stage,
              statusText = session.statusMessage.ifBlank { stage.label },
              elapsedSeconds = elapsed,
              persistedSession = session,
              clearedCloudRepoName = null,
              pendingResumeNavigation = triggerNavigation || state.cloudBuild.pendingResumeNavigation,
              translatedError = null,
            )
          )
        }
        startElapsedTimerFrom(session.startedAtEpochMs)
        if (!ShipSignBuildService.isRunning.value) {
          ShipSignBuildService.resumeCloudBuild(appCtx)
        }
      }
      session.status == BuildSessionStatus.COMPLETED_AWAITING_CLEANUP -> {
        elapsedTimerJob?.cancel()
        val sessionDir = ZeroTraceManager.createOrGetSessionDir(appCtx)
        val restoredTargets = if (_uiState.value.inspector.targetFile == null) {
          session.downloadedArtifactPaths
            .map { File(it) }
            .filter { it.exists() && it.isFile }
            .mapNotNull { file ->
              runCatching {
                val inspected = ZipInspectorEngine.inspectFile(file, file.name, sessionDir)
                if (inspected.binaryType == ResolvedBinaryType.APK || inspected.binaryType == ResolvedBinaryType.AAB) {
                  val info = PackageInfoInspector.inspectPackage(
                    context = appCtx,
                    file = inspected.sessionFile,
                    format = inspected.binaryType,
                    fallbackName = session.projectName.ifBlank { inspected.originalName.substringBeforeLast('.') },
                  )
                  inspected.copy(packageInfo = info, isAlreadySigned = info.isSigned)
                } else {
                  inspected
                }
              }.getOrNull()
            }
            .filter {
              it.binaryType == ResolvedBinaryType.APK || it.binaryType == ResolvedBinaryType.AAB
            }
        } else {
          emptyList()
        }
        _uiState.update { state ->
          val updatedInspector = if (restoredTargets.isNotEmpty() && state.inspector.targetFile == null) {
            state.inspector.copy(
              targetFile = restoredTargets.first(),
              availableBuildTargets = restoredTargets,
              signatureJustStripped = false,
              errorMessage = null,
            )
          } else {
            state.inspector
          }
          state.copy(
            inspector = updatedInspector,
            cloudBuild = state.cloudBuild.copy(
              isActive = false,
              currentStage = null,
              statusText = "",
              persistedSession = session,
              buildState = if (restoredTargets.isNotEmpty()) {
                CloudBuildState.ReadyForOfflineSigning(
                  targetFile = restoredTargets.first(),
                  availableTargets = restoredTargets,
                  repoDeleted = false,
                  repoFullName = session.repoFullName,
                  runId = session.runId,
                )
              } else {
                state.cloudBuild.buildState
              },
            ),
          )
        }
      }
      session.status == BuildSessionStatus.FAILED_AWAITING_CLEANUP -> {
        elapsedTimerJob?.cancel()
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = false,
              currentStage = null,
              statusText = "",
              persistedSession = session,
              translatedError = session.errorMessage?.let { msg ->
                TranslatedError(title = "Cloud Build Failed", message = msg)
              } ?: state.cloudBuild.translatedError,
            )
          )
        }
      }
      session.status == BuildSessionStatus.CLEANED -> {
        BuildSessionStore.clearSession(appCtx)
      }
    }
  }

  private fun startElapsedTimerFrom(startedAtMs: Long) {
    elapsedTimerJob?.cancel()
    elapsedTimerJob = viewModelScope.launch {
      while (isActive) {
        val sec = ((System.currentTimeMillis() - startedAtMs) / 1_000L).toInt().coerceAtLeast(0)
        _uiState.update { state ->
          if (state.cloudBuild.isActive) {
            state.copy(cloudBuild = state.cloudBuild.copy(elapsedSeconds = sec))
          } else {
            state
          }
        }
        delay(1_000L)
      }
    }
  }

  // --- Step 1: Input Selection, Deep Inspection & Signature Scanner ---

  fun selectInputCategory(category: InputCategory) {
    _uiState.update { it.copy(inspector = it.inspector.copy(selectedCategory = category)) }
  }

  fun selectOutputFormat(format: BuildOutputFormat) {
    _uiState.update { it.copy(inspector = it.inspector.copy(selectedOutputFormat = format)) }
  }

  fun selectActiveBuildTarget(target: AppTargetFile) {
    _uiState.update { state ->
      if (state.signingStudio.isSigning) return@update state
      state.copy(
        inspector = state.inspector.copy(targetFile = target),
        signingStudio = state.signingStudio.copy(
          translatedError = null,
          logs = emptyList(),
        ),
      )
    }
  }

  fun consumePendingAdvanceToKeystore() {
    _uiState.update { it.copy(inspector = it.inspector.copy(pendingAdvanceToKeystore = false)) }
  }

  fun inspectPickedUri(uri: Uri) {
    if (_uiState.value.inspector.isProcessing) return
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    _uiState.update {
      it.copy(
        inspector = it.inspector.copy(
          isProcessing = true,
          pendingAdvanceToKeystore = false,
          signatureJustStripped = false,
          lastExportedFileName = null,
          errorMessage = null,
        ),
        signingStudio = it.signingStudio.copy(
          result = null,
          logs = emptyList(),
          translatedError = null,
        ),
        cloudBuild = it.cloudBuild.copy(
          isActive = false,
          currentStage = null,
          statusText = "",
          elapsedSeconds = 0,
          buildState = CloudBuildState.Idle,
          needsRepoAccessGrant = false,
          translatedError = null,
        ),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        deleteInspectorFiles(_uiState.value.inspector)
        val raw = ZipInspectorEngine.inspectUriAsync(appCtx, uri)
        if (raw.binaryType == ResolvedBinaryType.APK || raw.binaryType == ResolvedBinaryType.AAB) {
          val info = PackageInfoInspector.inspectPackage(
            context = appCtx,
            file = raw.sessionFile,
            format = raw.binaryType,
            fallbackName = raw.originalName.substringBeforeLast('.'),
          )
          raw.copy(packageInfo = info, isAlreadySigned = info.isSigned)
        } else {
          raw
        }
      }.onSuccess { resolved ->
        val inferredCategory = when (resolved.binaryType) {
          ResolvedBinaryType.APK -> InputCategory.BUILT_APK
          ResolvedBinaryType.AAB -> InputCategory.PLAY_STORE_AAB
          ResolvedBinaryType.SOURCE_CODE_PROJECT -> InputCategory.STUDIO_SOURCE_ZIP
          ResolvedBinaryType.INVALID -> _uiState.value.inspector.selectedCategory
        }
        val isCleanPrebuilt = resolved.inputKind == InputKind.PREBUILT_PACKAGE && !resolved.isAlreadySigned
        _uiState.update {
          it.copy(
            inspector = it.inspector.copy(
              selectedCategory = inferredCategory,
              targetFile = if (resolved.inputKind == InputKind.INVALID) null else resolved,
              availableBuildTargets = if (resolved.inputKind == InputKind.PREBUILT_PACKAGE) {
                listOf(resolved)
              } else {
                emptyList()
              },
              pendingAdvanceToKeystore = isCleanPrebuilt,
              isProcessing = false,
              errorMessage = if (resolved.inputKind == InputKind.INVALID) {
                "Unsupported archive. No APK, AAB, Android, Flutter, React Native, Capacitor, or Godot project found."
              } else {
                null
              },
            )
          )
        }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            inspector = it.inspector.copy(
              targetFile = null,
              availableBuildTargets = emptyList(),
              pendingAdvanceToKeystore = false,
              isProcessing = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun inspectPackageForBranch(uri: Uri, expectedType: ResolvedBinaryType) {
    if (_uiState.value.inspector.isProcessing) return
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    _uiState.update {
      it.copy(
        inspector = it.inspector.copy(
          isProcessing = true,
          pendingAdvanceToKeystore = false,
          signatureJustStripped = false,
          lastExportedFileName = null,
          errorMessage = null,
        ),
        pipeline = OfflinePipelineUiState(),
        signingStudio = it.signingStudio.copy(
          result = null,
          logs = emptyList(),
          translatedError = null,
        ),
        cloudBuild = it.cloudBuild.copy(
          isActive = false,
          currentStage = null,
          statusText = "",
          elapsedSeconds = 0,
          buildState = CloudBuildState.Idle,
          needsRepoAccessGrant = false,
          translatedError = null,
        ),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        deleteInspectorFiles(_uiState.value.inspector)
        val raw = ZipInspectorEngine.inspectUriAsync(appCtx, uri)
        if (raw.binaryType != expectedType) {
          val expectedLabel = when (expectedType) {
            ResolvedBinaryType.SOURCE_CODE_PROJECT -> "source code .zip (Android, Flutter, or Web/Capacitor)"
            ResolvedBinaryType.APK -> ".apk package"
            ResolvedBinaryType.AAB -> ".aab app bundle"
            ResolvedBinaryType.INVALID -> "supported file"
          }
          ZeroTraceManager.secureDeleteFile(raw.sessionFile)
          throw IllegalArgumentException("Expected a valid $expectedLabel.")
        }
        if (raw.binaryType == ResolvedBinaryType.APK || raw.binaryType == ResolvedBinaryType.AAB) {
          val info = PackageInfoInspector.inspectPackage(
            context = appCtx,
            file = raw.sessionFile,
            format = raw.binaryType,
            fallbackName = raw.originalName.substringBeforeLast('.'),
          )
          raw.copy(packageInfo = info, isAlreadySigned = info.isSigned)
        } else {
          raw
        }
      }.onSuccess { resolved ->
        val inferredCategory = when (resolved.binaryType) {
          ResolvedBinaryType.APK -> InputCategory.BUILT_APK
          ResolvedBinaryType.AAB -> InputCategory.PLAY_STORE_AAB
          ResolvedBinaryType.SOURCE_CODE_PROJECT -> InputCategory.STUDIO_SOURCE_ZIP
          ResolvedBinaryType.INVALID -> _uiState.value.inspector.selectedCategory
        }
        _uiState.update {
          it.copy(
            inspector = it.inspector.copy(
              selectedCategory = inferredCategory,
              targetFile = resolved,
              availableBuildTargets = if (resolved.inputKind == InputKind.PREBUILT_PACKAGE) {
                listOf(resolved)
              } else {
                emptyList()
              },
              pendingAdvanceToKeystore = false,
              isProcessing = false,
              errorMessage = null,
            )
          )
        }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            inspector = it.inspector.copy(
              targetFile = null,
              availableBuildTargets = emptyList(),
              isProcessing = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun overrideSourceFramework(framework: ProjectFramework) {
    _uiState.update { state ->
      val target = state.inspector.targetFile ?: return@update state
      val meta = target.sourceMetadata ?: return@update state
      val updatedTarget = target.copy(
        detectedStack = ProjectStack.fromFramework(framework),
        sourceMetadata = meta.copy(framework = framework),
      )
      state.copy(inspector = state.inspector.copy(targetFile = updatedTarget))
    }
  }

  fun stripTargetSignature() {
    val currentTarget = _uiState.value.inspector.targetFile ?: return
    if (_uiState.value.inspector.isProcessing) return
    if (currentTarget.binaryType != ResolvedBinaryType.APK &&
      currentTarget.binaryType != ResolvedBinaryType.AAB
    ) {
      return
    }

    _uiState.update {
      it.copy(
        inspector = it.inspector.copy(
          isProcessing = true,
          errorMessage = null,
          lastExportedFileName = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val suffix = if (currentTarget.binaryType == ResolvedBinaryType.AAB) ".aab" else ".apk"
      val cleanOut: File = ZeroTraceManager.allocateTempFile(appCtx, "unsigned", suffix)

      runCatching {
        SignatureScanner.stripExistingSignature(currentTarget.sessionFile, cleanOut)
        ZeroTraceManager.secureDeleteFile(currentTarget.sessionFile)
        val stillSigned = SignatureScanner.hasExistingSignature(cleanOut)
        currentTarget.copy(
          sessionFile = cleanOut,
          sizeBytes = cleanOut.length(),
          isAlreadySigned = stillSigned,
        )
      }.onSuccess { updatedTarget ->
        _uiState.update {
          val updatedList = it.inspector.availableBuildTargets.map { candidate ->
            if (candidate.sessionFile == currentTarget.sessionFile) updatedTarget else candidate
          }
          it.copy(
            inspector = it.inspector.copy(
              targetFile = updatedTarget,
              availableBuildTargets = updatedList,
              isProcessing = false,
              signatureJustStripped = !updatedTarget.isAlreadySigned,
            )
          )
        }
      }.onFailure { err ->
        ZeroTraceManager.secureDeleteFile(cleanOut)
        _uiState.update {
          it.copy(
            inspector = it.inspector.copy(
              isProcessing = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun clearInspectedTarget() {
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    viewModelScope.launch(Dispatchers.IO) {
      deleteInspectorFiles(_uiState.value.inspector)
      _uiState.update {
        it.copy(
          inspector = InspectorUiState(
            selectedCategory = it.inspector.selectedCategory,
            selectedOutputFormat = it.inspector.selectedOutputFormat,
          ),
          signingStudio = SigningStudioUiState(options = it.signingStudio.options),
          cloudBuild = it.cloudBuild.copy(
            isActive = false,
            currentStage = null,
            statusText = "",
            elapsedSeconds = 0,
            buildState = CloudBuildState.Idle,
            needsRepoAccessGrant = false,
            translatedError = null,
          ),
        )
      }
    }
  }

  // --- Step 1B: Verified GitHub App OAuth (PKCE S256) & Ephemeral Cloud Build ---

  fun requestGitHubConnect(activityContext: Context) {
    if (_uiState.value.hasAcceptedGitHubDisclosure) {
      connectGitHub(activityContext)
    } else {
      _uiState.update { it.copy(showGitHubDisclosureDialog = true) }
    }
  }

  fun acceptGitHubDisclosureAndConnect(activityContext: Context) {
    val appCtx = getApplication<Application>()
    _uiState.update {
      it.copy(
        hasAcceptedGitHubDisclosure = true,
        showGitHubDisclosureDialog = false,
      )
    }
    viewModelScope.launch(Dispatchers.IO) {
      AppPreferences.markGitHubDisclosureAccepted(appCtx)
    }
    connectGitHub(activityContext)
  }

  fun dismissGitHubDisclosure() {
    _uiState.update { it.copy(showGitHubDisclosureDialog = false) }
  }

  fun connectGitHub(context: Context) {
    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isAuthorizing = true,
          needsRepoAccessGrant = false,
          translatedError = null,
        )
      )
    }
    runCatching {
      GitHubOAuthManager.startOAuthFlow(context)
    }.onFailure { err ->
      _uiState.update { state ->
        state.copy(
          cloudBuild = state.cloudBuild.copy(
            isAuthorizing = false,
            translatedError = ErrorTranslator.translate(err),
          )
        )
      }
    }
  }

  fun connectWithPersonalAccessToken(tokenChars: CharArray) {
    if (_uiState.value.cloudBuild.isAuthorizing) {
      ZeroTraceManager.wipeCharArray(tokenChars)
      return
    }
    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isAuthorizing = true,
          needsRepoAccessGrant = false,
          translatedError = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      try {
        val result = GitHubOAuthManager.connectWithPersonalAccessToken(
          context = appCtx,
          tokenChars = tokenChars,
        )
        result.onSuccess { session ->
          _uiState.update { state ->
            state.copy(
              cloudBuild = state.cloudBuild.copy(
                isConnected = true,
                isAuthorizing = false,
                connectedUsername = session.username,
                connectedAvatarUrl = session.avatarUrl,
                installationId = session.installationId,
                needsRepoAccessGrant = false,
                translatedError = null,
              )
            )
          }
        }.onFailure { err ->
          _uiState.update { state ->
            state.copy(
              cloudBuild = state.cloudBuild.copy(
                isAuthorizing = false,
                translatedError = ErrorTranslator.translate(err),
              )
            )
          }
        }
      } finally {
        ZeroTraceManager.wipeCharArray(tokenChars)
      }
    }
  }

  fun onGitHubCallback(uri: Uri) {
    if (!GitHubOAuthManager.isGitHubCallbackUri(uri)) return

    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isAuthorizing = true,
          translatedError = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val result = GitHubOAuthManager.handleAuthCallback(context = appCtx, uri = uri)
      result.onSuccess { session ->
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isConnected = true,
              isAuthorizing = false,
              connectedUsername = session.username,
              connectedAvatarUrl = session.avatarUrl,
              installationId = session.installationId,
              needsRepoAccessGrant = false,
              translatedError = null,
            )
          )
        }
      }.onFailure { err ->
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isAuthorizing = false,
              translatedError = ErrorTranslator.translate(err),
            )
          )
        }
      }
    }
  }

  fun handleOAuthCallbackUri(uri: Uri) = onGitHubCallback(uri)

  fun disconnectGitHub() {
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    cloudBuildJob = null
    val appCtx = getApplication<Application>()
    _uiState.update { state ->
      state.copy(cloudBuild = CloudBuildUiState())
    }
    viewModelScope.launch(Dispatchers.IO) {
      GitHubOAuthManager.disconnect(appCtx)
    }
  }

  fun startCloudBuild() = startGitHubCloudBuild()

  fun startGitHubCloudBuild() {
    val sourceProject = _uiState.value.inspector.targetFile
    val metadata = sourceProject?.sourceMetadata
    if (sourceProject == null ||
      sourceProject.inputKind != InputKind.SOURCE_ARCHIVE ||
      metadata == null ||
      metadata.framework == ProjectFramework.UNKNOWN
    ) {
      _uiState.update { state ->
        state.copy(
          cloudBuild = state.cloudBuild.copy(
            translatedError = TranslatedError(
              title = "Unrecognized Project",
              message = "Select a valid Android, Flutter, React Native, Capacitor, or Godot source .zip before building.",
            )
          )
        )
      }
      return
    }
    if (_uiState.value.cloudBuild.isActive) return

    val appCtx = getApplication<Application>()
    val savedSession = GitHubOAuthManager.getSavedSession(appCtx)
    if (savedSession == null) {
      _uiState.update { state ->
        state.copy(
          cloudBuild = state.cloudBuild.copy(
            isActive = false,
            isConnected = false,
            connectedUsername = null,
            currentStage = null,
            statusText = "",
            translatedError = TranslatedError(
              title = "GitHub Not Connected",
              message = "Connect GitHub before starting a cloud build.",
            ),
          )
        )
      }
      return
    }

    val targetFormat = _uiState.value.inspector.selectedOutputFormat
    val startedAtMs = System.currentTimeMillis()
    val keystoreRef = _uiState.value.keystoreStudio.importedFileName

    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isActive = true,
          currentStage = CloudBuildStage.PREPARING_ARCHIVE,
          statusText = CloudBuildStage.PREPARING_ARCHIVE.label,
          elapsedSeconds = 0,
          buildState = CloudBuildState.Idle,
          clearedCloudRepoName = null,
          needsRepoAccessGrant = false,
          repoAccessMessage = null,
          translatedError = null,
        )
      )
    }

    startElapsedTimerFrom(startedAtMs)
    ShipSignBuildService.startCloudBuild(
      context = appCtx,
      sourceProject = sourceProject,
      targetFormat = targetFormat,
      keystoreUri = keystoreRef,
    )
  }

  private fun handleCloudBuildState(
    buildState: CloudBuildState,
    previousSourceFile: File?,
  ) {
    when (buildState) {
      is CloudBuildState.StageProgress -> {
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = true,
              currentStage = buildState.stage,
              statusText = buildState.statusText,
              buildState = buildState,
              clearedCloudRepoName = null,
            )
          )
        }
      }
      is CloudBuildState.RepositoryAccessRequired -> {
        elapsedTimerJob?.cancel()
        ShipSignBuildService.resetBuildState()
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = false,
              buildState = buildState,
              needsRepoAccessGrant = true,
              repoAccessMessage = buildState.message,
              translatedError = null,
            )
          )
        }
      }
      is CloudBuildState.ReadyForOfflineSigning -> {
        elapsedTimerJob?.cancel()
        ShipSignBuildService.resetBuildState()
        val appCtx = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
          val retainedFiles = buildState.availableTargets.map { it.sessionFile }.toSet()
          if (previousSourceFile != null && previousSourceFile !in retainedFiles) {
            ZeroTraceManager.secureDeleteFile(previousSourceFile)
          }
          val enrichedTargets = buildState.availableTargets.map { target ->
            val info = PackageInfoInspector.inspectPackage(
              context = appCtx,
              file = target.sessionFile,
              format = target.binaryType,
              fallbackName = target.originalName.substringBeforeLast('.'),
            )
            target.copy(packageInfo = info, isAlreadySigned = info.isSigned)
          }
          val enrichedPrimary = enrichedTargets.firstOrNull() ?: buildState.targetFile
          _uiState.update { state ->
            state.copy(
              inspector = state.inspector.copy(
                targetFile = enrichedPrimary,
                availableBuildTargets = enrichedTargets,
                signatureJustStripped = false,
                errorMessage = null,
              ),
              cloudBuild = state.cloudBuild.copy(
                isActive = false,
                currentStage = null,
                statusText = "",
                buildState = buildState.copy(
                  targetFile = enrichedPrimary,
                  availableTargets = enrichedTargets,
                ),
                translatedError = null,
              ),
            )
          }
        }
      }
      is CloudBuildState.Failed -> {
        elapsedTimerJob?.cancel()
        ShipSignBuildService.resetBuildState()
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = false,
              needsRepoAccessGrant = false,
              buildState = buildState,
              translatedError = ErrorTranslator.translate(buildState.error),
            )
          )
        }
      }
      CloudBuildState.Idle -> Unit
    }
  }

  fun cancelCloudBuild() {
    val appCtx = getApplication<Application>()
    ShipSignBuildService.cancelBuild(appCtx)
    elapsedTimerJob?.cancel()
    viewModelScope.launch(Dispatchers.IO) {
      val current = BuildSessionStore.loadSession(appCtx)
      if (current != null && current.repoFullName.contains('/')) {
        BuildSessionStore.updateSession(appCtx) {
          it.copy(
            status = BuildSessionStatus.FAILED_AWAITING_CLEANUP,
            statusMessage = "Build cancelled",
            errorMessage = "Build cancelled by user. Clear temporary repository when ready.",
          )
        }
      } else {
        BuildSessionStore.clearSession(appCtx)
      }
    }
    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isActive = false,
          currentStage = null,
          statusText = "",
          elapsedSeconds = 0,
          buildState = CloudBuildState.Idle,
          needsRepoAccessGrant = false,
          translatedError = null,
        )
      )
    }
  }

  /**
   * User-confirmed Zero-Trace Cloud Cleanup: executes `DELETE /repos/{owner}/{repo}` on
   * [Dispatchers.IO], confirms deletion with a "Cloud Trace Cleared" badge, and clears the
   * persisted build session.
   */
  fun clearCloudTraceNow() {
    if (_uiState.value.cloudBuild.isClearingCloudTrace) return
    val appCtx = getApplication<Application>()
    val repoFullName = _uiState.value.cloudBuild.persistedSession?.repoFullName
      ?: BuildSessionStore.loadSession(appCtx)?.repoFullName
      ?: return

    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isClearingCloudTrace = true,
          translatedError = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val authSession = GitHubOAuthManager.getSavedSession(appCtx)
      if (authSession == null) {
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isClearingCloudTrace = false,
              translatedError = TranslatedError(
                title = "GitHub Not Connected",
                message = "Reconnect GitHub to delete $repoFullName.",
              ),
            )
          )
        }
        return@launch
      }

      val tokenChars = authSession.accessToken.toCharArray()
      try {
        val result = GitHubBuildModule.deleteEphemeralRepository(
          token = tokenChars,
          repoFullName = repoFullName,
          wipeTokenOnCompletion = true,
        )
        result.onSuccess {
          BuildSessionStore.clearSession(appCtx)
          ProjectHistoryRepository.markCloudTraceCleared(appCtx, repoFullName)
          _uiState.update { state ->
            state.copy(
              cloudBuild = state.cloudBuild.copy(
                isClearingCloudTrace = false,
                persistedSession = null,
                clearedCloudRepoName = repoFullName,
                translatedError = null,
              ),
              pipeline = state.pipeline.copy(
                completedProject = state.pipeline.completedProject?.let { proj ->
                  if (proj.cloudRepoFullName == repoFullName) {
                    proj.copy(cloudRepoFullName = null, cloudTraceCleared = true)
                  } else {
                    proj
                  }
                }
              ),
            )
          }
        }.onFailure { err ->
          _uiState.update { state ->
            state.copy(
              cloudBuild = state.cloudBuild.copy(
                isClearingCloudTrace = false,
                translatedError = ErrorTranslator.translate(err),
              )
            )
          }
        }
      } finally {
        ZeroTraceManager.wipeCharArray(tokenChars)
      }
    }
  }

  /**
   * Dismisses the prominent cleanup prompt while keeping a compact "Clear Cloud Trace" action
   * accessible so the user can inspect logs on GitHub first and wipe the repo whenever ready.
   */
  fun keepRepoForInspection() {
    val appCtx = getApplication<Application>()
    viewModelScope.launch(Dispatchers.IO) {
      BuildSessionStore.markKeepForInspection(appCtx)
    }
  }

  // --- Step 2A: Import Existing Keystore & 1-Tap Ephemeral Debug Key ---

  fun importKeystoreUri(uri: Uri) {
    if (_uiState.value.keystoreStudio.isBusy) return
    wipeActiveSigningCredentials()
    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          isBusy = true,
          verifiedSummary = null,
          hasUnlockedCredentials = false,
          errorMessage = null,
        ),
        signingStudio = it.signingStudio.copy(translatedError = null),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      _uiState.value.keystoreStudio.tempKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }

      runCatching {
        val sessionDir = ZeroTraceManager.createOrGetSessionDir(appCtx)
        val copied = SafFileBridge.copyUriToSession(appCtx, uri, sessionDir)
        val detected = KeystoreDetector.detectFormat(copied.file)
        copied to detected
      }.onSuccess { (copied, detected) ->
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              tempKeystoreFile = copied.file,
              importedFileName = copied.displayName,
              detectedFormat = detected,
              isBusy = false,
            )
          )
        }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              tempKeystoreFile = null,
              importedFileName = null,
              detectedFormat = KeystoreFormat.UNKNOWN,
              isBusy = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun verifyImportedKeystore(
    storePassword: CharArray,
    keyAlias: String,
    keyPassword: CharArray,
    onVerifiedSuccess: () -> Unit = {},
  ) {
    val studio = _uiState.value.keystoreStudio
    val tempFile = studio.tempKeystoreFile
    if (tempFile == null || studio.isBusy) {
      ZeroTraceManager.wipeCharArray(storePassword)
      ZeroTraceManager.wipeCharArray(keyPassword)
      return
    }

    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          isBusy = true,
          verifiedSummary = null,
          hasUnlockedCredentials = false,
          errorMessage = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val storeCopyForSession = storePassword.copyOf()
      val rawKeyCopy = if (keyPassword.isEmpty()) storePassword.copyOf() else keyPassword.copyOf()
      val trimmedAlias = keyAlias.trim()

      val config = ImportedKeystoreConfig(
        tempKeystoreFile = tempFile,
        detectedFormat = studio.detectedFormat,
        storePassword = storePassword,
        keyAlias = trimmedAlias,
        keyPassword = if (keyPassword.isEmpty()) storePassword.copyOf() else keyPassword,
      )

      try {
        val validated = KeystoreDetector.validateKeystoreCredentials(config)
        val leafCert = validated.certificateChain.first()
        val sha256 = MessageDigest.getInstance("SHA-256").digest(leafCert.encoded)
        val fingerprint = sha256.joinToString(":") { b -> String.format(Locale.US, "%02X", b) }
        ZeroTraceManager.wipeByteArray(sha256)

        wipeActiveSigningCredentials()
        activeStorePassChars = storeCopyForSession
        activeKeyPassChars = rawKeyCopy
        activeKeyAlias = validated.alias

        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              hasUnlockedCredentials = true,
              verifiedSummary = VerifiedKeystoreSummary(
                format = validated.format,
                alias = validated.alias,
                subjectDn = leafCert.subjectX500Principal.name,
                sha256Fingerprint = fingerprint,
              ),
            )
          )
        }
        viewModelScope.launch(Dispatchers.Main) {
          onVerifiedSuccess()
        }
      } catch (e: Exception) {
        ZeroTraceManager.wipeCharArray(storeCopyForSession)
        ZeroTraceManager.wipeCharArray(rawKeyCopy)
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              verifiedSummary = null,
              hasUnlockedCredentials = false,
              errorMessage = ErrorTranslator.translate(e).message,
            )
          )
        }
      } finally {
        ZeroTraceManager.wipeCharArray(storePassword)
        ZeroTraceManager.wipeCharArray(keyPassword)
        ZeroTraceManager.wipeCharArray(config.keyPassword)
      }
    }
  }

  /**
   * Generates a 1-tap offline ephemeral Android Debug Keystore (`androiddebugkey` / `android`)
   * inside the Zero-Trace sandbox for fast local test-signing without leaving any key on disk.
   */
  fun activateEphemeralDebugKeystore(onReady: () -> Unit = {}) {
    if (_uiState.value.keystoreStudio.isBusy) return
    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          isBusy = true,
          errorMessage = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val sessionDir = ZeroTraceManager.createOrGetSessionDir(appCtx)
      _uiState.value.keystoreStudio.tempKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }

      val storePass = "android".toCharArray()
      val keyPass = "android".toCharArray()
      var debugFile: File? = null
      try {
        debugFile = KeystoreGenerator.generateKeystore(
          request = KeystoreCreateRequest(
            format = KeystoreFormat.PKCS12,
            fileName = "ephemeral_debug",
            storePassword = storePass.copyOf(),
            keyAlias = "androiddebugkey",
            keyPassword = keyPass.copyOf(),
            validityDays = 365,
            commonName = "Android Debug",
            organizationalUnit = "ShipSign Ephemeral",
            organization = "Android",
            cityLocality = "",
            stateProvince = "",
            countryCode = "US",
          ),
          sessionDir = sessionDir,
        )

        val validated = KeystoreDetector.validateKeystoreCredentials(
          ImportedKeystoreConfig(
            tempKeystoreFile = debugFile,
            detectedFormat = KeystoreFormat.PKCS12,
            storePassword = storePass.copyOf(),
            keyAlias = "androiddebugkey",
            keyPassword = keyPass.copyOf(),
          )
        )
        val leafCert = validated.certificateChain.first()
        val sha256 = MessageDigest.getInstance("SHA-256").digest(leafCert.encoded)
        val fingerprint = sha256.joinToString(":") { b -> String.format(Locale.US, "%02X", b) }
        ZeroTraceManager.wipeByteArray(sha256)

        wipeActiveSigningCredentials()
        activeStorePassChars = storePass.copyOf()
        activeKeyPassChars = keyPass.copyOf()
        activeKeyAlias = validated.alias

        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              tempKeystoreFile = debugFile,
              importedFileName = debugFile.name,
              detectedFormat = KeystoreFormat.PKCS12,
              isBusy = false,
              hasUnlockedCredentials = true,
              verifiedSummary = VerifiedKeystoreSummary(
                format = KeystoreFormat.PKCS12,
                alias = validated.alias,
                subjectDn = leafCert.subjectX500Principal.name,
                sha256Fingerprint = fingerprint,
              ),
            )
          )
        }
        viewModelScope.launch(Dispatchers.Main) {
          onReady()
        }
      } catch (e: Exception) {
        debugFile?.let { ZeroTraceManager.secureDeleteFile(it) }
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(e).message,
            )
          )
        }
      } finally {
        ZeroTraceManager.wipeCharArray(storePass)
        ZeroTraceManager.wipeCharArray(keyPass)
      }
    }
  }

  // --- Step 2B: Create New Keystore ---

  fun generateKeystoreInSession(
    request: KeystoreCreateRequest,
    onGenerated: () -> Unit = {},
  ) {
    if (_uiState.value.keystoreStudio.isBusy) {
      ZeroTraceManager.wipeCharArray(request.storePassword)
      ZeroTraceManager.wipeCharArray(request.keyPassword)
      return
    }

    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          isBusy = true,
          generatedFileName = null,
          generatedFormat = null,
          generatedDownloaded = false,
          errorMessage = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val sessionDir = ZeroTraceManager.createOrGetSessionDir(appCtx)
      _uiState.value.keystoreStudio.generatedKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      wipeGeneratedCredentials()

      val storePassForSession = request.storePassword.copyOf()
      val keyPassForSession = if (request.keyPassword.isEmpty()) {
        request.storePassword.copyOf()
      } else {
        request.keyPassword.copyOf()
      }
      val aliasForSession = request.keyAlias.trim().lowercase(Locale.ROOT)
      var generatedFile: File? = null

      try {
        generatedFile = KeystoreGenerator.generateKeystore(request, sessionDir)
        generatedStorePassChars = storePassForSession
        generatedKeyPassChars = keyPassForSession
        generatedKeyAlias = aliasForSession

        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              generatedKeystoreFile = generatedFile,
              generatedFileName = generatedFile.name,
              generatedFormat = request.format,
              generatedDownloaded = false,
            )
          )
        }
        viewModelScope.launch(Dispatchers.Main) {
          onGenerated()
        }
      } catch (e: Exception) {
        generatedFile?.let { ZeroTraceManager.secureDeleteFile(it) }
        ZeroTraceManager.wipeCharArray(storePassForSession)
        ZeroTraceManager.wipeCharArray(keyPassForSession)
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(e).message,
            )
          )
        }
      } finally {
        ZeroTraceManager.wipeCharArray(request.storePassword)
        ZeroTraceManager.wipeCharArray(request.keyPassword)
      }
    }
  }

  fun downloadGeneratedKeystoreToDownloads() {
    val studio = _uiState.value.keystoreStudio
    val generatedFile = studio.generatedKeystoreFile ?: return
    val format = studio.generatedFormat ?: return
    if (studio.isBusy) return

    _uiState.update {
      it.copy(keystoreStudio = it.keystoreStudio.copy(isBusy = true, errorMessage = null))
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val mimeType = if (format == KeystoreFormat.PKCS12) {
        "application/x-pkcs12"
      } else {
        "application/octet-stream"
      }
      runCatching {
        SafFileBridge.exportFileToDownloads(
          context = appCtx,
          sourceFile = generatedFile,
          outputFileName = generatedFile.name,
          mimeType = mimeType,
        )
      }.onSuccess {
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              generatedDownloaded = true,
            )
          )
        }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun promoteGeneratedKeystoreForSigning(onReady: () -> Unit) {
    val studio = _uiState.value.keystoreStudio
    val file = studio.generatedKeystoreFile ?: return
    val format = studio.generatedFormat ?: return
    val storeChars = generatedStorePassChars ?: return
    val keyChars = generatedKeyPassChars ?: storeChars.copyOf()
    val alias = generatedKeyAlias ?: "upload"

    val appCtx = getApplication<Application>()
    viewModelScope.launch(Dispatchers.IO) {
      val signingCopy = ZeroTraceManager.allocateTempFile(
        appCtx,
        "signing_ks",
        if (format == KeystoreFormat.PKCS12) ".p12" else ".jks",
      )
      file.copyTo(signingCopy, overwrite = true)

      val validated = KeystoreDetector.validateKeystoreCredentials(
        ImportedKeystoreConfig(
          tempKeystoreFile = signingCopy,
          detectedFormat = format,
          storePassword = storeChars.copyOf(),
          keyAlias = alias,
          keyPassword = keyChars.copyOf(),
        )
      )
      val leafCert = validated.certificateChain.first()
      val sha256 = MessageDigest.getInstance("SHA-256").digest(leafCert.encoded)
      val fingerprint = sha256.joinToString(":") { b -> String.format(Locale.US, "%02X", b) }
      ZeroTraceManager.wipeByteArray(sha256)

      wipeActiveSigningCredentials()
      activeStorePassChars = storeChars.copyOf()
      activeKeyPassChars = keyChars.copyOf()
      activeKeyAlias = validated.alias

      ZeroTraceManager.secureDeleteFile(file)
      wipeGeneratedCredentials()

      _uiState.update {
        it.copy(
          keystoreStudio = it.keystoreStudio.copy(
            tempKeystoreFile = signingCopy,
            importedFileName = studio.generatedFileName ?: signingCopy.name,
            detectedFormat = format,
            hasUnlockedCredentials = true,
            verifiedSummary = VerifiedKeystoreSummary(
              format = format,
              alias = validated.alias,
              subjectDn = leafCert.subjectX500Principal.name,
              sha256Fingerprint = fingerprint,
            ),
            generatedKeystoreFile = null,
            generatedFileName = null,
            generatedFormat = null,
            generatedDownloaded = false,
          )
        )
      }
      viewModelScope.launch(Dispatchers.Main) {
        onReady()
      }
    }
  }

  fun discardGeneratedKeystoreCache() {
    val fileToShred = _uiState.value.keystoreStudio.generatedKeystoreFile
    wipeGeneratedCredentials()
    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          generatedKeystoreFile = null,
          generatedFileName = null,
          generatedFormat = null,
          generatedDownloaded = false,
        )
      )
    }
    if (fileToShred != null) {
      viewModelScope.launch(Dispatchers.IO) {
        ZeroTraceManager.secureDeleteFile(fileToShred)
      }
    }
  }

  fun clearKeystoreSandbox() {
    wipeActiveSigningCredentials()
    wipeGeneratedCredentials()
    viewModelScope.launch(Dispatchers.IO) {
      _uiState.value.keystoreStudio.tempKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      _uiState.value.keystoreStudio.generatedKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      _uiState.update {
        it.copy(keystoreStudio = KeystoreStudioUiState())
      }
    }
  }

  // --- Step 3: Signing & Result ---

  fun updateSigningOptions(transform: (SigningOptions) -> SigningOptions) {
    _uiState.update {
      it.copy(
        signingStudio = it.signingStudio.copy(
          options = transform(it.signingStudio.options)
        )
      )
    }
  }

  fun startSigningWithActiveCredentials() {
    val storeChars = activeStorePassChars?.copyOf() ?: return
    val keyChars = activeKeyPassChars?.copyOf() ?: storeChars.copyOf()
    val alias = activeKeyAlias ?: return
    startSigning(
      storePassword = storeChars,
      keyAlias = alias,
      keyPassword = keyChars,
    )
  }

  fun startSigning(
    storePassword: CharArray,
    keyAlias: String,
    keyPassword: CharArray,
  ) {
    val target = _uiState.value.inspector.targetFile
    val ksFile = _uiState.value.keystoreStudio.tempKeystoreFile
    if (target == null || ksFile == null || _uiState.value.signingStudio.isSigning) {
      ZeroTraceManager.wipeCharArray(storePassword)
      ZeroTraceManager.wipeCharArray(keyPassword)
      return
    }

    val effectiveKeyPass = if (keyPassword.isEmpty()) storePassword.copyOf() else keyPassword
    val ksConfig = ImportedKeystoreConfig(
      tempKeystoreFile = ksFile,
      detectedFormat = _uiState.value.keystoreStudio.detectedFormat,
      storePassword = storePassword,
      keyAlias = keyAlias.trim(),
      keyPassword = effectiveKeyPass,
    )

    _uiState.update {
      it.copy(
        signingStudio = it.signingStudio.copy(
          isSigning = true,
          logs = emptyList(),
          result = null,
          translatedError = null,
        )
      )
    }

    val appCtx = getApplication<Application>()
    ShipSignBuildService.startLocalSigning(
      context = appCtx,
      target = target,
      keystoreConfig = ksConfig,
      options = _uiState.value.signingStudio.options,
    )
  }

  private fun handleServiceSigningEvent(event: ServiceSigningEvent) {
    val appCtx = getApplication<Application>()
    when (event) {
      ServiceSigningEvent.Idle -> Unit
      is ServiceSigningEvent.Running -> {
        _uiState.update { state ->
          state.copy(
            signingStudio = state.signingStudio.copy(
              isSigning = true,
              logs = event.logs.takeLast(40),
            )
          )
        }
      }
      is ServiceSigningEvent.Completed -> {
        ShipSignBuildService.resetSigningEvent()
        val signedTargetMeta = _uiState.value.inspector.targetFile
        val activeCloudRepo = _uiState.value.cloudBuild.persistedSession?.repoFullName
          ?.takeIf { it.contains('/') }
        wipeActiveSigningCredentials()
        wipeGeneratedCredentials()
        viewModelScope.launch(Dispatchers.IO) {
          val format = signedTargetMeta?.binaryType?.takeIf {
            it == ResolvedBinaryType.APK || it == ResolvedBinaryType.AAB
          } ?: if (event.result.primaryFileName.endsWith(".aab", ignoreCase = true)) {
            ResolvedBinaryType.AAB
          } else {
            ResolvedBinaryType.APK
          }
          val savedEntry = runCatching {
            ProjectHistoryRepository.saveArtifactFromUri(
              context = appCtx,
              sourceUri = event.result.primarySignedUri,
              outputFileName = event.result.primaryFileName,
              packageInfo = signedTargetMeta?.packageInfo,
              format = format,
              isSigned = true,
              sha256Fingerprint = event.result.sha256Fingerprint,
              sha1Fingerprint = event.result.sha1Fingerprint,
              cloudRepoFullName = activeCloudRepo,
            )
          }.getOrNull()
          ZeroTraceManager.nukeCurrentSession(appCtx)
          _uiState.update { state ->
            state.copy(
              inspector = InspectorUiState(
                selectedCategory = state.inspector.selectedCategory,
                selectedOutputFormat = state.inspector.selectedOutputFormat,
              ),
              keystoreStudio = KeystoreStudioUiState(),
              signingStudio = state.signingStudio.copy(
                isSigning = false,
                result = event.result,
                logs = event.result.logs.takeLast(40),
              ),
              pipeline = state.pipeline.copy(
                isFinalizing = false,
                errorMessage = null,
                completedProject = savedEntry,
                completedExportUri = event.result.primarySignedUri,
                pendingNavigateToComplete = true,
              ),
            )
          }
        }
      }
      is ServiceSigningEvent.Failed -> {
        ShipSignBuildService.resetSigningEvent()
        wipeActiveSigningCredentials()
        _uiState.update { state ->
          state.copy(
            signingStudio = state.signingStudio.copy(
              isSigning = false,
              translatedError = ErrorTranslator.translate(event.error),
            ),
            pipeline = state.pipeline.copy(
              isFinalizing = false,
              errorMessage = ErrorTranslator.translate(event.error).message,
            ),
          )
        }
      }
    }
  }

  // --- Unified 03/03 Finish Pipeline: Customize? -> Convert? -> Sign? ---

  sealed class FinishSignAction {
    data object SkipSigning : FinishSignAction()
    data class UseVaultKeystore(val entryId: String) : FinishSignAction()
    data class ImportAndSign(
      val storePassword: CharArray,
      val keyAlias: String,
      val keyPassword: CharArray,
      val saveToVault: Boolean,
    ) : FinishSignAction()
    data class CreateAndSign(val request: KeystoreCreateRequest) : FinishSignAction()
  }

  fun consumePendingNavigateToComplete() {
    _uiState.update { it.copy(pipeline = it.pipeline.copy(pendingNavigateToComplete = false)) }
  }

  fun executeFinishPipeline(
    customization: PackageCustomizationRequest?,
    shouldConvert: Boolean,
    signAction: FinishSignAction,
    onUnsignedComplete: () -> Unit,
  ) {
    val initialTarget = _uiState.value.inspector.targetFile
    if (initialTarget == null || _uiState.value.signingStudio.isSigning || _uiState.value.pipeline.isFinalizing) {
      wipeSignActionSecrets(signAction)
      return
    }

    _uiState.update {
      it.copy(
        pipeline = it.pipeline.copy(
          isCustomizing = customization?.hasAnyChange == true,
          isConverting = shouldConvert,
          isFinalizing = true,
          errorMessage = null,
        ),
        signingStudio = it.signingStudio.copy(
          isSigning = signAction !is FinishSignAction.SkipSigning,
          logs = listOf("Preparing offline package pipeline..."),
          result = null,
          translatedError = null,
        ),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val logs = mutableListOf("Preparing offline package pipeline...")
      fun appendLog(msg: String) {
        logs.add(msg)
        _uiState.update { s ->
          s.copy(signingStudio = s.signingStudio.copy(logs = logs.toList()))
        }
      }

      try {
        var working = initialTarget

        if (customization != null && customization.hasAnyChange) {
          appendLog("Patching manifest & launcher assets offline...")
          val customized = PackageCustomizerEngine.customizePackage(appCtx, working, customization)
          if (customized.sessionFile != working.sessionFile) {
            ZeroTraceManager.secureDeleteFile(working.sessionFile)
          }
          working = customized
          _uiState.update { s ->
            s.copy(
              inspector = s.inspector.copy(targetFile = working, availableBuildTargets = listOf(working)),
              pipeline = s.pipeline.copy(isCustomizing = false),
            )
          }
          appendLog("Customization complete (${working.packageInfo?.packageId ?: working.originalName}).")
        }

        if (shouldConvert) {
          val direction = if (working.binaryType == ResolvedBinaryType.AAB) "AAB -> APK" else "APK -> AAB"
          appendLog("Converting $direction offline...")
          val converted = FormatConverterEngine.convertPackage(appCtx, working)
          if (converted.sessionFile != working.sessionFile) {
            ZeroTraceManager.secureDeleteFile(working.sessionFile)
          }
          working = converted
          _uiState.update { s ->
            s.copy(
              inspector = s.inspector.copy(targetFile = working, availableBuildTargets = listOf(working)),
              pipeline = s.pipeline.copy(isConverting = false),
            )
          }
          appendLog("Converted to ${working.originalName}.")
        }

        when (signAction) {
          is FinishSignAction.SkipSigning -> {
            appendLog("Saving package offline without signing...")
            val activeCloudRepo = _uiState.value.cloudBuild.persistedSession?.repoFullName
              ?.takeIf { it.contains('/') }
            val info = working.packageInfo ?: PackageInfoInspector.inspectPackage(
              context = appCtx,
              file = working.sessionFile,
              format = working.binaryType,
              fallbackName = working.originalName.substringBeforeLast('.'),
            )
            val saved = ProjectHistoryRepository.saveArtifact(
              context = appCtx,
              sourceFile = working.sessionFile,
              outputFileName = working.originalName,
              packageInfo = info,
              format = working.binaryType,
              isSigned = info.isSigned,
              sha256Fingerprint = info.sha256Fingerprint,
              sha1Fingerprint = info.sha1Fingerprint,
              cloudRepoFullName = activeCloudRepo,
            )
            val exportUri = runCatching {
              ProjectHistoryRepository.exportProjectToDownloads(appCtx, saved)
            }.getOrNull()
            ZeroTraceManager.nukeCurrentSession(appCtx)
            _uiState.update { s ->
              s.copy(
                inspector = InspectorUiState(
                  selectedCategory = s.inspector.selectedCategory,
                  selectedOutputFormat = s.inspector.selectedOutputFormat,
                ),
                pipeline = s.pipeline.copy(
                  isCustomizing = false,
                  isConverting = false,
                  isFinalizing = false,
                  errorMessage = null,
                  completedProject = saved,
                  completedExportUri = exportUri,
                  pendingNavigateToComplete = false,
                ),
                signingStudio = s.signingStudio.copy(isSigning = false),
              )
            }
            viewModelScope.launch(Dispatchers.Main) { onUnsignedComplete() }
          }

          is FinishSignAction.UseVaultKeystore -> {
            appendLog("Unlocking saved keystore from offline Vault...")
            val ksConfig = KeystoreVaultManager.unlockVaultKeystore(appCtx, signAction.entryId)
            ShipSignBuildService.startLocalSigning(
              context = appCtx,
              target = working,
              keystoreConfig = ksConfig,
              options = _uiState.value.signingStudio.options,
            )
          }

          is FinishSignAction.ImportAndSign -> {
            val ksFile = _uiState.value.keystoreStudio.tempKeystoreFile
              ?: throw IllegalStateException("Select a keystore file before signing")
            val ksName = _uiState.value.keystoreStudio.importedFileName ?: "imported.p12"
            val effectiveKeyPass = if (signAction.keyPassword.isEmpty()) {
              signAction.storePassword.copyOf()
            } else {
              signAction.keyPassword
            }
            val storeCopy = signAction.storePassword.copyOf()
            val keyCopy = effectiveKeyPass.copyOf()
            try {
              appendLog("Validating uploaded keystore credentials...")
              val ksConfig = if (signAction.saveToVault) {
                val savedEntry = KeystoreVaultManager.importVaultKeystore(
                  context = appCtx,
                  sourceFile = ksFile,
                  originalFileName = ksName,
                  storePassword = storeCopy.copyOf(),
                  keyAlias = signAction.keyAlias,
                  keyPassword = keyCopy.copyOf(),
                )
                KeystoreVaultManager.unlockVaultKeystore(appCtx, savedEntry.id)
              } else {
                val detected = KeystoreDetector.detectFormat(ksFile)
                val validated = KeystoreDetector.validateKeystoreCredentials(
                  ImportedKeystoreConfig(
                    tempKeystoreFile = ksFile,
                    detectedFormat = detected,
                    storePassword = storeCopy.copyOf(),
                    keyAlias = signAction.keyAlias.trim(),
                    keyPassword = keyCopy.copyOf(),
                  )
                )
                ImportedKeystoreConfig(
                  tempKeystoreFile = ksFile,
                  detectedFormat = validated.format,
                  storePassword = storeCopy.copyOf(),
                  keyAlias = validated.alias,
                  keyPassword = keyCopy.copyOf(),
                )
              }
              ShipSignBuildService.startLocalSigning(
                context = appCtx,
                target = working,
                keystoreConfig = ksConfig,
                options = _uiState.value.signingStudio.options,
              )
            } finally {
              ZeroTraceManager.wipeCharArray(signAction.storePassword)
              ZeroTraceManager.wipeCharArray(signAction.keyPassword)
              ZeroTraceManager.wipeCharArray(effectiveKeyPass)
              ZeroTraceManager.wipeCharArray(storeCopy)
              ZeroTraceManager.wipeCharArray(keyCopy)
            }
          }

          is FinishSignAction.CreateAndSign -> {
            appendLog("Generating RSA-2048 keystore offline...")
            val entry = KeystoreVaultManager.createNewVaultKeystore(appCtx, signAction.request)
            val ksConfig = KeystoreVaultManager.unlockVaultKeystore(appCtx, entry.id)
            ShipSignBuildService.startLocalSigning(
              context = appCtx,
              target = working,
              keystoreConfig = ksConfig,
              options = _uiState.value.signingStudio.options,
            )
          }
        }
      } catch (err: Exception) {
        wipeSignActionSecrets(signAction)
        val translated = ErrorTranslator.translate(err)
        _uiState.update { s ->
          s.copy(
            pipeline = s.pipeline.copy(
              isCustomizing = false,
              isConverting = false,
              isFinalizing = false,
              errorMessage = translated.message,
            ),
            signingStudio = s.signingStudio.copy(
              isSigning = false,
              translatedError = translated,
            ),
          )
        }
      }
    }
  }

  private fun wipeSignActionSecrets(action: FinishSignAction) {
    when (action) {
      is FinishSignAction.ImportAndSign -> {
        ZeroTraceManager.wipeCharArray(action.storePassword)
        ZeroTraceManager.wipeCharArray(action.keyPassword)
      }
      is FinishSignAction.CreateAndSign -> {
        ZeroTraceManager.wipeCharArray(action.request.storePassword)
        ZeroTraceManager.wipeCharArray(action.request.keyPassword)
      }
      else -> Unit
    }
  }

  fun applyPackageCustomization(
    request: PackageCustomizationRequest,
    onDone: () -> Unit,
  ) {
    val currentTarget = _uiState.value.inspector.targetFile ?: return
    if (_uiState.value.pipeline.isCustomizing) return

    _uiState.update {
      it.copy(pipeline = it.pipeline.copy(isCustomizing = true, errorMessage = null))
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        PackageCustomizerEngine.customizePackage(appCtx, currentTarget, request)
      }.onSuccess { customized ->
        if (customized.sessionFile != currentTarget.sessionFile) {
          ZeroTraceManager.secureDeleteFile(currentTarget.sessionFile)
        }
        _uiState.update { state ->
          state.copy(
            inspector = state.inspector.copy(
              targetFile = customized,
              availableBuildTargets = listOf(customized),
              signatureJustStripped = false,
            ),
            pipeline = state.pipeline.copy(isCustomizing = false, errorMessage = null),
          )
        }
        viewModelScope.launch(Dispatchers.Main) { onDone() }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            pipeline = it.pipeline.copy(
              isCustomizing = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun convertCurrentPackage(onDone: () -> Unit) {
    val currentTarget = _uiState.value.inspector.targetFile ?: return
    if (_uiState.value.pipeline.isConverting) return

    _uiState.update {
      it.copy(pipeline = it.pipeline.copy(isConverting = true, errorMessage = null))
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        FormatConverterEngine.convertPackage(appCtx, currentTarget)
      }.onSuccess { converted ->
        if (converted.sessionFile != currentTarget.sessionFile) {
          ZeroTraceManager.secureDeleteFile(currentTarget.sessionFile)
        }
        _uiState.update { state ->
          state.copy(
            inspector = state.inspector.copy(
              targetFile = converted,
              availableBuildTargets = listOf(converted),
              signatureJustStripped = false,
            ),
            pipeline = state.pipeline.copy(isConverting = false, errorMessage = null),
          )
        }
        viewModelScope.launch(Dispatchers.Main) { onDone() }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            pipeline = it.pipeline.copy(
              isConverting = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun finishWithoutSigning(onDone: () -> Unit) {
    val target = _uiState.value.inspector.targetFile ?: return
    if (_uiState.value.pipeline.isFinalizing) return

    _uiState.update {
      it.copy(pipeline = it.pipeline.copy(isFinalizing = true, errorMessage = null))
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val activeCloudRepo = _uiState.value.cloudBuild.persistedSession?.repoFullName
        ?.takeIf { it.contains('/') }
      runCatching {
        val info = target.packageInfo ?: PackageInfoInspector.inspectPackage(
          context = appCtx,
          file = target.sessionFile,
          format = target.binaryType,
          fallbackName = target.originalName.substringBeforeLast('.'),
        )
        val saved = ProjectHistoryRepository.saveArtifact(
          context = appCtx,
          sourceFile = target.sessionFile,
          outputFileName = target.originalName,
          packageInfo = info,
          format = target.binaryType,
          isSigned = info.isSigned,
          sha256Fingerprint = info.sha256Fingerprint,
          sha1Fingerprint = info.sha1Fingerprint,
          cloudRepoFullName = activeCloudRepo,
        )
        ZeroTraceManager.nukeCurrentSession(appCtx)
        saved
      }.onSuccess { saved ->
        _uiState.update { state ->
          state.copy(
            inspector = InspectorUiState(
              selectedCategory = state.inspector.selectedCategory,
              selectedOutputFormat = state.inspector.selectedOutputFormat,
            ),
            pipeline = state.pipeline.copy(
              isFinalizing = false,
              errorMessage = null,
              completedProject = saved,
              completedExportUri = null,
              pendingNavigateToComplete = false,
            ),
          )
        }
        viewModelScope.launch(Dispatchers.Main) { onDone() }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            pipeline = it.pipeline.copy(
              isFinalizing = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun signWithVaultKeystore(entryId: String) {
    val target = _uiState.value.inspector.targetFile ?: return
    if (_uiState.value.signingStudio.isSigning) return

    _uiState.update {
      it.copy(
        signingStudio = it.signingStudio.copy(
          isSigning = true,
          logs = listOf("Unlocking saved keystore from Vault..."),
          result = null,
          translatedError = null,
        ),
        pipeline = it.pipeline.copy(errorMessage = null),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        KeystoreVaultManager.unlockVaultKeystore(appCtx, entryId)
      }.onSuccess { ksConfig ->
        ShipSignBuildService.startLocalSigning(
          context = appCtx,
          target = target,
          keystoreConfig = ksConfig,
          options = _uiState.value.signingStudio.options,
        )
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            signingStudio = it.signingStudio.copy(
              isSigning = false,
              translatedError = ErrorTranslator.translate(err),
            ),
            pipeline = it.pipeline.copy(errorMessage = ErrorTranslator.translate(err).message),
          )
        }
      }
    }
  }

  fun createVaultKeystoreAndSign(request: KeystoreCreateRequest) {
    val target = _uiState.value.inspector.targetFile ?: return
    if (_uiState.value.signingStudio.isSigning) {
      ZeroTraceManager.wipeCharArray(request.storePassword)
      ZeroTraceManager.wipeCharArray(request.keyPassword)
      return
    }

    _uiState.update {
      it.copy(
        signingStudio = it.signingStudio.copy(
          isSigning = true,
          logs = listOf("Generating RSA-2048 keystore offline..."),
          result = null,
          translatedError = null,
        ),
        pipeline = it.pipeline.copy(errorMessage = null),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        val entry = KeystoreVaultManager.createNewVaultKeystore(appCtx, request)
        KeystoreVaultManager.unlockVaultKeystore(appCtx, entry.id)
      }.onSuccess { ksConfig ->
        ShipSignBuildService.startLocalSigning(
          context = appCtx,
          target = target,
          keystoreConfig = ksConfig,
          options = _uiState.value.signingStudio.options,
        )
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            signingStudio = it.signingStudio.copy(
              isSigning = false,
              translatedError = ErrorTranslator.translate(err),
            ),
            pipeline = it.pipeline.copy(errorMessage = ErrorTranslator.translate(err).message),
          )
        }
      }
    }
  }

  fun importKeystoreAndSign(
    storePassword: CharArray,
    keyAlias: String,
    keyPassword: CharArray,
    saveToVault: Boolean,
  ) {
    val target = _uiState.value.inspector.targetFile
    val ksFile = _uiState.value.keystoreStudio.tempKeystoreFile
    val fileName = _uiState.value.keystoreStudio.importedFileName ?: "imported.p12"
    if (target == null || ksFile == null || _uiState.value.signingStudio.isSigning) {
      ZeroTraceManager.wipeCharArray(storePassword)
      ZeroTraceManager.wipeCharArray(keyPassword)
      return
    }

    val effectiveKeyPass = if (keyPassword.isEmpty()) storePassword.copyOf() else keyPassword
    _uiState.update {
      it.copy(
        signingStudio = it.signingStudio.copy(
          isSigning = true,
          logs = listOf("Validating uploaded keystore..."),
          result = null,
          translatedError = null,
        ),
        pipeline = it.pipeline.copy(errorMessage = null),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val storeCopy = storePassword.copyOf()
      val keyCopy = effectiveKeyPass.copyOf()
      try {
        val ksConfig = if (saveToVault) {
          val savedEntry = KeystoreVaultManager.importVaultKeystore(
            context = appCtx,
            sourceFile = ksFile,
            originalFileName = fileName,
            storePassword = storeCopy.copyOf(),
            keyAlias = keyAlias,
            keyPassword = keyCopy.copyOf(),
          )
          KeystoreVaultManager.unlockVaultKeystore(appCtx, savedEntry.id)
        } else {
          val detected = KeystoreDetector.detectFormat(ksFile)
          val validated = KeystoreDetector.validateKeystoreCredentials(
            ImportedKeystoreConfig(
              tempKeystoreFile = ksFile,
              detectedFormat = detected,
              storePassword = storeCopy.copyOf(),
              keyAlias = keyAlias.trim(),
              keyPassword = keyCopy.copyOf(),
            )
          )
          ImportedKeystoreConfig(
            tempKeystoreFile = ksFile,
            detectedFormat = validated.format,
            storePassword = storeCopy.copyOf(),
            keyAlias = validated.alias,
            keyPassword = keyCopy.copyOf(),
          )
        }
        ShipSignBuildService.startLocalSigning(
          context = appCtx,
          target = target,
          keystoreConfig = ksConfig,
          options = _uiState.value.signingStudio.options,
        )
      } catch (err: Exception) {
        _uiState.update {
          it.copy(
            signingStudio = it.signingStudio.copy(
              isSigning = false,
              translatedError = ErrorTranslator.translate(err),
            ),
            pipeline = it.pipeline.copy(errorMessage = ErrorTranslator.translate(err).message),
          )
        }
      } finally {
        ZeroTraceManager.wipeCharArray(storePassword)
        ZeroTraceManager.wipeCharArray(keyPassword)
        ZeroTraceManager.wipeCharArray(effectiveKeyPass)
        ZeroTraceManager.wipeCharArray(storeCopy)
        ZeroTraceManager.wipeCharArray(keyCopy)
      }
    }
  }

  // --- Offline Keystore Vault (③ Create Keystore) ---

  fun createVaultKeystore(
    request: KeystoreCreateRequest,
    onCreated: (VaultKeystoreEntry) -> Unit,
  ) {
    if (_uiState.value.keystoreVault.isBusy) {
      ZeroTraceManager.wipeCharArray(request.storePassword)
      ZeroTraceManager.wipeCharArray(request.keyPassword)
      return
    }
    _uiState.update {
      it.copy(keystoreVault = it.keystoreVault.copy(isBusy = true, errorMessage = null, statusMessage = null))
    }
    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        KeystoreVaultManager.createNewVaultKeystore(appCtx, request)
      }.onSuccess { entry ->
        _uiState.update {
          it.copy(
            keystoreVault = it.keystoreVault.copy(
              isBusy = false,
              errorMessage = null,
              statusMessage = "Saved ${entry.fileName} to Keystore Vault.",
            )
          )
        }
        viewModelScope.launch(Dispatchers.Main) { onCreated(entry) }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            keystoreVault = it.keystoreVault.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun pickKeystoreForVaultImport(uri: Uri) {
    if (_uiState.value.keystoreVault.isBusy) return
    _uiState.update {
      it.copy(keystoreVault = it.keystoreVault.copy(isBusy = true, errorMessage = null, statusMessage = null))
    }
    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        _uiState.value.keystoreVault.importedTempFile?.let { ZeroTraceManager.secureDeleteFile(it) }
        val sessionDir = ZeroTraceManager.createOrGetSessionDir(appCtx)
        val copied = SafFileBridge.copyUriToSession(appCtx, uri, sessionDir)
        val format = KeystoreDetector.detectFormat(copied.file)
        copied to format
      }.onSuccess { (copied, format) ->
        _uiState.update {
          it.copy(
            keystoreVault = it.keystoreVault.copy(
              isBusy = false,
              importedTempFile = copied.file,
              importedFileName = copied.displayName,
              detectedFormat = format,
              errorMessage = null,
            )
          )
        }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            keystoreVault = it.keystoreVault.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun confirmVaultKeystoreImport(
    storePassword: CharArray,
    keyAlias: String,
    keyPassword: CharArray,
    onImported: (VaultKeystoreEntry) -> Unit,
  ) {
    val tempFile = _uiState.value.keystoreVault.importedTempFile
    val fileName = _uiState.value.keystoreVault.importedFileName ?: "imported.p12"
    if (tempFile == null || _uiState.value.keystoreVault.isBusy) {
      ZeroTraceManager.wipeCharArray(storePassword)
      ZeroTraceManager.wipeCharArray(keyPassword)
      return
    }
    _uiState.update {
      it.copy(keystoreVault = it.keystoreVault.copy(isBusy = true, errorMessage = null, statusMessage = null))
    }
    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val effectiveKeyPass = if (keyPassword.isEmpty()) storePassword.copyOf() else keyPassword
      runCatching {
        val entry = KeystoreVaultManager.importVaultKeystore(
          context = appCtx,
          sourceFile = tempFile,
          originalFileName = fileName,
          storePassword = storePassword,
          keyAlias = keyAlias,
          keyPassword = effectiveKeyPass,
        )
        ZeroTraceManager.secureDeleteFile(tempFile)
        entry
      }.onSuccess { entry ->
        _uiState.update {
          it.copy(
            keystoreVault = it.keystoreVault.copy(
              isBusy = false,
              importedTempFile = null,
              importedFileName = null,
              detectedFormat = KeystoreFormat.UNKNOWN,
              errorMessage = null,
              statusMessage = "Imported ${entry.fileName} into Keystore Vault.",
            )
          )
        }
        viewModelScope.launch(Dispatchers.Main) { onImported(entry) }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            keystoreVault = it.keystoreVault.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun exportVaultKeystore(entry: VaultKeystoreEntry, onResult: (String) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val msg = runCatching {
        KeystoreVaultManager.exportVaultKeystoreToDownloads(appCtx, entry)
        "Exported ${entry.fileName} to Downloads/ShipSign"
      }.getOrElse { err ->
        ErrorTranslator.translate(err).message
      }
      viewModelScope.launch(Dispatchers.Main) { onResult(msg) }
    }
  }

  fun deleteVaultKeystore(entryId: String) {
    viewModelScope.launch(Dispatchers.IO) {
      KeystoreVaultManager.deleteVaultKeystore(getApplication(), entryId)
    }
  }

  // --- Previous Projects Vault (② View Previous Projects) ---

  fun downloadSavedProject(entry: SavedProjectEntry, onResult: (String) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val msg = runCatching {
        ProjectHistoryRepository.exportProjectToDownloads(appCtx, entry)
        "Saved ${entry.fileName} to Downloads/ShipSign"
      }.getOrElse { err ->
        ErrorTranslator.translate(err).message
      }
      viewModelScope.launch(Dispatchers.Main) { onResult(msg) }
    }
  }

  fun loadSavedProjectIntoPipeline(entry: SavedProjectEntry, onLoaded: () -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        val src = File(entry.filePath)
        require(src.exists()) { "Saved project artifact no longer exists on disk" }
        val ext = if (entry.format == ResolvedBinaryType.AAB) ".aab" else ".apk"
        val workingCopy = ZeroTraceManager.allocateTempFile(appCtx, "reopened", ext)
        src.copyTo(workingCopy, overwrite = true)
        val info = PackageInfoInspector.inspectPackage(
          context = appCtx,
          file = workingCopy,
          format = entry.format,
          fallbackName = entry.appName,
        )
        AppTargetFile(
          sessionFile = workingCopy,
          originalName = entry.fileName,
          sizeBytes = workingCopy.length(),
          binaryType = entry.format,
          isAlreadySigned = info.isSigned,
          detectedStack = null,
          sourceMetadata = null,
          packageInfo = info,
        )
      }.onSuccess { target ->
        _uiState.update { state ->
          state.copy(
            inspector = state.inspector.copy(
              targetFile = target,
              availableBuildTargets = listOf(target),
              isProcessing = false,
              errorMessage = null,
            ),
            pipeline = OfflinePipelineUiState(),
            signingStudio = SigningStudioUiState(options = state.signingStudio.options),
          )
        }
        viewModelScope.launch(Dispatchers.Main) { onLoaded() }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            projectHistory = it.projectHistory.copy(
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun clearCloudTraceForProject(entry: SavedProjectEntry, onResult: (String) -> Unit) {
    val repoFullName = entry.cloudRepoFullName ?: return
    val appCtx = getApplication<Application>()
    _uiState.update {
      it.copy(projectHistory = it.projectHistory.copy(clearingRepoName = repoFullName, errorMessage = null))
    }
    viewModelScope.launch(Dispatchers.IO) {
      val authSession = GitHubOAuthManager.getSavedSession(appCtx)
      if (authSession == null) {
        _uiState.update {
          it.copy(projectHistory = it.projectHistory.copy(clearingRepoName = null))
        }
        viewModelScope.launch(Dispatchers.Main) {
          onResult("Reconnect GitHub to delete $repoFullName.")
        }
        return@launch
      }
      val tokenChars = authSession.accessToken.toCharArray()
      val msg = runCatching {
        GitHubBuildModule.deleteEphemeralRepository(
          token = tokenChars,
          repoFullName = repoFullName,
          wipeTokenOnCompletion = true,
        ).getOrThrow()
        ProjectHistoryRepository.markCloudTraceCleared(appCtx, repoFullName)
        if (BuildSessionStore.loadSession(appCtx)?.repoFullName == repoFullName) {
          BuildSessionStore.clearSession(appCtx)
        }
        "Cloud trace cleared ($repoFullName deleted)."
      }.getOrElse { err ->
        ErrorTranslator.translate(err).message
      }
      _uiState.update {
        it.copy(projectHistory = it.projectHistory.copy(clearingRepoName = null))
      }
      viewModelScope.launch(Dispatchers.Main) { onResult(msg) }
    }
  }

  fun deleteSavedProject(entryId: String) {
    viewModelScope.launch(Dispatchers.IO) {
      ProjectHistoryRepository.deleteProject(getApplication(), entryId)
    }
  }

  /** Copies an already-exported signed output URI to a user-selected SAF destination URI. */
  fun copySignedOutputToUri(sourceUri: Uri, destUri: Uri, onComplete: (Boolean) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val buffer = ByteArray(64 * 1024)
      val success = runCatching {
        val resolver = appCtx.contentResolver
        val inputStream = if (sourceUri.scheme.equals("file", ignoreCase = true) && sourceUri.path != null) {
          File(sourceUri.path!!).inputStream()
        } else {
          resolver.openInputStream(sourceUri)
        } ?: error("Unable to open signed binary stream")
        inputStream.use { input ->
          resolver.openOutputStream(destUri, "w")?.use { output ->
            while (true) {
              val read = input.read(buffer)
              if (read == -1) break
              output.write(buffer, 0, read)
            }
            output.flush()
          } ?: error("Unable to write to chosen destination")
        }
        true
      }.getOrDefault(false)
      ZeroTraceManager.wipeByteArray(buffer)
      viewModelScope.launch(Dispatchers.Main) {
        onComplete(success)
      }
    }
  }

  // --- Vault & Crypto Core Actions ---

  fun runZeroTraceAudit() {
    if (_uiState.value.isAuditing) return
    _uiState.update { it.copy(isAuditing = true) }
    viewModelScope.launch(Dispatchers.IO) {
      val result = ZeroTraceManager.runZeroTraceSelfTest(getApplication())
      _uiState.update { it.copy(isAuditing = false, lastAuditResult = result) }
    }
  }

  fun nukeCurrentSession() {
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    cloudBuildJob = null
    wipeActiveSigningCredentials()
    wipeGeneratedCredentials()
    viewModelScope.launch(Dispatchers.IO) {
      ZeroTraceManager.nukeCurrentSession(getApplication())
      _uiState.update { state ->
        state.copy(
          lastAuditResult = null,
          inspector = InspectorUiState(),
          keystoreStudio = KeystoreStudioUiState(),
          signingStudio = SigningStudioUiState(),
          cloudBuild = state.cloudBuild.copy(
            isActive = false,
            currentStage = null,
            statusText = "",
            elapsedSeconds = 0,
            buildState = CloudBuildState.Idle,
            needsRepoAccessGrant = false,
            translatedError = null,
          ),
        )
      }
    }
  }

  @Suppress("DEPRECATION")
  fun refreshCryptoProviders() {
    val allProviders = Security.getProviders()
    var bcSlot = -1
    var bcVersion = ""
    val mapped = allProviders.mapIndexed { index, provider ->
      val slot = index + 1
      val isBc = provider.name.equals(BouncyCastleProvider.PROVIDER_NAME, ignoreCase = true)
      if (isBc && bcSlot == -1) {
        bcSlot = slot
        bcVersion = provider.version.toString()
      }
      SecurityProviderInfo(
        slot = slot,
        name = provider.name,
        version = provider.version.toString(),
        info = provider.info,
        isBouncyCastle = isBc,
      )
    }
    _uiState.update { state ->
      state.copy(
        cryptoDiagnostics = state.cryptoDiagnostics.copy(
          bouncyCastleSlot = bcSlot,
          bouncyCastleVersion = bcVersion,
          providers = mapped,
        )
      )
    }
  }

  fun verifySigningCapabilities() {
    if (_uiState.value.cryptoDiagnostics.isTesting) return
    _uiState.update {
      it.copy(cryptoDiagnostics = it.cryptoDiagnostics.copy(isTesting = true))
    }
    viewModelScope.launch(Dispatchers.Default) {
      val passed = runCatching {
        val sha256 = MessageDigest.getInstance("SHA-256", BouncyCastleProvider.PROVIDER_NAME)
        val digest = sha256.digest(byteArrayOf(1, 2, 3, 4))
        ZeroTraceManager.wipeByteArray(digest)

        val ecGen = KeyPairGenerator.getInstance("EC", BouncyCastleProvider.PROVIDER_NAME)
        ecGen.initialize(256)
        ecGen.generateKeyPair()

        val rsaGen = KeyPairGenerator.getInstance("RSA", BouncyCastleProvider.PROVIDER_NAME)
        rsaGen.initialize(2048)
        rsaGen.generateKeyPair()

        Class.forName("com.android.apksig.ApkSigner")
        Class.forName("com.android.tools.build.bundletool.commands.BuildApksCommand")
        true
      }.getOrDefault(false)

      _uiState.update {
        it.copy(
          cryptoDiagnostics = it.cryptoDiagnostics.copy(
            isTesting = false,
            selfTestPassed = passed,
          )
        )
      }
    }
  }

  private fun wipeActiveSigningCredentials() {
    activeStorePassChars?.let { ZeroTraceManager.wipeCharArray(it) }
    activeKeyPassChars?.let { ZeroTraceManager.wipeCharArray(it) }
    activeStorePassChars = null
    activeKeyPassChars = null
    activeKeyAlias = null
  }

  private fun deleteInspectorFiles(inspector: InspectorUiState) {
    val files = buildSet {
      inspector.targetFile?.sessionFile?.let { add(it) }
      inspector.availableBuildTargets.forEach { add(it.sessionFile) }
    }
    files.forEach { ZeroTraceManager.secureDeleteFile(it) }
  }

  private fun wipeGeneratedCredentials() {
    generatedStorePassChars?.let { ZeroTraceManager.wipeCharArray(it) }
    generatedKeyPassChars?.let { ZeroTraceManager.wipeCharArray(it) }
    generatedStorePassChars = null
    generatedKeyPassChars = null
    generatedKeyAlias = null
  }
}
