package com.shipsign.app.core.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ResolvedBinaryType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

data class PackageCustomizationRequest(
  val appName: String? = null,
  val packageName: String? = null,
  val versionCode: Long? = null,
  val versionName: String? = null,
  val iconImageBytes: ByteArray? = null,
) {
  val hasAnyChange: Boolean
    get() = !appName.isNullOrBlank() ||
      !packageName.isNullOrBlank() ||
      (versionCode != null && versionCode > 0L) ||
      !versionName.isNullOrBlank() ||
      (iconImageBytes != null && iconImageBytes.isNotEmpty())
}

/**
 * 100% offline package customization engine for `.apk` and `.aab` binaries.
 *
 * - For `.apk`: Patches binary AXML `AndroidManifest.xml` (`package`, `android:label`,
 *   `android:versionCode`, `android:versionName`), replaces launcher icon PNGs across mipmap/drawable
 *   densities when provided, strips old signatures, and writes a 4-byte zip-aligned `.apk`.
 * - For `.aab`: Patches `com.android.aapt.Resources.XmlNode` protobuf `base/manifest/AndroidManifest.xml`
 *   and replaces matching launcher icon assets in `base/res/`.
 */
object PackageCustomizerEngine {

  private const val STREAM_BUFFER_SIZE = 64 * 1024
  private const val ANDROID_NS = "http://schemas.android.com/apk/res/android"
  private const val ATTR_ID_LABEL = 0x01010001
  private const val ATTR_ID_VERSION_CODE = 0x0101021b
  private const val ATTR_ID_VERSION_NAME = 0x0101021c

  suspend fun customizePackage(
    context: Context,
    target: AppTargetFile,
    request: PackageCustomizationRequest,
  ): AppTargetFile = withContext(Dispatchers.IO) {
    require(
      target.binaryType == ResolvedBinaryType.APK || target.binaryType == ResolvedBinaryType.AAB
    ) {
      "Customization supports APK and AAB files only"
    }

    if (!request.hasAnyChange) {
      val refreshedInfo = PackageInfoInspector.inspectPackage(
        context = context,
        file = target.sessionFile,
        format = target.binaryType,
        fallbackName = target.originalName.substringBeforeLast('.'),
      )
      return@withContext target.copy(packageInfo = refreshedInfo)
    }

    val scaledIcons = request.iconImageBytes?.let { buildDensityScaledIconMap(it) } ?: emptyMap()
    val rawIconFallback = request.iconImageBytes

    val outputFile = if (target.binaryType == ResolvedBinaryType.APK) {
      customizeApkInternal(context, target.sessionFile, request, scaledIcons, rawIconFallback)
    } else {
      customizeAabInternal(context, target.sessionFile, request, scaledIcons, rawIconFallback)
    }

    val newBaseName = request.appName
      ?.trim()
      ?.takeIf { it.isNotBlank() }
      ?.replace(Regex("[^A-Za-z0-9._-]+"), "-")
      ?.trim('-')
      ?.ifBlank { null }
      ?: target.originalName.substringBeforeLast('.')
    val ext = if (target.binaryType == ResolvedBinaryType.AAB) ".aab" else ".apk"
    val updatedName = "$newBaseName-custom$ext"

    val updatedInfo = PackageInfoInspector.inspectPackage(
      context = context,
      file = outputFile,
      format = target.binaryType,
      fallbackName = request.appName?.takeIf { it.isNotBlank() } ?: newBaseName,
    )

    AppTargetFile(
      sessionFile = outputFile,
      originalName = updatedName,
      sizeBytes = outputFile.length(),
      binaryType = target.binaryType,
      isAlreadySigned = false,
      detectedStack = target.detectedStack,
      sourceMetadata = target.sourceMetadata,
      packageInfo = updatedInfo,
    )
  }

  private fun customizeApkInternal(
    context: Context,
    inputApk: File,
    request: PackageCustomizationRequest,
    scaledIcons: Map<String, ByteArray>,
    rawIconFallback: ByteArray?,
  ): File {
    val unalignedOut = ZeroTraceManager.allocateTempFile(context, "custom_unaligned", ".apk")
    val alignedOut = ZeroTraceManager.allocateTempFile(context, "custom_aligned", ".apk")
    val buffer = ByteArray(STREAM_BUFFER_SIZE)

    try {
      ZipFile(inputApk).use { zip ->
        ZipOutputStream(BufferedOutputStream(FileOutputStream(unalignedOut, false), STREAM_BUFFER_SIZE)).use { zos ->
          val entries = zip.entries()
          while (entries.hasMoreElements()) {
            val entry = entries.nextElement()
            if (SignatureScanner.isSignatureArtifact(entry.name)) continue

            val normalized = entry.name.replace('\\', '/')
            when {
              normalized == "AndroidManifest.xml" -> {
                val origBytes = zip.getInputStream(entry).use { it.readBytes() }
                val patched = AxmlBinaryEditor.patchManifest(
                  axmlBytes = origBytes,
                  packageName = request.packageName,
                  appLabel = request.appName,
                  versionCode = request.versionCode,
                  versionName = request.versionName,
                )
                writeEntryBytes(zos, normalized, patched, ZipEntry.DEFLATED)
              }
              rawIconFallback != null && isApkLauncherIconPath(normalized) -> {
                val replacement = selectIconBytesForPath(normalized, scaledIcons, rawIconFallback)
                writeEntryBytes(zos, normalized, replacement, ZipEntry.STORED)
              }
              else -> {
                copyZipEntry(zip, entry, zos, buffer)
              }
            }
          }
          zos.flush()
        }
      }

      ZipAlignEngine.alignApk(
        inputApk = unalignedOut,
        outputApk = alignedOut,
        alignment = 4,
        pageAlignSharedLibs = true,
      )
      return alignedOut
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(alignedOut)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
      ZeroTraceManager.secureDeleteFile(unalignedOut)
    }
  }

  private fun customizeAabInternal(
    context: Context,
    inputAab: File,
    request: PackageCustomizationRequest,
    scaledIcons: Map<String, ByteArray>,
    rawIconFallback: ByteArray?,
  ): File {
    val outputAab = ZeroTraceManager.allocateTempFile(context, "custom_bundle", ".aab")
    val buffer = ByteArray(STREAM_BUFFER_SIZE)

    try {
      ZipFile(inputAab).use { zip ->
        ZipOutputStream(BufferedOutputStream(FileOutputStream(outputAab, false), STREAM_BUFFER_SIZE)).use { zos ->
          val entries = zip.entries()
          while (entries.hasMoreElements()) {
            val entry = entries.nextElement()
            if (SignatureScanner.isSignatureArtifact(entry.name)) continue

            val normalized = entry.name.replace('\\', '/')
            when {
              normalized == "base/manifest/AndroidManifest.xml" -> {
                val origBytes = zip.getInputStream(entry).use { it.readBytes() }
                val patched = if (AxmlBinaryEditor.isBinaryAxml(origBytes)) {
                  AxmlBinaryEditor.patchManifest(
                    axmlBytes = origBytes,
                    packageName = request.packageName,
                    appLabel = request.appName,
                    versionCode = request.versionCode,
                    versionName = request.versionName,
                  )
                } else {
                  patchProtoManifest(origBytes, request)
                }
                writeEntryBytes(zos, normalized, patched, ZipEntry.DEFLATED)
              }
              rawIconFallback != null && isAabLauncherIconPath(normalized) -> {
                val replacement = selectIconBytesForPath(normalized, scaledIcons, rawIconFallback)
                writeEntryBytes(zos, normalized, replacement, ZipEntry.DEFLATED)
              }
              else -> {
                copyZipEntry(zip, entry, zos, buffer)
              }
            }
          }
          zos.flush()
        }
      }
      return outputAab
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(outputAab)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  internal fun patchProtoManifest(
    manifestProtoBytes: ByteArray,
    request: PackageCustomizationRequest,
  ): ByteArray {
    val xmlNode = AabProtoCodec.parseXmlNode(manifestProtoBytes)
    val root = xmlNode.element ?: ProtoXmlElement(name = "manifest")
    var rootAttrs = root.attributes.toMutableList()
    val rootChildren = root.children.toMutableList()

    request.packageName?.trim()?.takeIf { it.isNotEmpty() }?.let { newPkg ->
      rootAttrs = upsertProtoAttribute(
        attributes = rootAttrs,
        name = "package",
        namespaceUri = "",
        resourceId = 0,
        newValue = newPkg,
        newCompiledItem = null,
      )
    }

    request.versionCode?.takeIf { it > 0L }?.let { newCode ->
      rootAttrs = upsertProtoAttribute(
        attributes = rootAttrs,
        name = "versionCode",
        namespaceUri = ANDROID_NS,
        resourceId = ATTR_ID_VERSION_CODE,
        newValue = newCode.toString(),
        newCompiledItem = ProtoItem(intDecimal = newCode.toInt()),
      )
    }

    request.versionName?.trim()?.takeIf { it.isNotEmpty() }?.let { newVerName ->
      rootAttrs = upsertProtoAttribute(
        attributes = rootAttrs,
        name = "versionName",
        namespaceUri = ANDROID_NS,
        resourceId = ATTR_ID_VERSION_NAME,
        newValue = newVerName,
        newCompiledItem = null,
      )
    }

    request.appName?.trim()?.takeIf { it.isNotEmpty() }?.let { newLabel ->
      var patchedApp = false
      for (i in rootChildren.indices) {
        val child = rootChildren[i]
        val el = child.element
        if (el != null && el.name == "application") {
          val updatedAppAttrs = upsertProtoAttribute(
            attributes = el.attributes.toMutableList(),
            name = "label",
            namespaceUri = ANDROID_NS,
            resourceId = ATTR_ID_LABEL,
            newValue = newLabel,
            newCompiledItem = null,
          )
          rootChildren[i] = child.copy(element = el.copy(attributes = updatedAppAttrs))
          patchedApp = true
          break
        }
      }
      if (!patchedApp) {
        rootChildren.add(
          ProtoXmlNode(
            element = ProtoXmlElement(
              name = "application",
              attributes = listOf(
                ProtoXmlAttribute(
                  namespaceUri = ANDROID_NS,
                  name = "label",
                  value = newLabel,
                  resourceId = ATTR_ID_LABEL,
                )
              ),
            )
          )
        )
      }
    }

    val updatedRoot = root.copy(attributes = rootAttrs, children = rootChildren)
    return AabProtoCodec.encodeXmlNode(xmlNode.copy(element = updatedRoot))
  }

  private fun upsertProtoAttribute(
    attributes: MutableList<ProtoXmlAttribute>,
    name: String,
    namespaceUri: String,
    resourceId: Int,
    newValue: String,
    newCompiledItem: ProtoItem?,
  ): MutableList<ProtoXmlAttribute> {
    for (i in attributes.indices) {
      val existing = attributes[i]
      val match = existing.name == name || (resourceId != 0 && existing.resourceId == resourceId)
      if (match) {
        attributes[i] = existing.copy(
          value = newValue,
          compiledItem = newCompiledItem,
        )
        return attributes
      }
    }
    attributes.add(
      ProtoXmlAttribute(
        namespaceUri = namespaceUri,
        name = name,
        value = newValue,
        resourceId = resourceId,
        compiledItem = newCompiledItem,
      )
    )
    return attributes
  }

  private fun isApkLauncherIconPath(path: String): Boolean {
    val lower = path.lowercase(Locale.US)
    val isPngOrWebp = lower.endsWith(".png") || lower.endsWith(".webp")
    if (!isPngOrWebp) return false
    val fileName = lower.substringAfterLast('/')
    val inMipmapOrDrawable = lower.startsWith("res/mipmap") || lower.startsWith("res/drawable")
    return inMipmapOrDrawable && (
      fileName.startsWith("ic_launcher") && !fileName.endsWith(".xml")
    )
  }

  private fun isAabLauncherIconPath(path: String): Boolean {
    val lower = path.lowercase(Locale.US)
    if (!lower.startsWith("base/")) return false
    return isApkLauncherIconPath(lower.removePrefix("base/"))
  }

  private fun buildDensityScaledIconMap(imageBytes: ByteArray): Map<String, ByteArray> {
    val decoded = runCatching {
      BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
    }.getOrNull() ?: return emptyMap()

    val targets = mapOf(
      "ldpi" to 36,
      "mdpi" to 48,
      "hdpi" to 72,
      "xhdpi" to 96,
      "xxhdpi" to 144,
      "xxxhdpi" to 192,
      "default" to 192,
    )
    val out = mutableMapOf<String, ByteArray>()
    try {
      for ((bucket, px) in targets) {
        val scaled = Bitmap.createScaledBitmap(decoded, px, px, true)
        val baos = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.PNG, 100, baos)
        out[bucket] = baos.toByteArray()
        if (scaled !== decoded) {
          scaled.recycle()
        }
      }
    } finally {
      decoded.recycle()
    }
    return out
  }

  private fun selectIconBytesForPath(
    path: String,
    scaledIcons: Map<String, ByteArray>,
    rawFallback: ByteArray,
  ): ByteArray {
    if (scaledIcons.isEmpty()) return rawFallback
    val lower = path.lowercase(Locale.US)
    val key = when {
      lower.contains("xxxhdpi") -> "xxxhdpi"
      lower.contains("xxhdpi") -> "xxhdpi"
      lower.contains("xhdpi") -> "xhdpi"
      lower.contains("hdpi") -> "hdpi"
      lower.contains("mdpi") -> "mdpi"
      lower.contains("ldpi") -> "ldpi"
      else -> "default"
    }
    return scaledIcons[key] ?: scaledIcons["default"] ?: rawFallback
  }

  private fun writeEntryBytes(
    zos: ZipOutputStream,
    name: String,
    data: ByteArray,
    method: Int,
  ) {
    val entry = ZipEntry(name).apply {
      this.method = method
      if (method == ZipEntry.STORED) {
        size = data.size.toLong()
        compressedSize = data.size.toLong()
        val crc32 = java.util.zip.CRC32()
        crc32.update(data)
        crc = crc32.value
      }
    }
    zos.putNextEntry(entry)
    zos.write(data)
    zos.closeEntry()
  }

  private fun copyZipEntry(
    zip: ZipFile,
    sourceEntry: ZipEntry,
    zos: ZipOutputStream,
    buffer: ByteArray,
  ) {
    val outEntry = ZipEntry(sourceEntry.name).apply {
      if (sourceEntry.time > 0L) time = sourceEntry.time
      if (sourceEntry.isDirectory) {
        method = ZipEntry.STORED
        size = 0L
        compressedSize = 0L
        crc = 0L
      } else if (
        sourceEntry.method == ZipEntry.STORED &&
          sourceEntry.size >= 0L &&
          sourceEntry.compressedSize >= 0L &&
          sourceEntry.crc >= 0L
      ) {
        method = ZipEntry.STORED
        size = sourceEntry.size
        compressedSize = sourceEntry.compressedSize
        crc = sourceEntry.crc
      } else {
        method = ZipEntry.DEFLATED
      }
    }
    zos.putNextEntry(outEntry)
    if (!sourceEntry.isDirectory) {
      zip.getInputStream(sourceEntry).use { input ->
        while (true) {
          val read = input.read(buffer)
          if (read == -1) break
          zos.write(buffer, 0, read)
        }
      }
    }
    zos.closeEntry()
  }
}
