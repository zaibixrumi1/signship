package com.shipsign.app

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.shipsign.app.core.engine.ErrorTranslator
import com.shipsign.app.core.github.BuildOutputFormat
import com.shipsign.app.core.github.CloudBuildStage
import com.shipsign.app.core.github.CloudBuildState
import com.shipsign.app.core.github.GitHubBuildModule
import com.shipsign.app.core.github.GitHubConfig
import com.shipsign.app.core.github.GitHubOAuthDeniedException
import com.shipsign.app.core.github.GitHubOAuthException
import com.shipsign.app.core.github.GitHubOAuthManager
import com.shipsign.app.core.github.GitHubOAuthStateMismatchException
import com.shipsign.app.core.github.WorkflowTemplateGenerator
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ProjectStack
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.domain.model.SourceProjectMetadata
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Protocol
import okhttp3.Response
import okhttp3.ResponseBody.Companion.toResponseBody
import okio.Buffer
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Step5GitHubCloudBuildTest {

  private lateinit var context: Context
  private lateinit var sessionDir: File

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    ZeroTraceManager.nukeAllSync(context)
    sessionDir = ZeroTraceManager.createOrGetSessionDir(context)
    GitHubConfig.resetEndpoints()
    GitHubOAuthManager.disconnect(context)
  }

  @After
  fun tearDown() {
    GitHubOAuthManager.disconnect(context)
    GitHubConfig.resetEndpoints()
    ZeroTraceManager.nukeAllSync(context)
  }

  @Test
  fun `GitHubConfig and BuildOutputFormat expose verified signship-testing OAuth config and 3 workflow formats`() {
    assertEquals("signship-testing", GitHubConfig.GITHUB_APP_SLUG)
    assertEquals("5837463", GitHubConfig.GITHUB_APP_ID)
    assertEquals("Iv23li9uobnY1r29Wel9", GitHubConfig.GITHUB_CLIENT_ID)
    assertEquals("shipsign://github/callback", GitHubConfig.REDIRECT_URI)
    assertEquals("ShipSign-Android/1.0", GitHubConfig.USER_AGENT)

    assertEquals("shipsign-build-apk.yml", BuildOutputFormat.APK_ONLY.workflowFileName)
    assertEquals("ShipSign-APK", BuildOutputFormat.APK_ONLY.artifactName)
    assertEquals("APK Only", BuildOutputFormat.APK_ONLY.displayLabel)

    assertEquals("shipsign-build-aab.yml", BuildOutputFormat.AAB_ONLY.workflowFileName)
    assertEquals("ShipSign-AAB", BuildOutputFormat.AAB_ONLY.artifactName)
    assertEquals("AAB Only", BuildOutputFormat.AAB_ONLY.displayLabel)

    assertEquals("shipsign-build-both.yml", BuildOutputFormat.BOTH.workflowFileName)
    assertEquals("ShipSign-Bundle", BuildOutputFormat.BOTH.artifactName)
    assertEquals("APK + AAB", BuildOutputFormat.BOTH.displayLabel)
  }

  @Test
  fun `GitHubOAuthManager validates missing secret, surfaces exact token error diagnostics, and supports PAT sign-in`() = runBlocking {
    val missingSecret = GitHubOAuthManager.validateOAuthCredentials(
      clientId = "Iv23li9uobnY1r29Wel9",
      clientSecret = "   ",
    )
    assertTrue(missingSecret.isFailure)
    val missingErr = missingSecret.exceptionOrNull()!!
    assertTrue(missingErr is GitHubOAuthException)
    assertEquals("Missing GITHUB_CLIENT_SECRET in build configuration", missingErr.message)
    assertEquals(
      "Missing GITHUB_CLIENT_SECRET in build configuration",
      ErrorTranslator.translate(missingErr).message,
    )

    // Token exchange exact error + error_description propagation
    val authReq = GitHubOAuthManager.createAuthorizeRequest(
      context = context,
      oauthBaseUrl = "https://github.test",
    )
    assertFalse("GitHub App authorize URL must NOT contain scope=", authReq.authorizeUrl.contains("scope="))

    val errorClient = OkHttpClient.Builder()
      .addInterceptor(Interceptor { chain ->
        val req = chain.request()
        assertEquals("application/json", req.header("Accept"))
        jsonResp(
          req,
          200,
          """{"error":"incorrect_client_credentials","error_description":"The client_id and/or client_secret passed are incorrect."}""",
        )
      })
      .build()

    val callbackUri = Uri.parse("shipsign://github/callback?code=bad_code&state=${authReq.state}")
    val tokenErrResult = GitHubOAuthManager.handleAuthCallback(
      context = context,
      uri = callbackUri,
      clientSecret = "wrong_secret",
      httpClient = errorClient,
      oauthBaseUrl = "https://github.test",
      apiBaseUrl = "https://api.github.test",
    )
    assertTrue(tokenErrResult.isFailure)
    val exactMessage = tokenErrResult.exceptionOrNull()?.message.orEmpty()
    assertEquals(
      "incorrect_client_credentials: The client_id and/or client_secret passed are incorrect.",
      exactMessage,
    )
    assertEquals(exactMessage, ErrorTranslator.translate(tokenErrResult.exceptionOrNull()!!).message)

    // Secondary Personal Access Token sign-in validates via GET /user, saves encrypted session, wipes CharArray
    val patClient = OkHttpClient.Builder()
      .addInterceptor(Interceptor { chain ->
        val req = chain.request()
        assertEquals("/user", req.url.encodedPath)
        assertEquals("Bearer ghp_verified_pat_token_123", req.header("Authorization"))
        jsonResp(req, 200, """{"login":"patdev","avatar_url":"https://avatars.githubusercontent.com/u/99"}""")
      })
      .build()

    val patChars = "  ghp_verified_pat_token_123  ".toCharArray()
    val patResult = GitHubOAuthManager.connectWithPersonalAccessToken(
      context = context,
      tokenChars = patChars,
      httpClient = patClient,
      apiBaseUrl = "https://api.github.test",
    )
    assertTrue("PAT CharArray must be wiped immediately", patChars.all { it == '\u0000' })
    assertTrue(patResult.isSuccess)
    val patSession = patResult.getOrThrow()
    assertEquals("patdev", patSession.username)
    assertEquals("ghp_verified_pat_token_123", patSession.accessToken)
    assertEquals("patdev", GitHubOAuthManager.getSavedSession(context)?.username)
  }

  @Test
  fun `GitHubOAuthManager executes PKCE S256 handshake, handles uncapped long token, persists encrypted session, and disconnects`() = runBlocking {
    val authReq = GitHubOAuthManager.createAuthorizeRequest(
      context = context,
      oauthBaseUrl = "https://github.test",
    )
    assertTrue(authReq.authorizeUrl.startsWith("https://github.test/login/oauth/authorize?"))
    assertTrue(authReq.authorizeUrl.contains("client_id=Iv23li9uobnY1r29Wel9"))
    assertTrue(authReq.authorizeUrl.contains("code_challenge_method=S256"))
    assertFalse("GitHub App authorize URL must NOT contain scope=", authReq.authorizeUrl.contains("scope="))
    assertFalse("client_secret must NEVER appear in authorize URL", authReq.authorizeUrl.contains("client_secret"))

    val longOpaqueToken = "ghu_" + "A".repeat(520)

    val fakeClient = OkHttpClient.Builder()
      .addInterceptor(Interceptor { chain ->
        val req = chain.request()
        assertEquals("ShipSign-Android/1.0", req.header("User-Agent"))
        val buf = Buffer()
        req.body?.writeTo(buf)
        val reqBody = buf.readUtf8()

        when (req.url.encodedPath) {
          "/login/oauth/access_token" -> {
            assertTrue(reqBody.contains("code=auth_code_999"))
            assertTrue(reqBody.contains("code_verifier="))
            assertTrue(reqBody.contains("client_secret=test_secret_value"))
            jsonResp(req, 200, """{"access_token":"$longOpaqueToken","token_type":"bearer"}""")
          }
          "/user" -> {
            assertEquals("Bearer $longOpaqueToken", req.header("Authorization"))
            jsonResp(req, 200, """{"login":"octobuilder","avatar_url":"https://avatars.githubusercontent.com/u/1"}""")
          }
          else -> error("Unexpected HTTP ${req.method} ${req.url.encodedPath}")
        }
      })
      .build()

    val callbackUri = Uri.parse(
      "shipsign://github/callback?code=auth_code_999&installation_id=424242&state=${authReq.state}"
    )
    assertTrue(GitHubOAuthManager.isGitHubCallbackUri(callbackUri))

    val result = GitHubOAuthManager.handleAuthCallback(
      context = context,
      uri = callbackUri,
      clientSecret = "test_secret_value",
      httpClient = fakeClient,
      oauthBaseUrl = "https://github.test",
      apiBaseUrl = "https://api.github.test",
    )

    assertTrue("Expected successful OAuth Result", result.isSuccess)
    val session = result.getOrThrow()
    assertEquals("octobuilder", session.username)
    assertEquals("octobuilder", session.profile.username)
    assertEquals("424242", session.installationId)
    assertEquals(longOpaqueToken, session.accessToken)

    val stored = GitHubOAuthManager.getSavedSession(context)
    assertNotNull(stored)
    assertEquals("octobuilder", stored?.username)
    assertEquals(longOpaqueToken, stored?.accessToken)

    GitHubOAuthManager.disconnect(context)
    assertNull(GitHubOAuthManager.getSavedSession(context))
  }

  @Test
  fun `GitHubOAuthManager returns failure on mismatched state and access_denied`() = runBlocking {
    GitHubOAuthManager.createAuthorizeRequest(context = context, oauthBaseUrl = "https://github.test")
    val tamperedUri = Uri.parse("shipsign://github/callback?code=abc&state=tampered_invalid_state")

    val mismatchResult = GitHubOAuthManager.handleAuthCallback(
      context = context,
      uri = tamperedUri,
      oauthBaseUrl = "https://github.test",
      apiBaseUrl = "https://api.github.test",
    )
    assertTrue(mismatchResult.isFailure)
    assertTrue(mismatchResult.exceptionOrNull() is GitHubOAuthStateMismatchException)

    val deniedUri = Uri.parse("shipsign://github/callback?error=access_denied&error_description=User+denied")
    val deniedResult = GitHubOAuthManager.handleAuthCallback(
      context = context,
      uri = deniedUri,
      oauthBaseUrl = "https://github.test",
      apiBaseUrl = "https://api.github.test",
    )
    assertTrue(deniedResult.isFailure)
    assertTrue(deniedResult.exceptionOrNull() is GitHubOAuthDeniedException)
  }

  @Test
  fun `WorkflowTemplateGenerator emits framework-matched workflows with exact container tags and 3-path fallbacks`() {
    // 1. APK ONLY — Native Android -> :android
    val apkWorkflow = WorkflowTemplateGenerator.generateWorkflow(
      metadata = SourceProjectMetadata(framework = ProjectFramework.NATIVE_ANDROID),
      format = BuildOutputFormat.APK_ONLY,
    )
    assertTrue(apkWorkflow.contains("image: ghcr.io/zaibixrumi1/shipsign-builder:android"))
    assertFalse("Single-job container workflow must not include a detect job", apkWorkflow.contains("detect:"))
    assertTrue(apkWorkflow.contains("actions/checkout@v6"))
    assertTrue(apkWorkflow.contains("actions/upload-artifact@v7"))
    assertTrue(apkWorkflow.contains("name: ShipSign-APK"))
    assertTrue(apkWorkflow.contains("compression-level: 0"))
    assertTrue(apkWorkflow.contains("path: \"**/outputs/apk/**/*.apk\""))
    assertFalse(apkWorkflow.contains("**/*.aab"))
    assertFalse("Must never pass android.injected.build.abi (triggers testOnly=true)", apkWorkflow.contains("android.injected.build.abi"))
    // Isolated 3-path fallback assertions with zero-overhead GRADLE_BIN & universal init-script
    assertTrue(apkWorkflow.contains("id: path_a"))
    assertTrue(apkWorkflow.contains("id: path_b"))
    assertTrue(apkWorkflow.contains("id: path_c"))
    assertTrue(apkWorkflow.contains("continue-on-error: true"))
    assertTrue(apkWorkflow.contains("if: steps.path_a.outcome != 'success'"))
    assertTrue(apkWorkflow.contains("if: steps.path_a.outcome != 'success' && steps.path_b.outcome != 'success'"))
    assertTrue(
      apkWorkflow.contains(
        "\$GRADLE_BIN assembleRelease --init-script /tmp/shipsign-init.gradle -PSHIPSIGN_ARM64_ONLY=true -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\""
      )
    )
    assertTrue(
      apkWorkflow.contains(
        "\$GRADLE_BIN assembleDebug --init-script /tmp/shipsign-init.gradle -PSHIPSIGN_ARM64_ONLY=true -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\""
      )
    )
    assertTrue(
      apkWorkflow.contains(
        "\$GRADLE_BIN assembleDebug --init-script /tmp/shipsign-init.gradle -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\""
      )
    )
    assertFalse(apkWorkflow.contains("bundleRelease"))
    // Zero-overhead Gradle invocation (no slow `gradle wrapper`), foojay stripping, & universal init-script
    assertTrue(apkWorkflow.contains("ABS_PROJECT_DIR=\$(cd \"\$PROJECT_DIR\" && pwd)"))
    assertTrue(apkWorkflow.contains("echo \"PROJECT_DIR=\$ABS_PROJECT_DIR\" >> \"\$GITHUB_ENV\""))
    assertTrue(apkWorkflow.contains("sed -i '/foojay-resolver-convention/d' settings.gradle settings.gradle.kts"))
    assertTrue(apkWorkflow.contains("echo \"GRADLE_BIN=./gradlew\" >> \"\$GITHUB_ENV\""))
    assertTrue(apkWorkflow.contains("echo \"GRADLE_BIN=gradle\" >> \"\$GITHUB_ENV\""))
    assertFalse("Must not waste CI time running gradle wrapper", apkWorkflow.contains("gradle wrapper"))
    assertFalse("Must not use heredoc for shipsign-init.gradle", apkWorkflow.contains("cat <<"))
    assertTrue(apkWorkflow.contains("printf '%s\\n' \\"))
    assertTrue(apkWorkflow.contains("'}' > /tmp/shipsign-init.gradle"))
    assertTrue(apkWorkflow.contains("androidExt.signingConfigs.all { sc ->"))
    assertTrue(apkWorkflow.contains("sc.storeFile = new File(System.getenv(\"PROJECT_DIR\") + \"/debug.keystore\")"))
    assertTrue(apkWorkflow.contains("if (project.hasProperty(\"SHIPSIGN_ARM64_ONLY\"))"))
    assertTrue(apkWorkflow.contains("androidExt.defaultConfig.ndk.abiFilters.add(\"arm64-v8a\")"))
    assertTrue(apkWorkflow.contains("androidExt.lint.checkReleaseBuilds = false"))
    assertTrue(apkWorkflow.contains("androidExt.lint.abortOnError = false"))
    assertFalse(apkWorkflow.contains("optimizeReleaseResources"))
    assertFalse(apkWorkflow.contains("ArtProfile"))
    assertFalse(apkWorkflow.contains("NativeSymbolTables"))
    // Self-healing assertions
    assertTrue(apkWorkflow.contains("local.properties"))
    assertTrue(apkWorkflow.contains("androiddebugkey"))
    assertTrue(apkWorkflow.contains("app/google-services.json"))
    assertTrue(apkWorkflow.contains(".env.example"))
    assertTrue(apkWorkflow.contains("sed -i 's/\\r\$//' gradlew && chmod +x gradlew"))
    assertFalse(apkWorkflow.contains("flutter pub get"))
    assertFalse(apkWorkflow.contains("npm install"))

    // 2. AAB ONLY — Flutter -> :flutter
    val aabWorkflow = WorkflowTemplateGenerator.generateWorkflow(
      metadata = SourceProjectMetadata(framework = ProjectFramework.FLUTTER),
      format = BuildOutputFormat.AAB_ONLY,
    )
    assertTrue(aabWorkflow.contains("image: ghcr.io/zaibixrumi1/shipsign-builder:flutter"))
    assertTrue(aabWorkflow.contains("name: ShipSign-AAB"))
    assertTrue(aabWorkflow.contains("compression-level: 0"))
    assertTrue(aabWorkflow.contains("path: \"**/outputs/bundle/**/*.aab\""))
    assertFalse(aabWorkflow.contains("**/*.apk"))
    assertTrue(aabWorkflow.contains("flutter pub get && flutter build appbundle --release"))
    assertFalse(aabWorkflow.contains("cat <<"))
    assertFalse(aabWorkflow.contains("gradle wrapper"))
    assertFalse(aabWorkflow.contains("assembleRelease"))

    // 3. BOTH — Capacitor / React Native -> :web
    val bothWorkflow = WorkflowTemplateGenerator.generateWorkflow(
      metadata = SourceProjectMetadata(framework = ProjectFramework.CAPACITOR_CORDOVA),
      format = BuildOutputFormat.BOTH,
    )
    assertTrue(bothWorkflow.contains("image: ghcr.io/zaibixrumi1/shipsign-builder:web"))
    assertTrue(bothWorkflow.contains("name: ShipSign-Bundle"))
    assertTrue(bothWorkflow.contains("compression-level: 0"))
    assertTrue(bothWorkflow.contains("**/outputs/apk/**/*.apk"))
    assertTrue(bothWorkflow.contains("**/outputs/bundle/**/*.aab"))
    assertTrue(bothWorkflow.contains("npm install --legacy-peer-deps"))
    assertTrue(bothWorkflow.contains("npx cap sync android"))
    assertTrue(bothWorkflow.contains("echo \"PROJECT_DIR=\$ABS_PROJECT_DIR\" >> \"\$GITHUB_ENV\""))
    assertFalse(bothWorkflow.contains("android.injected.build.abi"))
    assertTrue(
      bothWorkflow.contains(
        "\$GRADLE_BIN assembleRelease --init-script /tmp/shipsign-init.gradle -PSHIPSIGN_ARM64_ONLY=true -x lint -x test --no-build-cache --no-configuration-cache"
      )
    )
    assertTrue(
      bothWorkflow.contains(
        "\$GRADLE_BIN bundleRelease --init-script /tmp/shipsign-init.gradle -x lint -x test --no-build-cache --no-configuration-cache"
      )
    )
    assertTrue(
      bothWorkflow.contains(
        "\$GRADLE_BIN assembleDebug --init-script /tmp/shipsign-init.gradle -PSHIPSIGN_ARM64_ONLY=true -x lint -x test --no-build-cache --no-configuration-cache"
      )
    )
    assertTrue(
      bothWorkflow.contains(
        "\$GRADLE_BIN bundleDebug --init-script /tmp/shipsign-init.gradle -x lint -x test --no-build-cache --no-configuration-cache"
      )
    )
    assertFalse(bothWorkflow.contains("gradle wrapper"))
  }

  @Test
  fun `GitHubBuildModule blocks unclassified archive before making any GitHub API call`() = runBlocking {
    var networkCalled = false
    val failingClient = OkHttpClient.Builder()
      .addInterceptor(Interceptor { _ ->
        networkCalled = true
        error("Network must not be called for unclassified archives")
      })
      .build()

    val badTarget = AppTargetFile(
      sessionFile = File(sessionDir, "bad.zip").apply { writeBytes(byteArrayOf(1, 2, 3)) },
      originalName = "bad.zip",
      sizeBytes = 3L,
      binaryType = ResolvedBinaryType.SOURCE_CODE_PROJECT,
      isAlreadySigned = false,
      detectedStack = ProjectStack.UNKNOWN,
      sourceMetadata = SourceProjectMetadata(framework = ProjectFramework.UNKNOWN),
    )

    val tokenChars = "ghu_should_wipe".toCharArray()
    val states = GitHubBuildModule.buildUnsignedBinary(
      context = context,
      sourceProject = badTarget,
      token = tokenChars,
      httpClient = failingClient,
      apiBaseUrl = "https://api.github.test",
      pollIntervalMs = 1L,
    ).toList()

    assertFalse("GitHub API must never be touched for UNKNOWN framework", networkCalled)
    assertTrue(states.last() is CloudBuildState.Failed)
    assertTrue(tokenChars.all { it == '\u0000' })
  }

  @Test
  fun `GitHubBuildModule executes 6-stage APK_ONLY build with shipsign-build-apk yml and wipes repo and token`() = runBlocking {
    val sourceZip = createSourceZipWithAccidentalKeystoreAndIdeMetadata()
    val sourceTarget = AppTargetFile(
      sessionFile = sourceZip,
      originalName = "my-android-project.zip",
      sizeBytes = sourceZip.length(),
      binaryType = ResolvedBinaryType.SOURCE_CODE_PROJECT,
      isAlreadySigned = false,
      detectedStack = ProjectStack.ANDROID_GRADLE,
      sourceMetadata = SourceProjectMetadata(
        framework = ProjectFramework.NATIVE_ANDROID,
        projectRootPrefix = "MyApp/",
      ),
    )

    val artifactZipBytes = createArtifactZip(includeApk = true, includeAab = false)
    val eventsOrder = mutableListOf<String>()
    var uploadedTreeJson = ""
    var createdRepoName = ""
    var repoWasPrivate = false
    var dispatchPath = ""
    var dispatchBody = ""
    var runPollCount = 0

    val fakeClient = OkHttpClient.Builder()
      .addInterceptor(Interceptor { chain ->
        val req = chain.request()
        assertEquals("ShipSign-Android/1.0", req.header("User-Agent"))
        val path = req.url.encodedPath
        val bodyBuf = Buffer()
        req.body?.writeTo(bodyBuf)
        val reqBody = bodyBuf.readUtf8()

        when {
          req.method == "POST" && path == "/user/repos" -> {
            eventsOrder.add("CREATE_REPO")
            repoWasPrivate = reqBody.contains(""""private":true""")
            val nameMatch = Regex(""""name":"([^"]+)"""").find(reqBody)
            createdRepoName = nameMatch?.groupValues?.get(1).orEmpty()
            jsonResp(
              req,
              201,
              """{"name":"$createdRepoName","full_name":"devuser/$createdRepoName","private":true,"default_branch":"main"}""",
            )
          }
          req.method == "GET" && path.endsWith("/git/refs/heads/main") -> {
            jsonResp(req, 200, """{"ref":"refs/heads/main","object":{"sha":"head_sha_0"}}""")
          }
          req.method == "POST" && path.endsWith("/git/blobs") -> {
            jsonResp(req, 201, """{"sha":"blob_sha_1"}""")
          }
          req.method == "POST" && path.endsWith("/git/trees") -> {
            uploadedTreeJson = reqBody
            eventsOrder.add("CREATE_TREE")
            jsonResp(req, 201, """{"sha":"tree_sha_1"}""")
          }
          req.method == "POST" && path.endsWith("/git/commits") -> {
            jsonResp(req, 201, """{"sha":"commit_sha_1"}""")
          }
          req.method == "PATCH" && path.endsWith("/git/refs/heads/main") -> {
            jsonResp(req, 200, """{"ref":"refs/heads/main","object":{"sha":"commit_sha_1"}}""")
          }
          req.method == "POST" && path.endsWith("/dispatches") -> {
            dispatchPath = path
            dispatchBody = reqBody
            eventsOrder.add("DISPATCH")
            emptyResp(req, 204)
          }
          req.method == "GET" && path.endsWith("/actions/runs") -> {
            runPollCount++
            if (runPollCount == 1) {
              jsonResp(req, 200, """{"workflow_runs":[{"id":9001,"status":"in_progress","conclusion":null}]}""")
            } else {
              eventsOrder.add("RUN_COMPLETED")
              jsonResp(req, 200, """{"workflow_runs":[{"id":9001,"status":"completed","conclusion":"success"}]}""")
            }
          }
          req.method == "GET" && path.endsWith("/actions/runs/9001/artifacts") -> {
            jsonResp(
              req,
              200,
              """{"artifacts":[{"id":77,"name":"ShipSign-APK","expired":false,"archive_download_url":"https://api.github.test/artifacts/77/zip"}]}""",
            )
          }
          req.method == "GET" && path == "/artifacts/77/zip" -> {
            eventsOrder.add("DOWNLOAD_ARTIFACT")
            Response.Builder()
              .request(req)
              .protocol(Protocol.HTTP_1_1)
              .code(200)
              .message("OK")
              .body(artifactZipBytes.toResponseBody("application/zip".toMediaType()))
              .build()
          }
          req.method == "DELETE" && path == "/repos/devuser/$createdRepoName" -> {
            eventsOrder.add("DELETE_REPO")
            emptyResp(req, 204)
          }
          else -> error("Unexpected HTTP ${req.method} $path")
        }
      })
      .build()

    val tokenChars = "ghu_live_ephemeral_secret".toCharArray()
    val emittedStates = GitHubBuildModule.buildUnsignedBinary(
      context = context,
      sourceProject = sourceTarget,
      token = tokenChars,
      targetFormat = BuildOutputFormat.APK_ONLY,
      httpClient = fakeClient,
      apiBaseUrl = "https://api.github.test",
      pollIntervalMs = 1L,
      wipeTokenOnCompletion = true,
    ).toList()

    assertTrue("Repo must be private=true", repoWasPrivate)
    assertTrue("Repo must follow shipsign-tmp-* naming", createdRepoName.startsWith("shipsign-tmp-"))
    assertTrue(dispatchPath.endsWith("/workflows/shipsign-build-apk.yml/dispatches"))
    assertTrue(dispatchBody.contains(""""ref":"main""""))

    val stages = emittedStates.filterIsInstance<CloudBuildState.StageProgress>().map { it.stage }.toSet()
    assertTrue(CloudBuildStage.PREPARING_ARCHIVE in stages)
    assertTrue(CloudBuildStage.CREATING_EPHEMERAL_REPO in stages)
    assertTrue(CloudBuildStage.PUSHING_SOURCES in stages)
    assertTrue(CloudBuildStage.DISPATCHING_WORKFLOW in stages)
    assertTrue(CloudBuildStage.POLLING_BUILD in stages)
    assertTrue(CloudBuildStage.DOWNLOADING_AND_WIPING in stages)

    val ready = emittedStates.last() as CloudBuildState.ReadyForOfflineSigning
    assertTrue(ready.repoDeleted)
    assertEquals(1, ready.availableTargets.size)
    assertEquals(ResolvedBinaryType.APK, ready.targetFile.binaryType)
    assertEquals("app-release-unsigned.apk", ready.targetFile.originalName)
    assertFalse(ready.targetFile.isAlreadySigned)

    // Keystores and IDE metadata MUST NEVER be uploaded
    assertFalse(uploadedTreeJson.contains("release.jks"))
    assertFalse(uploadedTreeJson.contains("key.properties"))
    assertFalse(uploadedTreeJson.contains("metadata.json"))
    assertFalse(uploadedTreeJson.contains(".cursor"))
    assertTrue(uploadedTreeJson.contains("app/build.gradle.kts"))
    assertTrue(uploadedTreeJson.contains(".github/workflows/shipsign-build-apk.yml"))

    val dlIndex = eventsOrder.indexOf("DOWNLOAD_ARTIFACT")
    val delIndex = eventsOrder.indexOf("DELETE_REPO")
    assertTrue(dlIndex >= 0 && delIndex > dlIndex)
    assertTrue(tokenChars.all { it == '\u0000' })
  }

  @Test
  fun `GitHubBuildModule executes BOTH build with shipsign-build-both yml and extracts both APK and AAB`() = runBlocking {
    val sourceZip = createSourceZipWithAccidentalKeystoreAndIdeMetadata()
    val sourceTarget = AppTargetFile(
      sessionFile = sourceZip,
      originalName = "my-android-project.zip",
      sizeBytes = sourceZip.length(),
      binaryType = ResolvedBinaryType.SOURCE_CODE_PROJECT,
      isAlreadySigned = false,
      detectedStack = ProjectStack.ANDROID_GRADLE,
      sourceMetadata = SourceProjectMetadata(
        framework = ProjectFramework.NATIVE_ANDROID,
        projectRootPrefix = "MyApp/",
      ),
    )

    val artifactZipBytes = createArtifactZip(includeApk = true, includeAab = true)
    var uploadedTreeJson = ""
    var dispatchPath = ""
    var repoDeleted = false

    val fakeClient = OkHttpClient.Builder()
      .addInterceptor(Interceptor { chain ->
        val req = chain.request()
        val path = req.url.encodedPath
        val bodyBuf = Buffer()
        req.body?.writeTo(bodyBuf)
        val reqBody = bodyBuf.readUtf8()

        when {
          req.method == "POST" && path == "/user/repos" -> {
            jsonResp(req, 201, """{"name":"shipsign-tmp-both","full_name":"devuser/shipsign-tmp-both","private":true,"default_branch":"main"}""")
          }
          req.method == "GET" && path.endsWith("/git/refs/heads/main") -> {
            jsonResp(req, 200, """{"ref":"refs/heads/main","object":{"sha":"head_sha_0"}}""")
          }
          req.method == "POST" && path.endsWith("/git/blobs") -> jsonResp(req, 201, """{"sha":"b1"}""")
          req.method == "POST" && path.endsWith("/git/trees") -> {
            uploadedTreeJson = reqBody
            jsonResp(req, 201, """{"sha":"t1"}""")
          }
          req.method == "POST" && path.endsWith("/git/commits") -> jsonResp(req, 201, """{"sha":"c1"}""")
          req.method == "PATCH" && path.endsWith("/git/refs/heads/main") -> jsonResp(req, 200, """{"ref":"refs/heads/main","object":{"sha":"c1"}}""")
          req.method == "POST" && path.endsWith("/dispatches") -> {
            dispatchPath = path
            emptyResp(req, 204)
          }
          req.method == "GET" && path.endsWith("/actions/runs") -> {
            jsonResp(req, 200, """{"workflow_runs":[{"id":9002,"status":"completed","conclusion":"success"}]}""")
          }
          req.method == "GET" && path.endsWith("/actions/runs/9002/artifacts") -> {
            jsonResp(
              req,
              200,
              """{"artifacts":[{"id":88,"name":"ShipSign-Bundle","expired":false,"archive_download_url":"https://api.github.test/artifacts/88/zip"}]}""",
            )
          }
          req.method == "GET" && path == "/artifacts/88/zip" -> {
            Response.Builder()
              .request(req)
              .protocol(Protocol.HTTP_1_1)
              .code(200)
              .message("OK")
              .body(artifactZipBytes.toResponseBody("application/zip".toMediaType()))
              .build()
          }
          req.method == "DELETE" && path == "/repos/devuser/shipsign-tmp-both" -> {
            repoDeleted = true
            emptyResp(req, 204)
          }
          else -> error("Unexpected HTTP ${req.method} $path")
        }
      })
      .build()

    val tokenChars = "ghu_both_token".toCharArray()
    val emittedStates = GitHubBuildModule.buildUnsignedBinary(
      context = context,
      sourceProject = sourceTarget,
      token = tokenChars,
      targetFormat = BuildOutputFormat.BOTH,
      httpClient = fakeClient,
      apiBaseUrl = "https://api.github.test",
      pollIntervalMs = 1L,
      wipeTokenOnCompletion = true,
    ).toList()

    assertTrue(uploadedTreeJson.contains(".github/workflows/shipsign-build-both.yml"))
    assertTrue(dispatchPath.endsWith("/workflows/shipsign-build-both.yml/dispatches"))
    assertTrue(repoDeleted)

    val ready = emittedStates.last() as CloudBuildState.ReadyForOfflineSigning
    assertEquals(2, ready.availableTargets.size)
    assertEquals(ResolvedBinaryType.APK, ready.availableTargets[0].binaryType)
    assertEquals(ResolvedBinaryType.AAB, ready.availableTargets[1].binaryType)
    assertTrue(ready.availableTargets[0].sessionFile.exists())
    assertTrue(ready.availableTargets[1].sessionFile.exists())
    assertTrue(tokenChars.all { it == '\u0000' })
  }

  @Test
  fun `GitHubBuildModule fetches failed job logs before deleting ephemeral private repo in finally`() = runBlocking {
    val sourceZip = createSourceZipWithAccidentalKeystoreAndIdeMetadata()
    val sourceTarget = AppTargetFile(
      sessionFile = sourceZip,
      originalName = "my-app.zip",
      sizeBytes = sourceZip.length(),
      binaryType = ResolvedBinaryType.SOURCE_CODE_PROJECT,
      isAlreadySigned = false,
      detectedStack = ProjectStack.ANDROID_GRADLE,
      sourceMetadata = SourceProjectMetadata(
        framework = ProjectFramework.NATIVE_ANDROID,
        projectRootPrefix = "MyApp/",
      ),
    )

    var deleteCalledCount = 0
    var logsFetched = false
    val fakeClient = OkHttpClient.Builder()
      .addInterceptor(Interceptor { chain ->
        val req = chain.request()
        val path = req.url.encodedPath
        when {
          req.method == "POST" && path == "/user/repos" -> {
            jsonResp(req, 201, """{"name":"shipsign-tmp-fail","full_name":"dev/shipsign-tmp-fail","private":true,"default_branch":"main"}""")
          }
          req.method == "GET" && path.endsWith("/git/refs/heads/main") -> {
            jsonResp(req, 200, """{"ref":"refs/heads/main","object":{"sha":"head0"}}""")
          }
          req.method == "POST" && path.endsWith("/git/blobs") -> jsonResp(req, 201, """{"sha":"b1"}""")
          req.method == "POST" && path.endsWith("/git/trees") -> jsonResp(req, 201, """{"sha":"t1"}""")
          req.method == "POST" && path.endsWith("/git/commits") -> jsonResp(req, 201, """{"sha":"c1"}""")
          req.method == "PATCH" && path.endsWith("/git/refs/heads/main") -> jsonResp(req, 200, """{"ref":"refs/heads/main","object":{"sha":"c1"}}""")
          req.method == "POST" && path.endsWith("/dispatches") -> emptyResp(req, 204)
          req.method == "GET" && path.endsWith("/actions/runs") -> {
            jsonResp(req, 200, """{"workflow_runs":[{"id":555,"status":"completed","conclusion":"failure"}]}""")
          }
          req.method == "GET" && path.endsWith("/actions/runs/555/jobs") -> {
            jsonResp(req, 200, """{"jobs":[{"id":777,"name":"build","conclusion":"failure"}]}""")
          }
          req.method == "GET" && path.endsWith("/actions/jobs/777/logs") -> {
            logsFetched = true
            Response.Builder()
              .request(req)
              .protocol(Protocol.HTTP_1_1)
              .code(200)
              .message("OK")
              .body("FAILURE: Execution failed for task ':app:compileReleaseKotlin'.".toResponseBody("text/plain".toMediaType()))
              .build()
          }
          req.method == "DELETE" && path == "/repos/dev/shipsign-tmp-fail" -> {
            deleteCalledCount++
            emptyResp(req, 204)
          }
          else -> error("Unexpected HTTP ${req.method} $path")
        }
      })
      .build()

    val tokenChars = "ghu_fail_cleanup_token".toCharArray()
    val states = GitHubBuildModule.buildUnsignedBinary(
      context = context,
      sourceProject = sourceTarget,
      token = tokenChars,
      targetFormat = BuildOutputFormat.AAB_ONLY,
      httpClient = fakeClient,
      apiBaseUrl = "https://api.github.test",
      pollIntervalMs = 1L,
      wipeTokenOnCompletion = true,
    ).toList()

    val failed = states.last() as CloudBuildState.Failed
    assertTrue("Failed job logs must be fetched before repo cleanup", logsFetched)
    assertTrue(failed.error.message.orEmpty().contains("compileReleaseKotlin"))
    assertTrue("Ephemeral private repo must be deleted on failure", failed.repoDeleted)
    assertEquals(1, deleteCalledCount)
    assertTrue(tokenChars.all { it == '\u0000' })
  }

  @Test
  fun `GitHubBuildModule emits RepositoryAccessRequired on HTTP 403 or 404`() = runBlocking {
    val sourceZip = createSourceZipWithAccidentalKeystoreAndIdeMetadata()
    val sourceTarget = AppTargetFile(
      sessionFile = sourceZip,
      originalName = "my-app.zip",
      sizeBytes = sourceZip.length(),
      binaryType = ResolvedBinaryType.SOURCE_CODE_PROJECT,
      isAlreadySigned = false,
      detectedStack = ProjectStack.ANDROID_GRADLE,
      sourceMetadata = SourceProjectMetadata(
        framework = ProjectFramework.NATIVE_ANDROID,
        projectRootPrefix = "MyApp/",
      ),
    )

    val fakeClient = OkHttpClient.Builder()
      .addInterceptor(Interceptor { chain ->
        val req = chain.request()
        jsonResp(req, 403, """{"message":"Resource not accessible by integration"}""")
      })
      .build()

    val tokenChars = "ghu_403_token".toCharArray()
    val states = GitHubBuildModule.buildUnsignedBinary(
      context = context,
      sourceProject = sourceTarget,
      token = tokenChars,
      httpClient = fakeClient,
      apiBaseUrl = "https://api.github.test",
      pollIntervalMs = 1L,
      wipeTokenOnCompletion = true,
    ).toList()

    val reqAccess = states.last() as CloudBuildState.RepositoryAccessRequired
    assertEquals(403, reqAccess.httpCode)
    assertTrue(tokenChars.all { it == '\u0000' })
  }

  private fun jsonResp(req: okhttp3.Request, code: Int, json: String): Response =
    Response.Builder()
      .request(req)
      .protocol(Protocol.HTTP_1_1)
      .code(code)
      .message(if (code in 200..299) "OK" else "Error")
      .body(json.toResponseBody("application/json".toMediaType()))
      .build()

  private fun emptyResp(req: okhttp3.Request, code: Int): Response =
    Response.Builder()
      .request(req)
      .protocol(Protocol.HTTP_1_1)
      .code(code)
      .message("No Content")
      .body(ByteArray(0).toResponseBody(null))
      .build()

  private fun createSourceZipWithAccidentalKeystoreAndIdeMetadata(): File {
    val zipFile = File(sessionDir, "source_proj.zip")
    ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
      zos.putNextEntry(ZipEntry("MyApp/app/build.gradle.kts"))
      zos.write("android { defaultConfig { applicationId = \"com.demo.app\" } }".toByteArray())
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("MyApp/gradlew"))
      zos.write("#!/bin/sh\necho gradle".toByteArray())
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("MyApp/app/src/main/java/App.kt"))
      zos.write("class App".toByteArray())
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("MyApp/metadata.json"))
      zos.write("""{"name":"ide"}""".toByteArray())
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("MyApp/.cursor/config.json"))
      zos.write("{}".toByteArray())
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("MyApp/app/release.jks"))
      zos.write(byteArrayOf(0xFE.toByte(), 0xED.toByte(), 0xFE.toByte(), 0xED.toByte()))
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("MyApp/key.properties"))
      zos.write("storePassword=DO_NOT_LEAK".toByteArray())
      zos.closeEntry()
    }
    return zipFile
  }

  private fun createArtifactZip(includeApk: Boolean, includeAab: Boolean): ByteArray {
    val artifactZip = ByteArrayOutputStream()
    ZipOutputStream(artifactZip).use { zos ->
      if (includeApk) {
        val apkOut = ByteArrayOutputStream()
        ZipOutputStream(apkOut).use { apkZos ->
          apkZos.putNextEntry(ZipEntry("AndroidManifest.xml"))
          apkZos.write(byteArrayOf(0x03, 0x00, 0x08, 0x00, 0x24, 0x00, 0x00, 0x00))
          apkZos.closeEntry()
          apkZos.putNextEntry(ZipEntry("classes.dex"))
          apkZos.write(ByteArray(32) { 0x11 })
          apkZos.closeEntry()
        }
        zos.putNextEntry(ZipEntry("app/build/outputs/apk/release/app-release-unsigned.apk"))
        zos.write(apkOut.toByteArray())
        zos.closeEntry()
      }
      if (includeAab) {
        val aabOut = ByteArrayOutputStream()
        ZipOutputStream(aabOut).use { aabZos ->
          aabZos.putNextEntry(ZipEntry("BundleConfig.pb"))
          aabZos.write(byteArrayOf(0x0A, 0x05, 0x31, 0x2E, 0x31, 0x37, 0x00))
          aabZos.closeEntry()
          aabZos.putNextEntry(ZipEntry("base/manifest/AndroidManifest.xml"))
          aabZos.write(ByteArray(16) { 0x22 })
          aabZos.closeEntry()
        }
        zos.putNextEntry(ZipEntry("app/build/outputs/bundle/release/app-release.aab"))
        zos.write(aabOut.toByteArray())
        zos.closeEntry()
      }
    }
    return artifactZip.toByteArray()
  }
}
