package com.shipsign.app

import android.content.Context
import android.graphics.Bitmap
import androidx.test.core.app.ApplicationProvider
import com.shipsign.app.core.engine.AabProtoCodec
import com.shipsign.app.core.engine.AxmlBinaryEditor
import com.shipsign.app.core.engine.FormatConverterEngine
import com.shipsign.app.core.engine.PackageCustomizationRequest
import com.shipsign.app.core.engine.PackageCustomizerEngine
import com.shipsign.app.core.engine.PackageInfoInspector
import com.shipsign.app.core.security.KeystoreVaultManager
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.core.storage.ProjectHistoryRepository
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.domain.model.ResolvedBinaryType
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class OfflineEnginesAndVaultTest {

  private lateinit var context: Context

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    ZeroTraceManager.nukeCurrentSession(context)
    KeystoreVaultManager.clearAllForTesting(context)
    ProjectHistoryRepository.clearAllForTesting(context)
  }

  @After
  fun tearDown() {
    ZeroTraceManager.nukeCurrentSession(context)
    KeystoreVaultManager.clearAllForTesting(context)
    ProjectHistoryRepository.clearAllForTesting(context)
  }

  private fun createSyntheticApk(
    packageName: String = "com.shipsign.demo",
    appName: String = "Demo App",
    versionCode: Long = 10L,
    versionName: String = "1.0.0",
  ): File {
    val file = ZeroTraceManager.allocateTempFile(context, "test_app", ".apk")
    val axml = AxmlBinaryEditor.createMinimalBinaryManifest(
      packageName = packageName,
      appLabel = appName,
      versionCode = versionCode,
      versionName = versionName,
    )
    ZipOutputStream(FileOutputStream(file)).use { zos ->
      zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
      zos.write(axml)
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("classes.dex"))
      zos.write(byteArrayOf(0x64, 0x65, 0x78, 0x0A, 0x30, 0x33, 0x35, 0x00))
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("res/mipmap-hdpi/ic_launcher.png"))
      zos.write(byteArrayOf(1, 2, 3, 4))
      zos.closeEntry()
    }
    return file
  }

  private fun createSamplePngBytes(): ByteArray {
    val bmp = Bitmap.createBitmap(64, 64, Bitmap.Config.ARGB_8888)
    bmp.eraseColor(0xFF2EA043.toInt())
    val out = ByteArrayOutputStream()
    bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
    bmp.recycle()
    return out.toByteArray()
  }

  @Test
  fun `PackageInfoInspector and PackageCustomizerEngine patch APK manifest metadata and launcher icon offline`() = runBlocking {
    val apk = createSyntheticApk()
    val initialInfo = PackageInfoInspector.inspectPackage(context, apk, ResolvedBinaryType.APK, "fallback")
    assertEquals("Demo App", initialInfo.appName)
    assertEquals("com.shipsign.demo", initialInfo.packageId)
    assertEquals(10L, initialInfo.versionCode)
    assertEquals("1.0.0", initialInfo.versionName)
    assertFalse(initialInfo.isSigned)

    val target = AppTargetFile(
      sessionFile = apk,
      originalName = "demo.apk",
      sizeBytes = apk.length(),
      binaryType = ResolvedBinaryType.APK,
      isAlreadySigned = false,
      detectedStack = null,
      packageInfo = initialInfo,
    )

    val customized = PackageCustomizerEngine.customizePackage(
      context = context,
      target = target,
      request = PackageCustomizationRequest(
        appName = "ShipSign Pro",
        packageName = "com.shipsign.pro",
        versionCode = 42L,
        versionName = "2.5.0",
        iconImageBytes = createSamplePngBytes(),
      ),
    )

    val patchedInfo = customized.packageInfo
    assertNotNull(patchedInfo)
    assertEquals("ShipSign Pro", patchedInfo!!.appName)
    assertEquals("com.shipsign.pro", patchedInfo.packageId)
    assertEquals(42L, patchedInfo.versionCode)
    assertEquals("2.5.0", patchedInfo.versionName)

    ZipFile(customized.sessionFile).use { zip ->
      val iconEntry = zip.getEntry("res/mipmap-hdpi/ic_launcher.png")
      assertNotNull(iconEntry)
      val bytes = zip.getInputStream(iconEntry).use { it.readBytes() }
      assertTrue("Launcher PNG should be replaced with valid PNG header", bytes.size > 16)
      assertEquals(0x89.toByte(), bytes[0])
      assertEquals(0x50.toByte(), bytes[1])
    }
  }

  @Test
  fun `FormatConverterEngine converts APK to AAB and back to APK offline while preserving manifest metadata`() = runBlocking {
    val apk = createSyntheticApk(
      packageName = "com.shipsign.convert",
      appName = "Convert Me",
      versionCode = 7L,
      versionName = "1.7",
    )
    val apkInfo = PackageInfoInspector.inspectPackage(context, apk, ResolvedBinaryType.APK, "fallback")
    val apkTarget = AppTargetFile(
      sessionFile = apk,
      originalName = "convert.apk",
      sizeBytes = apk.length(),
      binaryType = ResolvedBinaryType.APK,
      isAlreadySigned = false,
      detectedStack = null,
      packageInfo = apkInfo,
    )

    // APK -> AAB
    val aabTarget = FormatConverterEngine.convertPackage(context, apkTarget)
    assertEquals(ResolvedBinaryType.AAB, aabTarget.binaryType)
    assertTrue(aabTarget.sessionFile.exists())
    assertEquals("Convert Me", aabTarget.packageInfo?.appName)
    assertEquals("com.shipsign.convert", aabTarget.packageInfo?.packageId)
    assertEquals(7L, aabTarget.packageInfo?.versionCode)
    assertEquals("1.7", aabTarget.packageInfo?.versionName)

    ZipFile(aabTarget.sessionFile).use { zip ->
      assertNotNull(zip.getEntry("BundleConfig.pb"))
      assertNotNull(zip.getEntry("base/manifest/AndroidManifest.xml"))
      assertNotNull(zip.getEntry("base/resources.pb"))
      assertNotNull(zip.getEntry("base/dex/classes.dex"))
    }

    // Customize the AAB offline (protobuf XmlNode patching)
    val patchedAab = PackageCustomizerEngine.customizePackage(
      context = context,
      target = aabTarget,
      request = PackageCustomizationRequest(
        appName = "Patched Bundle",
        packageName = "com.shipsign.bundle",
        versionCode = 99L,
        versionName = "9.9",
      ),
    )
    assertEquals("Patched Bundle", patchedAab.packageInfo?.appName)
    assertEquals("com.shipsign.bundle", patchedAab.packageInfo?.packageId)
    assertEquals(99L, patchedAab.packageInfo?.versionCode)
    assertEquals("9.9", patchedAab.packageInfo?.versionName)

    // AAB -> APK
    val backToApk = FormatConverterEngine.convertPackage(context, patchedAab)
    assertEquals(ResolvedBinaryType.APK, backToApk.binaryType)
    assertEquals("Patched Bundle", backToApk.packageInfo?.appName)
    assertEquals("com.shipsign.bundle", backToApk.packageInfo?.packageId)
    assertEquals(99L, backToApk.packageInfo?.versionCode)
    assertEquals("9.9", backToApk.packageInfo?.versionName)

    // Verify AabProtoCodec round-trip preserves structure
    ZipFile(patchedAab.sessionFile).use { zip ->
      val protoBytes = zip.getInputStream(zip.getEntry("base/manifest/AndroidManifest.xml")).use { it.readBytes() }
      val parsed = AabProtoCodec.parseXmlNode(protoBytes)
      assertEquals("manifest", parsed.element?.name)
    }
  }

  @Test
  fun `KeystoreVaultManager creates, unlocks, wipes passwords, and deletes offline RSA-2048 keystores`() = runBlocking {
    val storePass = "VaultPass!234".toCharArray()
    val keyPass = "VaultPass!234".toCharArray()

    val created = KeystoreVaultManager.createNewVaultKeystore(
      context = context,
      request = KeystoreCreateRequest(
        format = KeystoreFormat.PKCS12,
        fileName = "release-key",
        storePassword = storePass,
        keyAlias = "upload",
        keyPassword = keyPass,
        validityDays = 3650,
        commonName = "ShipSign Dev",
        organizationalUnit = "Engineering",
        organization = "ShipSign",
        cityLocality = "Austin",
        stateProvince = "TX",
        countryCode = "US",
      ),
    )

    // Input CharArrays must be wiped immediately
    assertTrue(storePass.all { it == '\u0000' })
    assertTrue(keyPass.all { it == '\u0000' })
    assertTrue(File(created.filePath).exists())
    assertTrue(created.sha256Fingerprint.contains(":"))
    assertEquals(1, KeystoreVaultManager.listKeystores(context).size)

    val unlocked = KeystoreVaultManager.unlockVaultKeystore(context, created.id)
    assertEquals("upload", unlocked.keyAlias)
    assertEquals("VaultPass!234", String(unlocked.storePassword))
    ZeroTraceManager.wipeCharArray(unlocked.storePassword)
    ZeroTraceManager.wipeCharArray(unlocked.keyPassword)

    KeystoreVaultManager.deleteVaultKeystore(context, created.id)
    assertFalse(File(created.filePath).exists())
    assertEquals(0, KeystoreVaultManager.listKeystores(context).size)
  }

  @Test
  fun `ProjectHistoryRepository persists artifacts offline, tracks cloud trace cleanup, and deletes cleanly`() = runBlocking {
    val apk = createSyntheticApk(appName = "Vaulted App", packageName = "com.shipsign.vaulted")
    val info = PackageInfoInspector.inspectPackage(context, apk, ResolvedBinaryType.APK, "Vaulted App")

    val saved = ProjectHistoryRepository.saveArtifact(
      context = context,
      sourceFile = apk,
      outputFileName = "vaulted-app.apk",
      packageInfo = info,
      format = ResolvedBinaryType.APK,
      isSigned = false,
      cloudRepoFullName = "devuser/shipsign-tmp-1234",
    )

    assertTrue(File(saved.filePath).exists())
    assertTrue(saved.hasUncleanedCloudTrace)
    assertEquals(1, ProjectHistoryRepository.listProjects(context).size)

    ProjectHistoryRepository.markCloudTraceCleared(context, "devuser/shipsign-tmp-1234")
    val afterCleanup = ProjectHistoryRepository.listProjects(context).first()
    assertFalse(afterCleanup.hasUncleanedCloudTrace)
    assertTrue(afterCleanup.cloudTraceCleared)

    ProjectHistoryRepository.deleteProject(context, saved.id)
    assertFalse(File(saved.filePath).exists())
    assertEquals(0, ProjectHistoryRepository.listProjects(context).size)
  }
}
