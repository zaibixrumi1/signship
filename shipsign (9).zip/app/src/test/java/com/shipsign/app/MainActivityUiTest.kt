package com.shipsign.app

import android.view.WindowManager
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import com.shipsign.app.core.security.KeystoreVaultManager
import com.shipsign.app.core.storage.ProjectHistoryRepository
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h891dp-xxhdpi")
class MainActivityUiTest {

  @get:Rule
  val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Before
  fun setUp() {
    KeystoreVaultManager.clearAllForTesting(composeTestRule.activity)
    ProjectHistoryRepository.clearAllForTesting(composeTestRule.activity)
  }

  @After
  fun tearDown() {
    KeystoreVaultManager.clearAllForTesting(composeTestRule.activity)
    ProjectHistoryRepository.clearAllForTesting(composeTestRule.activity)
  }

  @Test
  fun `launch MainActivity and verify Splash to editorial 3-card Home, 01-03 Source radio + Continue, PreviousProjects, and Offline Keystore Vault`() {
    // Screenshots must be allowed everywhere (FLAG_SECURE must never be set)
    assertEquals(
      0,
      composeTestRule.activity.window.attributes.flags and WindowManager.LayoutParams.FLAG_SECURE,
    )

    // Wait for Splash -> Home auto-transition
    composeTestRule.waitUntil(timeoutMillis = 10_000L) {
      composeTestRule.onAllNodesWithTag("home_start_project_card").fetchSemanticsNodes().isNotEmpty()
    }

    // Home has ONLY the 3 editorial primary cards
    composeTestRule.onNodeWithTag("home_start_project_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_previous_projects_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_create_keystore_card").assertIsDisplayed()

    // 01 Start Your Project -> 01 / 03 — SOURCE (radio cards + Continue button)
    composeTestRule.onNodeWithTag("home_start_project_card").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("branch_source_zip_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("branch_apk_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("branch_aab_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("start_project_continue_button").assertIsDisplayed()

    // Select Built APK radio card and tap Continue -> 02 / 03 Built APK screen
    composeTestRule.onNodeWithTag("branch_apk_card").performClick()
    composeTestRule.onNodeWithTag("start_project_continue_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("package_upload_card").assertIsDisplayed()

    // Navigate back to Home
    composeTestRule.onNodeWithTag("top_back_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("top_back_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("home_previous_projects_card").assertIsDisplayed()

    // 02 Previous Projects (Offline Vault)
    composeTestRule.onNodeWithTag("home_previous_projects_card").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("previous_projects_empty_card").assertIsDisplayed()

    // Navigate back to Home
    composeTestRule.onNodeWithTag("top_back_button").performClick()
    composeTestRule.waitForIdle()

    // 03 Create Keystore (Offline) -> Create New PKCS12 offline
    composeTestRule.onNodeWithTag("home_create_keystore_card").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("vault_tab_create").assertIsDisplayed()
    composeTestRule.onNodeWithTag("vault_tab_import").assertIsDisplayed()

    composeTestRule.onNodeWithTag("vault_create_password_input").performTextInput("StrongPass123!")
    composeTestRule.onNodeWithTag("keystore_vault_list")
      .performScrollToNode(hasTestTag("vault_create_submit_button"))
    composeTestRule.onNodeWithTag("vault_create_submit_button").performClick()

    composeTestRule.waitUntil(timeoutMillis = 15_000L) {
      composeTestRule.onAllNodesWithTag("vault_status_banner").fetchSemanticsNodes().isNotEmpty()
    }
    composeTestRule.onNodeWithTag("vault_status_banner").assertIsDisplayed()
    assertEquals(1, KeystoreVaultManager.listKeystores(composeTestRule.activity).size)
  }
}
