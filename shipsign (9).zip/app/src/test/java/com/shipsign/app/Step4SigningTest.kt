package com.shipsign.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.android.apksig.ApkVerifier
import com.android.apksig.apk.ApkFormatException
import com.shipsign.app.core.engine.AxmlBinaryEditor
import com.shipsign.app.core.engine.BundleToolEngine
import com.shipsign.app.core.engine.ErrorTranslator
import com.shipsign.app.core.engine.FormatConverterEngine
import com.shipsign.app.core.engine.KeystoreGenerator
import com.shipsign.app.core.engine.PackageCustomizationRequest
import com.shipsign.app.core.engine.PackageCustomizerEngine
import com.shipsign.app.core.engine.SignatureScanner
import com.shipsign.app.core.engine.SigningEngine
import com.shipsign.app.core.engine.ZipAlignEngine
import com.shipsign.app.core.security.KeystoreDetector
import com.shipsign.app.core.security.UnsupportedKeystoreException
import com.shipsign.app.core.security.WrongAliasException
import com.shipsign.app.core.security.WrongPasswordException
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ImportedKeystoreConfig
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.domain.model.SigningOptions
import com.shipsign.app.domain.model.SigningResult
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.UnrecoverableKeyException
import java.util.jar.JarFile
import java.util.zip.CRC32
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Step4SigningTest {

  private lateinit var context: Context
  private lateinit var sessionDir: File

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    ZeroTraceManager.nukeAllSync(context)
    sessionDir = ZeroTraceManager.createOrGetSessionDir(context)
  }

  @After
  fun tearDown() {
    ZeroTraceManager.nukeAllSync(context)
  }

  @Test
  fun `ZipAlignEngine aligns STORED entries to 4 bytes and native so libraries to 16KB`() {
    val unalignedApk = File(sessionDir, "unaligned.apk")
    val alignedApk = File(sessionDir, "aligned.apk")

    val manifestBytes = byteArrayOf(0x03, 0x00, 0x08, 0x00, 0x01, 0x02, 0x03)
    val arscBytes = ByteArray(137) { (it % 127).toByte() }
    val soBytes = ByteArray(513) { (0x7F xor (it and 0xFF)).toByte() }

    ZipOutputStream(FileOutputStream(unalignedApk)).use { zos ->
      zos.putNextEntry(ZipEntry("AndroidManifest.xml").apply { method = ZipEntry.DEFLATED })
      zos.write(manifestBytes)
      zos.closeEntry()

      writeStoredEntry(zos, "resources.arsc", arscBytes)
      writeStoredEntry(zos, "lib/arm64-v8a/libtest.so", soBytes)
    }

    val ok = ZipAlignEngine.alignApk(
      inputApk = unalignedApk,
      outputApk = alignedApk,
      alignment = 4,
      pageAlignSharedLibs = true,
    )
    assertTrue(ok)
    assertTrue(alignedApk.exists())

    val dataOffsets = readLocalHeaderDataOffsets(alignedApk)
    val arscOffset = dataOffsets["resources.arsc"]!!
    val soOffset = dataOffsets["lib/arm64-v8a/libtest.so"]!!

    assertEquals("resources.arsc must be 4-byte aligned", 0L, arscOffset % 4L)
    assertEquals("native .so must be 16KB aligned", 0L, soOffset % 16_384L)

    // Ensure ZIP contents were preserved verbatim
    ZipFile(alignedApk).use { zf ->
      val readArsc = zf.getInputStream(zf.getEntry("resources.arsc")).readBytes()
      val readSo = zf.getInputStream(zf.getEntry("lib/arm64-v8a/libtest.so")).readBytes()
      assertTrue(arscBytes.contentEquals(readArsc))
      assertTrue(soBytes.contentEquals(readSo))
    }
  }

  @Test
  fun `SigningEngine aligns and signs APK with JKS and PKCS12 and verifies via ApkVerifier`() = runBlocking {
    val unsignedApk = createMinimalSignableApk("app-release-unsigned.apk")

    for (format in listOf(KeystoreFormat.JKS, KeystoreFormat.PKCS12)) {
      val storePass = "ShipSignStore!9".toCharArray()
      val keyPass = "ShipSignKey!7".toCharArray()
      val ksFile = KeystoreGenerator.generateKeystore(
        KeystoreCreateRequest(
          format = format,
          fileName = "test_${format.name.lowercase()}",
          storePassword = storePass,
          keyAlias = "upload",
          keyPassword = keyPass,
          commonName = "ShipSign Signer",
          organizationalUnit = "Release",
          organization = "ShipSign",
          cityLocality = "San Francisco",
          stateProvince = "CA",
          countryCode = "US",
        ),
        sessionDir,
      )

      val target = AppTargetFile(
        sessionFile = unsignedApk,
        originalName = "app-release-unsigned.apk",
        sizeBytes = unsignedApk.length(),
        binaryType = ResolvedBinaryType.APK,
        isAlreadySigned = false,
        detectedStack = null,
      )
      val ksConfig = ImportedKeystoreConfig(
        tempKeystoreFile = ksFile,
        detectedFormat = format,
        storePassword = "ShipSignStore!9".toCharArray(),
        keyAlias = "upload",
        keyPassword = "ShipSignKey!7".toCharArray(),
      )

      var capturedResult: SigningResult? = null
      val logs = SigningEngine.signWithLogs(
        context = context,
        target = target,
        keystoreConfig = ksConfig,
        options = SigningOptions(
          v1Enabled = true,
          v2Enabled = true,
          v3Enabled = true,
          v4Enabled = true,
          zipAlignBeforeSign = true,
        ),
        onResult = { capturedResult = it },
      ).toList()

      assertTrue(logs.any { it.contains("Aligning APK") })
      assertTrue(logs.any { it.contains("Signing APK with v1/v2/v3/v4") })
      assertTrue(logs.any { it.contains("Verifying cryptographic signature integrity") })

      val result = capturedResult
      assertNotNull(result)
      assertEquals("app-release-unsigned-signed.apk", result!!.primaryFileName)
      assertTrue(result.sha1Fingerprint.matches(Regex("([0-9A-F]{2}:){19}[0-9A-F]{2}")))
      assertTrue(result.sha256Fingerprint.matches(Regex("([0-9A-F]{2}:){31}[0-9A-F]{2}")))

      // Re-read exported APK via ContentResolver and verify via ApkVerifier
      val exportedCopy = File(sessionDir, "verify_${format.name}.apk")
      context.contentResolver.openInputStream(result.primarySignedUri)!!.use { input ->
        FileOutputStream(exportedCopy).use { out -> input.copyTo(out) }
      }
      val verifyResult = ApkVerifier.Builder(exportedCopy)
        .setMinCheckedPlatformVersion(21)
        .build()
        .verify()
      assertTrue("ApkVerifier must verify ${format.name} signed APK", verifyResult.isVerified)
      assertTrue(verifyResult.isVerifiedUsingV1Scheme)
      assertTrue(verifyResult.isVerifiedUsingV2Scheme)
      assertTrue(verifyResult.isVerifiedUsingV3Scheme)
      assertTrue(verifyResult.signerCertificates.isNotEmpty())
    }
  }

  @Test
  fun `SigningEngine signs AAB with BouncyCastle JAR signature and passes JarFile verification`() {
    val rawAab = File(sessionDir, "app-release.aab")
    ZipOutputStream(FileOutputStream(rawAab)).use { zos ->
      zos.putNextEntry(ZipEntry("base/manifest/AndroidManifest.xml"))
      zos.write(byteArrayOf(0x0A, 0x04, 0x74, 0x65, 0x73, 0x74))
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("base/dex/classes.dex"))
      zos.write(ByteArray(256) { (it % 61).toByte() })
      zos.closeEntry()
    }

    val jksFile = KeystoreGenerator.generateKeystore(
      KeystoreCreateRequest(
        format = KeystoreFormat.JKS,
        fileName = "aab_signer",
        storePassword = "BundleStore!1".toCharArray(),
        keyAlias = "bundle_key",
        keyPassword = "BundleKey!2".toCharArray(),
        commonName = "Bundle Signer",
        organizationalUnit = "Mobile",
        organization = "ShipSign",
        cityLocality = "San Francisco",
        stateProvince = "CA",
        countryCode = "US",
      ),
      sessionDir,
    )

    val creds = KeystoreDetector.validateKeystoreCredentials(
      ImportedKeystoreConfig(
        tempKeystoreFile = jksFile,
        detectedFormat = KeystoreFormat.JKS,
        storePassword = "BundleStore!1".toCharArray(),
        keyAlias = "bundle_key",
        keyPassword = "BundleKey!2".toCharArray(),
      )
    )

    val signedAab = File(sessionDir, "app-release-signed.aab")
    SigningEngine.signJarArchiveWithBouncyCastle(rawAab, signedAab, creds)

    assertTrue(signedAab.exists())
    JarFile(signedAab, true).use { jar ->
      val manifestEntry = jar.getJarEntry("META-INF/MANIFEST.MF")
      val sfEntry = jar.getJarEntry("META-INF/CERT.SF")
      val rsaEntry = jar.getJarEntry("META-INF/CERT.RSA")
      assertNotNull(manifestEntry)
      assertNotNull(sfEntry)
      assertNotNull(rsaEntry)

      val entries = jar.entries()
      var verifiedContentCount = 0
      while (entries.hasMoreElements()) {
        val entry = entries.nextElement()
        if (!entry.isDirectory) {
          jar.getInputStream(entry).use { it.readBytes() }
          if (!entry.name.startsWith("META-INF/")) {
            assertFalse(
              "Certificates must verify for ${entry.name}",
              entry.certificates.isNullOrEmpty(),
            )
            verifiedContentCount++
          }
        }
      }
      assertEquals(2, verifiedContentCount)
    }
  }

  @Test
  fun `ErrorTranslator maps low-level crypto and archive failures to technical English`() {
    val wrongPass = ErrorTranslator.translate(WrongPasswordException("bad store pass"))
    assertEquals("Wrong Password", wrongPass.title)
    assertTrue(wrongPass.message.contains("password", ignoreCase = true))

    val unrecoverable = ErrorTranslator.translate(UnrecoverableKeyException("Cannot recover key"))
    assertEquals("Wrong Password", unrecoverable.title)

    val wrongAlias = ErrorTranslator.translate(WrongAliasException("missing", listOf("upload", "release")))
    assertEquals("Wrong Alias", wrongAlias.title)
    assertTrue(wrongAlias.message.contains("upload, release"))

    val alreadySigned = ErrorTranslator.translate(IllegalStateException("APK already signed"))
    assertEquals("File Already Signed", alreadySigned.title)

    val unsupportedKs = ErrorTranslator.translate(UnsupportedKeystoreException("Unknown keystore format"))
    assertEquals("Keystore Type Not Supported", unsupportedKs.title)

    val corruptZip = ErrorTranslator.translate(ZipException("invalid END header (bad central directory offset)"))
    assertEquals("File Corrupted", corruptZip.title)

    val badApk = ErrorTranslator.translate(ApkFormatException("Truncated ZIP EOCD"))
    assertEquals("File Corrupted", badApk.title)
  }

  @Test
  fun `BundleToolEngine reports clear diagnostic when native aapt2 binary is unavailable`() {
    val fakeAab = File(sessionDir, "fake.aab")
    fakeAab.writeBytes(byteArrayOf(0x50, 0x4B, 0x05, 0x06) + ByteArray(18))
    val outApk = File(sessionDir, "out.apk")

    var threwCleanException = false
    try {
      BundleToolEngine.convertSignedAabToUniversalApk(
        context = context,
        signedAab = fakeAab,
        outputUniversalApk = outApk,
      )
    } catch (_: Exception) {
      threwCleanException = true
    }
    assertTrue(threwCleanException)
    assertFalse("Temp failed universal output must be shredded", outApk.exists())
  }

  @Test
  fun `Customized APK strips stale META-INF signatures, aligns STORED arsc and so, and signs v1 v2 v3 with built-in fallback keystore`() = runBlocking {
    val inputApk = File(sessionDir, "ci-presigned.apk")
    val axml = AxmlBinaryEditor.createMinimalBinaryManifest(
      packageName = "com.shipsign.original",
      appLabel = "Original App",
      versionCode = 1L,
      versionName = "1.0",
    )
    val arscBytes = ByteArray(141) { (it % 89).toByte() }
    val soBytes = ByteArray(517) { (0x5A xor (it and 0xFF)).toByte() }

    // Create APK with stale META-INF signature files and DEFLATED resources.arsc + STORED .so
    ZipOutputStream(FileOutputStream(inputApk)).use { zos ->
      zos.putNextEntry(ZipEntry("AndroidManifest.xml").apply { method = ZipEntry.DEFLATED })
      zos.write(axml)
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("classes.dex").apply { method = ZipEntry.DEFLATED })
      zos.write(ByteArray(128) { (it % 73).toByte() })
      zos.closeEntry()

      // Intentionally DEFLATED resources.arsc to confirm PackageCustomizerEngine forces STORED + 4-byte align
      zos.putNextEntry(ZipEntry("resources.arsc").apply { method = ZipEntry.DEFLATED })
      zos.write(arscBytes)
      zos.closeEntry()

      writeStoredEntry(zos, "lib/arm64-v8a/libcore.so", soBytes)

      // Stale CI signature entries across all signature file extensions
      for (sigName in listOf(
        "META-INF/MANIFEST.MF",
        "META-INF/CERT.SF",
        "META-INF/CERT.RSA",
        "META-INF/OLD.DSA",
        "META-INF/OLD.EC",
      )) {
        zos.putNextEntry(ZipEntry(sigName).apply { method = ZipEntry.DEFLATED })
        zos.write("stale-signature-payload".toByteArray())
        zos.closeEntry()
      }
    }

    val target = AppTargetFile(
      sessionFile = inputApk,
      originalName = "app-release.apk",
      sizeBytes = inputApk.length(),
      binaryType = ResolvedBinaryType.APK,
      isAlreadySigned = true,
      detectedStack = null,
    )

    val customized = PackageCustomizerEngine.customizePackage(
      context = context,
      target = target,
      request = PackageCustomizationRequest(
        appName = "Custom ShipSign",
        packageName = "com.shipsign.custom",
        versionCode = 9L,
        versionName = "2.0.0",
      ),
    )

    // Confirm zero stale META-INF signature entries remain and resources.arsc + .so are STORED & aligned
    assertFalse(SignatureScanner.hasExistingSignature(customized.sessionFile))
    ZipFile(customized.sessionFile).use { zip ->
      val names = zip.entries().toList().map { it.name }
      assertTrue(
        "All stale META-INF signature files must be stripped",
        names.none { it.startsWith("META-INF/") },
      )
      val arscEntry = zip.getEntry("resources.arsc")
      assertNotNull(arscEntry)
      assertEquals(ZipEntry.STORED, arscEntry.method)
      assertEquals(arscBytes.size.toLong(), arscEntry.size)
      assertEquals(arscBytes.size.toLong(), arscEntry.compressedSize)

      val soEntry = zip.getEntry("lib/arm64-v8a/libcore.so")
      assertNotNull(soEntry)
      assertEquals(ZipEntry.STORED, soEntry.method)
      assertEquals(soBytes.size.toLong(), soEntry.size)
      assertEquals(soBytes.size.toLong(), soEntry.compressedSize)
    }

    val customOffsets = readLocalHeaderDataOffsets(customized.sessionFile)
    assertEquals("Customized resources.arsc must be 4-byte aligned", 0L, customOffsets["resources.arsc"]!! % 4L)
    assertEquals("Customized native .so must be 16KB aligned", 0L, customOffsets["lib/arm64-v8a/libcore.so"]!! % 16_384L)

    // Sign with ShipSign's built-in deterministic fallback keystore (androiddebugkey / android / android)
    val fallbackKeystore = KeystoreGenerator.materializeFallbackDebugKeystore(context)
    var signingResult: SigningResult? = null
    SigningEngine.signWithLogs(
      context = context,
      target = customized,
      keystoreConfig = fallbackKeystore,
      options = SigningOptions(
        v1Enabled = true,
        v2Enabled = true,
        v3Enabled = true,
        v4Enabled = false,
        zipAlignBeforeSign = true,
      ),
      onResult = { signingResult = it },
    ).toList()

    val result = signingResult
    assertNotNull(result)
    val stagedSignedFile = File(result!!.stagedSignedFilePath!!)
    assertTrue("stagedSignedFilePath must exist and differ from customized input", stagedSignedFile.exists())
    assertFalse(
      "Signed output must be distinct from intermediate customized APK",
      stagedSignedFile.canonicalPath == customized.sessionFile.canonicalPath,
    )

    val verifyStaged = ApkVerifier.Builder(stagedSignedFile)
      .setMinCheckedPlatformVersion(21)
      .build()
      .verify()
    assertTrue("Staged signed customized APK must verify", verifyStaged.isVerified)
    assertTrue(verifyStaged.isVerifiedUsingV1Scheme)
    assertTrue(verifyStaged.isVerifiedUsingV2Scheme)
    assertTrue(verifyStaged.isVerifiedUsingV3Scheme)
    assertTrue("Signer certificates must be non-empty", verifyStaged.signerCertificates.isNotEmpty())

    // Also verify the exported Downloads URI contains the exact signed APK
    val exportedCopy = File(sessionDir, "exported-custom-signed.apk")
    context.contentResolver.openInputStream(result.primarySignedUri)!!.use { input ->
      FileOutputStream(exportedCopy).use { out -> input.copyTo(out) }
    }
    val verifyExported = ApkVerifier.Builder(exportedCopy)
      .setMinCheckedPlatformVersion(21)
      .build()
      .verify()
    assertTrue("Exported customized APK must verify", verifyExported.isVerified)
    assertTrue(verifyExported.isVerifiedUsingV1Scheme)
    assertTrue(verifyExported.isVerifiedUsingV2Scheme)
    assertTrue(verifyExported.isVerifiedUsingV3Scheme)
    assertTrue(verifyExported.signerCertificates.isNotEmpty())
  }

  @Test
  fun `Converted AAB to APK strips stale signatures, preserves STORED resources and so, and verifies v1 v2 v3 after signing`() = runBlocking {
    val rawAab = File(sessionDir, "signed-source.aab")
    val axml = AxmlBinaryEditor.createMinimalBinaryManifest(
      packageName = "com.shipsign.bundleconv",
      appLabel = "Bundle Conv",
      versionCode = 3L,
      versionName = "1.3.0",
    )
    val protoManifest = com.shipsign.app.core.engine.AabProtoCodec.encodeXmlNode(
      AxmlBinaryEditor.convertAxmlToProtoXml(axml)
    )
    val arscBytes = ByteArray(113) { (it % 71).toByte() }
    val soBytes = ByteArray(389) { (it % 97).toByte() }

    ZipOutputStream(FileOutputStream(rawAab)).use { zos ->
      zos.putNextEntry(ZipEntry("BundleConfig.pb"))
      zos.write(com.shipsign.app.core.engine.AabProtoCodec.encodeBundleConfig("1.18.3"))
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("base/manifest/AndroidManifest.xml"))
      zos.write(protoManifest)
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("base/dex/classes.dex"))
      zos.write(ByteArray(96) { 0x11 })
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("base/root/resources.arsc").apply { method = ZipEntry.DEFLATED })
      zos.write(arscBytes)
      zos.closeEntry()

      writeStoredEntry(zos, "base/lib/arm64-v8a/libconv.so", soBytes)

      zos.putNextEntry(ZipEntry("META-INF/MANIFEST.MF"))
      zos.write("Manifest-Version: 1.0\r\n".toByteArray())
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("META-INF/CERT.SF"))
      zos.write("stale-sf".toByteArray())
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("META-INF/CERT.RSA"))
      zos.write("stale-rsa".toByteArray())
      zos.closeEntry()
    }

    val aabTarget = AppTargetFile(
      sessionFile = rawAab,
      originalName = "bundle-conv.aab",
      sizeBytes = rawAab.length(),
      binaryType = ResolvedBinaryType.AAB,
      isAlreadySigned = true,
      detectedStack = null,
    )

    val convertedApk = FormatConverterEngine.convertAabToApk(context, aabTarget)
    assertFalse(SignatureScanner.hasExistingSignature(convertedApk.sessionFile))

    ZipFile(convertedApk.sessionFile).use { zip ->
      assertTrue(zip.entries().toList().none { it.name.startsWith("META-INF/") })
      val arscEntry = zip.getEntry("resources.arsc")
      assertNotNull(arscEntry)
      assertEquals(ZipEntry.STORED, arscEntry.method)
      val soEntry = zip.getEntry("lib/arm64-v8a/libconv.so")
      assertNotNull(soEntry)
      assertEquals(ZipEntry.STORED, soEntry.method)
    }

    val offsets = readLocalHeaderDataOffsets(convertedApk.sessionFile)
    assertEquals(0L, offsets["resources.arsc"]!! % 4L)
    assertEquals(0L, offsets["lib/arm64-v8a/libconv.so"]!! % 16_384L)

    val fallbackKeystore = KeystoreGenerator.materializeFallbackDebugKeystore(context)
    var signingResult: SigningResult? = null
    SigningEngine.signWithLogs(
      context = context,
      target = convertedApk,
      keystoreConfig = fallbackKeystore,
      options = SigningOptions(v4Enabled = false),
      onResult = { signingResult = it },
    ).toList()

    val verify = ApkVerifier.Builder(File(signingResult!!.stagedSignedFilePath!!))
      .setMinCheckedPlatformVersion(21)
      .build()
      .verify()
    assertTrue("Converted + signed APK must verify", verify.isVerified)
    assertTrue(verify.isVerifiedUsingV1Scheme)
    assertTrue(verify.isVerifiedUsingV2Scheme)
    assertTrue(verify.isVerifiedUsingV3Scheme)
    assertTrue(verify.signerCertificates.isNotEmpty())
  }

  @Test
  fun `SigningEngine propagates exceptions and never returns an unsigned fallback file`() = runBlocking {
    val corruptApk = File(sessionDir, "corrupt.apk").apply {
      writeBytes("not-a-valid-apk-archive".toByteArray())
    }
    val target = AppTargetFile(
      sessionFile = corruptApk,
      originalName = "corrupt.apk",
      sizeBytes = corruptApk.length(),
      binaryType = ResolvedBinaryType.APK,
      isAlreadySigned = false,
      detectedStack = null,
    )
    val fallbackKeystore = KeystoreGenerator.materializeFallbackDebugKeystore(context)
    var result: SigningResult? = null
    var caught: Throwable? = null
    try {
      SigningEngine.signWithLogs(
        context = context,
        target = target,
        keystoreConfig = fallbackKeystore,
        options = SigningOptions(v4Enabled = false),
        onResult = { result = it },
      ).toList()
    } catch (e: Throwable) {
      caught = e
    }
    assertNotNull("SigningEngine must propagate failure exceptions", caught)
    assertEquals("SigningEngine must never emit an unsigned fallback SigningResult", null, result)
  }

  private fun writeStoredEntry(zos: ZipOutputStream, name: String, data: ByteArray) {
    val crc = CRC32().apply { update(data) }.value
    val entry = ZipEntry(name).apply {
      method = ZipEntry.STORED
      size = data.size.toLong()
      compressedSize = data.size.toLong()
      this.crc = crc
    }
    zos.putNextEntry(entry)
    zos.write(data)
    zos.closeEntry()
  }

  private fun readLocalHeaderDataOffsets(zipFile: File): Map<String, Long> {
    val result = linkedMapOf<String, Long>()
    RandomAccessFile(zipFile, "r").use { raf ->
      val fileLen = raf.length()
      val searchStart = (fileLen - 65_557L).coerceAtLeast(0L)
      val tailLen = (fileLen - searchStart).toInt()
      val tail = ByteArray(tailLen)
      raf.seek(searchStart)
      raf.readFully(tail)

      var eocdIndex = -1
      for (i in (tailLen - 22) downTo 0) {
        if (
          tail[i] == 0x50.toByte() &&
          tail[i + 1] == 0x4B.toByte() &&
          tail[i + 2] == 0x05.toByte() &&
          tail[i + 3] == 0x06.toByte()
        ) {
          eocdIndex = i
          break
        }
      }
      require(eocdIndex >= 0) { "EOCD not found" }
      val eocdBuf = ByteBuffer.wrap(tail, eocdIndex, 22).slice().order(ByteOrder.LITTLE_ENDIAN)
      val cdEntries = eocdBuf.getShort(10).toInt() and 0xFFFF
      val cdOffset = eocdBuf.getInt(16).toLong() and 0xFFFFFFFFL

      var cenPos = cdOffset
      val cenHeader = ByteArray(46)
      val lfhHeader = ByteArray(30)
      repeat(cdEntries) {
        raf.seek(cenPos)
        raf.readFully(cenHeader)
        val cbb = ByteBuffer.wrap(cenHeader).order(ByteOrder.LITTLE_ENDIAN)
        val sig = cbb.getInt(0)
        require(sig == 0x02014B50) { "Invalid CEN signature at $cenPos" }
        val nameLen = cbb.getShort(28).toInt() and 0xFFFF
        val extraLen = cbb.getShort(30).toInt() and 0xFFFF
        val commentLen = cbb.getShort(32).toInt() and 0xFFFF
        val lfhOffset = cbb.getInt(42).toLong() and 0xFFFFFFFFL

        val nameBytes = ByteArray(nameLen)
        raf.readFully(nameBytes)
        val name = nameBytes.toString(Charsets.UTF_8)

        raf.seek(lfhOffset)
        raf.readFully(lfhHeader)
        val lbb = ByteBuffer.wrap(lfhHeader).order(ByteOrder.LITTLE_ENDIAN)
        require(lbb.getInt(0) == 0x04034B50) { "Invalid LFH signature at $lfhOffset" }
        val lfhNameLen = lbb.getShort(26).toInt() and 0xFFFF
        val lfhExtraLen = lbb.getShort(28).toInt() and 0xFFFF
        result[name] = lfhOffset + 30L + lfhNameLen + lfhExtraLen

        cenPos += 46L + nameLen + extraLen + commentLen
      }
    }
    return result
  }

  private fun createMinimalSignableApk(fileName: String): File {
    val apk = File(sessionDir, fileName)
    // Spec-compliant 36-byte binary AXML: 8-byte RES_XML_TYPE header + 28-byte RES_STRING_POOL_TYPE (0 strings)
    val minimalManifestXml = byteArrayOf(
      0x03, 0x00, 0x08, 0x00, 0x24, 0x00, 0x00, 0x00,
      0x01, 0x00, 0x1C, 0x00, 0x1C, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
      0x00, 0x00, 0x00, 0x00,
    )
    val dummyDex = ByteArray(128) { (it % 97).toByte() }
    val dummyArsc = ByteArray(64) { (it % 53).toByte() }

    ZipOutputStream(FileOutputStream(apk)).use { zos ->
      zos.putNextEntry(ZipEntry("AndroidManifest.xml").apply { method = ZipEntry.DEFLATED })
      zos.write(minimalManifestXml)
      zos.closeEntry()

      zos.putNextEntry(ZipEntry("classes.dex").apply { method = ZipEntry.DEFLATED })
      zos.write(dummyDex)
      zos.closeEntry()

      writeStoredEntry(zos, "resources.arsc", dummyArsc)
      writeStoredEntry(zos, "lib/arm64-v8a/libnative.so", ByteArray(256) { 0x42 })
    }
    return apk
  }
}
