package com.shipsign.app.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.shipsign.app.R

val SpaceGroteskFamily = FontFamily(
  Font(R.font.space_grotesk, FontWeight.Normal),
  Font(R.font.space_grotesk, FontWeight.Medium),
  Font(R.font.space_grotesk, FontWeight.SemiBold),
  Font(R.font.space_grotesk, FontWeight.Bold),
)

val PlusJakartaSansFamily = FontFamily(
  Font(R.font.plus_jakarta_sans, FontWeight.Normal),
  Font(R.font.plus_jakarta_sans, FontWeight.Medium),
  Font(R.font.plus_jakarta_sans, FontWeight.SemiBold),
  Font(R.font.plus_jakarta_sans, FontWeight.Bold),
)

val JetBrainsMonoFamily = FontFamily(
  Font(R.font.jetbrains_mono, FontWeight.Normal),
  Font(R.font.jetbrains_mono, FontWeight.Medium),
  Font(R.font.jetbrains_mono, FontWeight.Bold),
)

// Explicit editorial text styles matching the canonical ShipSign design system
val ShipSignWordmarkStyle = TextStyle(
  fontFamily = SpaceGroteskFamily,
  fontWeight = FontWeight.Bold,
  fontSize = 22.sp,
  lineHeight = 26.sp,
  letterSpacing = (-0.5).sp,
)

val ShipSignHeroStyle = TextStyle(
  fontFamily = SpaceGroteskFamily,
  fontWeight = FontWeight.Bold,
  fontSize = 28.sp,
  lineHeight = 34.sp,
  letterSpacing = (-0.6).sp,
)

val ShipSignStepHeaderStyle = TextStyle(
  fontFamily = JetBrainsMonoFamily,
  fontWeight = FontWeight.SemiBold,
  fontSize = 11.sp,
  lineHeight = 14.sp,
  letterSpacing = 1.4.sp,
)

val ShipSignSectionLabelStyle = TextStyle(
  fontFamily = PlusJakartaSansFamily,
  fontWeight = FontWeight.Bold,
  fontSize = 11.sp,
  lineHeight = 14.sp,
  letterSpacing = 1.2.sp,
)

val ShipSignPillBadgeStyle = TextStyle(
  fontFamily = JetBrainsMonoFamily,
  fontWeight = FontWeight.SemiBold,
  fontSize = 10.sp,
  lineHeight = 13.sp,
  letterSpacing = 1.2.sp,
)

val ShipSignFooterNoticeStyle = TextStyle(
  fontFamily = JetBrainsMonoFamily,
  fontWeight = FontWeight.Medium,
  fontSize = 10.sp,
  lineHeight = 14.sp,
  letterSpacing = 1.0.sp,
)

val ShipSignTypography = Typography(
  displaySmall = ShipSignHeroStyle,
  headlineLarge = ShipSignHeroStyle,
  headlineMedium = TextStyle(
    fontFamily = SpaceGroteskFamily,
    fontWeight = FontWeight.Bold,
    fontSize = 24.sp,
    lineHeight = 30.sp,
    letterSpacing = (-0.4).sp,
  ),
  headlineSmall = TextStyle(
    fontFamily = SpaceGroteskFamily,
    fontWeight = FontWeight.Bold,
    fontSize = 22.sp,
    lineHeight = 28.sp,
    letterSpacing = (-0.3).sp,
  ),
  titleLarge = ShipSignWordmarkStyle,
  titleMedium = TextStyle(
    fontFamily = PlusJakartaSansFamily,
    fontWeight = FontWeight.SemiBold,
    fontSize = 16.sp,
    lineHeight = 22.sp,
  ),
  titleSmall = TextStyle(
    fontFamily = PlusJakartaSansFamily,
    fontWeight = FontWeight.SemiBold,
    fontSize = 14.sp,
    lineHeight = 20.sp,
  ),
  bodyLarge = TextStyle(
    fontFamily = PlusJakartaSansFamily,
    fontWeight = FontWeight.Normal,
    fontSize = 15.sp,
    lineHeight = 22.sp,
  ),
  bodyMedium = TextStyle(
    fontFamily = PlusJakartaSansFamily,
    fontWeight = FontWeight.Normal,
    fontSize = 14.sp,
    lineHeight = 20.sp,
  ),
  bodySmall = TextStyle(
    fontFamily = PlusJakartaSansFamily,
    fontWeight = FontWeight.Normal,
    fontSize = 13.sp,
    lineHeight = 18.sp,
  ),
  labelLarge = TextStyle(
    fontFamily = PlusJakartaSansFamily,
    fontWeight = FontWeight.Bold,
    fontSize = 15.sp,
    lineHeight = 20.sp,
  ),
  labelMedium = TextStyle(
    fontFamily = JetBrainsMonoFamily,
    fontWeight = FontWeight.Medium,
    fontSize = 12.sp,
    lineHeight = 16.sp,
    letterSpacing = 0.2.sp,
  ),
  labelSmall = ShipSignPillBadgeStyle,
)
