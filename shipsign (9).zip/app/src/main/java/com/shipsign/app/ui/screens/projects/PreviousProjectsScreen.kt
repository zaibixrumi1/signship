package com.shipsign.app.ui.screens.projects

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.FolderOff
import androidx.compose.material.icons.rounded.DeleteForever
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Draw
import androidx.compose.material.icons.rounded.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shipsign.app.core.storage.SavedProjectEntry
import com.shipsign.app.ui.ProjectHistoryUiState
import com.shipsign.app.ui.components.EditorialOutlineBadge
import com.shipsign.app.ui.components.EditorialScreenHeader
import com.shipsign.app.ui.components.OfflineOutlineBadge
import com.shipsign.app.ui.theme.InkOnDark
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PaperBorder
import com.shipsign.app.ui.theme.PaperSurface
import com.shipsign.app.ui.theme.PineOffline
import com.shipsign.app.ui.theme.VermilionAccent
import com.shipsign.app.ui.theme.VermilionContainer
import com.shipsign.app.ui.theme.VermilionOnContainer
import java.util.Locale

/**
 * 02 — Previous Projects (Offline Local Vault).
 */
@Composable
fun PreviousProjectsScreen(
  state: ProjectHistoryUiState,
  onBack: () -> Unit,
  onDownloadAgain: (SavedProjectEntry) -> Unit,
  onSignLater: (SavedProjectEntry) -> Unit,
  onCustomizeLater: (SavedProjectEntry) -> Unit,
  onClearCloudTrace: (SavedProjectEntry) -> Unit,
  onDeleteProject: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .navigationBarsPadding()
        .testTag("previous_projects_list"),
      contentPadding = PaddingValues(horizontal = 24.dp, vertical = 0.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      item {
        EditorialScreenHeader(
          kicker = "02 — PROJECTS",
          title = "Previous Projects",
          subtitle = "Download, sign or edit completed packages offline.",
          onBack = onBack,
          trailingBadge = { OfflineOutlineBadge() },
        )
      }

      if (!state.errorMessage.isNullOrBlank()) {
        item {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = VermilionContainer,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = state.errorMessage,
              style = MaterialTheme.typography.bodySmall,
              color = VermilionOnContainer,
              modifier = Modifier.padding(14.dp),
            )
          }
        }
      }

      if (state.projects.isEmpty()) {
        item {
          Spacer(modifier = Modifier.height(4.dp))
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("previous_projects_empty_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PaperSurface),
            border = BorderStroke(1.dp, PaperBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 40.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Icon(
                imageVector = Icons.Outlined.FolderOff,
                contentDescription = null,
                tint = InkSecondary,
                modifier = Modifier.size(36.dp),
              )
              Spacer(modifier = Modifier.height(12.dp))
              Text(
                text = "No saved projects yet",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = InkPrimary,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Completed signed or unsigned APKs and AABs are stored offline here for quick access.",
                style = MaterialTheme.typography.bodySmall,
                color = InkSecondary,
              )
            }
          }
        }
      } else {
        items(state.projects, key = { it.id }) { entry ->
          SavedProjectCard(
            entry = entry,
            isClearingThisRepo = state.clearingRepoName != null && state.clearingRepoName == entry.cloudRepoFullName,
            onDownloadAgain = { onDownloadAgain(entry) },
            onSignLater = { onSignLater(entry) },
            onCustomizeLater = { onCustomizeLater(entry) },
            onClearCloudTrace = { onClearCloudTrace(entry) },
            onDelete = { onDeleteProject(entry.id) },
          )
        }
      }

      item { Spacer(modifier = Modifier.height(24.dp)) }
    }
  }
}

@Composable
private fun SavedProjectCard(
  entry: SavedProjectEntry,
  isClearingThisRepo: Boolean,
  onDownloadAgain: () -> Unit,
  onSignLater: () -> Unit,
  onCustomizeLater: () -> Unit,
  onClearCloudTrace: () -> Unit,
  onDelete: () -> Unit,
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("saved_project_card_${entry.id}"),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = PaperSurface),
    border = BorderStroke(1.dp, PaperBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(18.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top,
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = entry.appName,
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = InkPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = entry.packageId,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
            color = InkSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            EditorialOutlineBadge(text = entry.format.name, tint = InkPrimary)
            EditorialOutlineBadge(
              text = if (entry.isSigned) "SIGNED" else "UNSIGNED",
              tint = if (entry.isSigned) PineOffline else VermilionAccent,
            )
            EditorialOutlineBadge(
              text = "${entry.versionCode} / ${entry.versionName}",
              tint = InkSecondary,
            )
          }
        }
        IconButton(
          onClick = onDelete,
          modifier = Modifier.testTag("delete_project_button_${entry.id}"),
        ) {
          Icon(
            imageVector = Icons.Outlined.Delete,
            contentDescription = "Delete project",
            tint = InkSecondary,
          )
        }
      }

      Text(
        text = "${entry.fileName} · ${formatProjectBytes(entry.sizeBytes)}",
        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
        color = InkSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )

      HorizontalDivider(color = PaperBorder)

      Button(
        onClick = onDownloadAgain,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("download_project_button_${entry.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = InkPrimary,
          contentColor = InkOnDark,
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
      ) {
        Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(17.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Download", fontWeight = FontWeight.SemiBold, maxLines = 1)
      }

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(
          onClick = onSignLater,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("sign_later_button_${entry.id}"),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, PaperBorder),
        ) {
          Icon(Icons.Rounded.Draw, contentDescription = null, tint = InkPrimary, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Sign", color = InkPrimary, maxLines = 1)
        }

        OutlinedButton(
          onClick = onCustomizeLater,
          modifier = Modifier
            .weight(1f)
            .height(48.dp)
            .testTag("customize_later_button_${entry.id}"),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, PaperBorder),
        ) {
          Icon(Icons.Rounded.Tune, contentDescription = null, tint = InkPrimary, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Edit", color = InkPrimary, maxLines = 1)
        }
      }

      if (entry.hasUncleanedCloudTrace) {
        OutlinedButton(
          onClick = onClearCloudTrace,
          enabled = !isClearingThisRepo,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("clear_project_cloud_trace_button_${entry.id}"),
          shape = RoundedCornerShape(12.dp),
          border = BorderStroke(1.dp, VermilionAccent),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = VermilionAccent),
        ) {
          if (isClearingThisRepo) {
            CircularProgressIndicator(
              modifier = Modifier.size(16.dp),
              strokeWidth = 2.dp,
              color = VermilionAccent,
            )
            Spacer(modifier = Modifier.width(8.dp))
          } else {
            Icon(Icons.Rounded.DeleteForever, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
          }
          Text("Clear Cloud Trace (${entry.cloudRepoFullName})", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
      }
    }
  }
}

private fun formatProjectBytes(bytes: Long): String {
  if (bytes < 1024L) return "$bytes B"
  val kb = bytes / 1024.0
  if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
  return String.format(Locale.US, "%.2f MB", kb / 1024.0)
}
