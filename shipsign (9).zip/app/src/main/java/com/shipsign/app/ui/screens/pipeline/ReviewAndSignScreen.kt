package com.shipsign.app.ui.screens.pipeline

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shipsign.app.core.engine.PackageCustomizationRequest
import com.shipsign.app.core.security.VaultKeystoreEntry
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.ui.KeystoreStudioUiState
import com.shipsign.app.ui.OfflinePipelineUiState
import com.shipsign.app.ui.ShipSignViewModel
import com.shipsign.app.ui.SigningStudioUiState
import com.shipsign.app.ui.components.EditorialScreenHeader
import com.shipsign.app.ui.components.EditorialSectionKicker
import com.shipsign.app.ui.components.OfflineOutlineBadge
import com.shipsign.app.ui.components.PasswordTextField
import com.shipsign.app.ui.components.TerminalLogBox
import com.shipsign.app.ui.theme.InkMuted
import com.shipsign.app.ui.theme.InkOnDark
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PaperBorder
import com.shipsign.app.ui.theme.PaperSurface
import com.shipsign.app.ui.theme.PaperSurfaceSubtle
import com.shipsign.app.ui.theme.PlusJakartaSansFamily
import com.shipsign.app.ui.theme.VermilionAccent
import com.shipsign.app.ui.theme.VermilionContainer
import com.shipsign.app.ui.theme.VermilionOnAccent
import com.shipsign.app.ui.theme.VermilionOnContainer

private enum class SignMode {
  SAVED_VAULT,
  UPLOAD_KEYSTORE,
  CREATE_NEW,
  SKIP_SIGNING,
}

/**
 * Page 3 of the ShipSign Visual Concept — "03 / 03 — FINISH / Review and sign":
 * Unified offline review screen combining:
 *   - CUSTOMIZE (grouped white card with App name, Package name, Version code / name, optional App icon)
 *   - CONVERT (segmented pill: Keep as is vs AAB -> APK / APK -> AAB)
 *   - SIGN — LAST STEP (saved keystore / upload / create new / skip signing + OFFLINE badge)
 *   - Pinned Vermilion CTA: "Sign and download" (or "Save and download" when unsigned)
 */
@Composable
fun ReviewAndSignScreen(
  targetFile: AppTargetFile?,
  vaultKeystores: List<VaultKeystoreEntry>,
  keystoreStudio: KeystoreStudioUiState,
  signingState: SigningStudioUiState,
  pipelineState: OfflinePipelineUiState,
  focusSection: String,
  onBack: () -> Unit,
  onPickKeystoreUri: (Uri) -> Unit,
  onExecuteFinish: (
    customization: PackageCustomizationRequest?,
    shouldConvert: Boolean,
    signAction: ShipSignViewModel.FinishSignAction,
  ) -> Unit,
  modifier: Modifier = Modifier,
) {
  val pkgInfo = targetFile?.packageInfo
  val initialAppName = pkgInfo?.appName ?: targetFile?.originalName?.substringBeforeLast('.') ?: "My App"
  val initialPackageId = pkgInfo?.packageId ?: "com.example.app"
  val initialVersionName = pkgInfo?.versionName ?: "1.0.0"
  val initialVersionCode = (pkgInfo?.versionCode ?: 1L).toString()

  var appName by remember(targetFile?.sessionFile?.absolutePath) { mutableStateOf(initialAppName) }
  var packageId by remember(targetFile?.sessionFile?.absolutePath) { mutableStateOf(initialPackageId) }
  var versionCode by remember(targetFile?.sessionFile?.absolutePath) { mutableStateOf(initialVersionCode) }
  var versionName by remember(targetFile?.sessionFile?.absolutePath) { mutableStateOf(initialVersionName) }
  var selectedIconUri by remember(targetFile?.sessionFile?.absolutePath) { mutableStateOf<Uri?>(null) }
  var selectedIconBytes by remember(targetFile?.sessionFile?.absolutePath) { mutableStateOf<ByteArray?>(null) }
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  var shouldConvert by remember(targetFile?.sessionFile?.absolutePath) { mutableStateOf(false) }

  // Signing choice defaults to first vault keystore if available, otherwise Skip Signing (never forces keystore)
  var signMode by remember(vaultKeystores.size, focusSection) {
    mutableStateOf(
      when {
        vaultKeystores.isNotEmpty() -> SignMode.SAVED_VAULT
        focusSection == "SIGN" -> SignMode.CREATE_NEW
        else -> SignMode.SKIP_SIGNING
      }
    )
  }
  var selectedVaultId by remember(vaultKeystores) {
    mutableStateOf(vaultKeystores.firstOrNull()?.id)
  }
  var isSignPickerExpanded by remember(focusSection) {
    mutableStateOf(focusSection == "SIGN")
  }

  // Upload keystore form state
  var uploadStorePass by remember { mutableStateOf("") }
  var uploadAlias by remember { mutableStateOf("") }
  var uploadKeyPass by remember { mutableStateOf("") }
  var saveUploadToVault by remember { mutableStateOf(true) }

  // Create new keystore form state
  var newFormat by remember { mutableStateOf(KeystoreFormat.PKCS12) }
  var newFileName by remember { mutableStateOf("release-key") }
  var newAlias by remember { mutableStateOf("release") }
  var newPassword by remember { mutableStateOf("") }

  // Zero-permission Android Photo Picker for custom icon (Google Play Policy compliant)
  val iconPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.PickVisualMedia(),
  ) { uri ->
    if (uri != null) {
      selectedIconUri = uri
      scope.launch {
        val bytes = withContext(Dispatchers.IO) {
          runCatching {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
          }.getOrNull()
        }
        selectedIconBytes = bytes
      }
    }
  }

  val keystoreFilePicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument(),
  ) { uri ->
    if (uri != null) onPickKeystoreUri(uri)
  }

  val isAab = targetFile?.binaryType == ResolvedBinaryType.AAB
  val convertLabel = if (isAab) "AAB → APK" else "APK → AAB"
  val isBusy = pipelineState.isFinalizing || signingState.isSigning || pipelineState.isCustomizing || pipelineState.isConverting
  val selectedVaultEntry = vaultKeystores.firstOrNull { it.id == selectedVaultId } ?: vaultKeystores.firstOrNull()

  val willOutputApk = if (shouldConvert) isAab else !isAab
  val hasCustomChanges = appName.trim().let { it.isNotEmpty() && it != initialAppName } ||
    packageId.trim().let { it.isNotEmpty() && it != initialPackageId } ||
    versionCode.trim().toLongOrNull().let { it != null && it > 0L && it != (pkgInfo?.versionCode ?: 1L) } ||
    versionName.trim().let { it.isNotEmpty() && it != initialVersionName } ||
    selectedIconBytes != null
  val willAutoSignApk = signMode == SignMode.SKIP_SIGNING &&
    willOutputApk &&
    (hasCustomChanges || shouldConvert || targetFile?.isAlreadySigned == false)

  val primaryKeystoreLabel = when (signMode) {
    SignMode.SAVED_VAULT -> selectedVaultEntry?.fileName ?: "Select saved keystore"
    SignMode.UPLOAD_KEYSTORE -> keystoreStudio.importedFileName ?: "Upload .jks / .p12"
    SignMode.CREATE_NEW -> "${newFileName.trim().ifBlank { "release-key" }}.${if (newFormat == KeystoreFormat.JKS) "jks" else "p12"}"
    SignMode.SKIP_SIGNING -> if (willAutoSignApk) "Built-in test key" else "Save unsigned"
  }

  val secondaryKeystoreLabel = when (signMode) {
    SignMode.SAVED_VAULT -> if (selectedVaultEntry != null) "Saved keystore" else "Tap to choose or create"
    SignMode.UPLOAD_KEYSTORE -> "Imported keystore"
    SignMode.CREATE_NEW -> "Generate new RSA-2048 key"
    SignMode.SKIP_SIGNING -> if (willAutoSignApk) {
      "Auto-signed offline (v1/v2/v3) for Android install"
    } else {
      "Skip signing · sign anytime later"
    }
  }

  val isPrimaryActionEnabled = !isBusy && targetFile != null && when (signMode) {
    SignMode.SKIP_SIGNING -> true
    SignMode.SAVED_VAULT -> selectedVaultEntry != null
    SignMode.UPLOAD_KEYSTORE -> keystoreStudio.tempKeystoreFile != null && uploadStorePass.isNotEmpty()
    SignMode.CREATE_NEW -> newPassword.length >= 6 && newAlias.isNotBlank()
  }

  val primaryCtaLabel = when {
    isBusy && (signMode != SignMode.SKIP_SIGNING || willAutoSignApk) -> "Signing package..."
    isBusy -> "Saving package..."
    signMode == SignMode.SKIP_SIGNING && !willAutoSignApk -> "Save and download"
    else -> "Sign and download"
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .navigationBarsPadding()
        .padding(horizontal = 24.dp),
    ) {
      Column(
        modifier = Modifier
          .weight(1f)
          .verticalScroll(rememberScrollState())
          .testTag("review_and_sign_scroll"),
      ) {
        EditorialScreenHeader(
          kicker = "03 / 03 — FINISH",
          title = "Review and sign",
          onBack = onBack,
        )

        Spacer(modifier = Modifier.height(22.dp))

        // ── SECTION 1: CUSTOMIZE ────────────────────────────────────────────
        EditorialSectionKicker(text = "CUSTOMIZE")
        Spacer(modifier = Modifier.height(8.dp))

        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("review_customize_card"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = PaperSurface),
          border = BorderStroke(1.dp, PaperBorder),
          elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            // App name row
            GroupedEditableRow(
              label = "App name",
              value = appName,
              onValueChange = { appName = it },
              textStyle = TextStyle(
                fontFamily = PlusJakartaSansFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = InkPrimary,
              ),
              testTag = "customize_app_name_input",
            )

            HorizontalDivider(color = PaperBorder, thickness = 1.dp)

            // Package name row (mono)
            GroupedEditableRow(
              label = "Package name",
              value = packageId,
              onValueChange = { packageId = it.trim() },
              textStyle = TextStyle(
                fontFamily = JetBrainsMonoFamily,
                fontWeight = FontWeight.Normal,
                fontSize = 16.sp,
                color = InkPrimary,
              ),
              testTag = "customize_package_id_input",
            )

            HorizontalDivider(color = PaperBorder, thickness = 1.dp)

            // Version code / name row (mono)
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            ) {
              Text(
                text = "Version code / name",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.5.sp),
                color = InkSecondary,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
              ) {
                BasicTextField(
                  value = versionCode,
                  onValueChange = { raw -> versionCode = raw.filter { it.isDigit() } },
                  singleLine = true,
                  keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                  textStyle = TextStyle(
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 16.sp,
                    color = InkPrimary,
                  ),
                  cursorBrush = SolidColor(InkPrimary),
                  modifier = Modifier
                    .widthIn(min = 28.dp, max = 96.dp)
                    .testTag("customize_version_code_input"),
                )
                Text(
                  text = " / ",
                  style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 16.sp,
                  ),
                  color = InkMuted,
                )
                BasicTextField(
                  value = versionName,
                  onValueChange = { versionName = it },
                  singleLine = true,
                  textStyle = TextStyle(
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 16.sp,
                    color = InkPrimary,
                  ),
                  cursorBrush = SolidColor(InkPrimary),
                  modifier = Modifier
                    .weight(1f)
                    .testTag("customize_version_name_input"),
                )
              }
            }

            HorizontalDivider(color = PaperBorder, thickness = 1.dp)

            // Optional App Icon row (zero-permission PickVisualMedia)
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = !isBusy) {
                  iconPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }
                .padding(horizontal = 18.dp, vertical = 12.dp)
                .testTag("customize_pick_icon_button"),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Icon(
                  imageVector = Icons.Outlined.Image,
                  contentDescription = "App icon",
                  tint = InkSecondary,
                  modifier = Modifier.size(18.dp),
                )
                Column {
                  Text(
                    text = "App icon",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                    color = InkSecondary,
                  )
                  Text(
                    text = if (selectedIconUri != null) "Custom icon selected" else "Keep original icon",
                    style = MaterialTheme.typography.bodyMedium.copy(
                      fontWeight = FontWeight.Medium,
                      fontSize = 14.sp,
                    ),
                    color = InkPrimary,
                  )
                }
              }

              if (selectedIconUri != null) {
                TextButton(
                  onClick = {
                    selectedIconUri = null
                    selectedIconBytes = null
                  },
                  enabled = !isBusy,
                ) {
                  Text("Reset", color = VermilionAccent)
                }
              } else {
                Text(
                  text = "Replace",
                  style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 12.sp,
                  ),
                  color = InkSecondary,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // ── SECTION 2: CONVERT ──────────────────────────────────────────────
        EditorialSectionKicker(text = "CONVERT")
        Spacer(modifier = Modifier.height(8.dp))

        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("review_convert_segmented"),
          shape = RoundedCornerShape(15.dp),
          color = PaperSurface,
          border = BorderStroke(1.dp, PaperBorder),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            ConvertSegmentPill(
              label = "Keep as is",
              selected = !shouldConvert,
              onClick = { if (!isBusy) shouldConvert = false },
              modifier = Modifier
                .weight(1f)
                .testTag("convert_keep_as_is_button"),
            )
            ConvertSegmentPill(
              label = convertLabel,
              selected = shouldConvert,
              onClick = { if (!isBusy) shouldConvert = true },
              modifier = Modifier
                .weight(1f)
                .testTag("convert_switch_format_button"),
            )
          }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // ── SECTION 3: SIGN — LAST STEP ─────────────────────────────────────
        EditorialSectionKicker(text = "SIGN — LAST STEP")
        Spacer(modifier = Modifier.height(8.dp))

        Card(
          onClick = { if (!isBusy) isSignPickerExpanded = !isSignPickerExpanded },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("review_sign_card"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = PaperSurface),
          border = BorderStroke(
            width = if (isSignPickerExpanded) 1.4.dp else 1.dp,
            color = if (isSignPickerExpanded) InkPrimary else PaperBorder,
          ),
          elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 16.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Outlined.Key,
                contentDescription = "Keystore",
                tint = InkPrimary,
                modifier = Modifier.size(21.dp),
              )

              Spacer(modifier = Modifier.width(14.dp))

              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = primaryKeystoreLabel,
                  style = MaterialTheme.typography.bodyLarge.copy(
                    fontFamily = JetBrainsMonoFamily,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                  ),
                  color = InkPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = secondaryKeystoreLabel,
                  style = MaterialTheme.typography.bodySmall.copy(fontSize = 13.sp),
                  color = InkSecondary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }

              Spacer(modifier = Modifier.width(10.dp))

              OfflineOutlineBadge()

              Spacer(modifier = Modifier.width(4.dp))

              Icon(
                imageVector = if (isSignPickerExpanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore,
                contentDescription = "Choose signing method",
                tint = InkSecondary,
                modifier = Modifier.size(20.dp),
              )
            }

            AnimatedVisibility(visible = isSignPickerExpanded) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                HorizontalDivider(color = PaperBorder)

                // Compact mode chips
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  if (vaultKeystores.isNotEmpty()) {
                    SignModeChip(
                      label = "Saved",
                      selected = signMode == SignMode.SAVED_VAULT,
                      onClick = { signMode = SignMode.SAVED_VAULT },
                      modifier = Modifier.testTag("sign_mode_vault"),
                    )
                  }
                  SignModeChip(
                    label = "Upload",
                    selected = signMode == SignMode.UPLOAD_KEYSTORE,
                    onClick = { signMode = SignMode.UPLOAD_KEYSTORE },
                    modifier = Modifier.testTag("sign_mode_upload"),
                  )
                  SignModeChip(
                    label = "Create",
                    selected = signMode == SignMode.CREATE_NEW,
                    onClick = { signMode = SignMode.CREATE_NEW },
                    modifier = Modifier.testTag("sign_mode_create"),
                  )
                  SignModeChip(
                    label = "Skip",
                    selected = signMode == SignMode.SKIP_SIGNING,
                    onClick = { signMode = SignMode.SKIP_SIGNING },
                    modifier = Modifier.testTag("sign_mode_skip"),
                  )
                }

                when (signMode) {
                  SignMode.SAVED_VAULT -> {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                      vaultKeystores.forEach { entry ->
                        val isChosen = entry.id == selectedVaultEntry?.id
                        Surface(
                          onClick = { selectedVaultId = entry.id },
                          shape = RoundedCornerShape(12.dp),
                          color = if (isChosen) PaperSurfaceSubtle else PaperSurface,
                          border = BorderStroke(
                            width = if (isChosen) 1.4.dp else 1.dp,
                            color = if (isChosen) InkPrimary else PaperBorder,
                          ),
                          modifier = Modifier
                            .fillMaxWidth()
                            .testTag("vault_picker_item_${entry.id}"),
                        ) {
                          Row(
                            modifier = Modifier
                              .fillMaxWidth()
                              .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                          ) {
                            Box(
                              modifier = Modifier
                                .size(16.dp)
                                .clip(CircleShape)
                                .border(1.5.dp, InkPrimary, CircleShape),
                              contentAlignment = Alignment.Center,
                            ) {
                              if (isChosen) {
                                Box(
                                  modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(InkPrimary),
                                )
                              }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                              Text(
                                text = entry.fileName,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                  fontFamily = JetBrainsMonoFamily,
                                  fontWeight = FontWeight.Medium,
                                ),
                                color = InkPrimary,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                              )
                              Text(
                                text = "Alias: ${entry.alias} · ${entry.format.name}",
                                style = MaterialTheme.typography.bodySmall,
                                color = InkSecondary,
                              )
                            }
                          }
                        }
                      }
                    }
                  }

                  SignMode.UPLOAD_KEYSTORE -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                      OutlinedButton(
                        onClick = { keystoreFilePicker.launch(arrayOf("*/*")) },
                        modifier = Modifier
                          .fillMaxWidth()
                          .height(48.dp)
                          .testTag("review_pick_keystore_button"),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, PaperBorder),
                      ) {
                        Icon(
                          imageVector = Icons.Rounded.UploadFile,
                          contentDescription = null,
                          tint = InkPrimary,
                          modifier = Modifier.size(18.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                          text = keystoreStudio.importedFileName ?: "Choose .jks / .keystore / .p12",
                          color = InkPrimary,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis,
                        )
                      }

                      PasswordTextField(
                        value = uploadStorePass,
                        onValueChange = { uploadStorePass = it },
                        label = "Store password",
                        modifier = Modifier.testTag("review_upload_store_pass"),
                      )

                      OutlinedTextField(
                        value = uploadAlias,
                        onValueChange = { uploadAlias = it },
                        label = { Text("Key alias (optional)") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                      )

                      PasswordTextField(
                        value = uploadKeyPass,
                        onValueChange = { uploadKeyPass = it },
                        label = "Key password (blank = same)",
                        imeAction = ImeAction.Done,
                      )

                      Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                          checked = saveUploadToVault,
                          onCheckedChange = { saveUploadToVault = it },
                          colors = CheckboxDefaults.colors(checkedColor = InkPrimary),
                        )
                        Text(
                          text = "Save keystore offline for future releases",
                          style = MaterialTheme.typography.bodySmall,
                          color = InkSecondary,
                        )
                      }
                    }
                  }

                  SignMode.CREATE_NEW -> {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(KeystoreFormat.PKCS12, KeystoreFormat.JKS).forEach { fmt ->
                          SignModeChip(
                            label = fmt.name,
                            selected = newFormat == fmt,
                            onClick = { newFormat = fmt },
                          )
                        }
                      }
                      OutlinedTextField(
                        value = newFileName,
                        onValueChange = { newFileName = it },
                        label = { Text("File name") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                      )
                      OutlinedTextField(
                        value = newAlias,
                        onValueChange = { newAlias = it },
                        label = { Text("Key alias") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth(),
                      )
                      PasswordTextField(
                        value = newPassword,
                        onValueChange = { newPassword = it },
                        label = "Password (min 6 chars)",
                        imeAction = ImeAction.Done,
                        modifier = Modifier.testTag("review_create_password_input"),
                      )
                    }
                  }

                  SignMode.SKIP_SIGNING -> {
                    Text(
                      text = if (willAutoSignApk) {
                        "Modified or unsigned APKs are automatically signed offline with ShipSign's built-in test key (v1/v2/v3) so Android installs them cleanly. Select your own keystore for Play Store releases."
                      } else {
                        "Your package will be saved in Previous Projects and Downloads/ShipSign. You can sign it offline anytime."
                      },
                      style = MaterialTheme.typography.bodySmall,
                      color = InkSecondary,
                    )
                  }
                }
              }
            }
          }
        }

        // Live Signing / Processing Log
        if (signingState.logs.isNotEmpty() && isBusy) {
          Spacer(modifier = Modifier.height(16.dp))
          TerminalLogBox(
            title = "On-Device Pipeline",
            logs = signingState.logs,
          )
        }

        // Error banner
        val err = pipelineState.errorMessage ?: signingState.translatedError?.message ?: keystoreStudio.errorMessage
        if (!err.isNullOrBlank()) {
          Spacer(modifier = Modifier.height(14.dp))
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = VermilionContainer,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("review_error_banner"),
          ) {
            Text(
              text = err,
              style = MaterialTheme.typography.bodySmall,
              color = VermilionOnContainer,
              modifier = Modifier.padding(14.dp),
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))
      }

      // Pinned Vermilion Primary CTA matching Page 3 ("Sign and download")
      Button(
        onClick = {
          val trimmedAppName = appName.trim()
          val trimmedPkg = packageId.trim()
          val trimmedVerName = versionName.trim()
          val parsedVerCode = versionCode.trim().toLongOrNull()

          val customReq = PackageCustomizationRequest(
            appName = trimmedAppName.takeIf { it.isNotEmpty() && it != initialAppName },
            packageName = trimmedPkg.takeIf { it.isNotEmpty() && it != initialPackageId },
            versionCode = parsedVerCode?.takeIf { it > 0L && it != (pkgInfo?.versionCode ?: 1L) },
            versionName = trimmedVerName.takeIf { it.isNotEmpty() && it != initialVersionName },
            iconImageBytes = selectedIconBytes,
          ).takeIf { it.hasAnyChange }

          val action = when (signMode) {
            SignMode.SKIP_SIGNING -> ShipSignViewModel.FinishSignAction.SkipSigning
            SignMode.SAVED_VAULT -> {
              val entry = selectedVaultEntry ?: return@Button
              ShipSignViewModel.FinishSignAction.UseVaultKeystore(entry.id)
            }
            SignMode.UPLOAD_KEYSTORE -> {
              val sp = uploadStorePass.toCharArray()
              val kp = uploadKeyPass.toCharArray()
              uploadStorePass = ""
              uploadKeyPass = ""
              ShipSignViewModel.FinishSignAction.ImportAndSign(
                storePassword = sp,
                keyAlias = uploadAlias.trim(),
                keyPassword = kp,
                saveToVault = saveUploadToVault,
              )
            }
            SignMode.CREATE_NEW -> {
              val pw = newPassword.toCharArray()
              newPassword = ""
              ShipSignViewModel.FinishSignAction.CreateAndSign(
                KeystoreCreateRequest(
                  format = newFormat,
                  fileName = newFileName.trim().ifBlank { "release-key" },
                  storePassword = pw,
                  keyAlias = newAlias.trim().ifBlank { "release" },
                  keyPassword = pw.copyOf(),
                  validityDays = 10000,
                  commonName = "Developer",
                  organizationalUnit = "Mobile",
                  organization = "ShipSign",
                  cityLocality = "San Francisco",
                  stateProvince = "CA",
                  countryCode = "US",
                )
              )
            }
          }

          onExecuteFinish(customReq, shouldConvert, action)
        },
        enabled = isPrimaryActionEnabled,
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp, bottom = 22.dp)
          .height(54.dp)
          .testTag("review_sign_and_download_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = VermilionAccent,
          contentColor = VermilionOnAccent,
          disabledContainerColor = VermilionAccent.copy(alpha = 0.42f),
          disabledContentColor = VermilionOnAccent.copy(alpha = 0.85f),
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
      ) {
        if (isBusy) {
          CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            strokeWidth = 2.dp,
            color = VermilionOnAccent,
          )
          Spacer(modifier = Modifier.width(10.dp))
        }
        Text(
          text = primaryCtaLabel,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp,
          ),
        )
      }
    }
  }
}

@Composable
private fun GroupedEditableRow(
  label: String,
  value: String,
  onValueChange: (String) -> Unit,
  textStyle: TextStyle,
  testTag: String,
) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 18.dp, vertical = 14.dp),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.5.sp),
      color = InkSecondary,
    )
    Spacer(modifier = Modifier.height(4.dp))
    BasicTextField(
      value = value,
      onValueChange = onValueChange,
      singleLine = true,
      textStyle = textStyle,
      cursorBrush = SolidColor(InkPrimary),
      modifier = Modifier
        .fillMaxWidth()
        .testTag(testTag),
    )
  }
}

@Composable
private fun ConvertSegmentPill(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    onClick = onClick,
    modifier = modifier.height(48.dp),
    shape = RoundedCornerShape(11.dp),
    color = if (selected) InkPrimary else PaperSurface,
  ) {
    Box(contentAlignment = Alignment.Center) {
      Text(
        text = label,
        style = MaterialTheme.typography.titleSmall.copy(
          fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
          fontSize = 15.sp,
        ),
        color = if (selected) InkOnDark else InkSecondary,
        maxLines = 1,
      )
    }
  }
}

@Composable
private fun SignModeChip(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    onClick = onClick,
    modifier = modifier.height(36.dp),
    shape = RoundedCornerShape(9.dp),
    color = if (selected) InkPrimary else PaperSurfaceSubtle,
    border = if (selected) null else BorderStroke(1.dp, PaperBorder),
  ) {
    Box(
      modifier = Modifier.padding(horizontal = 12.dp),
      contentAlignment = Alignment.Center,
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium.copy(
          fontFamily = JetBrainsMonoFamily,
          fontSize = 11.5.sp,
          fontWeight = FontWeight.Medium,
        ),
        color = if (selected) InkOnDark else InkSecondary,
      )
    }
  }
}
