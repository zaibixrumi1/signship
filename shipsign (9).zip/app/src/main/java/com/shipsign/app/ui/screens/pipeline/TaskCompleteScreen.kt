package com.shipsign.app.ui.screens.pipeline

import android.content.Intent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import com.shipsign.app.core.storage.SavedProjectEntry
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.ui.CloudBuildUiState
import com.shipsign.app.ui.components.EditorialOutlineBadge
import com.shipsign.app.ui.components.EditorialScreenHeader
import com.shipsign.app.ui.components.EditorialSectionKicker
import com.shipsign.app.ui.components.FingerprintCopyCard
import com.shipsign.app.ui.components.ZeroTraceCloudCleanupCard
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PaperBorder
import com.shipsign.app.ui.theme.PaperSurface
import com.shipsign.app.ui.theme.PineOffline
import com.shipsign.app.ui.theme.VermilionAccent
import com.shipsign.app.ui.theme.VermilionOnAccent
import java.io.File
import java.util.Locale

/**
 * Editorial Task Complete screen reached after signed OR unsigned finish.
 */
@Composable
fun TaskCompleteScreen(
  completedProject: SavedProjectEntry?,
  cloudBuildState: CloudBuildUiState,
  onDownloadFinalFile: (SavedProjectEntry) -> Unit,
  onClearCloudTraceNow: () -> Unit,
  onKeepRepoForInspection: () -> Unit,
  onViewPreviousProjects: () -> Unit,
  onReturnHome: () -> Unit,
  onShowMessage: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .navigationBarsPadding()
        .testTag("task_complete_list"),
      contentPadding = PaddingValues(horizontal = 24.dp, vertical = 0.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        EditorialScreenHeader(
          kicker = "COMPLETE — ON-DEVICE",
          title = if (completedProject?.isSigned == true) "Signed and ready" else "Saved and ready",
          subtitle = completedProject?.fileName ?: "Saved offline in Previous Projects",
          trailingBadge = {
            EditorialOutlineBadge(
              text = if (completedProject?.isSigned == true) "SIGNED" else "UNSIGNED",
              tint = if (completedProject?.isSigned == true) PineOffline else VermilionAccent,
            )
          },
        )
      }

      if (completedProject != null) {
        item {
          EditorialSectionKicker(text = "PACKAGE SUMMARY")
          Spacer(modifier = Modifier.height(8.dp))
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("task_complete_summary_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PaperSurface),
            border = BorderStroke(1.dp, PaperBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              SummaryRow("App name", completedProject.appName)
              HorizontalDivider(color = PaperBorder)
              SummaryRow("Package name", completedProject.packageId, mono = true)
              HorizontalDivider(color = PaperBorder)
              SummaryRow(
                "Version",
                "${completedProject.versionCode} / ${completedProject.versionName}",
                mono = true,
              )
              HorizontalDivider(color = PaperBorder)
              SummaryRow(
                "Artifact",
                "${completedProject.format.name} · ${formatCompleteSize(completedProject.sizeBytes)}",
                mono = true,
              )
            }
          }
        }
      }

      if (completedProject != null &&
        completedProject.isSigned &&
        !completedProject.sha256Fingerprint.isNullOrBlank()
      ) {
        item {
          EditorialSectionKicker(text = "SIGNING FINGERPRINTS")
          Spacer(modifier = Modifier.height(8.dp))
          FingerprintCopyCard(
            sha1 = completedProject.sha1Fingerprint.orEmpty(),
            sha256 = completedProject.sha256Fingerprint,
            onCopied = { label -> onShowMessage("Copied $label fingerprint") },
          )
        }
      }

      if (completedProject != null) {
        item {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
              onClick = { onDownloadFinalFile(completedProject) },
              modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("task_complete_download_button"),
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.buttonColors(
                containerColor = VermilionAccent,
                contentColor = VermilionOnAccent,
              ),
              elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
            ) {
              Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Download final file",
                style = MaterialTheme.typography.titleMedium.copy(
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 16.sp,
                ),
              )
            }

            OutlinedButton(
              onClick = {
                val file = File(completedProject.filePath)
                if (!file.exists()) {
                  onShowMessage("Artifact file not found on disk.")
                } else {
                  runCatching {
                    val shareUri = FileProvider.getUriForFile(
                      context,
                      "${context.packageName}.fileprovider",
                      file,
                    )
                    val mime = if (completedProject.format == ResolvedBinaryType.APK) {
                      "application/vnd.android.package-archive"
                    } else {
                      "application/octet-stream"
                    }
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                      type = mime
                      putExtra(Intent.EXTRA_STREAM, shareUri)
                      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share ${completedProject.fileName}"))
                  }.onFailure {
                    onShowMessage("Unable to open share sheet.")
                  }
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .testTag("task_complete_share_button"),
              shape = RoundedCornerShape(14.dp),
              border = BorderStroke(1.dp, PaperBorder),
            ) {
              Icon(Icons.Rounded.Share, contentDescription = null, tint = InkPrimary, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Share file", color = InkPrimary, fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }

      item {
        ZeroTraceCloudCleanupCard(
          persistedSession = cloudBuildState.persistedSession,
          isClearing = cloudBuildState.isClearingCloudTrace,
          clearedRepoName = cloudBuildState.clearedCloudRepoName,
          onClearCloudTraceNow = onClearCloudTraceNow,
          onKeepForInspection = onKeepRepoForInspection,
        )
      }

      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          OutlinedButton(
            onClick = onViewPreviousProjects,
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("task_complete_previous_projects_button"),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, PaperBorder),
          ) {
            Icon(Icons.Outlined.Folder, contentDescription = null, tint = InkPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Projects", color = InkPrimary)
          }

          OutlinedButton(
            onClick = onReturnHome,
            modifier = Modifier
              .weight(1f)
              .height(48.dp)
              .testTag("task_complete_home_button"),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, PaperBorder),
          ) {
            Icon(Icons.Outlined.Home, contentDescription = null, tint = InkPrimary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text("Home", color = InkPrimary)
          }
        }
      }

      item { Spacer(modifier = Modifier.height(24.dp)) }
    }
  }
}

@Composable
private fun SummaryRow(label: String, value: String, mono: Boolean = false) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = InkSecondary,
    )
    Spacer(modifier = Modifier.width(12.dp))
    Text(
      text = value,
      style = if (mono) {
        MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily)
      } else {
        MaterialTheme.typography.bodySmall
      },
      fontWeight = FontWeight.Medium,
      color = InkPrimary,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

private fun formatCompleteSize(bytes: Long): String {
  if (bytes < 1024L) return "$bytes B"
  val kb = bytes / 1024.0
  if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
  return String.format(Locale.US, "%.2f MB", kb / 1024.0)
}
