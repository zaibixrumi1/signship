package com.shipsign.app.core.storage

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.domain.model.PackageMetadataInfo
import com.shipsign.app.domain.model.ResolvedBinaryType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

@Serializable
data class SavedProjectEntry(
  val id: String,
  val appName: String,
  val packageId: String,
  val versionCode: Long,
  val versionName: String,
  val fileName: String,
  val filePath: String,
  val formatName: String,
  val isSigned: Boolean,
  val sha256Fingerprint: String? = null,
  val sha1Fingerprint: String? = null,
  val sizeBytes: Long,
  val createdAtEpochMs: Long,
  val cloudRepoFullName: String? = null,
  val cloudTraceCleared: Boolean = false,
) {
  val format: ResolvedBinaryType
    get() = runCatching { ResolvedBinaryType.valueOf(formatName) }.getOrDefault(ResolvedBinaryType.APK)

  val hasUncleanedCloudTrace: Boolean
    get() = !cloudRepoFullName.isNullOrBlank() && !cloudTraceCleared
}

/**
 * 100% offline local project vault storing completed APK/AAB artifacts under
 * `context.filesDir/projects/` so users can re-download, sign later, customize later,
 * clear any remaining GitHub cloud trace, or delete artifacts at any time.
 */
object ProjectHistoryRepository {

  private const val PROJECTS_DIR_NAME = "projects"
  private const val PREFS_NAME = "shipsign_project_history_encrypted"
  private const val KEY_PROJECTS_JSON = "saved_projects_json"

  private val json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
  }

  private val _projectsFlow = MutableStateFlow<List<SavedProjectEntry>>(emptyList())
  val projectsFlow: StateFlow<List<SavedProjectEntry>> = _projectsFlow.asStateFlow()

  @Volatile private var cachedPrefs: SharedPreferences? = null

  private fun prefs(context: Context): SharedPreferences {
    cachedPrefs?.let { return it }
    synchronized(this) {
      cachedPrefs?.let { return it }
      val appCtx = context.applicationContext
      val instance = try {
        val masterKey = MasterKey.Builder(appCtx)
          .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
          .build()
        EncryptedSharedPreferences.create(
          appCtx,
          PREFS_NAME,
          masterKey,
          EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
          EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
      } catch (_: Exception) {
        appCtx.getSharedPreferences("${PREFS_NAME}_fallback", Context.MODE_PRIVATE)
      }
      cachedPrefs = instance
      return instance
    }
  }

  private fun projectsDir(context: Context): File {
    val dir = File(context.applicationContext.filesDir, PROJECTS_DIR_NAME)
    if (!dir.exists()) dir.mkdirs()
    return dir
  }

  fun listProjects(context: Context): List<SavedProjectEntry> {
    val raw = prefs(context).getString(KEY_PROJECTS_JSON, null)
    val parsed = if (raw.isNullOrBlank()) {
      emptyList()
    } else {
      runCatching {
        json.decodeFromString(ListSerializer(SavedProjectEntry.serializer()), raw)
      }.getOrDefault(emptyList())
    }
    val valid = parsed.filter { File(it.filePath).exists() }
    if (valid.size != parsed.size) {
      persistProjects(context, valid)
    }
    _projectsFlow.value = valid
    return valid
  }

  suspend fun saveArtifact(
    context: Context,
    sourceFile: File,
    outputFileName: String,
    packageInfo: PackageMetadataInfo?,
    format: ResolvedBinaryType,
    isSigned: Boolean,
    sha256Fingerprint: String? = packageInfo?.sha256Fingerprint,
    sha1Fingerprint: String? = packageInfo?.sha1Fingerprint,
    cloudRepoFullName: String? = null,
  ): SavedProjectEntry = withContext(Dispatchers.IO) {
    require(sourceFile.exists() && sourceFile.isFile) { "Artifact file does not exist" }
    val id = UUID.randomUUID().toString().take(12)
    val safeName = SafFileBridge.sanitizeFileName(outputFileName)
    val destDir = File(projectsDir(context), id).apply { mkdirs() }
    val destFile = File(destDir, safeName)

    copyStreaming(sourceFile, destFile)

    val entry = SavedProjectEntry(
      id = id,
      appName = packageInfo?.appName?.takeIf { it.isNotBlank() } ?: safeName.substringBeforeLast('.'),
      packageId = packageInfo?.packageId?.takeIf { it.isNotBlank() } ?: "com.example.app",
      versionCode = packageInfo?.versionCode ?: 1L,
      versionName = packageInfo?.versionName?.takeIf { it.isNotBlank() } ?: "1.0",
      fileName = safeName,
      filePath = destFile.absolutePath,
      formatName = format.name,
      isSigned = isSigned,
      sha256Fingerprint = sha256Fingerprint,
      sha1Fingerprint = sha1Fingerprint,
      sizeBytes = destFile.length(),
      createdAtEpochMs = System.currentTimeMillis(),
      cloudRepoFullName = cloudRepoFullName?.takeIf { it.isNotBlank() },
      cloudTraceCleared = cloudRepoFullName.isNullOrBlank(),
    )

    val updated = listOf(entry) + listProjects(context)
    persistProjects(context, updated)
    entry
  }

  suspend fun saveArtifactFromUri(
    context: Context,
    sourceUri: Uri,
    outputFileName: String,
    packageInfo: PackageMetadataInfo?,
    format: ResolvedBinaryType,
    isSigned: Boolean,
    sha256Fingerprint: String? = packageInfo?.sha256Fingerprint,
    sha1Fingerprint: String? = packageInfo?.sha1Fingerprint,
    cloudRepoFullName: String? = null,
  ): SavedProjectEntry = withContext(Dispatchers.IO) {
    val id = UUID.randomUUID().toString().take(12)
    val safeName = SafFileBridge.sanitizeFileName(outputFileName)
    val destDir = File(projectsDir(context), id).apply { mkdirs() }
    val destFile = File(destDir, safeName)
    val buffer = ByteArray(64 * 1024)
    try {
      val inputStream = if (sourceUri.scheme.equals("file", ignoreCase = true) && !sourceUri.path.isNullOrBlank()) {
        FileInputStream(File(sourceUri.path!!))
      } else {
        context.contentResolver.openInputStream(sourceUri)
      }
      inputStream?.use { input ->
        FileOutputStream(destFile, false).use { output ->
          while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
          }
          output.flush()
        }
      } ?: throw IllegalStateException("Unable to read finalized artifact URI")
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }

    val entry = SavedProjectEntry(
      id = id,
      appName = packageInfo?.appName?.takeIf { it.isNotBlank() } ?: safeName.substringBeforeLast('.'),
      packageId = packageInfo?.packageId?.takeIf { it.isNotBlank() } ?: "com.example.app",
      versionCode = packageInfo?.versionCode ?: 1L,
      versionName = packageInfo?.versionName?.takeIf { it.isNotBlank() } ?: "1.0",
      fileName = safeName,
      filePath = destFile.absolutePath,
      formatName = format.name,
      isSigned = isSigned,
      sha256Fingerprint = sha256Fingerprint,
      sha1Fingerprint = sha1Fingerprint,
      sizeBytes = destFile.length(),
      createdAtEpochMs = System.currentTimeMillis(),
      cloudRepoFullName = cloudRepoFullName?.takeIf { it.isNotBlank() },
      cloudTraceCleared = cloudRepoFullName.isNullOrBlank(),
    )

    val updated = listOf(entry) + listProjects(context)
    persistProjects(context, updated)
    entry
  }

  suspend fun exportProjectToDownloads(
    context: Context,
    entry: SavedProjectEntry,
  ): Uri = withContext(Dispatchers.IO) {
    val file = File(entry.filePath)
    require(file.exists()) { "Saved project artifact is missing" }
    val mimeType = if (entry.format == ResolvedBinaryType.APK) {
      "application/vnd.android.package-archive"
    } else {
      "application/octet-stream"
    }
    SafFileBridge.exportFileToDownloads(
      context = context,
      sourceFile = file,
      outputFileName = entry.fileName,
      mimeType = mimeType,
    )
  }

  fun markCloudTraceCleared(context: Context, repoFullName: String) {
    if (repoFullName.isBlank()) return
    val current = listProjects(context)
    val updated = current.map { entry ->
      if (entry.cloudRepoFullName == repoFullName) {
        entry.copy(cloudRepoFullName = null, cloudTraceCleared = true)
      } else {
        entry
      }
    }
    persistProjects(context, updated)
  }

  suspend fun deleteProject(
    context: Context,
    projectId: String,
  ) = withContext(Dispatchers.IO) {
    val current = listProjects(context)
    val target = current.firstOrNull { it.id == projectId }
    if (target != null) {
      val file = File(target.filePath)
      val parent = file.parentFile
      ZeroTraceManager.secureDeleteFile(file)
      if (parent != null && parent.parentFile?.name == PROJECTS_DIR_NAME) {
        parent.deleteRecursively()
      }
    }
    persistProjects(context, current.filterNot { it.id == projectId })
  }

  fun clearAllForTesting(context: Context) {
    listProjects(context).forEach { entry ->
      ZeroTraceManager.secureDeleteFile(File(entry.filePath))
    }
    projectsDir(context).deleteRecursively()
    prefs(context).edit().remove(KEY_PROJECTS_JSON).commit()
    _projectsFlow.value = emptyList()
  }

  private fun persistProjects(context: Context, entries: List<SavedProjectEntry>) {
    val encoded = json.encodeToString(ListSerializer(SavedProjectEntry.serializer()), entries)
    prefs(context).edit().putString(KEY_PROJECTS_JSON, encoded).commit()
    _projectsFlow.value = entries
  }

  private fun copyStreaming(source: File, dest: File) {
    val buffer = ByteArray(64 * 1024)
    try {
      FileInputStream(source).use { input ->
        FileOutputStream(dest, false).use { output ->
          while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
          }
          output.flush()
        }
      }
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }
}
