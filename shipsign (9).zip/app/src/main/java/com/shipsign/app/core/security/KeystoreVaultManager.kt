package com.shipsign.app.core.security

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.shipsign.app.core.engine.KeystoreGenerator
import com.shipsign.app.core.engine.SigningEngine
import com.shipsign.app.core.storage.SafFileBridge
import com.shipsign.app.domain.model.ImportedKeystoreConfig
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID

@Serializable
data class VaultKeystoreEntry(
  val id: String,
  val displayName: String,
  val fileName: String,
  val filePath: String,
  val formatName: String,
  val alias: String,
  val subjectDn: String,
  val sha256Fingerprint: String,
  val createdAtEpochMs: Long,
) {
  val format: KeystoreFormat
    get() = runCatching { KeystoreFormat.valueOf(formatName) }.getOrDefault(KeystoreFormat.PKCS12)
}

@Serializable
private data class EncryptedKeystoreSecret(
  val storePass: String,
  val keyPass: String,
)

/**
 * 100% Offline Keystore Vault storing user keystores in `context.filesDir/keystores/` and
 * encrypting alias/password metadata in AES-256 [EncryptedSharedPreferences].
 *
 * Uses pure BouncyCastle (`bcprov-jdk18on` + `bcpkix-jdk18on`) via [KeystoreGenerator] and
 * [KeystoreDetector] — never references `sun.security.x509` or `keytool`.
 */
object KeystoreVaultManager {

  private const val VAULT_DIR_NAME = "keystores"
  private const val PREFS_NAME = "shipsign_keystore_vault_encrypted"
  private const val KEY_ENTRIES_JSON = "vault_entries_json"
  private const val KEY_SECRET_PREFIX = "vault_secret_"

  private val json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
  }

  private val _vaultFlow = MutableStateFlow<List<VaultKeystoreEntry>>(emptyList())
  val vaultFlow: StateFlow<List<VaultKeystoreEntry>> = _vaultFlow.asStateFlow()

  @Volatile private var cachedPrefs: SharedPreferences? = null

  private fun prefs(context: Context): SharedPreferences {
    cachedPrefs?.let { return it }
    synchronized(this) {
      cachedPrefs?.let { return it }
      val appCtx = context.applicationContext
      val instance = try {
        val masterKey = MasterKey.Builder(appCtx)
          .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
          .build()
        EncryptedSharedPreferences.create(
          appCtx,
          PREFS_NAME,
          masterKey,
          EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
          EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
      } catch (_: Exception) {
        // Fallback only for JVM Robolectric runners without AndroidKeyStore hardware
        appCtx.getSharedPreferences("${PREFS_NAME}_fallback", Context.MODE_PRIVATE)
      }
      cachedPrefs = instance
      return instance
    }
  }

  private fun vaultDir(context: Context): File {
    val dir = File(context.applicationContext.filesDir, VAULT_DIR_NAME)
    if (!dir.exists()) dir.mkdirs()
    return dir
  }

  fun listKeystores(context: Context): List<VaultKeystoreEntry> {
    val raw = prefs(context).getString(KEY_ENTRIES_JSON, null)
    val parsed = if (raw.isNullOrBlank()) {
      emptyList()
    } else {
      runCatching {
        json.decodeFromString(ListSerializer(VaultKeystoreEntry.serializer()), raw)
      }.getOrDefault(emptyList())
    }
    val existing = parsed.filter { File(it.filePath).exists() }
    if (existing.size != parsed.size) {
      persistEntries(context, existing)
    }
    _vaultFlow.value = existing
    return existing
  }

  suspend fun createNewVaultKeystore(
    context: Context,
    request: KeystoreCreateRequest,
  ): VaultKeystoreEntry = withContext(Dispatchers.IO) {
    val id = UUID.randomUUID().toString().take(12)
    val ext = when (request.format) {
      KeystoreFormat.JKS -> ".jks"
      KeystoreFormat.PKCS12 -> ".p12"
      KeystoreFormat.BKS -> ".bks"
      KeystoreFormat.UNKNOWN -> ".p12"
    }
    val safeDisplayName = request.fileName.trim().ifBlank { "shipsign-release" }
    val cleanFileName = SafFileBridge.sanitizeFileName(
      if (safeDisplayName.endsWith(ext, ignoreCase = true)) safeDisplayName else "$safeDisplayName$ext"
    )
    val destDir = File(vaultDir(context), id).apply { mkdirs() }
    val destFile = File(destDir, cleanFileName)
    val storePassCopy = request.storePassword.copyOf()
    val keyPassCopy = request.keyPassword.copyOf()

    try {
      val generated = KeystoreGenerator.generateKeystore(
        request = request.copy(
          fileName = cleanFileName,
          storePassword = request.storePassword.copyOf(),
          keyPassword = request.keyPassword.copyOf(),
        ),
        sessionDir = destDir,
      )
      if (generated.absolutePath != destFile.absolutePath) {
        copyFileStreaming(generated, destFile)
        ZeroTraceManager.secureDeleteFile(generated)
      }

      val validated = KeystoreDetector.validateKeystoreCredentials(
        ImportedKeystoreConfig(
          tempKeystoreFile = destFile,
          detectedFormat = request.format,
          storePassword = storePassCopy.copyOf(),
          keyAlias = request.keyAlias.trim(),
          keyPassword = keyPassCopy.copyOf(),
        )
      )

      val cert = validated.certificateChain.first()
      val sha256 = SigningEngine.formatCertFingerprint(cert, "SHA-256")
      val entry = VaultKeystoreEntry(
        id = id,
        displayName = cleanFileName.substringBeforeLast('.'),
        fileName = cleanFileName,
        filePath = destFile.absolutePath,
        formatName = validated.format.name,
        alias = validated.alias,
        subjectDn = cert.subjectX500Principal.name,
        sha256Fingerprint = sha256,
        createdAtEpochMs = System.currentTimeMillis(),
      )

      saveEntryAndSecret(context, entry, storePassCopy, keyPassCopy)
      entry
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(destFile)
      throw e
    } finally {
      ZeroTraceManager.wipeCharArray(request.storePassword)
      ZeroTraceManager.wipeCharArray(request.keyPassword)
      ZeroTraceManager.wipeCharArray(storePassCopy)
      ZeroTraceManager.wipeCharArray(keyPassCopy)
    }
  }

  suspend fun importVaultKeystore(
    context: Context,
    sourceFile: File,
    originalFileName: String,
    storePassword: CharArray,
    keyAlias: String,
    keyPassword: CharArray,
  ): VaultKeystoreEntry = withContext(Dispatchers.IO) {
    val id = UUID.randomUUID().toString().take(12)
    val cleanFileName = SafFileBridge.sanitizeFileName(originalFileName.ifBlank { "imported.p12" })
    val destFile = File(vaultDir(context), "${id}_$cleanFileName")
    val storePassCopy = storePassword.copyOf()
    val keyPassCopy = keyPassword.copyOf()

    try {
      val detectedFormat = KeystoreDetector.detectFormat(sourceFile)
      val validated = KeystoreDetector.validateKeystoreCredentials(
        ImportedKeystoreConfig(
          tempKeystoreFile = sourceFile,
          detectedFormat = detectedFormat,
          storePassword = storePassCopy.copyOf(),
          keyAlias = keyAlias.trim(),
          keyPassword = keyPassCopy.copyOf(),
        )
      )

      copyFileStreaming(sourceFile, destFile)
      val cert = validated.certificateChain.first()
      val sha256 = SigningEngine.formatCertFingerprint(cert, "SHA-256")

      val entry = VaultKeystoreEntry(
        id = id,
        displayName = cleanFileName.substringBeforeLast('.'),
        fileName = cleanFileName,
        filePath = destFile.absolutePath,
        formatName = validated.format.name,
        alias = validated.alias,
        subjectDn = cert.subjectX500Principal.name,
        sha256Fingerprint = sha256,
        createdAtEpochMs = System.currentTimeMillis(),
      )

      saveEntryAndSecret(context, entry, storePassCopy, keyPassCopy)
      entry
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(destFile)
      throw e
    } finally {
      ZeroTraceManager.wipeCharArray(storePassword)
      ZeroTraceManager.wipeCharArray(keyPassword)
      ZeroTraceManager.wipeCharArray(storePassCopy)
      ZeroTraceManager.wipeCharArray(keyPassCopy)
    }
  }

  /**
   * Unlocks a vaulted keystore into an in-memory [ImportedKeystoreConfig] with fresh [CharArray]
   * buffers ready for one-tap offline signing. Caller is responsible for wiping the arrays.
   */
  suspend fun unlockVaultKeystore(
    context: Context,
    entryId: String,
  ): ImportedKeystoreConfig = withContext(Dispatchers.IO) {
    val entry = listKeystores(context).firstOrNull { it.id == entryId }
      ?: throw IllegalStateException("Saved keystore not found in Vault")
    val ksFile = File(entry.filePath)
    if (!ksFile.exists()) {
      throw IllegalStateException("Saved keystore file is missing from Vault")
    }
    val secretJson = prefs(context).getString("$KEY_SECRET_PREFIX${entry.id}", null)
      ?: throw IllegalStateException("Encrypted keystore credentials are missing")
    val secret = json.decodeFromString(EncryptedKeystoreSecret.serializer(), secretJson)
    ImportedKeystoreConfig(
      tempKeystoreFile = ksFile,
      detectedFormat = entry.format,
      storePassword = secret.storePass.toCharArray(),
      keyAlias = entry.alias,
      keyPassword = secret.keyPass.toCharArray(),
    )
  }

  suspend fun exportVaultKeystoreToDownloads(
    context: Context,
    entry: VaultKeystoreEntry,
  ): Uri = withContext(Dispatchers.IO) {
    val file = File(entry.filePath)
    require(file.exists()) { "Keystore file no longer exists in Vault" }
    SafFileBridge.exportFileToDownloads(
      context = context,
      sourceFile = file,
      outputFileName = entry.fileName,
      mimeType = "application/octet-stream",
    )
  }

  suspend fun deleteVaultKeystore(
    context: Context,
    entryId: String,
  ) = withContext(Dispatchers.IO) {
    val current = listKeystores(context)
    val target = current.firstOrNull { it.id == entryId }
    if (target != null) {
      ZeroTraceManager.secureDeleteFile(File(target.filePath))
    }
    prefs(context).edit().remove("$KEY_SECRET_PREFIX$entryId").commit()
    val remaining = current.filterNot { it.id == entryId }
    persistEntries(context, remaining)
  }

  fun clearAllForTesting(context: Context) {
    val current = listKeystores(context)
    current.forEach { ZeroTraceManager.secureDeleteFile(File(it.filePath)) }
    val editor = prefs(context).edit()
    current.forEach { editor.remove("$KEY_SECRET_PREFIX${it.id}") }
    editor.remove(KEY_ENTRIES_JSON).commit()
    _vaultFlow.value = emptyList()
  }

  private fun saveEntryAndSecret(
    context: Context,
    entry: VaultKeystoreEntry,
    storePassword: CharArray,
    keyPassword: CharArray,
  ) {
    val secretPayload = json.encodeToString(
      EncryptedKeystoreSecret.serializer(),
      EncryptedKeystoreSecret(
        storePass = String(storePassword),
        keyPass = String(keyPassword),
      ),
    )
    prefs(context).edit()
      .putString("$KEY_SECRET_PREFIX${entry.id}", secretPayload)
      .commit()

    val updated = listOf(entry) + listKeystores(context).filterNot { it.id == entry.id }
    persistEntries(context, updated)
  }

  private fun persistEntries(context: Context, entries: List<VaultKeystoreEntry>) {
    val encoded = json.encodeToString(ListSerializer(VaultKeystoreEntry.serializer()), entries)
    prefs(context).edit().putString(KEY_ENTRIES_JSON, encoded).commit()
    _vaultFlow.value = entries
  }

  private fun copyFileStreaming(source: File, dest: File) {
    val buffer = ByteArray(32 * 1024)
    try {
      FileInputStream(source).use { input ->
        FileOutputStream(dest, false).use { output ->
          while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
          }
          output.flush()
        }
      }
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }
}
