package com.shipsign.app.core.engine

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class ParsedManifestMeta(
  val packageName: String? = null,
  val versionCode: Long? = null,
  val versionName: String? = null,
  val appLabel: String? = null,
  val minSdk: Int? = null,
  val targetSdk: Int? = null,
)

/**
 * Pure-Kotlin binary Android XML (AXML) parser, patcher, and Proto↔AXML converter.
 *
 * Supports:
 * - Extracting `<manifest>` (`package`, `versionCode`, `versionName`), `<uses-sdk>`, and
 *   `<application>` (`label`) from binary `AndroidManifest.xml` inside `.apk` archives.
 * - Patching `package`, `android:label`, `android:versionCode`, and `android:versionName`
 *   directly in binary AXML chunks (preserving resource maps, UTF-8/UTF-16 string pools, and
 *   all other elements/attributes intact).
 * - Converting binary AXML -> `com.android.aapt.Resources.XmlNode` (for `APK → AAB`).
 * - Converting `com.android.aapt.Resources.XmlNode` -> binary AXML (for `AAB → APK`).
 */
object AxmlBinaryEditor {

  private const val RES_STRING_POOL_TYPE = 0x0001
  private const val RES_XML_TYPE = 0x0003
  private const val RES_XML_START_NAMESPACE_TYPE = 0x0100
  private const val RES_XML_END_NAMESPACE_TYPE = 0x0101
  private const val RES_XML_START_ELEMENT_TYPE = 0x0102
  private const val RES_XML_END_ELEMENT_TYPE = 0x0103
  private const val RES_XML_CDATA_TYPE = 0x0104
  private const val RES_XML_RESOURCE_MAP_TYPE = 0x0180

  private const val UTF8_FLAG = 1 shl 8

  private const val TYPE_REFERENCE = 0x01
  private const val TYPE_STRING = 0x03
  private const val TYPE_INT_DEC = 0x10
  private const val TYPE_INT_HEX = 0x11
  private const val TYPE_INT_BOOLEAN = 0x12

  private const val ATTR_ID_LABEL = 0x01010001
  private const val ATTR_ID_MIN_SDK = 0x0101020c
  private const val ATTR_ID_VERSION_CODE = 0x0101021b
  private const val ATTR_ID_VERSION_NAME = 0x0101021c
  private const val ATTR_ID_TARGET_SDK = 0x01010270

  private const val ANDROID_NS = "http://schemas.android.com/apk/res/android"
  private const val NO_INDEX = -1

  fun isBinaryAxml(bytes: ByteArray): Boolean {
    if (bytes.size < 8) return false
    val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    val type = bb.getShort(0).toInt() and 0xFFFF
    val headerSize = bb.getShort(2).toInt() and 0xFFFF
    return type == RES_XML_TYPE && headerSize == 8
  }

  fun parseManifestMeta(axmlBytes: ByteArray): ParsedManifestMeta {
    if (!isBinaryAxml(axmlBytes)) return ParsedManifestMeta()
    val doc = decodeAxml(axmlBytes) ?: return ParsedManifestMeta()

    var packageName: String? = null
    var versionCode: Long? = null
    var versionName: String? = null
    var appLabel: String? = null
    var minSdk: Int? = null
    var targetSdk: Int? = null

    for (chunk in doc.bodyChunks) {
      if (chunk !is AxmlStartElementChunk) continue
      val elemName = doc.strings.getOrNull(chunk.nameIdx) ?: continue
      when (elemName) {
        "manifest" -> {
          for (attr in chunk.attributes) {
            val attrName = doc.strings.getOrNull(attr.nameIdx)
            val resId = doc.resourceIds.getOrNull(attr.nameIdx)
            when {
              attrName == "package" -> {
                packageName = resolveStringValue(doc.strings, attr)
              }
              attrName == "versionCode" || resId == ATTR_ID_VERSION_CODE -> {
                if (attr.valueType == TYPE_INT_DEC || attr.valueType == TYPE_INT_HEX) {
                  versionCode = attr.valueData.toLong() and 0xFFFFFFFFL
                }
              }
              attrName == "versionName" || resId == ATTR_ID_VERSION_NAME -> {
                versionName = resolveStringValue(doc.strings, attr)
              }
            }
          }
        }
        "application" -> {
          for (attr in chunk.attributes) {
            val attrName = doc.strings.getOrNull(attr.nameIdx)
            val resId = doc.resourceIds.getOrNull(attr.nameIdx)
            if (attrName == "label" || resId == ATTR_ID_LABEL) {
              val strVal = resolveStringValue(doc.strings, attr)
              if (!strVal.isNullOrBlank()) {
                appLabel = strVal
              }
            }
          }
        }
        "uses-sdk" -> {
          for (attr in chunk.attributes) {
            val attrName = doc.strings.getOrNull(attr.nameIdx)
            val resId = doc.resourceIds.getOrNull(attr.nameIdx)
            when {
              attrName == "minSdkVersion" || resId == ATTR_ID_MIN_SDK -> {
                if (attr.valueType == TYPE_INT_DEC || attr.valueType == TYPE_INT_HEX) {
                  minSdk = attr.valueData
                }
              }
              attrName == "targetSdkVersion" || resId == ATTR_ID_TARGET_SDK -> {
                if (attr.valueType == TYPE_INT_DEC || attr.valueType == TYPE_INT_HEX) {
                  targetSdk = attr.valueData
                }
              }
            }
          }
        }
      }
    }

    return ParsedManifestMeta(
      packageName = packageName,
      versionCode = versionCode,
      versionName = versionName,
      appLabel = appLabel,
      minSdk = minSdk,
      targetSdk = targetSdk,
    )
  }

  /**
   * Patches binary AXML `AndroidManifest.xml` in place, updating any non-null fields
   * (`packageName`, `appLabel`, `versionCode`, `versionName`) while keeping all other
   * chunks, namespaces, activities, and resource IDs intact.
   */
  fun patchManifest(
    axmlBytes: ByteArray,
    packageName: String? = null,
    appLabel: String? = null,
    versionCode: Long? = null,
    versionName: String? = null,
  ): ByteArray {
    if (!isBinaryAxml(axmlBytes)) return axmlBytes
    val doc = decodeAxml(axmlBytes) ?: return axmlBytes

    val strings = doc.strings.toMutableList()
    val resourceIds = doc.resourceIds.toMutableList()

    fun appendString(value: String): Int {
      strings.add(value)
      return strings.lastIndex
    }

    fun ensureAndroidNamespaceIdx(): Int {
      val existing = strings.indexOf(ANDROID_NS)
      return if (existing >= 0) existing else appendString(ANDROID_NS)
    }

    fun ensureResourceAttrIdx(name: String, resId: Int): Int {
      val byId = resourceIds.indexOf(resId)
      if (byId >= 0) return byId
      val byName = strings.indexOf(name)
      if (byName >= 0 && byName < resourceIds.size) {
        if (resourceIds[byName] == 0) resourceIds[byName] = resId
        return byName
      }
      // Resource map covers indices 0 until resourceIds.size; append to resource map if strings match
      if (strings.size == resourceIds.size) {
        strings.add(name)
        resourceIds.add(resId)
        return strings.lastIndex
      }
      return appendString(name)
    }

    val newPkgIdx = packageName?.takeIf { it.isNotBlank() }?.let { appendString(it.trim()) }
    val newLabelIdx = appLabel?.takeIf { it.isNotBlank() }?.let { appendString(it.trim()) }
    val newVerNameIdx = versionName?.takeIf { it.isNotBlank() }?.let { appendString(it.trim()) }

    val updatedChunks = doc.bodyChunks.map { chunk ->
      if (chunk !is AxmlStartElementChunk) {
        chunk
      } else {
        val elemName = strings.getOrNull(chunk.nameIdx)
        when (elemName) {
          "manifest" -> {
            val attrs = chunk.attributes.toMutableList()
            if (newPkgIdx != null) {
              val idx = attrs.indexOfFirst { strings.getOrNull(it.nameIdx) == "package" }
              if (idx >= 0) {
                attrs[idx] = attrs[idx].copy(
                  rawValueIdx = newPkgIdx,
                  valueType = TYPE_STRING,
                  valueData = newPkgIdx,
                )
              } else {
                val pkgNameIdx = strings.indexOf("package").takeIf { it >= 0 } ?: appendString("package")
                attrs.add(
                  AxmlAttribute(
                    namespaceIdx = NO_INDEX,
                    nameIdx = pkgNameIdx,
                    rawValueIdx = newPkgIdx,
                    valueType = TYPE_STRING,
                    valueData = newPkgIdx,
                  )
                )
              }
            }
            if (versionCode != null && versionCode > 0L) {
              val idx = attrs.indexOfFirst {
                strings.getOrNull(it.nameIdx) == "versionCode" ||
                  resourceIds.getOrNull(it.nameIdx) == ATTR_ID_VERSION_CODE
              }
              if (idx >= 0) {
                attrs[idx] = attrs[idx].copy(
                  rawValueIdx = NO_INDEX,
                  valueType = TYPE_INT_DEC,
                  valueData = versionCode.toInt(),
                )
              } else {
                val nsIdx = ensureAndroidNamespaceIdx()
                val nameIdx = ensureResourceAttrIdx("versionCode", ATTR_ID_VERSION_CODE)
                attrs.add(
                  AxmlAttribute(
                    namespaceIdx = nsIdx,
                    nameIdx = nameIdx,
                    rawValueIdx = NO_INDEX,
                    valueType = TYPE_INT_DEC,
                    valueData = versionCode.toInt(),
                  )
                )
              }
            }
            if (newVerNameIdx != null) {
              val idx = attrs.indexOfFirst {
                strings.getOrNull(it.nameIdx) == "versionName" ||
                  resourceIds.getOrNull(it.nameIdx) == ATTR_ID_VERSION_NAME
              }
              if (idx >= 0) {
                attrs[idx] = attrs[idx].copy(
                  rawValueIdx = newVerNameIdx,
                  valueType = TYPE_STRING,
                  valueData = newVerNameIdx,
                )
              } else {
                val nsIdx = ensureAndroidNamespaceIdx()
                val nameIdx = ensureResourceAttrIdx("versionName", ATTR_ID_VERSION_NAME)
                attrs.add(
                  AxmlAttribute(
                    namespaceIdx = nsIdx,
                    nameIdx = nameIdx,
                    rawValueIdx = newVerNameIdx,
                    valueType = TYPE_STRING,
                    valueData = newVerNameIdx,
                  )
                )
              }
            }
            chunk.copy(attributes = attrs)
          }
          "application" -> {
            val attrs = chunk.attributes.toMutableList()
            if (newLabelIdx != null) {
              val idx = attrs.indexOfFirst {
                strings.getOrNull(it.nameIdx) == "label" ||
                  resourceIds.getOrNull(it.nameIdx) == ATTR_ID_LABEL
              }
              if (idx >= 0) {
                attrs[idx] = attrs[idx].copy(
                  rawValueIdx = newLabelIdx,
                  valueType = TYPE_STRING,
                  valueData = newLabelIdx,
                )
              } else {
                val nsIdx = ensureAndroidNamespaceIdx()
                val nameIdx = ensureResourceAttrIdx("label", ATTR_ID_LABEL)
                attrs.add(
                  AxmlAttribute(
                    namespaceIdx = nsIdx,
                    nameIdx = nameIdx,
                    rawValueIdx = newLabelIdx,
                    valueType = TYPE_STRING,
                    valueData = newLabelIdx,
                  )
                )
              }
            }
            chunk.copy(attributes = attrs)
          }
          else -> chunk
        }
      }
    }

    return encodeAxml(
      AxmlDocument(
        strings = strings,
        styleBytes = doc.styleBytes,
        styleCount = doc.styleCount,
        resourceIds = resourceIds,
        bodyChunks = updatedChunks,
      )
    )
  }

  /**
   * Converts binary AXML (`AndroidManifest.xml` from an `.apk`) to a protobuf
   * [ProtoXmlNode] (for `base/manifest/AndroidManifest.xml` in an `.aab`).
   */
  fun convertAxmlToProtoXml(axmlBytes: ByteArray): ProtoXmlNode {
    val doc = decodeAxml(axmlBytes)
      ?: throw IllegalArgumentException("Invalid binary AXML AndroidManifest.xml")

    val namespaceStack = ArrayDeque<Pair<String, String>>()
    class ElementAcc(
      val name: String,
      val namespaceUri: String,
      val namespaces: MutableList<ProtoXmlNamespace> = mutableListOf(),
      val attributes: MutableList<ProtoXmlAttribute> = mutableListOf(),
      val children: MutableList<ProtoXmlNode> = mutableListOf(),
    ) {
      fun build() = ProtoXmlElement(
        namespaces = namespaces.toList(),
        namespaceUri = namespaceUri,
        name = name,
        attributes = attributes.toList(),
        children = children.toList(),
      )
    }

    val elementStack = ArrayDeque<ElementAcc>()
    var rootElement: ProtoXmlElement? = null

    for (chunk in doc.bodyChunks) {
      when (chunk) {
        is AxmlNamespaceChunk -> {
          val prefix = doc.strings.getOrNull(chunk.prefixIdx).orEmpty()
          val uri = doc.strings.getOrNull(chunk.uriIdx).orEmpty()
          if (chunk.isStart) {
            namespaceStack.addLast(prefix to uri)
          } else if (namespaceStack.isNotEmpty()) {
            namespaceStack.removeLast()
          }
        }
        is AxmlStartElementChunk -> {
          val name = doc.strings.getOrNull(chunk.nameIdx).orEmpty()
          val nsUri = if (chunk.namespaceIdx >= 0) doc.strings.getOrNull(chunk.namespaceIdx).orEmpty() else ""
          val acc = ElementAcc(name = name, namespaceUri = nsUri)

          if (elementStack.isEmpty()) {
            for ((prefix, uri) in namespaceStack) {
              acc.namespaces.add(ProtoXmlNamespace(prefix = prefix, uri = uri))
            }
          }

          for (attr in chunk.attributes) {
            val attrName = doc.strings.getOrNull(attr.nameIdx).orEmpty()
            val attrNs = if (attr.namespaceIdx >= 0) doc.strings.getOrNull(attr.namespaceIdx).orEmpty() else ""
            val resId = doc.resourceIds.getOrNull(attr.nameIdx) ?: 0

            val (attrValue, compiled) = when (attr.valueType) {
              TYPE_STRING -> {
                resolveStringValue(doc.strings, attr).orEmpty() to null
              }
              TYPE_INT_DEC -> {
                attr.valueData.toString() to ProtoItem(intDecimal = attr.valueData)
              }
              TYPE_INT_HEX -> {
                attr.valueData.toString() to ProtoItem(intHex = attr.valueData)
              }
              TYPE_INT_BOOLEAN -> {
                val boolVal = attr.valueData != 0
                boolVal.toString() to ProtoItem(booleanValue = boolVal)
              }
              TYPE_REFERENCE -> {
                "" to ProtoItem(refId = attr.valueData)
              }
              else -> {
                val rawStr = if (attr.rawValueIdx >= 0) doc.strings.getOrNull(attr.rawValueIdx) else null
                (rawStr ?: attr.valueData.toString()) to null
              }
            }

            acc.attributes.add(
              ProtoXmlAttribute(
                namespaceUri = attrNs,
                name = attrName,
                value = attrValue,
                resourceId = resId,
                compiledItem = compiled,
              )
            )
          }
          elementStack.addLast(acc)
        }
        is AxmlEndElementChunk -> {
          if (elementStack.isNotEmpty()) {
            val finished = elementStack.removeLast().build()
            if (elementStack.isNotEmpty()) {
              elementStack.last().children.add(ProtoXmlNode(element = finished))
            } else {
              rootElement = finished
            }
          }
        }
        is AxmlRawChunk -> Unit
      }
    }

    val finalRoot = rootElement ?: ProtoXmlElement(name = "manifest")
    return ProtoXmlNode(element = finalRoot)
  }

  /**
   * Compiles a protobuf [ProtoXmlNode] (from an `.aab` manifest) back into valid binary AXML
   * bytes (`AndroidManifest.xml` for an `.apk`).
   */
  fun compileProtoXmlToAxml(xmlNode: ProtoXmlNode): ByteArray {
    val root = xmlNode.element ?: ProtoXmlElement(name = "manifest")
    val resourceNameToId = linkedMapOf<String, Int>()
    val plainStrings = linkedSetOf<String>()

    fun collect(el: ProtoXmlElement) {
      for (ns in el.namespaces) {
        plainStrings.add(ns.prefix)
        plainStrings.add(ns.uri)
      }
      if (el.namespaceUri.isNotEmpty()) plainStrings.add(el.namespaceUri)
      plainStrings.add(el.name)
      for (attr in el.attributes) {
        if (attr.namespaceUri.isNotEmpty()) plainStrings.add(attr.namespaceUri)
        if (attr.resourceId != 0) {
          resourceNameToId.putIfAbsent(attr.name, attr.resourceId)
        } else {
          plainStrings.add(attr.name)
        }
        if (attr.value.isNotEmpty()) {
          plainStrings.add(attr.value)
        }
      }
      for (child in el.children) {
        child.element?.let { collect(it) }
      }
    }
    collect(root)

    val strings = mutableListOf<String>()
    val resourceIds = mutableListOf<Int>()
    for ((name, resId) in resourceNameToId) {
      strings.add(name)
      resourceIds.add(resId)
    }
    for (s in plainStrings) {
      if (s !in strings) {
        strings.add(s)
      }
    }

    val indexOf = strings.withIndex().associate { it.value to it.index }
    val chunks = mutableListOf<AxmlChunk>()

    for (ns in root.namespaces) {
      chunks.add(
        AxmlNamespaceChunk(
          isStart = true,
          lineNumber = 1,
          commentIdx = NO_INDEX,
          prefixIdx = indexOf[ns.prefix] ?: NO_INDEX,
          uriIdx = indexOf[ns.uri] ?: NO_INDEX,
        )
      )
    }

    fun emitElement(el: ProtoXmlElement) {
      val attrs = el.attributes.map { attr ->
        val nsIdx = if (attr.namespaceUri.isNotEmpty()) indexOf[attr.namespaceUri] ?: NO_INDEX else NO_INDEX
        val nameIdx = indexOf[attr.name] ?: NO_INDEX
        val compiled = attr.compiledItem
        when {
          compiled?.intDecimal != null -> AxmlAttribute(
            namespaceIdx = nsIdx,
            nameIdx = nameIdx,
            rawValueIdx = NO_INDEX,
            valueType = TYPE_INT_DEC,
            valueData = compiled.intDecimal,
          )
          compiled?.intHex != null -> AxmlAttribute(
            namespaceIdx = nsIdx,
            nameIdx = nameIdx,
            rawValueIdx = NO_INDEX,
            valueType = TYPE_INT_HEX,
            valueData = compiled.intHex,
          )
          compiled?.booleanValue != null -> AxmlAttribute(
            namespaceIdx = nsIdx,
            nameIdx = nameIdx,
            rawValueIdx = NO_INDEX,
            valueType = TYPE_INT_BOOLEAN,
            valueData = if (compiled.booleanValue) -1 else 0,
          )
          compiled?.refId != null && compiled.refId != 0 -> AxmlAttribute(
            namespaceIdx = nsIdx,
            nameIdx = nameIdx,
            rawValueIdx = NO_INDEX,
            valueType = TYPE_REFERENCE,
            valueData = compiled.refId,
          )
          else -> {
            val vIdx = indexOf[attr.value] ?: NO_INDEX
            AxmlAttribute(nsIdx, nameIdx, vIdx, TYPE_STRING, vIdx)
          }
        }
      }

      val elemNsIdx = if (el.namespaceUri.isNotEmpty()) indexOf[el.namespaceUri] ?: NO_INDEX else NO_INDEX
      val elemNameIdx = indexOf[el.name] ?: NO_INDEX

      chunks.add(
        AxmlStartElementChunk(
          lineNumber = 1,
          commentIdx = NO_INDEX,
          namespaceIdx = elemNsIdx,
          nameIdx = elemNameIdx,
          idIndex = 0,
          classIndex = 0,
          styleIndex = 0,
          attributes = attrs,
        )
      )

      for (child in el.children) {
        child.element?.let { emitElement(it) }
      }

      chunks.add(
        AxmlEndElementChunk(
          lineNumber = 1,
          commentIdx = NO_INDEX,
          namespaceIdx = elemNsIdx,
          nameIdx = elemNameIdx,
        )
      )
    }

    emitElement(root)

    for (ns in root.namespaces.asReversed()) {
      chunks.add(
        AxmlNamespaceChunk(
          isStart = false,
          lineNumber = 1,
          commentIdx = NO_INDEX,
          prefixIdx = indexOf[ns.prefix] ?: NO_INDEX,
          uriIdx = indexOf[ns.uri] ?: NO_INDEX,
        )
      )
    }

    return encodeAxml(
      AxmlDocument(
        strings = strings,
        styleBytes = ByteArray(0),
        styleCount = 0,
        resourceIds = resourceIds,
        bodyChunks = chunks,
      )
    )
  }

  /**
   * Builds a minimal, structurally valid binary AXML `AndroidManifest.xml` (useful for tests
   * and synthesizing clean manifests).
   */
  fun createMinimalBinaryManifest(
    packageName: String,
    appLabel: String,
    versionCode: Long = 1L,
    versionName: String = "1.0",
  ): ByteArray {
    val root = ProtoXmlElement(
      name = "manifest",
      namespaces = listOf(ProtoXmlNamespace(prefix = "android", uri = ANDROID_NS)),
      attributes = listOf(
        ProtoXmlAttribute(name = "package", value = packageName),
        ProtoXmlAttribute(
          namespaceUri = ANDROID_NS,
          name = "versionCode",
          value = versionCode.toString(),
          resourceId = ATTR_ID_VERSION_CODE,
          compiledItem = ProtoItem(intDecimal = versionCode.toInt()),
        ),
        ProtoXmlAttribute(
          namespaceUri = ANDROID_NS,
          name = "versionName",
          value = versionName,
          resourceId = ATTR_ID_VERSION_NAME,
        ),
      ),
      children = listOf(
        ProtoXmlNode(
          element = ProtoXmlElement(
            name = "application",
            attributes = listOf(
              ProtoXmlAttribute(
                namespaceUri = ANDROID_NS,
                name = "label",
                value = appLabel,
                resourceId = ATTR_ID_LABEL,
              )
            ),
          )
        )
      ),
    )
    return compileProtoXmlToAxml(ProtoXmlNode(element = root))
  }

  private fun resolveStringValue(strings: List<String>, attr: AxmlAttribute): String? {
    if (attr.valueType == TYPE_STRING && attr.valueData in strings.indices) {
      return strings[attr.valueData]
    }
    if (attr.rawValueIdx in strings.indices) {
      return strings[attr.rawValueIdx]
    }
    return null
  }

  // --- Binary AXML Codec ---

  private data class AxmlDocument(
    val strings: List<String>,
    val styleBytes: ByteArray,
    val styleCount: Int,
    val resourceIds: List<Int>,
    val bodyChunks: List<AxmlChunk>,
  )

  private sealed interface AxmlChunk

  private data class AxmlNamespaceChunk(
    val isStart: Boolean,
    val lineNumber: Int,
    val commentIdx: Int,
    val prefixIdx: Int,
    val uriIdx: Int,
  ) : AxmlChunk

  private data class AxmlAttribute(
    val namespaceIdx: Int,
    val nameIdx: Int,
    val rawValueIdx: Int,
    val valueType: Int,
    val valueData: Int,
  )

  private data class AxmlStartElementChunk(
    val lineNumber: Int,
    val commentIdx: Int,
    val namespaceIdx: Int,
    val nameIdx: Int,
    val idIndex: Int,
    val classIndex: Int,
    val styleIndex: Int,
    val attributes: List<AxmlAttribute>,
  ) : AxmlChunk

  private data class AxmlEndElementChunk(
    val lineNumber: Int,
    val commentIdx: Int,
    val namespaceIdx: Int,
    val nameIdx: Int,
  ) : AxmlChunk

  private data class AxmlRawChunk(val rawBytes: ByteArray) : AxmlChunk

  private fun decodeAxml(bytes: ByteArray): AxmlDocument? {
    return runCatching {
      val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
      val rootType = bb.getShort(0).toInt() and 0xFFFF
      val rootHeaderSize = bb.getShort(2).toInt() and 0xFFFF
      val rootSize = bb.getInt(4)
      if (rootType != RES_XML_TYPE || rootHeaderSize < 8 || rootSize > bytes.size) return null

      var pos = rootHeaderSize
      var strings: List<String> = emptyList()
      var styleBytes = ByteArray(0)
      var styleCount = 0
      var resourceIds: List<Int> = emptyList()
      val bodyChunks = mutableListOf<AxmlChunk>()

      while (pos + 8 <= rootSize) {
        val chunkType = bb.getShort(pos).toInt() and 0xFFFF
        val headerSize = bb.getShort(pos + 2).toInt() and 0xFFFF
        val chunkSize = bb.getInt(pos + 4)
        if (chunkSize < 8 || pos + chunkSize > rootSize) break

        when (chunkType) {
          RES_STRING_POOL_TYPE -> {
            val decodedPool = decodeStringPool(bytes, pos, chunkSize)
            strings = decodedPool.strings
            styleBytes = decodedPool.styleBytes
            styleCount = decodedPool.styleCount
          }
          RES_XML_RESOURCE_MAP_TYPE -> {
            val count = (chunkSize - headerSize) / 4
            val ids = ArrayList<Int>(count)
            for (i in 0 until count) {
              ids.add(bb.getInt(pos + headerSize + i * 4))
            }
            resourceIds = ids
          }
          RES_XML_START_NAMESPACE_TYPE, RES_XML_END_NAMESPACE_TYPE -> {
            bodyChunks.add(
              AxmlNamespaceChunk(
                isStart = chunkType == RES_XML_START_NAMESPACE_TYPE,
                lineNumber = bb.getInt(pos + 8),
                commentIdx = bb.getInt(pos + 12),
                prefixIdx = bb.getInt(pos + 16),
                uriIdx = bb.getInt(pos + 20),
              )
            )
          }
          RES_XML_START_ELEMENT_TYPE -> {
            val lineNumber = bb.getInt(pos + 8)
            val commentIdx = bb.getInt(pos + 12)
            val nsIdx = bb.getInt(pos + 16)
            val nameIdx = bb.getInt(pos + 20)
            val attrStart = bb.getShort(pos + 24).toInt() and 0xFFFF
            val attrSize = bb.getShort(pos + 26).toInt() and 0xFFFF
            val attrCount = bb.getShort(pos + 28).toInt() and 0xFFFF
            val idIndex = bb.getShort(pos + 30).toInt() and 0xFFFF
            val classIndex = bb.getShort(pos + 32).toInt() and 0xFFFF
            val styleIndex = bb.getShort(pos + 34).toInt() and 0xFFFF

            val attrs = ArrayList<AxmlAttribute>(attrCount)
            var attrPos = pos + headerSize + attrStart
            val stride = if (attrSize >= 20) attrSize else 20
            for (i in 0 until attrCount) {
              if (attrPos + 20 > pos + chunkSize) break
              val aNs = bb.getInt(attrPos)
              val aName = bb.getInt(attrPos + 4)
              val aRaw = bb.getInt(attrPos + 8)
              val aType = bb.get(attrPos + 15).toInt() and 0xFF
              val aData = bb.getInt(attrPos + 16)
              attrs.add(AxmlAttribute(aNs, aName, aRaw, aType, aData))
              attrPos += stride
            }
            bodyChunks.add(
              AxmlStartElementChunk(
                lineNumber = lineNumber,
                commentIdx = commentIdx,
                namespaceIdx = nsIdx,
                nameIdx = nameIdx,
                idIndex = idIndex,
                classIndex = classIndex,
                styleIndex = styleIndex,
                attributes = attrs,
              )
            )
          }
          RES_XML_END_ELEMENT_TYPE -> {
            bodyChunks.add(
              AxmlEndElementChunk(
                lineNumber = bb.getInt(pos + 8),
                commentIdx = bb.getInt(pos + 12),
                namespaceIdx = bb.getInt(pos + 16),
                nameIdx = bb.getInt(pos + 20),
              )
            )
          }
          else -> {
            bodyChunks.add(AxmlRawChunk(bytes.copyOfRange(pos, pos + chunkSize)))
          }
        }
        pos += chunkSize
      }

      AxmlDocument(
        strings = strings,
        styleBytes = styleBytes,
        styleCount = styleCount,
        resourceIds = resourceIds,
        bodyChunks = bodyChunks,
      )
    }.getOrNull()
  }

  private data class DecodedStringPool(
    val strings: List<String>,
    val styleBytes: ByteArray,
    val styleCount: Int,
  )

  private fun decodeStringPool(bytes: ByteArray, chunkStart: Int, chunkSize: Int): DecodedStringPool {
    val bb = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)
    val headerSize = bb.getShort(chunkStart + 2).toInt() and 0xFFFF
    val stringCount = bb.getInt(chunkStart + 8)
    val styleCount = bb.getInt(chunkStart + 12)
    val flags = bb.getInt(chunkStart + 16)
    val stringsStart = bb.getInt(chunkStart + 20)
    val stylesStart = bb.getInt(chunkStart + 24)
    val isUtf8 = (flags and UTF8_FLAG) != 0

    val offsets = IntArray(stringCount) { i -> bb.getInt(chunkStart + headerSize + i * 4) }
    val strings = ArrayList<String>(stringCount)
    val dataBase = chunkStart + stringsStart

    for (i in 0 until stringCount) {
      var p = dataBase + offsets[i]
      if (isUtf8) {
        // UTF-16 length (1 or 2 bytes)
        val firstCharLen = bytes[p].toInt() and 0xFF
        p += if ((firstCharLen and 0x80) != 0) 2 else 1
        // UTF-8 byte length (1 or 2 bytes)
        val b0 = bytes[p].toInt() and 0xFF
        val byteLen = if ((b0 and 0x80) != 0) {
          val b1 = bytes[p + 1].toInt() and 0xFF
          p += 2
          ((b0 and 0x7F) shl 8) or b1
        } else {
          p += 1
          b0
        }
        val safeLen = byteLen.coerceAtMost((chunkStart + chunkSize - p).coerceAtLeast(0))
        strings.add(String(bytes, p, safeLen, Charsets.UTF_8))
      } else {
        // UTF-16LE length (1 or 2 shorts)
        val s0 = bb.getShort(p).toInt() and 0xFFFF
        val charLen = if ((s0 and 0x8000) != 0) {
          val s1 = bb.getShort(p + 2).toInt() and 0xFFFF
          p += 4
          ((s0 and 0x7FFF) shl 16) or s1
        } else {
          p += 2
          s0
        }
        val byteLen = (charLen * 2).coerceAtMost((chunkStart + chunkSize - p).coerceAtLeast(0))
        strings.add(String(bytes, p, byteLen, Charsets.UTF_16LE))
      }
    }

    val styleBytes = if (styleCount > 0 && stylesStart > 0 && chunkStart + stylesStart < chunkStart + chunkSize) {
      bytes.copyOfRange(chunkStart + stylesStart, chunkStart + chunkSize)
    } else {
      ByteArray(0)
    }
    return DecodedStringPool(strings, styleBytes, styleCount)
  }

  private fun encodeAxml(doc: AxmlDocument): ByteArray {
    val stringPoolBytes = encodeStringPoolUtf16(doc.strings)
    val resMapBytes = if (doc.resourceIds.isNotEmpty()) encodeResourceMap(doc.resourceIds) else ByteArray(0)

    val bodyOut = ByteArrayOutputStream()
    for (chunk in doc.bodyChunks) {
      when (chunk) {
        is AxmlNamespaceChunk -> {
          val buf = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
          buf.putShort((if (chunk.isStart) RES_XML_START_NAMESPACE_TYPE else RES_XML_END_NAMESPACE_TYPE).toShort())
          buf.putShort(16)
          buf.putInt(24)
          buf.putInt(chunk.lineNumber)
          buf.putInt(chunk.commentIdx)
          buf.putInt(chunk.prefixIdx)
          buf.putInt(chunk.uriIdx)
          bodyOut.write(buf.array())
        }
        is AxmlStartElementChunk -> {
          val totalSize = 36 + chunk.attributes.size * 20
          val buf = ByteBuffer.allocate(totalSize).order(ByteOrder.LITTLE_ENDIAN)
          buf.putShort(RES_XML_START_ELEMENT_TYPE.toShort())
          buf.putShort(16)
          buf.putInt(totalSize)
          buf.putInt(chunk.lineNumber)
          buf.putInt(chunk.commentIdx)
          buf.putInt(chunk.namespaceIdx)
          buf.putInt(chunk.nameIdx)
          buf.putShort(20) // attributeStart (relative to headerSize=16)
          buf.putShort(20) // attributeSize
          buf.putShort(chunk.attributes.size.toShort())
          buf.putShort(chunk.idIndex.toShort())
          buf.putShort(chunk.classIndex.toShort())
          buf.putShort(chunk.styleIndex.toShort())
          for (attr in chunk.attributes) {
            buf.putInt(attr.namespaceIdx)
            buf.putInt(attr.nameIdx)
            buf.putInt(attr.rawValueIdx)
            buf.putShort(8) // Res_value.size
            buf.put(0) // res0
            buf.put(attr.valueType.toByte())
            buf.putInt(attr.valueData)
          }
          bodyOut.write(buf.array())
        }
        is AxmlEndElementChunk -> {
          val buf = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
          buf.putShort(RES_XML_END_ELEMENT_TYPE.toShort())
          buf.putShort(16)
          buf.putInt(24)
          buf.putInt(chunk.lineNumber)
          buf.putInt(chunk.commentIdx)
          buf.putInt(chunk.namespaceIdx)
          buf.putInt(chunk.nameIdx)
          bodyOut.write(buf.array())
        }
        is AxmlRawChunk -> bodyOut.write(chunk.rawBytes)
      }
    }

    val bodyBytes = bodyOut.toByteArray()
    val totalDocSize = 8 + stringPoolBytes.size + resMapBytes.size + bodyBytes.size
    val out = ByteBuffer.allocate(totalDocSize).order(ByteOrder.LITTLE_ENDIAN)
    out.putShort(RES_XML_TYPE.toShort())
    out.putShort(8)
    out.putInt(totalDocSize)
    out.put(stringPoolBytes)
    out.put(resMapBytes)
    out.put(bodyBytes)
    return out.array()
  }

  private fun encodeStringPoolUtf16(strings: List<String>): ByteArray {
    val strData = ByteArrayOutputStream()
    val offsets = IntArray(strings.size)
    for (i in strings.indices) {
      offsets[i] = strData.size()
      val s = strings[i]
      val len = s.length
      if (len > 0x7FFF) {
        val high = ((len ushr 16) and 0x7FFF) or 0x8000
        val low = len and 0xFFFF
        strData.write(high and 0xFF)
        strData.write((high ushr 8) and 0xFF)
        strData.write(low and 0xFF)
        strData.write((low ushr 8) and 0xFF)
      } else {
        strData.write(len and 0xFF)
        strData.write((len ushr 8) and 0xFF)
      }
      strData.write(s.toByteArray(Charsets.UTF_16LE))
      // 2-byte UTF-16 null terminator
      strData.write(0)
      strData.write(0)
    }
    while (strData.size() % 4 != 0) {
      strData.write(0)
    }

    val headerSize = 28
    val stringsStart = headerSize + strings.size * 4
    val rawData = strData.toByteArray()
    val chunkSize = stringsStart + rawData.size

    val buf = ByteBuffer.allocate(chunkSize).order(ByteOrder.LITTLE_ENDIAN)
    buf.putShort(RES_STRING_POOL_TYPE.toShort())
    buf.putShort(headerSize.toShort())
    buf.putInt(chunkSize)
    buf.putInt(strings.size)
    buf.putInt(0) // styleCount
    buf.putInt(0) // flags (UTF-16LE)
    buf.putInt(stringsStart)
    buf.putInt(0) // stylesStart
    for (offset in offsets) {
      buf.putInt(offset)
    }
    buf.put(rawData)
    return buf.array()
  }

  private fun encodeResourceMap(resourceIds: List<Int>): ByteArray {
    val chunkSize = 8 + resourceIds.size * 4
    val buf = ByteBuffer.allocate(chunkSize).order(ByteOrder.LITTLE_ENDIAN)
    buf.putShort(RES_XML_RESOURCE_MAP_TYPE.toShort())
    buf.putShort(8)
    buf.putInt(chunkSize)
    for (id in resourceIds) {
      buf.putInt(id)
    }
    return buf.array()
  }
}
