package com.shipsign.app.core.engine

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.android.apksig.ApkVerifier
import com.shipsign.app.domain.model.PackageMetadataInfo
import com.shipsign.app.domain.model.ResolvedBinaryType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.bouncycastle.cert.X509CertificateHolder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cms.CMSSignedData
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.File
import java.security.cert.X509Certificate
import java.util.Locale
import java.util.zip.ZipFile

/**
 * 100% offline package inspector for `.apk` and `.aab` files.
 * Extracts App Name, Package ID, Version Code, Version Name, and cryptographic signature
 * status (`Signed` + SHA-256/SHA-1 certificate fingerprint vs. `Unsigned`).
 */
object PackageInfoInspector {

  private const val ANDROID_NS = "http://schemas.android.com/apk/res/android"
  private const val ATTR_ID_LABEL = 0x01010001
  private const val ATTR_ID_VERSION_CODE = 0x0101021b
  private const val ATTR_ID_VERSION_NAME = 0x0101021c
  private const val ATTR_ID_MIN_SDK = 0x0101020c
  private const val ATTR_ID_TARGET_SDK = 0x01010270

  suspend fun inspectPackageAsync(
    context: Context,
    file: File,
    format: ResolvedBinaryType,
    fallbackName: String = file.nameWithoutExtension,
  ): PackageMetadataInfo = withContext(Dispatchers.IO) {
    inspectPackage(context, file, format, fallbackName)
  }

  fun inspectPackage(
    context: Context,
    file: File,
    format: ResolvedBinaryType,
    fallbackName: String = file.nameWithoutExtension,
  ): PackageMetadataInfo {
    return when (format) {
      ResolvedBinaryType.APK -> inspectApk(context, file, fallbackName)
      ResolvedBinaryType.AAB -> inspectAab(file, fallbackName)
      else -> PackageMetadataInfo(
        appName = fallbackName,
        packageId = "unknown",
        versionCode = 1L,
        versionName = "1.0",
        format = format,
        isSigned = SignatureScanner.hasExistingSignature(file),
      )
    }
  }

  private fun inspectApk(
    context: Context,
    apkFile: File,
    fallbackName: String,
  ): PackageMetadataInfo {
    var axmlMeta = ParsedManifestMeta()
    runCatching {
      ZipFile(apkFile).use { zip ->
        val manifestEntry = zip.getEntry("AndroidManifest.xml") ?: return@use
        val bytes = zip.getInputStream(manifestEntry).use { it.readBytes() }
        if (AxmlBinaryEditor.isBinaryAxml(bytes)) {
          axmlMeta = AxmlBinaryEditor.parseManifestMeta(bytes)
        }
      }
    }

    // Supplement label / package / version via Android PackageManager when available on device
    var pmLabel: String? = null
    var pmPackage: String? = null
    var pmVersionCode: Long? = null
    var pmVersionName: String? = null
    runCatching {
      val pm = context.packageManager
      val pkgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        pm.getPackageArchiveInfo(apkFile.absolutePath, PackageManager.PackageInfoFlags.of(0L))
      } else {
        @Suppress("DEPRECATION")
        pm.getPackageArchiveInfo(apkFile.absolutePath, 0)
      }
      if (pkgInfo != null) {
        pmPackage = pkgInfo.packageName
        pmVersionName = pkgInfo.versionName
        pmVersionCode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
          pkgInfo.longVersionCode
        } else {
          @Suppress("DEPRECATION")
          pkgInfo.versionCode.toLong()
        }
        pkgInfo.applicationInfo?.let { appInfo ->
          appInfo.sourceDir = apkFile.absolutePath
          appInfo.publicSourceDir = apkFile.absolutePath
          pmLabel = pm.getApplicationLabel(appInfo).toString().takeIf { it.isNotBlank() }
        }
      }
    }

    val cert = extractApkSigningCertificate(apkFile)
    val isSigned = cert != null || SignatureScanner.hasExistingSignature(apkFile)
    val sha256 = cert?.let { SigningEngine.formatCertFingerprint(it, "SHA-256") }
    val sha1 = cert?.let { SigningEngine.formatCertFingerprint(it, "SHA-1") }

    val resolvedAppName = axmlMeta.appLabel?.takeIf { it.isNotBlank() }
      ?: pmLabel?.takeIf { it.isNotBlank() && it != pmPackage }
      ?: fallbackName.ifBlank { "Android App" }
    val resolvedPackage = axmlMeta.packageName?.takeIf { it.isNotBlank() }
      ?: pmPackage?.takeIf { it.isNotBlank() }
      ?: "com.example.app"
    val resolvedVersionCode = axmlMeta.versionCode ?: pmVersionCode ?: 1L
    val resolvedVersionName = axmlMeta.versionName?.takeIf { it.isNotBlank() }
      ?: pmVersionName?.takeIf { it.isNotBlank() }
      ?: "1.0"

    return PackageMetadataInfo(
      appName = resolvedAppName,
      packageId = resolvedPackage,
      versionCode = resolvedVersionCode,
      versionName = resolvedVersionName,
      format = ResolvedBinaryType.APK,
      isSigned = isSigned,
      sha256Fingerprint = sha256,
      sha1Fingerprint = sha1,
      minSdk = axmlMeta.minSdk,
      targetSdk = axmlMeta.targetSdk,
    )
  }

  private fun inspectAab(
    aabFile: File,
    fallbackName: String,
  ): PackageMetadataInfo {
    var packageName: String? = null
    var versionCode: Long? = null
    var versionName: String? = null
    var appLabel: String? = null
    var labelResId: Int? = null
    var minSdk: Int? = null
    var targetSdk: Int? = null

    runCatching {
      ZipFile(aabFile).use { zip ->
        val manifestEntry = zip.getEntry("base/manifest/AndroidManifest.xml")
        if (manifestEntry != null) {
          val bytes = zip.getInputStream(manifestEntry).use { it.readBytes() }
          if (AxmlBinaryEditor.isBinaryAxml(bytes)) {
            val meta = AxmlBinaryEditor.parseManifestMeta(bytes)
            packageName = meta.packageName
            versionCode = meta.versionCode
            versionName = meta.versionName
            appLabel = meta.appLabel
            minSdk = meta.minSdk
            targetSdk = meta.targetSdk
          } else {
            val xmlNode = AabProtoCodec.parseXmlNode(bytes)
            val root = xmlNode.element
            if (root != null) {
              for (attr in root.attributes) {
                when {
                  attr.name == "package" -> packageName = attr.value.takeIf { it.isNotBlank() }
                  attr.name == "versionCode" || attr.resourceId == ATTR_ID_VERSION_CODE -> {
                    versionCode = extractProtoIntAttr(attr)?.toLong()
                  }
                  attr.name == "versionName" || attr.resourceId == ATTR_ID_VERSION_NAME -> {
                    versionName = attr.value.takeIf { it.isNotBlank() }
                  }
                }
              }
              for (child in root.children) {
                val el = child.element ?: continue
                when (el.name) {
                  "application" -> {
                    for (attr in el.attributes) {
                      if (attr.name == "label" || attr.resourceId == ATTR_ID_LABEL) {
                        val refId = attr.compiledItem?.refId
                        if (refId != null && refId != 0) {
                          labelResId = refId
                        }
                        if (attr.value.isNotBlank() && !attr.value.startsWith("@")) {
                          appLabel = attr.value
                        }
                      }
                    }
                  }
                  "uses-sdk" -> {
                    for (attr in el.attributes) {
                      when {
                        attr.name == "minSdkVersion" || attr.resourceId == ATTR_ID_MIN_SDK -> {
                          minSdk = extractProtoIntAttr(attr)
                        }
                        attr.name == "targetSdkVersion" || attr.resourceId == ATTR_ID_TARGET_SDK -> {
                          targetSdk = extractProtoIntAttr(attr)
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }

        // Resolve @string/app_name from base/resources.pb if label was a resource reference
        if (appLabel.isNullOrBlank() && labelResId != null && labelResId != 0) {
          val resEntry = zip.getEntry("base/resources.pb")
          if (resEntry != null) {
            val resBytes = zip.getInputStream(resEntry).use { it.readBytes() }
            appLabel = AabProtoCodec.resolveResourceTableString(resBytes, labelResId!!)
          }
        }
      }
    }

    val cert = extractJarCmsCertificate(aabFile)
    val isSigned = cert != null || SignatureScanner.hasExistingSignature(aabFile)
    val sha256 = cert?.let { SigningEngine.formatCertFingerprint(it, "SHA-256") }
    val sha1 = cert?.let { SigningEngine.formatCertFingerprint(it, "SHA-1") }

    return PackageMetadataInfo(
      appName = appLabel?.takeIf { it.isNotBlank() } ?: fallbackName.ifBlank { "App Bundle" },
      packageId = packageName?.takeIf { it.isNotBlank() } ?: "com.example.app",
      versionCode = versionCode ?: 1L,
      versionName = versionName?.takeIf { it.isNotBlank() } ?: "1.0",
      format = ResolvedBinaryType.AAB,
      isSigned = isSigned,
      sha256Fingerprint = sha256,
      sha1Fingerprint = sha1,
      minSdk = minSdk,
      targetSdk = targetSdk,
    )
  }

  private fun extractProtoIntAttr(attr: ProtoXmlAttribute): Int? {
    val compiled = attr.compiledItem
    if (compiled?.intDecimal != null) return compiled.intDecimal
    if (compiled?.intHex != null) return compiled.intHex
    return attr.value.toIntOrNull()
  }

  private fun extractApkSigningCertificate(apkFile: File): X509Certificate? {
    val verifiedCert = runCatching {
      val result = ApkVerifier.Builder(apkFile).build().verify()
      result.signerCertificates.firstOrNull()
    }.getOrNull()
    if (verifiedCert != null) return verifiedCert
    return extractJarCmsCertificate(apkFile)
  }

  private fun extractJarCmsCertificate(archiveFile: File): X509Certificate? {
    return runCatching {
      ZipFile(archiveFile).use { zip ->
        val entries = zip.entries()
        while (entries.hasMoreElements()) {
          val entry = entries.nextElement()
          val upper = entry.name.replace('\\', '/').uppercase(Locale.US)
          if (upper.startsWith("META-INF/") && !upper.removePrefix("META-INF/").contains('/')) {
            if (upper.endsWith(".RSA") || upper.endsWith(".DSA") || upper.endsWith(".EC")) {
              val cmsBytes = zip.getInputStream(entry).use { it.readBytes() }
              val cms = CMSSignedData(cmsBytes)
              val certHolder = cms.certificates.getMatches(null)
                .firstOrNull() as? X509CertificateHolder
              if (certHolder != null) {
                return@use JcaX509CertificateConverter()
                  .setProvider(BouncyCastleProvider.PROVIDER_NAME)
                  .getCertificate(certHolder)
              }
            }
          }
        }
        null
      }
    }.getOrNull()
  }
}
