package com.shipsign.app.ui.screens.project

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.CloudDone
import androidx.compose.material.icons.rounded.CloudUpload
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Key
import androidx.compose.material.icons.rounded.Link
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.shipsign.app.core.github.BuildOutputFormat
import com.shipsign.app.core.github.CloudBuildStage
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.ui.CloudBuildUiState
import com.shipsign.app.ui.InspectorUiState
import com.shipsign.app.ui.components.EditorialScreenHeader
import com.shipsign.app.ui.components.EditorialSectionKicker
import com.shipsign.app.ui.components.GitHubDisclosureDialog
import com.shipsign.app.ui.components.OnlineBuildOutlineBadge
import com.shipsign.app.ui.components.PasswordTextField
import com.shipsign.app.ui.components.ZeroTraceCloudCleanupCard
import com.shipsign.app.ui.theme.InkOnDark
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PaperBorder
import com.shipsign.app.ui.theme.PaperSurface
import com.shipsign.app.ui.theme.PaperSurfaceSubtle
import com.shipsign.app.ui.theme.PineOffline
import com.shipsign.app.ui.theme.VermilionAccent
import com.shipsign.app.ui.theme.VermilionContainer
import com.shipsign.app.ui.theme.VermilionOnAccent
import com.shipsign.app.ui.theme.VermilionOnContainer
import java.util.Locale

/**
 * Step 02 / 03 — Source Code (.ZIP) Online Build via user's own GitHub account.
 * Compiles unsigned APK/AAB in a private temporary repo while keeping signing 100% offline.
 */
@Composable
fun SourceBuildScreen(
  inspectorState: InspectorUiState,
  cloudBuildState: CloudBuildUiState,
  showGitHubDisclosureDialog: Boolean,
  onBack: () -> Unit,
  onConnectGitHub: () -> Unit,
  onConnectWithPat: (CharArray) -> Unit,
  onDisconnectGitHub: () -> Unit,
  onConfirmGitHubDisclosure: () -> Unit,
  onDismissGitHubDisclosure: () -> Unit,
  onPickSourceZip: (Uri) -> Unit,
  onClearSelectedFile: () -> Unit,
  onSelectFramework: (ProjectFramework) -> Unit,
  onSelectOutputFormat: (BuildOutputFormat) -> Unit,
  onStartCloudBuild: () -> Unit,
  onCancelCloudBuild: () -> Unit,
  onSelectReadyTarget: (AppTargetFile) -> Unit,
  onClearCloudTraceNow: () -> Unit,
  onKeepRepoForInspection: () -> Unit,
  onContinueToPipeline: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  var showPatEntry by remember { mutableStateOf(false) }
  var patInput by remember { mutableStateOf("") }

  val zipPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument(),
  ) { uri ->
    if (uri != null) onPickSourceZip(uri)
  }

  val notificationPermissionLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission(),
  ) {
    onStartCloudBuild()
  }

  fun launchBuildWithNotificationCheck() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      val granted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.POST_NOTIFICATIONS,
      ) == PackageManager.PERMISSION_GRANTED
      if (!granted) {
        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        return
      }
    }
    onStartCloudBuild()
  }

  if (showGitHubDisclosureDialog) {
    GitHubDisclosureDialog(
      onConfirm = onConfirmGitHubDisclosure,
      onDismiss = onDismissGitHubDisclosure,
    )
  }

  val target = inspectorState.targetFile
  val isSourceReady = target?.binaryType == ResolvedBinaryType.SOURCE_CODE_PROJECT
  val isBuildDone = target != null &&
    (target.binaryType == ResolvedBinaryType.APK || target.binaryType == ResolvedBinaryType.AAB) &&
    !cloudBuildState.isActive

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .navigationBarsPadding()
        .testTag("source_build_list"),
      contentPadding = PaddingValues(horizontal = 24.dp, vertical = 0.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        EditorialScreenHeader(
          kicker = "02 / 03 — SOURCE BUILD",
          title = "Compile source ZIP",
          subtitle = "Builds an unsigned package on GitHub Actions. Keystores never leave your phone.",
          onBack = onBack,
          trailingBadge = { OnlineBuildOutlineBadge() },
        )
      }

      // 1. GitHub Connection Card
      item {
        EditorialSectionKicker(text = "01 — GITHUB ACCOUNT")
        Spacer(modifier = Modifier.height(8.dp))
        Card(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("github_connect_card"),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = PaperSurface),
          border = BorderStroke(
            width = if (cloudBuildState.isConnected) 1.2.dp else 1.dp,
            color = if (cloudBuildState.isConnected) PineOffline else PaperBorder,
          ),
          elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f),
              ) {
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(PaperSurfaceSubtle)
                    .border(1.dp, PaperBorder, RoundedCornerShape(10.dp)),
                  contentAlignment = Alignment.Center,
                ) {
                  Icon(
                    imageVector = if (cloudBuildState.isConnected) Icons.Rounded.CloudDone else Icons.Rounded.Link,
                    contentDescription = null,
                    tint = if (cloudBuildState.isConnected) PineOffline else InkPrimary,
                    modifier = Modifier.size(20.dp),
                  )
                }
                Column {
                  Text(
                    text = if (cloudBuildState.isConnected) {
                      "@${cloudBuildState.connectedUsername ?: "github"}"
                    } else {
                      "Connect GitHub"
                    },
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontFamily = if (cloudBuildState.isConnected) JetBrainsMonoFamily else MaterialTheme.typography.titleMedium.fontFamily,
                      fontWeight = FontWeight.Bold,
                    ),
                    color = InkPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Text(
                    text = if (cloudBuildState.isConnected) {
                      "Private build runner ready"
                    } else {
                      "Compiles in a temporary private repo"
                    },
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary,
                  )
                }
              }

              if (cloudBuildState.isConnected && !cloudBuildState.isActive) {
                IconButton(
                  onClick = onDisconnectGitHub,
                  modifier = Modifier.testTag("disconnect_github_button"),
                ) {
                  Icon(
                    imageVector = Icons.AutoMirrored.Rounded.Logout,
                    contentDescription = "Disconnect GitHub",
                    tint = InkSecondary,
                  )
                }
              }
            }

            if (!cloudBuildState.isConnected) {
              Button(
                onClick = onConnectGitHub,
                enabled = !cloudBuildState.isAuthorizing,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(50.dp)
                  .testTag("connect_github_oauth_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = InkPrimary,
                  contentColor = InkOnDark,
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
              ) {
                if (cloudBuildState.isAuthorizing) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = InkOnDark,
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                }
                Text("Connect GitHub (OAuth)", fontWeight = FontWeight.SemiBold)
              }

              TextButton(
                onClick = { showPatEntry = !showPatEntry },
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("toggle_pat_entry_button"),
              ) {
                Icon(
                  imageVector = Icons.Rounded.Key,
                  contentDescription = null,
                  tint = InkSecondary,
                  modifier = Modifier.size(16.dp),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = if (showPatEntry) "Hide Personal Access Token" else "Or use Personal Access Token",
                  color = InkSecondary,
                )
              }

              if (showPatEntry) {
                PasswordTextField(
                  value = patInput,
                  onValueChange = { patInput = it },
                  label = "GitHub Personal Access Token",
                  imeAction = ImeAction.Done,
                  supportingText = "Requires repo + workflow scopes",
                  modifier = Modifier.testTag("github_pat_input"),
                )
                OutlinedButton(
                  onClick = {
                    val chars = patInput.trim().toCharArray()
                    patInput = ""
                    onConnectWithPat(chars)
                  },
                  enabled = patInput.isNotBlank() && !cloudBuildState.isAuthorizing,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("connect_github_pat_button"),
                  shape = RoundedCornerShape(12.dp),
                  border = BorderStroke(1.dp, PaperBorder),
                ) {
                  Text("Connect with Token", color = InkPrimary)
                }
              }
            }
          }
        }
      }

      // 2. Active Cloud Build Progress Card
      if (cloudBuildState.isActive) {
        item {
          EditorialSectionKicker(text = "BUILD IN PROGRESS")
          Spacer(modifier = Modifier.height(8.dp))
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("cloud_build_progress_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PaperSurface),
            border = BorderStroke(1.4.dp, InkPrimary),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text = "GitHub Actions",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold,
                  color = InkPrimary,
                )
                Text(
                  text = formatBuildClock(cloudBuildState.elapsedSeconds),
                  style = MaterialTheme.typography.labelLarge.copy(fontFamily = JetBrainsMonoFamily),
                  color = VermilionAccent,
                )
              }

              val stageIndex = cloudBuildState.currentStage?.ordinal ?: 0
              val stageProgress = ((stageIndex + 1).toFloat() / CloudBuildStage.entries.size.toFloat())
                .coerceIn(0.15f, 1f)
              LinearProgressIndicator(
                progress = { stageProgress },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(6.dp)
                  .clip(RoundedCornerShape(3.dp)),
                color = InkPrimary,
                trackColor = PaperSurfaceSubtle,
              )

              Text(
                text = cloudBuildState.statusText.ifBlank {
                  cloudBuildState.currentStage?.label ?: "Compiling project..."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = InkPrimary,
              )

              Text(
                text = "Runs safely in the background — you can switch apps and return anytime.",
                style = MaterialTheme.typography.bodySmall,
                color = InkSecondary,
              )

              OutlinedButton(
                onClick = onCancelCloudBuild,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("cancel_cloud_build_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, PaperBorder),
              ) {
                Icon(Icons.Rounded.Close, contentDescription = null, tint = InkPrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Cancel Build", color = InkPrimary)
              }
            }
          }
        }
      }

      // 3. Build Done Card
      if (isBuildDone && target != null) {
        item {
          EditorialSectionKicker(text = "ARTIFACT READY")
          Spacer(modifier = Modifier.height(8.dp))
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("cloud_build_done_card"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PaperSurface),
            border = BorderStroke(1.4.dp, PineOffline),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
              ) {
                Icon(
                  imageVector = Icons.Rounded.CheckCircle,
                  contentDescription = null,
                  tint = PineOffline,
                  modifier = Modifier.size(24.dp),
                )
                Column {
                  Text(
                    text = "Build Ready Offline",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = InkPrimary,
                  )
                  Text(
                    text = target.originalName,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = InkSecondary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                }
              }

              if (inspectorState.availableBuildTargets.size > 1) {
                HorizontalDivider(color = PaperBorder)
                Text(
                  text = "Select artifact to review",
                  style = MaterialTheme.typography.labelMedium,
                  color = InkSecondary,
                )
                Row(
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  inspectorState.availableBuildTargets.forEach { candidate ->
                    val selected = candidate.sessionFile == target.sessionFile
                    EditorialOptionPill(
                      label = if (candidate.binaryType == ResolvedBinaryType.AAB) "AAB" else "APK",
                      selected = selected,
                      onClick = { onSelectReadyTarget(candidate) },
                      modifier = Modifier.weight(1f),
                    )
                  }
                }
              }

              Button(
                onClick = onContinueToPipeline,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(54.dp)
                  .testTag("cloud_build_continue_offline_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = InkPrimary,
                  contentColor = InkOnDark,
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
              ) {
                Text(
                  text = "Continue to review",
                  style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 16.sp,
                  ),
                )
              }
            }
          }
        }
      }

      // 4. Upload .ZIP & Choose Framework + Format
      if (!cloudBuildState.isActive && !isBuildDone) {
        item {
          EditorialSectionKicker(text = "02 — SOURCE ARCHIVE")
          Spacer(modifier = Modifier.height(8.dp))
          if (!isSourceReady) {
            Card(
              onClick = {
                if (!inspectorState.isProcessing) {
                  zipPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "*/*"))
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("upload_source_zip_card"),
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = PaperSurface),
              border = BorderStroke(1.dp, PaperBorder),
              elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 24.dp, vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                if (inspectorState.isProcessing) {
                  CircularProgressIndicator(
                    color = InkPrimary,
                    strokeWidth = 2.4.dp,
                    modifier = Modifier.size(32.dp),
                  )
                  Spacer(modifier = Modifier.height(12.dp))
                  Text(
                    text = "Inspecting source archive...",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = InkPrimary,
                  )
                } else {
                  Box(
                    modifier = Modifier
                      .size(48.dp)
                      .clip(RoundedCornerShape(12.dp))
                      .background(PaperSurfaceSubtle)
                      .border(1.dp, PaperBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.CloudUpload,
                      contentDescription = "Upload Source ZIP",
                      tint = InkPrimary,
                      modifier = Modifier.size(22.dp),
                    )
                  }
                  Spacer(modifier = Modifier.height(12.dp))
                  Text(
                    text = "Upload source .ZIP",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = InkPrimary,
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "Raw Project .zip (Cloud IDE / Flutter / Android Source)",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary,
                  )
                }
              }
            }
          } else if (target != null) {
            val detectedFramework = target.sourceMetadata?.framework ?: ProjectFramework.NATIVE_ANDROID
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("source_config_card"),
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = PaperSurface),
              border = BorderStroke(1.dp, PaperBorder),
              elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(10.dp),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.FolderZip,
                    contentDescription = null,
                    tint = InkPrimary,
                    modifier = Modifier.size(22.dp),
                  )
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = target.originalName,
                      style = MaterialTheme.typography.titleSmall.copy(
                        fontFamily = JetBrainsMonoFamily,
                        fontWeight = FontWeight.Medium,
                      ),
                      color = InkPrimary,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text = "Detected: ${detectedFramework.displayName}",
                      style = MaterialTheme.typography.bodySmall,
                      color = PineOffline,
                    )
                  }
                  TextButton(onClick = onClearSelectedFile) {
                    Text("Change", color = InkSecondary)
                  }
                }

                HorizontalDivider(color = PaperBorder)

                EditorialSectionKicker(text = "FRAMEWORK")
                Row(
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  val frameworkChoices = listOf(
                    ProjectFramework.NATIVE_ANDROID to "Android",
                    ProjectFramework.FLUTTER to "Flutter",
                    ProjectFramework.CAPACITOR_CORDOVA to "Web / Cap",
                  )
                  frameworkChoices.forEach { (fw, label) ->
                    val isSelected = detectedFramework == fw ||
                      (fw == ProjectFramework.CAPACITOR_CORDOVA && detectedFramework == ProjectFramework.REACT_NATIVE)
                    EditorialOptionPill(
                      label = label,
                      selected = isSelected,
                      onClick = { onSelectFramework(fw) },
                      modifier = Modifier
                        .weight(1f)
                        .testTag("framework_chip_${fw.name.lowercase(Locale.US)}"),
                    )
                  }
                }

                EditorialSectionKicker(text = "OUTPUT FORMAT")
                Row(
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  modifier = Modifier.fillMaxWidth(),
                ) {
                  BuildOutputFormat.entries.forEach { format ->
                    EditorialOptionPill(
                      label = format.displayLabel,
                      selected = inspectorState.selectedOutputFormat == format,
                      onClick = { onSelectOutputFormat(format) },
                      modifier = Modifier
                        .weight(1f)
                        .testTag("format_chip_${format.name.lowercase(Locale.US)}"),
                    )
                  }
                }

                Button(
                  onClick = { launchBuildWithNotificationCheck() },
                  enabled = cloudBuildState.isConnected,
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("start_cloud_build_button"),
                  shape = RoundedCornerShape(14.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = VermilionAccent,
                    contentColor = VermilionOnAccent,
                    disabledContainerColor = VermilionAccent.copy(alpha = 0.42f),
                    disabledContentColor = VermilionOnAccent,
                  ),
                  elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
                ) {
                  Text(
                    text = if (cloudBuildState.isConnected) "Build on GitHub" else "Connect GitHub first",
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.SemiBold,
                      fontSize = 16.sp,
                    ),
                  )
                }
              }
            }
          }
        }
      }

      // 5. User-Confirmed Zero-Trace Cloud Cleanup Card
      item {
        ZeroTraceCloudCleanupCard(
          persistedSession = cloudBuildState.persistedSession,
          isClearing = cloudBuildState.isClearingCloudTrace,
          clearedRepoName = cloudBuildState.clearedCloudRepoName,
          onClearCloudTraceNow = onClearCloudTraceNow,
          onKeepForInspection = onKeepRepoForInspection,
        )
      }

      // 6. Error Display
      val errorMsg = inspectorState.errorMessage ?: cloudBuildState.translatedError?.message
        ?: cloudBuildState.repoAccessMessage
      if (!errorMsg.isNullOrBlank()) {
        item {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = VermilionContainer,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("source_build_error_banner"),
          ) {
            Text(
              text = errorMsg,
              style = MaterialTheme.typography.bodySmall,
              color = VermilionOnContainer,
              modifier = Modifier.padding(14.dp),
            )
          }
        }
      }

      item { Spacer(modifier = Modifier.height(24.dp)) }
    }
  }
}

@Composable
private fun EditorialOptionPill(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    onClick = onClick,
    modifier = modifier.height(44.dp),
    shape = RoundedCornerShape(11.dp),
    color = if (selected) InkPrimary else PaperSurfaceSubtle,
    border = if (selected) null else BorderStroke(1.dp, PaperBorder),
  ) {
    Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 8.dp)) {
      Text(
        text = label,
        style = MaterialTheme.typography.labelMedium.copy(
          fontFamily = JetBrainsMonoFamily,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
        ),
        color = if (selected) InkOnDark else InkSecondary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

private fun formatBuildClock(totalSec: Int): String {
  val safe = totalSec.coerceAtLeast(0)
  return String.format(Locale.US, "%02d:%02d", safe / 60, safe % 60)
}
