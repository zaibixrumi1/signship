package com.shipsign.app.ui.screens.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shipsign.app.R
import com.shipsign.app.ui.components.ShipSignEmblem
import com.shipsign.app.ui.theme.InkMuted
import com.shipsign.app.ui.theme.InkMutedOnDark
import com.shipsign.app.ui.theme.InkOnDark
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PaperBorder
import com.shipsign.app.ui.theme.PaperSurface
import com.shipsign.app.ui.theme.PineOffline
import com.shipsign.app.ui.theme.SpaceGroteskFamily
import com.shipsign.app.ui.theme.VermilionAccent
import com.shipsign.app.ui.theme.VermilionOnAccent

/**
 * Page 1 of the ShipSign Visual Concept:
 * Warm Paper & Ink Swiss-editorial Home screen with strictly 3 clean action cards:
 *   01 — Start Your Project (Dark Ink hero card with Vermilion arrow)
 *   02 — Previous Projects (White card)
 *   03 — Create Keystore (White card)
 */
@Composable
fun HomeScreen(
  savedProjectCount: Int,
  savedKeystoreCount: Int,
  onStartProject: () -> Unit,
  onViewPreviousProjects: () -> Unit,
  onCreateKeystore: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 24.dp),
    ) {
      Column(
        modifier = Modifier
          .weight(1f)
          .verticalScroll(rememberScrollState()),
      ) {
        Spacer(modifier = Modifier.height(18.dp))

        // Editorial Brand Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            ShipSignEmblem(size = 30.dp)
            Text(
              text = stringResource(R.string.app_name),
              style = MaterialTheme.typography.titleLarge.copy(
                fontFamily = SpaceGroteskFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                letterSpacing = (-0.3).sp,
              ),
              color = InkPrimary,
            )
          }

          Text(
            text = "ANDROID",
            style = MaterialTheme.typography.labelMedium.copy(
              fontFamily = JetBrainsMonoFamily,
              fontSize = 12.sp,
              letterSpacing = 1.4.sp,
              fontWeight = FontWeight.Normal,
            ),
            color = InkSecondary,
          )
        }

        Spacer(modifier = Modifier.height(34.dp))

        // Hero Headline & Subtitle
        Text(
          text = "What are we shipping\ntoday?",
          style = MaterialTheme.typography.displaySmall.copy(
            fontFamily = SpaceGroteskFamily,
            fontWeight = FontWeight.Bold,
            fontSize = 33.sp,
            lineHeight = 39.sp,
            letterSpacing = (-0.7).sp,
          ),
          color = InkPrimary,
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "Build, brand and sign Android apps. Almost everything runs on your device.",
          style = MaterialTheme.typography.bodyLarge.copy(
            fontSize = 15.sp,
            lineHeight = 22.sp,
          ),
          color = InkSecondary,
        )

        Spacer(modifier = Modifier.height(28.dp))

        // 01 — Dark Ink Hero Card: Start Your Project
        Card(
          onClick = onStartProject,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("home_start_project_card"),
          shape = RoundedCornerShape(18.dp),
          colors = CardDefaults.cardColors(containerColor = InkPrimary),
          elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(22.dp),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.Top,
            ) {
              Text(
                text = "01",
                style = MaterialTheme.typography.labelMedium.copy(
                  fontFamily = JetBrainsMonoFamily,
                  fontSize = 13.sp,
                  letterSpacing = 0.8.sp,
                ),
                color = InkMutedOnDark,
                modifier = Modifier.padding(top = 4.dp),
              )

              Box(
                modifier = Modifier
                  .size(42.dp)
                  .clip(RoundedCornerShape(11.dp))
                  .background(VermilionAccent),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                  contentDescription = "Start Your Project",
                  tint = VermilionOnAccent,
                  modifier = Modifier.size(20.dp),
                )
              }
            }

            Spacer(modifier = Modifier.height(30.dp))

            Text(
              text = "Start Your Project",
              style = MaterialTheme.typography.headlineSmall.copy(
                fontFamily = SpaceGroteskFamily,
                fontWeight = FontWeight.Bold,
                fontSize = 23.sp,
                lineHeight = 28.sp,
              ),
              color = InkOnDark,
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
              text = "From source code, an APK or an AAB",
              style = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp),
              color = InkMutedOnDark,
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 02 — Secondary White Card: Previous Projects
        HomeSecondaryCard(
          indexLabel = "02",
          icon = Icons.Outlined.Folder,
          title = "Previous Projects",
          subtitle = if (savedProjectCount > 0) {
            "$savedProjectCount saved · Download, sign or edit later"
          } else {
            "Download, sign or edit later"
          },
          onClick = onViewPreviousProjects,
          testTag = "home_previous_projects_card",
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 03 — Secondary White Card: Create Keystore
        HomeSecondaryCard(
          indexLabel = "03",
          icon = Icons.Outlined.Key,
          title = "Create Keystore",
          subtitle = if (savedKeystoreCount > 0) {
            "$savedKeystoreCount in vault · Generate or import one"
          } else {
            "Generate a new key or import one"
          },
          onClick = onCreateKeystore,
          testTag = "home_create_keystore_card",
        )

        Spacer(modifier = Modifier.height(24.dp))
      }

      // Pinned Footer Status Line
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp, bottom = 22.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
          modifier = Modifier
            .size(6.dp)
            .clip(RoundedCornerShape(1.5.dp))
            .background(PineOffline),
        )
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = "ONLINE ONLY FOR GITHUB BUILDS. SIGNING IS ON-DEVICE.",
          style = MaterialTheme.typography.labelSmall.copy(
            fontFamily = JetBrainsMonoFamily,
            fontSize = 11.sp,
            lineHeight = 16.sp,
            letterSpacing = 0.8.sp,
          ),
          color = InkSecondary,
        )
      }
    }
  }
}

@Composable
private fun HomeSecondaryCard(
  indexLabel: String,
  icon: ImageVector,
  title: String,
  subtitle: String,
  onClick: () -> Unit,
  testTag: String,
) {
  Card(
    onClick = onClick,
    modifier = Modifier
      .fillMaxWidth()
      .testTag(testTag),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = PaperSurface),
    border = BorderStroke(1.dp, PaperBorder),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 18.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(RoundedCornerShape(12.dp))
          .background(PaperSurface)
          .border(1.dp, PaperBorder, RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = InkPrimary,
          modifier = Modifier.size(20.dp),
        )
      }

      Spacer(modifier = Modifier.width(16.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 17.sp,
          ),
          color = InkPrimary,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall.copy(
            fontSize = 13.5.sp,
            lineHeight = 18.sp,
          ),
          color = InkSecondary,
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Text(
        text = indexLabel,
        style = MaterialTheme.typography.labelMedium.copy(
          fontFamily = JetBrainsMonoFamily,
          fontSize = 13.sp,
        ),
        color = InkMuted,
      )
    }
  }
}
