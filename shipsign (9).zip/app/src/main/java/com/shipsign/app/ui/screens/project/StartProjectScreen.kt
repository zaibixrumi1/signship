package com.shipsign.app.ui.screens.project

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shipsign.app.ui.components.EditorialScreenHeader
import com.shipsign.app.ui.components.OfflineOutlineBadge
import com.shipsign.app.ui.components.OnlineBuildOutlineBadge
import com.shipsign.app.ui.theme.InkOnDark
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PaperBorder
import com.shipsign.app.ui.theme.PaperSurface

private enum class SourceChoice {
  SOURCE_ZIP,
  BUILT_APK,
  BUILT_AAB,
}

/**
 * Page 2 of the ShipSign Visual Concept — "01 / 03 — SOURCE / What do you have?":
 * Three selectable radio cards (Source code .ZIP, Built APK, Built AAB) + pinned Ink Continue CTA.
 */
@Composable
fun StartProjectScreen(
  onBack: () -> Unit,
  onSelectSourceZip: () -> Unit,
  onSelectAlreadyBuiltApk: () -> Unit,
  onSelectAlreadyBuiltAab: () -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedChoice by rememberSaveable { mutableStateOf(SourceChoice.SOURCE_ZIP) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .navigationBarsPadding()
        .padding(horizontal = 24.dp),
    ) {
      Column(
        modifier = Modifier
          .weight(1f)
          .verticalScroll(rememberScrollState()),
      ) {
        EditorialScreenHeader(
          kicker = "01 / 03 — SOURCE",
          title = "What do you have?",
          onBack = onBack,
        )

        Spacer(modifier = Modifier.height(24.dp))

        SourceRadioCard(
          title = "Source code (.ZIP)",
          description = "Connect GitHub, upload ZIP, pick framework. Produces an unsigned AAB or APK.",
          selected = selectedChoice == SourceChoice.SOURCE_ZIP,
          isOnline = true,
          onClick = { selectedChoice = SourceChoice.SOURCE_ZIP },
          testTag = "branch_source_zip_card",
        )

        Spacer(modifier = Modifier.height(14.dp))

        SourceRadioCard(
          title = "Built APK",
          description = "View info, customize, convert to AAB, then sign.",
          selected = selectedChoice == SourceChoice.BUILT_APK,
          isOnline = false,
          onClick = { selectedChoice = SourceChoice.BUILT_APK },
          testTag = "branch_apk_card",
        )

        Spacer(modifier = Modifier.height(14.dp))

        SourceRadioCard(
          title = "Built AAB",
          description = "View info, customize, convert to APK, then sign.",
          selected = selectedChoice == SourceChoice.BUILT_AAB,
          isOnline = false,
          onClick = { selectedChoice = SourceChoice.BUILT_AAB },
          testTag = "branch_aab_card",
        )

        Spacer(modifier = Modifier.height(24.dp))
      }

      Button(
        onClick = {
          when (selectedChoice) {
            SourceChoice.SOURCE_ZIP -> onSelectSourceZip()
            SourceChoice.BUILT_APK -> onSelectAlreadyBuiltApk()
            SourceChoice.BUILT_AAB -> onSelectAlreadyBuiltAab()
          }
        },
        modifier = Modifier
          .fillMaxWidth()
          .padding(top = 8.dp, bottom = 22.dp)
          .height(54.dp)
          .testTag("start_project_continue_button"),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(
          containerColor = InkPrimary,
          contentColor = InkOnDark,
        ),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
      ) {
        Text(
          text = "Continue",
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp,
          ),
        )
      }
    }
  }
}

@Composable
private fun SourceRadioCard(
  title: String,
  description: String,
  selected: Boolean,
  isOnline: Boolean,
  onClick: () -> Unit,
  testTag: String,
) {
  Card(
    onClick = onClick,
    modifier = Modifier
      .fillMaxWidth()
      .testTag(testTag),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = PaperSurface),
    border = BorderStroke(
      width = if (selected) 1.6.dp else 1.dp,
      color = if (selected) InkPrimary else PaperBorder,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 18.dp, vertical = 18.dp),
      verticalAlignment = Alignment.Top,
    ) {
      // Crisp custom radio indicator matching Page 2
      Box(
        modifier = Modifier
          .padding(top = 2.dp)
          .size(21.dp)
          .clip(CircleShape)
          .border(
            width = if (selected) 2.dp else 1.5.dp,
            color = InkPrimary,
            shape = CircleShape,
          ),
        contentAlignment = Alignment.Center,
      ) {
        if (selected) {
          Box(
            modifier = Modifier
              .size(9.dp)
              .clip(CircleShape)
              .background(InkPrimary),
          )
        }
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium.copy(
            fontWeight = FontWeight.Bold,
            fontSize = 18.sp,
          ),
          color = InkPrimary,
        )

        Text(
          text = description,
          style = MaterialTheme.typography.bodyMedium.copy(
            fontSize = 14.sp,
            lineHeight = 20.sp,
          ),
          color = InkSecondary,
        )

        Spacer(modifier = Modifier.height(4.dp))

        if (isOnline) {
          OnlineBuildOutlineBadge()
        } else {
          OfflineOutlineBadge()
        }
      }
    }
  }
}
