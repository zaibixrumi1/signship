package com.shipsign.app

import android.app.Application
import android.os.Handler
import android.os.Looper
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.shipsign.app.core.github.BuildSessionStore
import com.shipsign.app.core.github.ShipSignBuildService
import com.shipsign.app.core.security.AppPreferences
import com.shipsign.app.core.security.ZeroTraceManager
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.security.Security

class ShipSignApp : Application(), DefaultLifecycleObserver {

  private val mainHandler = Handler(Looper.getMainLooper())
  private val backgroundWipeRunnable = Runnable {
    if (!shouldPreserveActiveBuildSession()) {
      ZeroTraceManager.nukeAllSync(this@ShipSignApp)
    }
  }

  override fun onCreate() {
    super<Application>.onCreate()

    // Register Bouncy Castle at priority slot 1 so BC overrides truncated Android JCA providers
    Security.removeProvider(BouncyCastleProvider.PROVIDER_NAME)
    Security.insertProviderAt(BouncyCastleProvider(), 1)

    // Guarantee a clean ephemeral workspace on cold start unless a cloud build session is active/awaiting signing
    if (!shouldPreserveActiveBuildSession()) {
      ZeroTraceManager.nukeAllSync(this)
    } else {
      ZeroTraceManager.createOrGetSessionDir(this)
    }

    // Attach ProcessLifecycleOwner observer for background timeout zero-trace wiping
    ProcessLifecycleOwner.get().lifecycle.addObserver(this)

    // Attach uncaught exception handler so crashes trigger immediate synchronous shredding
    val previousHandler = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
      if (!shouldPreserveActiveBuildSession()) {
        runCatching { ZeroTraceManager.nukeAllSync(this@ShipSignApp) }
      }
      previousHandler?.uncaughtException(thread, throwable)
    }
  }

  override fun onStart(owner: LifecycleOwner) {
    mainHandler.removeCallbacks(backgroundWipeRunnable)
    ZeroTraceManager.createOrGetSessionDir(this)
  }

  override fun onStop(owner: LifecycleOwner) {
    mainHandler.removeCallbacks(backgroundWipeRunnable)
    if (shouldPreserveActiveBuildSession()) {
      return
    }
    val delaySec = AppPreferences.getBackgroundWipeTimeoutSec(this)
    if (delaySec <= 0) {
      ZeroTraceManager.nukeAllSync(this)
    } else {
      mainHandler.postDelayed(backgroundWipeRunnable, delaySec * 1000L)
    }
  }

  private fun shouldPreserveActiveBuildSession(): Boolean {
    return ShipSignBuildService.isRunning.value || BuildSessionStore.hasProtectedBuildArtifacts(this)
  }
}
