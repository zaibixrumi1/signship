package com.shipsign.app.ui.screens.step3

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SaveAlt
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import com.shipsign.app.R
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.domain.model.SigningOptions
import com.shipsign.app.ui.CloudBuildUiState
import com.shipsign.app.ui.KeystoreStudioUiState
import com.shipsign.app.ui.SigningStudioUiState
import com.shipsign.app.ui.components.FingerprintCopyCard
import com.shipsign.app.ui.components.StandardCardShape
import com.shipsign.app.ui.components.TerminalLogBox
import com.shipsign.app.ui.components.ZeroTraceCloudCleanupCard
import java.io.File

@Composable
fun SignAndResultScreen(
  targetFile: AppTargetFile?,
  availableTargets: List<AppTargetFile> = emptyList(),
  keystoreState: KeystoreStudioUiState,
  signingState: SigningStudioUiState,
  cloudBuildState: CloudBuildUiState = CloudBuildUiState(),
  onSelectTarget: (AppTargetFile) -> Unit = {},
  onUpdateOptions: ((SigningOptions) -> SigningOptions) -> Unit,
  onSignNow: () -> Unit,
  onSaveCopyToUri: (sourceUri: Uri, destUri: Uri, onComplete: (Boolean) -> Unit) -> Unit,
  onClearCloudTraceNow: () -> Unit = {},
  onKeepRepoForInspection: () -> Unit = {},
  onSignAnotherApp: () -> Unit,
  onShowSnackbar: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val copiedTemplate = stringResource(R.string.copied_fingerprint_snackbar)
  val shareTitle = stringResource(R.string.step3_share_chooser_title)
  val savedMsg = stringResource(R.string.saved_copy_snackbar)
  val saveFailedMsg = stringResource(R.string.save_copy_failed_snackbar)
  val result = signingState.result
  val isAab = targetFile?.binaryType == ResolvedBinaryType.AAB
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  val saveDocumentLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.CreateDocument("application/octet-stream"),
  ) { destUri ->
    val currentResult = signingState.result
    if (destUri != null && currentResult != null) {
      onSaveCopyToUri(currentResult.primarySignedUri, destUri) { ok ->
        onShowSnackbar(if (ok) savedMsg else saveFailedMsg)
      }
    }
  }

  val canSign = !signingState.isSigning &&
    targetFile != null &&
    keystoreState.tempKeystoreFile != null &&
    keystoreState.hasUnlockedCredentials

  Column(
    modifier = modifier.fillMaxSize(),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .widthIn(max = 600.dp)
        .testTag("sign_and_result_list"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = if (result == null) 16.dp else 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      if (result == null) {
        item {
          Text(
            text = stringResource(R.string.step3_title),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
          )
        }

        // Dual-artifact toggle pill when BuildOutputFormat.BOTH produced both .apk and .aab
        if (availableTargets.size >= 2) {
          item {
            SingleChoiceSegmentedButtonRow(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("step3_dual_artifact_switcher"),
            ) {
              availableTargets.forEachIndexed { index, candidate ->
                val isSelected = candidate.sessionFile == targetFile?.sessionFile
                val isCandidateAab = candidate.binaryType == ResolvedBinaryType.AAB
                val pillLabel = if (isCandidateAab) "AAB" else "APK"
                SegmentedButton(
                  selected = isSelected,
                  onClick = { if (!signingState.isSigning) onSelectTarget(candidate) },
                  enabled = !signingState.isSigning,
                  shape = SegmentedButtonDefaults.itemShape(
                    index = index,
                    count = availableTargets.size,
                  ),
                  icon = {
                    Icon(
                      imageVector = if (isCandidateAab) Icons.Filled.Inventory2 else Icons.Filled.Android,
                      contentDescription = null,
                      modifier = Modifier.size(16.dp),
                    )
                  },
                  modifier = Modifier.testTag(
                    if (isCandidateAab) "step3_toggle_aab" else "step3_toggle_apk"
                  ),
                ) {
                  Text(
                    text = pillLabel,
                    style = MaterialTheme.typography.labelMedium,
                    maxLines = 1,
                  )
                }
              }
            }
          }
        }

        // Aligned Summary Card: Target File, Certificate Alias, Schemes, ZipAlign status
        item {
          val opts = signingState.options
          val activeSchemes = if (isAab) {
            "JAR (Play Bundle)"
          } else {
            buildList {
              if (opts.v1Enabled) add("v1")
              if (opts.v2Enabled) add("v2")
              if (opts.v3Enabled) add("v3")
              if (opts.v4Enabled) add("v4")
            }.joinToString(" · ").ifEmpty { "None" }
          }
          val zipAlignLabel = when {
            isAab -> "N/A (AAB)"
            opts.zipAlignBeforeSign -> "4B + 16KB .so"
            else -> "Disabled"
          }
          val aliasDisplay = keystoreState.verifiedSummary?.let { summary ->
            "${summary.alias} (${summary.format.name})"
          } ?: keystoreState.importedFileName?.let { "$it (${keystoreState.detectedFormat.name})" } ?: "—"

          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("step3_summary_card"),
            shape = StandardCardShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              SummaryKeyValueRow(
                label = stringResource(R.string.step3_summary_target_label),
                value = targetFile?.originalName ?: "—",
              )
              HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
              SummaryKeyValueRow(
                label = stringResource(R.string.step3_summary_alias_label),
                value = aliasDisplay,
                accent = true,
              )
              HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
              SummaryKeyValueRow(
                label = stringResource(R.string.step3_summary_schemes_label),
                value = activeSchemes,
              )
              HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
              SummaryKeyValueRow(
                label = stringResource(R.string.step3_summary_zipalign_label),
                value = zipAlignLabel,
              )
            }
          }
        }

        // Signing Option Toggles
        item {
          val opts = signingState.options
          Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = StandardCardShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
              ToggleRow(
                label = stringResource(R.string.step3_opt_v1),
                checked = opts.v1Enabled,
                enabled = !signingState.isSigning && !isAab,
                onCheckedChange = { checked -> onUpdateOptions { it.copy(v1Enabled = checked) } },
                testTag = "toggle_v1_signing",
              )
              ToggleRow(
                label = stringResource(R.string.step3_opt_v2),
                checked = opts.v2Enabled,
                enabled = !signingState.isSigning && !isAab,
                onCheckedChange = { checked -> onUpdateOptions { it.copy(v2Enabled = checked) } },
                testTag = "toggle_v2_signing",
              )
              ToggleRow(
                label = stringResource(R.string.step3_opt_v3),
                checked = opts.v3Enabled,
                enabled = !signingState.isSigning && !isAab,
                onCheckedChange = { checked -> onUpdateOptions { it.copy(v3Enabled = checked) } },
                testTag = "toggle_v3_signing",
              )
              ToggleRow(
                label = stringResource(R.string.step3_opt_v4),
                checked = opts.v4Enabled,
                enabled = !signingState.isSigning && !isAab,
                onCheckedChange = { checked -> onUpdateOptions { it.copy(v4Enabled = checked) } },
                testTag = "toggle_v4_signing",
              )
              ToggleRow(
                label = stringResource(R.string.step3_opt_zipalign),
                checked = opts.zipAlignBeforeSign,
                enabled = !signingState.isSigning && !isAab,
                onCheckedChange = { checked ->
                  onUpdateOptions { it.copy(zipAlignBeforeSign = checked) }
                },
                testTag = "toggle_zipalign",
              )
              if (isAab) {
                ToggleRow(
                  label = stringResource(R.string.step3_opt_aab_to_apk),
                  checked = opts.convertAabToApk,
                  enabled = !signingState.isSigning,
                  onCheckedChange = { checked ->
                    onUpdateOptions { it.copy(convertAabToApk = checked) }
                  },
                  testTag = "toggle_aab_to_apk",
                )
              }
            }
          }
        }

        item {
          AnimatedVisibility(visible = signingState.translatedError != null) {
            signingState.translatedError?.let { err ->
              Surface(
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("step3_error_banner"),
                shape = StandardCardShape,
                color = MaterialTheme.colorScheme.errorContainer,
              ) {
                Row(
                  modifier = Modifier.padding(16.dp),
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                  verticalAlignment = Alignment.Top,
                ) {
                  Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onErrorContainer,
                    modifier = Modifier.size(20.dp),
                  )
                  Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                      text = err.title,
                      style = MaterialTheme.typography.titleSmall,
                      color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                    Text(
                      text = err.message,
                      style = MaterialTheme.typography.bodyMedium,
                      color = MaterialTheme.colorScheme.onErrorContainer,
                    )
                  }
                }
              }
            }
          }
        }

        if (signingState.logs.isNotEmpty()) {
          item {
            TerminalLogBox(
              title = stringResource(R.string.step3_console_title),
              logs = signingState.logs,
            )
          }
        }
      } else {
        // Post-Sign Verified Result Card with centered 56dp shield icon
        item {
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("step3_success_card"),
            shape = StandardCardShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.65f)),
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Box(
                modifier = Modifier
                  .size(56.dp)
                  .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Filled.VerifiedUser,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onPrimaryContainer,
                  modifier = Modifier.size(30.dp),
                )
              }

              Text(
                text = stringResource(R.string.step3_success_title),
                style = MaterialTheme.typography.headlineSmall,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
              )

              Surface(
                shape = RoundedCornerShape(10.dp),
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
              ) {
                Text(
                  text = stringResource(R.string.step3_saved_path, result.primaryFileName),
                  style = MaterialTheme.typography.labelMedium,
                  color = MaterialTheme.colorScheme.secondary,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                )
              }

              result.companionApkFileName?.let { companion ->
                Text(
                  text = stringResource(R.string.step3_saved_companion, companion),
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  textAlign = TextAlign.Center,
                )
              }
            }
          }
        }

        // SHA-256 & SHA-1 copyable JetBrains Mono boxes
        item {
          FingerprintCopyCard(
            sha1 = result.sha1Fingerprint,
            sha256 = result.sha256Fingerprint,
            onCopied = { label ->
              onShowSnackbar(String.format(copiedTemplate, label))
            },
          )
        }

        // Two equal-width 48dp action buttons side-by-side: Share | Save to Device
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Button(
              onClick = {
                shareExportedUri(
                  context = context,
                  rawUri = result.primarySignedUri,
                  fileName = result.primaryFileName,
                  chooserTitle = shareTitle,
                )
              },
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("share_signed_button"),
              shape = RoundedCornerShape(12.dp),
            ) {
              Icon(Icons.Filled.Share, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = stringResource(R.string.step3_share_button),
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
              )
            }

            OutlinedButton(
              onClick = {
                saveDocumentLauncher.launch(result.primaryFileName)
              },
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("save_to_device_button"),
              shape = RoundedCornerShape(12.dp),
            ) {
              Icon(Icons.Filled.SaveAlt, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = stringResource(R.string.step3_save_device_button),
                style = MaterialTheme.typography.labelLarge,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }

        if ((cloudBuildState.persistedSession != null && cloudBuildState.persistedSession.status.isAwaitingCleanup) ||
          !cloudBuildState.clearedCloudRepoName.isNullOrBlank()
        ) {
          item {
            ZeroTraceCloudCleanupCard(
              persistedSession = cloudBuildState.persistedSession,
              isClearing = cloudBuildState.isClearingCloudTrace,
              clearedRepoName = cloudBuildState.clearedCloudRepoName,
              onClearCloudTraceNow = onClearCloudTraceNow,
              onKeepForInspection = onKeepRepoForInspection,
            )
          }
        }

        if (result.logs.isNotEmpty()) {
          item {
            TerminalLogBox(
              title = stringResource(R.string.step3_console_title),
              logs = result.logs,
            )
          }
        }

        item {
          OutlinedButton(
            onClick = onSignAnotherApp,
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("sign_another_app_button"),
            shape = RoundedCornerShape(12.dp),
          ) {
            Icon(Icons.Filled.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.step3_sign_another_button),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }
    }

    // Sticky Bottom CTA Bar during Pre-Sign stage
    if (result == null) {
      Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .imePadding(),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .widthIn(max = 600.dp)
              .padding(horizontal = 16.dp, vertical = 12.dp),
          ) {
            Button(
              onClick = onSignNow,
              enabled = canSign,
              modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("sign_now_button"),
              shape = RoundedCornerShape(12.dp),
            ) {
              if (signingState.isSigning) {
                CircularProgressIndicator(
                  modifier = Modifier.size(20.dp),
                  strokeWidth = 2.5.dp,
                  color = MaterialTheme.colorScheme.onPrimary,
                )
                Spacer(modifier = Modifier.width(10.dp))
              } else {
                Icon(Icons.Filled.Draw, contentDescription = null, modifier = Modifier.size(20.dp))
                Spacer(modifier = Modifier.width(10.dp))
              }
              Text(
                text = stringResource(R.string.step3_sign_now),
                style = MaterialTheme.typography.labelLarge,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SummaryKeyValueRow(
  label: String,
  value: String,
  accent: Boolean = false,
) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    Spacer(modifier = Modifier.width(12.dp))
    Text(
      text = value,
      style = MaterialTheme.typography.labelMedium,
      color = if (accent) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.onSurface,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

@Composable
private fun ToggleRow(
  label: String,
  checked: Boolean,
  enabled: Boolean,
  onCheckedChange: (Boolean) -> Unit,
  testTag: String,
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .minimumInteractiveComponentSize(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodyMedium,
      color = if (enabled) {
        MaterialTheme.colorScheme.onSurface
      } else {
        MaterialTheme.colorScheme.onSurfaceVariant
      },
      modifier = Modifier
        .weight(1f)
        .padding(end = 12.dp),
    )
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      enabled = enabled,
      modifier = Modifier.testTag(testTag),
    )
  }
}

private fun shareExportedUri(
  context: Context,
  rawUri: Uri,
  fileName: String,
  chooserTitle: String,
) {
  val shareUri = if (rawUri.scheme.equals("file", ignoreCase = true) && rawUri.path != null) {
    runCatching {
      FileProvider.getUriForFile(
        context,
        "${context.packageName}.fileprovider",
        File(rawUri.path!!),
      )
    }.getOrDefault(rawUri)
  } else {
    rawUri
  }

  val mimeType = if (fileName.endsWith(".apk", ignoreCase = true)) {
    "application/vnd.android.package-archive"
  } else {
    "application/octet-stream"
  }

  val intent = Intent(Intent.ACTION_SEND).apply {
    type = mimeType
    putExtra(Intent.EXTRA_STREAM, shareUri)
    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
  }
  context.startActivity(Intent.createChooser(intent, chooserTitle))
}
