package com.shipsign.app.ui.screens.project

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Android
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.ui.InspectorUiState
import com.shipsign.app.ui.components.EditorialOutlineBadge
import com.shipsign.app.ui.components.EditorialScreenHeader
import com.shipsign.app.ui.components.EditorialSectionKicker
import com.shipsign.app.ui.components.OfflineOutlineBadge
import com.shipsign.app.ui.theme.InkOnDark
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PaperBorder
import com.shipsign.app.ui.theme.PaperSurface
import com.shipsign.app.ui.theme.PaperSurfaceSubtle
import com.shipsign.app.ui.theme.PineOffline
import com.shipsign.app.ui.theme.VermilionAccent
import com.shipsign.app.ui.theme.VermilionContainer
import com.shipsign.app.ui.theme.VermilionOnContainer
import java.util.Locale

/**
 * Step 02 / 03 — Built APK or Built AAB (100% Offline Inspection):
 * Select .APK / .AAB -> Inspect offline -> Inspect metadata -> Continue to 03 / 03 Review & Sign.
 */
@Composable
fun PackageUploadScreen(
  expectedType: ResolvedBinaryType,
  inspectorState: InspectorUiState,
  onBack: () -> Unit,
  onPickPackageUri: (Uri) -> Unit,
  onClearSelected: () -> Unit,
  onContinueToPipeline: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val isAab = expectedType == ResolvedBinaryType.AAB
  val labelExt = if (isAab) ".AAB" else ".APK"
  val filePicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument(),
  ) { uri ->
    if (uri != null) onPickPackageUri(uri)
  }

  val target = inspectorState.targetFile?.takeIf { it.binaryType == expectedType }
  val pkgInfo = target?.packageInfo

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .navigationBarsPadding(),
    ) {
      LazyColumn(
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .testTag("package_upload_list"),
        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 0.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
      ) {
        item {
          EditorialScreenHeader(
            kicker = if (isAab) "02 / 03 — BUILT AAB" else "02 / 03 — BUILT APK",
            title = if (isAab) "Select your AAB" else "Select your APK",
            subtitle = "Inspected locally on your device. Nothing is uploaded.",
            onBack = onBack,
            trailingBadge = { OfflineOutlineBadge() },
          )
        }

        if (target == null) {
          item {
            Spacer(modifier = Modifier.height(4.dp))
            Card(
              onClick = {
                if (!inspectorState.isProcessing) {
                  filePicker.launch(arrayOf("*/*"))
                }
              },
              modifier = Modifier
                .fillMaxWidth()
                .testTag("package_upload_card"),
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = PaperSurface),
              border = BorderStroke(1.2.dp, InkPrimary),
              elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(horizontal = 24.dp, vertical = 38.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                if (inspectorState.isProcessing) {
                  CircularProgressIndicator(
                    color = InkPrimary,
                    strokeWidth = 2.4.dp,
                    modifier = Modifier.size(34.dp),
                  )
                  Spacer(modifier = Modifier.height(14.dp))
                  Text(
                    text = "Inspecting $labelExt offline...",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = InkPrimary,
                  )
                } else {
                  Box(
                    modifier = Modifier
                      .size(52.dp)
                      .clip(RoundedCornerShape(14.dp))
                      .background(PaperSurfaceSubtle)
                      .border(1.dp, PaperBorder, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center,
                  ) {
                    Icon(
                      imageVector = Icons.Rounded.UploadFile,
                      contentDescription = "Upload $labelExt",
                      tint = InkPrimary,
                      modifier = Modifier.size(24.dp),
                    )
                  }
                  Spacer(modifier = Modifier.height(14.dp))
                  Text(
                    text = "Choose $labelExt file",
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.Bold,
                      fontSize = 18.sp,
                    ),
                    color = InkPrimary,
                  )
                  Spacer(modifier = Modifier.height(4.dp))
                  Text(
                    text = "Tap to browse storage for an Android $labelExt",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary,
                  )
                }
              }
            }
          }
        } else {
          item {
            EditorialSectionKicker(text = "PACKAGE INFO")
            Spacer(modifier = Modifier.height(8.dp))
            Card(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("package_info_card"),
              shape = RoundedCornerShape(16.dp),
              colors = CardDefaults.cardColors(containerColor = PaperSurface),
              border = BorderStroke(1.dp, PaperBorder),
              elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
            ) {
              Column(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
              ) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                  Box(
                    modifier = Modifier
                      .size(44.dp)
                      .clip(RoundedCornerShape(12.dp))
                      .background(PaperSurfaceSubtle)
                      .border(1.dp, PaperBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                  ) {
                    Icon(
                      imageVector = if (isAab) Icons.Outlined.Inventory2 else Icons.Outlined.Android,
                      contentDescription = null,
                      tint = InkPrimary,
                      modifier = Modifier.size(22.dp),
                    )
                  }
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = pkgInfo?.appName ?: target.originalName.substringBeforeLast('.'),
                      style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                      ),
                      color = InkPrimary,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text = target.originalName,
                      style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                      color = InkSecondary,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                }

                HorizontalDivider(color = PaperBorder)

                PackageInfoRow("Package name", pkgInfo?.packageId ?: "Unknown", mono = true)
                PackageInfoRow(
                  "Version",
                  "${pkgInfo?.versionCode ?: 1L} / ${pkgInfo?.versionName ?: "1.0"}",
                  mono = true,
                )
                PackageInfoRow("Format", if (isAab) "AAB" else "APK", mono = true)
                PackageInfoRow("Size", formatPackageSize(target.sizeBytes), mono = true)

                val isSigned = pkgInfo?.isSigned ?: target.isAlreadySigned
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Text(
                    text = "Signature",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary,
                  )
                  EditorialOutlineBadge(
                    text = if (isSigned) "SIGNED" else "UNSIGNED",
                    tint = if (isSigned) PineOffline else VermilionAccent,
                  )
                }

                val sha256 = pkgInfo?.sha256Fingerprint
                if (isSigned && !sha256.isNullOrBlank()) {
                  Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = PaperSurfaceSubtle,
                    border = BorderStroke(1.dp, PaperBorder),
                    modifier = Modifier.fillMaxWidth(),
                  ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                      Text(
                        text = "SHA-256",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = InkSecondary,
                      )
                      Spacer(modifier = Modifier.height(4.dp))
                      Text(
                        text = sha256,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily),
                        color = InkPrimary,
                      )
                    }
                  }
                }
              }
            }
          }

          item {
            OutlinedButton(
              onClick = onClearSelected,
              modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("package_change_file_button"),
              shape = RoundedCornerShape(14.dp),
              border = BorderStroke(1.dp, PaperBorder),
            ) {
              Text("Choose different file", color = InkPrimary)
            }
          }
        }

        if (!inspectorState.errorMessage.isNullOrBlank()) {
          item {
            Surface(
              shape = RoundedCornerShape(12.dp),
              color = VermilionContainer,
              modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                text = inspectorState.errorMessage,
                style = MaterialTheme.typography.bodySmall,
                color = VermilionOnContainer,
                modifier = Modifier.padding(14.dp),
              )
            }
          }
        }

        item { Spacer(modifier = Modifier.height(16.dp)) }
      }

      if (target != null) {
        Button(
          onClick = onContinueToPipeline,
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 18.dp)
            .height(54.dp)
            .testTag("package_info_continue_button"),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = InkPrimary,
            contentColor = InkOnDark,
          ),
          elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
        ) {
          Text(
            text = "Continue to review",
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.SemiBold,
              fontSize = 16.sp,
            ),
          )
        }
      }
    }
  }
}

@Composable
private fun PackageInfoRow(label: String, value: String, mono: Boolean = false) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall,
      color = InkSecondary,
    )
    Spacer(modifier = Modifier.width(12.dp))
    Text(
      text = value,
      style = if (mono) {
        MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFamily)
      } else {
        MaterialTheme.typography.bodySmall
      },
      fontWeight = FontWeight.Medium,
      color = InkPrimary,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
    )
  }
}

private fun formatPackageSize(bytes: Long): String {
  if (bytes < 1024L) return "$bytes B"
  val kb = bytes / 1024.0
  if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
  return String.format(Locale.US, "%.2f MB", kb / 1024.0)
}
