package com.shipsign.app.core.github

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.shipsign.app.MainActivity
import com.shipsign.app.R
import com.shipsign.app.core.engine.SigningEngine
import com.shipsign.app.core.engine.SigningProgressEvent
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ImportedKeystoreConfig
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ProjectStack
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.domain.model.SigningOptions
import com.shipsign.app.domain.model.SigningResult
import com.shipsign.app.domain.model.SourceProjectMetadata
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.util.concurrent.atomic.AtomicReference

sealed interface ServiceSigningEvent {
  data object Idle : ServiceSigningEvent
  data class Running(val logs: List<String>) : ServiceSigningEvent
  data class Completed(val result: SigningResult) : ServiceSigningEvent
  data class Failed(val error: Throwable) : ServiceSigningEvent
}

private data class PendingLocalSigningRequest(
  val target: AppTargetFile,
  val keystoreConfig: ImportedKeystoreConfig,
  val options: SigningOptions,
) {
  fun wipeCredentials() {
    ZeroTraceManager.wipeCharArray(keystoreConfig.storePassword)
    ZeroTraceManager.wipeCharArray(keystoreConfig.keyPassword)
  }
}

/**
 * Persistent Android Foreground Service (`foregroundServiceType="dataSync"`) executing
 * GitHub Actions source upload, workflow run polling, artifact download, and local
 * `apksig`/`bundletool` signing so minimizing or closing ShipSign never cancels a running build.
 */
class ShipSignBuildService : Service() {

  private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  private var activeJob: Job? = null
  private var activeProjectLabel: String = "Project"

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onCreate() {
    super.onCreate()
    ensureNotificationChannel()
  }

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val action = intent?.action

    when (action) {
      ACTION_CANCEL_BUILD -> {
        activeJob?.cancel()
        activeJob = null
        _isRunning.value = false
        _buildState.value = CloudBuildState.Idle
        stopForegroundAndSelf()
        return START_NOT_STICKY
      }
      ACTION_RUN_SIGNING -> {
        val pending = pendingSigningRef.getAndSet(null)
        if (pending == null) {
          stopForegroundAndSelf()
          return START_NOT_STICKY
        }
        activeProjectLabel = pending.target.originalName
        startForegroundWithNotification("ShipSign: Signing $activeProjectLabel...")
        runLocalSigningJob(pending)
        return START_NOT_STICKY
      }
      ACTION_START_BUILD -> {
        val sourcePath = intent.getStringExtra(EXTRA_SOURCE_PATH)
        val originalName = intent.getStringExtra(EXTRA_ORIGINAL_NAME) ?: "project.zip"
        val frameworkName = intent.getStringExtra(EXTRA_FRAMEWORK) ?: ProjectFramework.NATIVE_ANDROID.name
        val rootPrefix = intent.getStringExtra(EXTRA_ROOT_PREFIX).orEmpty()
        val packageId = intent.getStringExtra(EXTRA_PACKAGE_ID)
        val formatName = intent.getStringExtra(EXTRA_OUTPUT_FORMAT) ?: BuildOutputFormat.APK_ONLY.name
        val keystoreUri = intent.getStringExtra(EXTRA_KEYSTORE_URI)

        if (sourcePath.isNullOrBlank() || !File(sourcePath).exists()) {
          _buildState.value = CloudBuildState.Failed(
            IllegalStateException("Source archive is no longer available in the session folder.")
          )
          stopForegroundAndSelf()
          return START_NOT_STICKY
        }

        val sourceFile = File(sourcePath)
        val framework = runCatching { ProjectFramework.valueOf(frameworkName) }
          .getOrDefault(ProjectFramework.NATIVE_ANDROID)
        val format = runCatching { BuildOutputFormat.valueOf(formatName) }
          .getOrDefault(BuildOutputFormat.APK_ONLY)
        val target = AppTargetFile(
          sessionFile = sourceFile,
          originalName = originalName,
          sizeBytes = sourceFile.length(),
          binaryType = ResolvedBinaryType.SOURCE_CODE_PROJECT,
          isAlreadySigned = false,
          detectedStack = ProjectStack.fromFramework(framework),
          sourceMetadata = SourceProjectMetadata(
            framework = framework,
            projectRootPrefix = rootPrefix,
            applicationId = packageId,
          ),
        )

        activeProjectLabel = originalName.removeSuffix(".zip")
        startForegroundWithNotification("ShipSign: Building $activeProjectLabel (Preparing Archive...)")
        runCloudBuildJob(target = target, targetFormat = format, keystoreUri = keystoreUri)
        return START_REDELIVER_INTENT
      }
      ACTION_RESUME_BUILD, null -> {
        val persisted = BuildSessionStore.loadSession(applicationContext)
        if (persisted == null || !persisted.status.isActiveInCloud) {
          stopForegroundAndSelf()
          return START_NOT_STICKY
        }
        if (activeJob?.isActive == true) {
          return START_REDELIVER_INTENT
        }
        activeProjectLabel = persisted.projectName.ifBlank { "Project" }
        val statusLabel = persisted.statusMessage.ifBlank { "In Progress on GitHub..." }
        startForegroundWithNotification("ShipSign: Building $activeProjectLabel ($statusLabel)")
        runResumeBuildJob(persisted)
        return START_REDELIVER_INTENT
      }
      else -> {
        stopForegroundAndSelf()
        return START_NOT_STICKY
      }
    }
  }

  override fun onDestroy() {
    activeJob?.cancel()
    pendingSigningRef.getAndSet(null)?.wipeCredentials()
    _isRunning.value = false
    serviceScope.cancel()
    super.onDestroy()
  }

  private fun runCloudBuildJob(
    target: AppTargetFile,
    targetFormat: BuildOutputFormat,
    keystoreUri: String?,
  ) {
    activeJob?.cancel()
    _isRunning.value = true
    activeJob = serviceScope.launch {
      val session = GitHubOAuthManager.getSavedSession(applicationContext)
      if (session == null) {
        _buildState.value = CloudBuildState.Failed(
          GitHubOAuthExpiredException("Connect GitHub before starting a cloud build.")
        )
        _isRunning.value = false
        stopForegroundAndSelf()
        return@launch
      }

      val tokenChars = session.accessToken.toCharArray()
      try {
        GitHubBuildModule.buildUnsignedBinary(
          context = applicationContext,
          sourceProject = target,
          token = tokenChars,
          targetFormat = targetFormat,
          keystoreUri = keystoreUri,
          wipeTokenOnCompletion = true,
        ).collect { state ->
          handleBuildProgressUpdate(state)
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        _buildState.value = CloudBuildState.Failed(error = e)
        postResultNotification("ShipSign: $activeProjectLabel Build Failed", e.message ?: "Tap to inspect")
      } finally {
        ZeroTraceManager.wipeCharArray(tokenChars)
        _isRunning.value = false
        stopForegroundAndSelf()
      }
    }
  }

  private fun runResumeBuildJob(persisted: PersistedBuildSession) {
    activeJob?.cancel()
    _isRunning.value = true
    activeJob = serviceScope.launch {
      val session = GitHubOAuthManager.getSavedSession(applicationContext)
      if (session == null) {
        _buildState.value = CloudBuildState.Failed(
          error = GitHubOAuthExpiredException("GitHub session expired. Reconnect to resume build."),
          repoFullName = persisted.repoFullName,
          runId = persisted.runId,
        )
        _isRunning.value = false
        stopForegroundAndSelf()
        return@launch
      }

      val tokenChars = session.accessToken.toCharArray()
      try {
        GitHubBuildModule.resumeUnsignedBuild(
          context = applicationContext,
          session = persisted,
          token = tokenChars,
          wipeTokenOnCompletion = true,
        ).collect { state ->
          handleBuildProgressUpdate(state)
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        _buildState.value = CloudBuildState.Failed(
          error = e,
          repoFullName = persisted.repoFullName,
          runId = persisted.runId,
        )
        postResultNotification("ShipSign: $activeProjectLabel Build Failed", e.message ?: "Tap to inspect")
      } finally {
        ZeroTraceManager.wipeCharArray(tokenChars)
        _isRunning.value = false
        stopForegroundAndSelf()
      }
    }
  }

  private fun runLocalSigningJob(request: PendingLocalSigningRequest) {
    activeJob?.cancel()
    _isRunning.value = true
    val accumulatedLogs = mutableListOf<String>()
    _signingEvent.value = ServiceSigningEvent.Running(emptyList())

    activeJob = serviceScope.launch {
      try {
        SigningEngine.signEvents(
          context = applicationContext,
          target = request.target,
          keystoreConfig = request.keystoreConfig,
          options = request.options,
        ).collect { event ->
          when (event) {
            is SigningProgressEvent.Log -> {
              accumulatedLogs.add(event.line)
              if (accumulatedLogs.size > 40) {
                accumulatedLogs.removeAt(0)
              }
              _signingEvent.value = ServiceSigningEvent.Running(accumulatedLogs.toList())
              updateNotification("ShipSign: Signing $activeProjectLabel (${event.line})")
            }
            is SigningProgressEvent.Completed -> {
              _signingEvent.value = ServiceSigningEvent.Completed(event.result)
              postResultNotification(
                "ShipSign: Signed ${event.result.primaryFileName}",
                "Saved to Downloads/ShipSign",
              )
            }
          }
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        _signingEvent.value = ServiceSigningEvent.Failed(e)
        postResultNotification("ShipSign: Signing Failed", e.message ?: "Tap to view details")
      } finally {
        request.wipeCredentials()
        _isRunning.value = false
        stopForegroundAndSelf()
      }
    }
  }

  private fun handleBuildProgressUpdate(state: CloudBuildState) {
    _buildState.value = state
    when (state) {
      is CloudBuildState.StageProgress -> {
        val stepDetail = state.statusText.ifBlank { state.stage.label }
        updateNotification("ShipSign: Building $activeProjectLabel ($stepDetail)")
      }
      is CloudBuildState.ReadyForOfflineSigning -> {
        postResultNotification(
          "ShipSign: $activeProjectLabel Ready to Sign",
          "Unsigned package downloaded. Tap to sign & clear cloud repo.",
        )
      }
      is CloudBuildState.Failed -> {
        postResultNotification(
          "ShipSign: $activeProjectLabel Build Failed",
          "Tap to view error or clear temporary repo.",
        )
      }
      is CloudBuildState.RepositoryAccessRequired -> {
        postResultNotification(
          "ShipSign: Repository Access Required",
          state.message,
        )
      }
      CloudBuildState.Idle -> Unit
    }
  }

  private fun ensureNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val manager = getSystemService(NotificationManager::class.java) ?: return
      val progressChannel = NotificationChannel(
        CHANNEL_ID,
        getString(R.string.notification_channel_build_name),
        NotificationManager.IMPORTANCE_LOW,
      ).apply {
        description = getString(R.string.notification_channel_build_desc)
        setShowBadge(false)
      }
      manager.createNotificationChannel(progressChannel)
    }
  }

  private fun startForegroundWithNotification(contentText: String) {
    val notification = buildNotification(title = getString(R.string.app_name), text = contentText, ongoing = true)
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
      ServiceCompat.startForeground(
        this,
        NOTIFICATION_ID_PROGRESS,
        notification,
        ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
      )
    } else {
      startForeground(NOTIFICATION_ID_PROGRESS, notification)
    }
  }

  private fun updateNotification(contentText: String) {
    val manager = getSystemService(NotificationManager::class.java) ?: return
    val notification = buildNotification(title = getString(R.string.app_name), text = contentText, ongoing = true)
    runCatching { manager.notify(NOTIFICATION_ID_PROGRESS, notification) }
  }

  private fun postResultNotification(title: String, text: String) {
    val manager = getSystemService(NotificationManager::class.java) ?: return
    val notification = buildNotification(title = title, text = text, ongoing = false)
    runCatching { manager.notify(NOTIFICATION_ID_RESULT, notification) }
  }

  private fun buildNotification(title: String, text: String, ongoing: Boolean): Notification {
    val openIntent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
    }
    val pendingIntent = PendingIntent.getActivity(
      this,
      0,
      openIntent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )
    return NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle(title)
      .setContentText(text)
      .setStyle(NotificationCompat.BigTextStyle().bigText(text))
      .setOngoing(ongoing)
      .setOnlyAlertOnce(true)
      .setAutoCancel(!ongoing)
      .setContentIntent(pendingIntent)
      .setPriority(NotificationCompat.PRIORITY_LOW)
      .build()
  }

  private fun stopForegroundAndSelf() {
    runCatching { ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE) }
    stopSelf()
  }

  companion object {
    const val CHANNEL_ID = "shipsign_cloud_build"
    private const val NOTIFICATION_ID_PROGRESS = 4101
    private const val NOTIFICATION_ID_RESULT = 4102

    const val ACTION_START_BUILD = "com.shipsign.app.action.START_BUILD"
    const val ACTION_RESUME_BUILD = "com.shipsign.app.action.RESUME_BUILD"
    const val ACTION_RUN_SIGNING = "com.shipsign.app.action.RUN_SIGNING"
    const val ACTION_CANCEL_BUILD = "com.shipsign.app.action.CANCEL_BUILD"

    private const val EXTRA_SOURCE_PATH = "extra_source_path"
    private const val EXTRA_ORIGINAL_NAME = "extra_original_name"
    private const val EXTRA_FRAMEWORK = "extra_framework"
    private const val EXTRA_ROOT_PREFIX = "extra_root_prefix"
    private const val EXTRA_PACKAGE_ID = "extra_package_id"
    private const val EXTRA_OUTPUT_FORMAT = "extra_output_format"
    private const val EXTRA_KEYSTORE_URI = "extra_keystore_uri"

    private val _isRunning = MutableStateFlow(false)
    val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

    private val _buildState = MutableStateFlow<CloudBuildState>(CloudBuildState.Idle)
    val buildState: StateFlow<CloudBuildState> = _buildState.asStateFlow()

    private val _signingEvent = MutableStateFlow<ServiceSigningEvent>(ServiceSigningEvent.Idle)
    val signingEvent: StateFlow<ServiceSigningEvent> = _signingEvent.asStateFlow()

    private val pendingSigningRef = AtomicReference<PendingLocalSigningRequest?>(null)

    fun resetBuildState() {
      _buildState.value = CloudBuildState.Idle
    }

    fun resetSigningEvent() {
      _signingEvent.value = ServiceSigningEvent.Idle
    }

    fun startCloudBuild(
      context: Context,
      sourceProject: AppTargetFile,
      targetFormat: BuildOutputFormat,
      keystoreUri: String? = null,
    ) {
      val metadata = sourceProject.sourceMetadata ?: return
      _buildState.value = CloudBuildState.StageProgress(
        stage = CloudBuildStage.PREPARING_ARCHIVE,
        statusText = CloudBuildStage.PREPARING_ARCHIVE.label,
      )
      val intent = Intent(context, ShipSignBuildService::class.java).apply {
        action = ACTION_START_BUILD
        putExtra(EXTRA_SOURCE_PATH, sourceProject.sessionFile.absolutePath)
        putExtra(EXTRA_ORIGINAL_NAME, sourceProject.originalName)
        putExtra(EXTRA_FRAMEWORK, metadata.framework.name)
        putExtra(EXTRA_ROOT_PREFIX, metadata.projectRootPrefix)
        putExtra(EXTRA_PACKAGE_ID, metadata.applicationId)
        putExtra(EXTRA_OUTPUT_FORMAT, targetFormat.name)
        putExtra(EXTRA_KEYSTORE_URI, keystoreUri)
      }
      ContextCompat.startForegroundService(context.applicationContext, intent)
    }

    fun resumeCloudBuild(context: Context) {
      val intent = Intent(context, ShipSignBuildService::class.java).apply {
        action = ACTION_RESUME_BUILD
      }
      ContextCompat.startForegroundService(context.applicationContext, intent)
    }

    fun startLocalSigning(
      context: Context,
      target: AppTargetFile,
      keystoreConfig: ImportedKeystoreConfig,
      options: SigningOptions,
    ) {
      pendingSigningRef.getAndSet(
        PendingLocalSigningRequest(
          target = target,
          keystoreConfig = keystoreConfig,
          options = options,
        )
      )?.wipeCredentials()
      _signingEvent.value = ServiceSigningEvent.Running(emptyList())
      val intent = Intent(context, ShipSignBuildService::class.java).apply {
        action = ACTION_RUN_SIGNING
      }
      ContextCompat.startForegroundService(context.applicationContext, intent)
    }

    fun cancelBuild(context: Context) {
      val intent = Intent(context, ShipSignBuildService::class.java).apply {
        action = ACTION_CANCEL_BUILD
      }
      context.applicationContext.startService(intent)
    }
  }
}
