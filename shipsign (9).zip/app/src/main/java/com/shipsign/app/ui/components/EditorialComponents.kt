package com.shipsign.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shipsign.app.R
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperSurface
import com.shipsign.app.ui.theme.PineOffline
import com.shipsign.app.ui.theme.SpaceGroteskFamily
import com.shipsign.app.ui.theme.VermilionAccent

/**
 * Editorial top header matching Pages 2 & 3 of the ShipSign Visual Concept:
 * Clean back arrow + monospace step kicker + bold Space Grotesk title.
 */
@Composable
fun EditorialScreenHeader(
  kicker: String,
  title: String,
  onBack: (() -> Unit)? = null,
  subtitle: String? = null,
  trailingBadge: (@Composable () -> Unit)? = null,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .statusBarsPadding()
      .padding(top = 8.dp),
  ) {
    if (onBack != null) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        IconButton(
          onClick = onBack,
          modifier = Modifier
            .offset(x = (-12).dp)
            .minimumInteractiveComponentSize()
            .testTag("top_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Rounded.ArrowBack,
            contentDescription = stringResource(R.string.cd_back),
            tint = InkPrimary,
            modifier = Modifier.size(22.dp),
          )
        }
        if (trailingBadge != null) {
          trailingBadge()
        }
      }
      Spacer(modifier = Modifier.height(6.dp))
    } else if (trailingBadge != null) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End,
      ) {
        trailingBadge()
      }
      Spacer(modifier = Modifier.height(8.dp))
    }

    Text(
      text = kicker.uppercase(),
      style = MaterialTheme.typography.labelMedium.copy(
        fontFamily = JetBrainsMonoFamily,
        fontSize = 12.sp,
        letterSpacing = 1.2.sp,
        fontWeight = FontWeight.Normal,
      ),
      color = InkSecondary,
    )

    Spacer(modifier = Modifier.height(6.dp))

    Text(
      text = title,
      style = MaterialTheme.typography.displaySmall.copy(
        fontFamily = SpaceGroteskFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        lineHeight = 36.sp,
        letterSpacing = (-0.5).sp,
      ),
      color = InkPrimary,
    )

    if (!subtitle.isNullOrBlank()) {
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = subtitle,
        style = MaterialTheme.typography.bodyMedium,
        color = InkSecondary,
      )
    }
  }
}

/**
 * Small uppercase monospace section label (e.g., CUSTOMIZE, CONVERT, SIGN — LAST STEP).
 */
@Composable
fun EditorialSectionKicker(
  text: String,
  modifier: Modifier = Modifier,
) {
  Text(
    text = text.uppercase(),
    style = MaterialTheme.typography.labelMedium.copy(
      fontFamily = JetBrainsMonoFamily,
      fontSize = 11.sp,
      letterSpacing = 1.1.sp,
      fontWeight = FontWeight.Medium,
    ),
    color = InkSecondary,
    modifier = modifier,
  )
}

/**
 * Crisp outlined monospace pill matching "ONLINE BUILD" (vermilion) and "OFFLINE" (pine green).
 */
@Composable
fun EditorialOutlineBadge(
  text: String,
  tint: Color,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(6.dp),
    color = PaperSurface,
    border = BorderStroke(1.dp, tint.copy(alpha = 0.72f)),
  ) {
    Text(
      text = text.uppercase(),
      style = MaterialTheme.typography.labelSmall.copy(
        fontFamily = JetBrainsMonoFamily,
        fontSize = 11.sp,
        letterSpacing = 0.9.sp,
        fontWeight = FontWeight.Medium,
      ),
      color = tint,
      modifier = Modifier.padding(horizontal = 9.dp, vertical = 4.dp),
    )
  }
}

@Composable
fun OfflineOutlineBadge(modifier: Modifier = Modifier) {
  EditorialOutlineBadge(text = "OFFLINE", tint = PineOffline, modifier = modifier)
}

@Composable
fun OnlineBuildOutlineBadge(modifier: Modifier = Modifier) {
  EditorialOutlineBadge(text = "ONLINE BUILD", tint = VermilionAccent, modifier = modifier)
}
