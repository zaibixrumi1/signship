package com.shipsign.app.ui.screens.splash

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shipsign.app.R
import com.shipsign.app.ui.components.ShipSignEmblem
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PineOffline
import com.shipsign.app.ui.theme.SpaceGroteskFamily
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Editorial warm-paper splash screen that introduces the ShipSign emblem and transitions to Home.
 */
@Composable
fun SplashScreen(
  onSplashComplete: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val emblemScale = remember { Animatable(0.84f) }
  val contentAlpha = remember { Animatable(0f) }

  LaunchedEffect(Unit) {
    launch {
      emblemScale.animateTo(
        targetValue = 1f,
        animationSpec = spring(
          dampingRatio = Spring.DampingRatioMediumBouncy,
          stiffness = Spring.StiffnessMediumLow,
        ),
      )
    }
    launch {
      contentAlpha.animateTo(
        targetValue = 1f,
        animationSpec = tween(durationMillis = 360),
      )
    }
    delay(780L)
    onSplashComplete()
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground)
      .navigationBarsPadding()
      .testTag("splash_screen"),
  ) {
    Column(
      modifier = Modifier
        .align(Alignment.Center)
        .alpha(contentAlpha.value),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      ShipSignEmblem(
        size = 68.dp,
        modifier = Modifier.scale(emblemScale.value),
      )

      Spacer(modifier = Modifier.height(20.dp))

      Text(
        text = stringResource(R.string.app_name),
        style = MaterialTheme.typography.displaySmall.copy(
          fontFamily = SpaceGroteskFamily,
          fontWeight = FontWeight.Bold,
          fontSize = 32.sp,
          letterSpacing = (-0.6).sp,
        ),
        color = InkPrimary,
      )

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "ANDROID BUILD & ON-DEVICE SIGNING",
        style = MaterialTheme.typography.labelSmall.copy(
          fontFamily = JetBrainsMonoFamily,
          fontSize = 11.sp,
          letterSpacing = 1.2.sp,
        ),
        color = InkSecondary,
      )
    }

    Row(
      modifier = Modifier
        .align(Alignment.BottomCenter)
        .padding(bottom = 28.dp)
        .alpha(contentAlpha.value),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Box(
        modifier = Modifier
          .size(6.dp)
          .clip(RoundedCornerShape(1.5.dp))
          .background(PineOffline),
      )
      Text(
        text = "SIGNING IS 100% ON-DEVICE",
        style = MaterialTheme.typography.labelSmall.copy(
          fontFamily = JetBrainsMonoFamily,
          fontSize = 11.sp,
          letterSpacing = 0.9.sp,
        ),
        color = InkSecondary,
      )
    }
  }
}
