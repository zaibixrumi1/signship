package com.shipsign.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ShipSignLightColorScheme = lightColorScheme(
  primary = InkPrimary,
  onPrimary = PaperSurface,
  primaryContainer = PineContainer,
  onPrimaryContainer = PineOnContainer,
  secondary = VermilionAccent,
  onSecondary = VermilionOnAccent,
  secondaryContainer = VermilionContainer,
  onSecondaryContainer = VermilionOnContainer,
  tertiary = PineOffline,
  onTertiary = PaperSurface,
  tertiaryContainer = PineContainer,
  onTertiaryContainer = PineOnContainer,
  error = VermilionAccent,
  onError = VermilionOnAccent,
  errorContainer = VermilionContainer,
  onErrorContainer = VermilionOnContainer,
  background = PaperBackground,
  onBackground = InkPrimary,
  surface = PaperSurface,
  onSurface = InkPrimary,
  surfaceVariant = PaperSurfaceSubtle,
  onSurfaceVariant = InkSecondary,
  surfaceContainerLow = PaperSurfaceSubtle,
  surfaceContainer = PaperSurface,
  surfaceContainerHigh = PaperSurfaceSubtle,
  outline = InkMuted,
  outlineVariant = PaperBorder,
)

private val ShipSignDarkColorScheme = darkColorScheme(
  primary = EmeraldAction,
  onPrimary = EmeraldOnAction,
  primaryContainer = EmeraldContainer,
  onPrimaryContainer = EmeraldOnContainer,
  secondary = TechBlueSecondary,
  onSecondary = TechBlueOnSecondary,
  secondaryContainer = TechBlueContainer,
  onSecondaryContainer = TechBlueOnContainer,
  tertiary = AmberWarning,
  onTertiary = AmberOnWarning,
  tertiaryContainer = AmberContainer,
  onTertiaryContainer = AmberOnContainer,
  error = CrimsonError,
  onError = EmeraldOnAction,
  errorContainer = CrimsonContainer,
  onErrorContainer = CrimsonOnContainer,
  background = ObsidianBackground,
  onBackground = TextPrimaryDark,
  surface = ObsidianCard,
  onSurface = TextPrimaryDark,
  surfaceVariant = ObsidianCardElevated,
  onSurfaceVariant = TextSecondaryDark,
  surfaceContainerLow = ObsidianConsole,
  surfaceContainer = ObsidianCard,
  surfaceContainerHigh = ObsidianCardElevated,
  outline = ObsidianBorder,
  outlineVariant = ObsidianBorder,
)

val ShipSignShapes = Shapes(
  small = RoundedCornerShape(8.dp),
  medium = RoundedCornerShape(14.dp),
  large = RoundedCornerShape(18.dp),
  extraLarge = RoundedCornerShape(22.dp),
)

@Composable
fun ShipSignTheme(
  darkTheme: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) ShipSignDarkColorScheme else ShipSignLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = ShipSignTypography,
    shapes = ShipSignShapes,
    content = content,
  )
}
