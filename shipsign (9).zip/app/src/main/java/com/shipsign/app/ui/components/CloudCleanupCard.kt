package com.shipsign.app.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shipsign.app.R
import com.shipsign.app.core.github.BuildSessionStatus
import com.shipsign.app.core.github.PersistedBuildSession
import java.util.Locale

/**
 * User-confirmed Zero-Trace Cloud Cleanup card displayed after a GitHub Actions build completes
 * or fails. Never deletes the temporary private repository silently — always gives the user
 * explicit control to wipe immediately or inspect logs on GitHub first.
 */
@Composable
fun ZeroTraceCloudCleanupCard(
  persistedSession: PersistedBuildSession?,
  isClearing: Boolean,
  clearedRepoName: String?,
  onClearCloudTraceNow: () -> Unit,
  onKeepForInspection: () -> Unit,
  modifier: Modifier = Modifier,
) {
  if (persistedSession == null && !clearedRepoName.isNullOrBlank()) {
    Surface(
      modifier = modifier
        .fillMaxWidth()
        .testTag("cloud_trace_cleared_badge"),
      shape = StandardCardShape,
      color = MaterialTheme.colorScheme.primaryContainer,
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)),
    ) {
      Row(
        modifier = Modifier.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.VerifiedUser,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.size(22.dp),
        )
        Column(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(2.dp),
        ) {
          Text(
            text = stringResource(R.string.cloud_cleanup_cleared_badge),
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
          )
          Text(
            text = clearedRepoName,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }
    return
  }

  if (persistedSession == null || !persistedSession.status.isAwaitingCleanup) return

  val isFailed = persistedSession.status == BuildSessionStatus.FAILED_AWAITING_CLEANUP
  val accentColor = if (isFailed) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.primary

  if (persistedSession.keepForInspection) {
    // Compact persistent inspection strip keeping "Clear Cloud Trace" accessible anytime
    Surface(
      modifier = modifier
        .fillMaxWidth()
        .testTag("cloud_cleanup_inspection_card"),
      shape = StandardCardShape,
      color = MaterialTheme.colorScheme.surface,
      border = BorderStroke(1.dp, accentColor.copy(alpha = 0.55f)),
    ) {
      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Visibility,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(20.dp),
          )
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.cloud_cleanup_kept_title),
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
              text = persistedSession.repoFullName,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.secondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }

        Button(
          onClick = onClearCloudTraceNow,
          enabled = !isClearing,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("clear_cloud_trace_compact_button"),
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error,
            contentColor = MaterialTheme.colorScheme.onError,
          ),
        ) {
          if (isClearing) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = MaterialTheme.colorScheme.onError,
            )
            Spacer(modifier = Modifier.width(8.dp))
          } else {
            Icon(
              imageVector = Icons.Filled.DeleteForever,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
          }
          Text(
            text = stringResource(R.string.cloud_cleanup_clear_action_short),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }
    }
    return
  }

  // Prominent user-confirmed Zero-Trace Cloud Cleanup card
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("zero_trace_cloud_cleanup_card"),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, accentColor.copy(alpha = 0.7f)),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Box(
          modifier = Modifier
            .size(40.dp)
            .background(accentColor.copy(alpha = 0.16f), RoundedCornerShape(10.dp)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = if (isFailed) Icons.Filled.Warning else Icons.Filled.Shield,
            contentDescription = null,
            tint = accentColor,
            modifier = Modifier.size(22.dp),
          )
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = stringResource(R.string.cloud_cleanup_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = if (isFailed) {
              stringResource(R.string.cloud_cleanup_status_failed)
            } else {
              stringResource(R.string.cloud_cleanup_status_completed)
            },
            style = MaterialTheme.typography.labelSmall,
            color = accentColor,
          )
        }
      }

      Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        color = MaterialTheme.colorScheme.surfaceContainerLow,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
      ) {
        Row(
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.CloudDone,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.size(16.dp),
          )
          Text(
            text = persistedSession.repoFullName,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.testTag("cloud_cleanup_repo_name"),
          )
        }
      }

      Button(
        onClick = onClearCloudTraceNow,
        enabled = !isClearing,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("clear_cloud_trace_now_button"),
        shape = RoundedCornerShape(12.dp),
      ) {
        if (isClearing) {
          CircularProgressIndicator(
            modifier = Modifier.size(18.dp),
            strokeWidth = 2.dp,
            color = MaterialTheme.colorScheme.onPrimary,
          )
          Spacer(modifier = Modifier.width(8.dp))
        } else {
          Icon(
            imageVector = Icons.Filled.DeleteForever,
            contentDescription = null,
            modifier = Modifier.size(18.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
          text = stringResource(R.string.cloud_cleanup_clear_now),
          style = MaterialTheme.typography.labelLarge,
        )
      }

      OutlinedButton(
        onClick = onKeepForInspection,
        enabled = !isClearing,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("keep_repo_inspection_button"),
        shape = RoundedCornerShape(12.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Visibility,
          contentDescription = null,
          modifier = Modifier.size(18.dp),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = stringResource(R.string.cloud_cleanup_keep_inspection),
          style = MaterialTheme.typography.labelLarge,
        )
      }
    }
  }
}

/**
 * Compact banner shown on HomeScreen whenever a background cloud build is actively running,
 * allowing one-tap return to the live build progress view.
 */
@Composable
fun ActiveCloudBuildResumeBanner(
  session: PersistedBuildSession,
  elapsedSeconds: Int,
  onResumeView: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .minimumInteractiveComponentSize()
      .testTag("active_cloud_build_resume_banner")
      .clickable(onClick = onResumeView),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.55f),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.secondary.copy(alpha = 0.65f)),
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      CircularProgressIndicator(
        modifier = Modifier.size(22.dp),
        strokeWidth = 2.5.dp,
        color = MaterialTheme.colorScheme.secondary,
      )
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = stringResource(R.string.cloud_resume_banner_title, session.projectName),
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = "${session.statusMessage.ifBlank { "In Progress on GitHub..." }} · ${formatTimer(elapsedSeconds)}",
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.secondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = stringResource(R.string.cloud_resume_open_action),
        tint = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.size(20.dp),
      )
    }
  }
}

private fun formatTimer(totalSec: Int): String {
  val safe = totalSec.coerceAtLeast(0)
  return String.format(Locale.US, "%02d:%02d", safe / 60, safe % 60)
}
