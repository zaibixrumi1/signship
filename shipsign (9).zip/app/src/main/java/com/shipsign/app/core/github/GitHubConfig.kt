package com.shipsign.app.core.github

import com.shipsign.app.BuildConfig

/**
 * Verified GitHub App OAuth 2.0 + PKCE (`S256`) configuration for ShipSign (`signship-testing`).
 *
 * The optional OAuth client secret is injected at build time via the Secrets Gradle Plugin
 * (`BuildConfig.GITHUB_CLIENT_SECRET`) and is never hardcoded in source control.
 * Endpoints are overrideable for deterministic unit tests.
 */
object GitHubConfig {
  const val OAUTH_APP_NAME: String = "ShipSign"
  const val GITHUB_APP_SLUG: String = "signship-testing"
  const val GITHUB_APP_ID: String = "5837463"
  const val DEFAULT_GITHUB_CLIENT_ID: String = "Iv23li9uobnY1r29Wel9"
  const val CALLBACK_SCHEME: String = "shipsign"
  const val CALLBACK_HOST: String = "github"
  const val CALLBACK_PATH: String = "/callback"
  const val REDIRECT_URI: String = "$CALLBACK_SCHEME://$CALLBACK_HOST$CALLBACK_PATH"
  const val USER_AGENT: String = "ShipSign-Android/1.0"
  const val DEFAULT_OAUTH_BASE_URL: String = "https://github.com"
  const val DEFAULT_API_BASE_URL: String = "https://api.github.com"

  private const val PLACEHOLDER_CLIENT_ID = "YOUR_GITHUB_CLIENT_ID"
  private const val PLACEHOLDER_SECRET = "YOUR_GITHUB_CLIENT_SECRET"

  val GITHUB_CLIENT_ID: String
    get() = BuildConfig.GITHUB_CLIENT_ID
      .trim()
      .takeUnless { it.isBlank() || it == PLACEHOLDER_CLIENT_ID }
      ?: DEFAULT_GITHUB_CLIENT_ID

  val CLIENT_ID: String
    get() = GITHUB_CLIENT_ID

  val GITHUB_CLIENT_SECRET: String
    get() = BuildConfig.GITHUB_CLIENT_SECRET
      .trim()
      .takeUnless { it.isBlank() || it == PLACEHOLDER_SECRET }
      .orEmpty()

  @Volatile
  var oauthBaseUrl: String = DEFAULT_OAUTH_BASE_URL

  @Volatile
  var apiBaseUrl: String = DEFAULT_API_BASE_URL

  fun resetEndpoints() {
    oauthBaseUrl = DEFAULT_OAUTH_BASE_URL
    apiBaseUrl = DEFAULT_API_BASE_URL
  }
}
