package com.shipsign.app.ui.theme

import androidx.compose.ui.graphics.Color

// ShipSign Editorial Paper & Ink Palette (Primary Visual Concept)
val PaperBackground = Color(0xFFF5F2EB)
val PaperSurface = Color(0xFFFFFFFF)
val PaperSurfaceSubtle = Color(0xFFEEEAE1)
val PaperBorder = Color(0xFFE2DDD3)

val InkPrimary = Color(0xFF14171A)
val InkSecondary = Color(0xFF5C5E63)
val InkMuted = Color(0xFF7B7D82)
val InkOnDark = Color(0xFFF5F2EB)
val InkMutedOnDark = Color(0xFFA0A4AB)

val VermilionAccent = Color(0xFFC93B1F)
val VermilionOnAccent = Color(0xFFFFFFFF)
val VermilionContainer = Color(0xFFFBEAE6)
val VermilionOnContainer = Color(0xFF9C2912)

val PineOffline = Color(0xFF1E6B4B)
val PineContainer = Color(0xFFE7F3ED)
val PineOnContainer = Color(0xFF155138)

// Legacy Dark Palette Tokens (retained for dark mode compatibility)
val ObsidianBackground = Color(0xFF0D1117)
val ObsidianCard = Color(0xFF161B22)
val ObsidianCardElevated = Color(0xFF1F2630)
val ObsidianConsole = Color(0xFF090D12)
val ObsidianBorder = Color(0xFF30363D)

val EmeraldAction = Color(0xFF2EA043)
val EmeraldOnAction = Color(0xFFFFFFFF)
val EmeraldContainer = Color(0xFF123820)
val EmeraldOnContainer = Color(0xFF56D364)

val TechBlueSecondary = Color(0xFF58A6FF)
val TechBlueOnSecondary = Color(0xFF051D38)
val TechBlueContainer = Color(0xFF112C48)
val TechBlueOnContainer = Color(0xFFA5D6FF)

val AmberWarning = Color(0xFFD29922)
val AmberOnWarning = Color(0xFF231802)
val AmberContainer = Color(0xFF332509)
val AmberOnContainer = Color(0xFFF2CC60)

val CrimsonError = Color(0xFFC93B1F)
val CrimsonContainer = Color(0xFFFBEAE6)
val CrimsonOnContainer = Color(0xFF9C2912)

val TextPrimaryDark = Color(0xFFF0F6FC)
val TextSecondaryDark = Color(0xFF8B949E)

val LightBg = PaperBackground
val LightSurface = PaperSurface
val LightSurfaceVariant = PaperSurfaceSubtle
val TextPrimaryLight = InkPrimary
val TextSecondaryLight = InkSecondary
