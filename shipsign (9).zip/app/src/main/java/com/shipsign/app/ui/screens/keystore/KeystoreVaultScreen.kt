package com.shipsign.app.ui.screens.keystore

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Key
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.UploadFile
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.shipsign.app.core.security.VaultKeystoreEntry
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.ui.KeystoreVaultUiState
import com.shipsign.app.ui.components.EditorialScreenHeader
import com.shipsign.app.ui.components.EditorialSectionKicker
import com.shipsign.app.ui.components.OfflineOutlineBadge
import com.shipsign.app.ui.components.PasswordTextField
import com.shipsign.app.ui.theme.InkOnDark
import com.shipsign.app.ui.theme.InkPrimary
import com.shipsign.app.ui.theme.InkSecondary
import com.shipsign.app.ui.theme.JetBrainsMonoFamily
import com.shipsign.app.ui.theme.PaperBackground
import com.shipsign.app.ui.theme.PaperBorder
import com.shipsign.app.ui.theme.PaperSurface
import com.shipsign.app.ui.theme.PaperSurfaceSubtle
import com.shipsign.app.ui.theme.PineContainer
import com.shipsign.app.ui.theme.PineOffline
import com.shipsign.app.ui.theme.PineOnContainer
import com.shipsign.app.ui.theme.VermilionAccent
import com.shipsign.app.ui.theme.VermilionContainer
import com.shipsign.app.ui.theme.VermilionOnAccent
import com.shipsign.app.ui.theme.VermilionOnContainer

/**
 * 03 — Create Keystore (100% Offline Vault).
 */
@Composable
fun KeystoreVaultScreen(
  state: KeystoreVaultUiState,
  onBack: () -> Unit,
  onCreateNew: (KeystoreCreateRequest) -> Unit,
  onPickImportUri: (Uri) -> Unit,
  onConfirmImport: (storePass: CharArray, alias: String, keyPass: CharArray) -> Unit,
  onExportKeystore: (VaultKeystoreEntry) -> Unit,
  onDeleteKeystore: (String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedTab by remember { mutableIntStateOf(0) }

  // Create New fields
  var format by remember { mutableStateOf(KeystoreFormat.PKCS12) }
  var fileName by remember { mutableStateOf("release-key") }
  var alias by remember { mutableStateOf("release") }
  var password by remember { mutableStateOf("") }
  var commonName by remember { mutableStateOf("Developer") }
  var organization by remember { mutableStateOf("ShipSign") }
  var countryCode by remember { mutableStateOf("US") }

  // Import fields
  var importStorePass by remember { mutableStateOf("") }
  var importAlias by remember { mutableStateOf("") }
  var importKeyPass by remember { mutableStateOf("") }

  val importPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument(),
  ) { uri ->
    if (uri != null) onPickImportUri(uri)
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(PaperBackground),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .navigationBarsPadding()
        .testTag("keystore_vault_list"),
      contentPadding = PaddingValues(horizontal = 24.dp, vertical = 0.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        EditorialScreenHeader(
          kicker = "03 — KEYSTORE",
          title = "Create Keystore",
          subtitle = "Generate a new RSA-2048 signing key or import an existing one offline.",
          onBack = onBack,
          trailingBadge = { OfflineOutlineBadge() },
        )
      }

      // Segmented switcher matching Page 3's CONVERT pill
      item {
        Surface(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(15.dp),
          color = PaperSurface,
          border = BorderStroke(1.dp, PaperBorder),
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            VaultSegmentPill(
              label = "Create New",
              selected = selectedTab == 0,
              onClick = { selectedTab = 0 },
              modifier = Modifier
                .weight(1f)
                .testTag("vault_tab_create"),
            )
            VaultSegmentPill(
              label = "Import",
              selected = selectedTab == 1,
              onClick = { selectedTab = 1 },
              modifier = Modifier
                .weight(1f)
                .testTag("vault_tab_import"),
            )
          }
        }
      }

      if (selectedTab == 0) {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PaperSurface),
            border = BorderStroke(1.dp, PaperBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              EditorialSectionKicker(text = "FORMAT")
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(KeystoreFormat.PKCS12, KeystoreFormat.JKS).forEach { fmt ->
                  Surface(
                    onClick = { format = fmt },
                    shape = RoundedCornerShape(10.dp),
                    color = if (format == fmt) InkPrimary else PaperSurfaceSubtle,
                    border = if (format == fmt) null else BorderStroke(1.dp, PaperBorder),
                    modifier = Modifier
                      .height(38.dp)
                      .testTag("vault_format_${fmt.name.lowercase()}"),
                  ) {
                    Box(
                      modifier = Modifier.padding(horizontal = 16.dp),
                      contentAlignment = Alignment.Center,
                    ) {
                      Text(
                        text = fmt.name,
                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                        color = if (format == fmt) InkOnDark else InkSecondary,
                      )
                    }
                  }
                }
              }

              OutlinedTextField(
                value = fileName,
                onValueChange = { fileName = it },
                label = { Text("Keystore File Name") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("vault_create_filename_input"),
              )

              OutlinedTextField(
                value = alias,
                onValueChange = { alias = it },
                label = { Text("Key Alias") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("vault_create_alias_input"),
              )

              PasswordTextField(
                value = password,
                onValueChange = { password = it },
                label = "Keystore Password (min 6 chars)",
                imeAction = ImeAction.Next,
                modifier = Modifier.testTag("vault_create_password_input"),
              )

              Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                  value = commonName,
                  onValueChange = { commonName = it },
                  label = { Text("Name (CN)") },
                  singleLine = true,
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f),
                )
                OutlinedTextField(
                  value = organization,
                  onValueChange = { organization = it },
                  label = { Text("Org (O)") },
                  singleLine = true,
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f),
                )
              }

              OutlinedTextField(
                value = countryCode,
                onValueChange = { countryCode = it.take(2).uppercase() },
                label = { Text("Country Code (2 letters)") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth(),
              )

              Button(
                onClick = {
                  val pw = password.toCharArray()
                  password = ""
                  onCreateNew(
                    KeystoreCreateRequest(
                      format = format,
                      fileName = fileName.trim().ifBlank { "release-key" },
                      storePassword = pw,
                      keyAlias = alias.trim().ifBlank { "release" },
                      keyPassword = pw.copyOf(),
                      validityDays = 10000,
                      commonName = commonName.trim().ifBlank { "Developer" },
                      organizationalUnit = "Mobile",
                      organization = organization.trim().ifBlank { "ShipSign" },
                      cityLocality = "San Francisco",
                      stateProvince = "CA",
                      countryCode = countryCode.trim().ifBlank { "US" },
                    )
                  )
                },
                enabled = !state.isBusy && password.length >= 6 && alias.isNotBlank(),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(54.dp)
                  .testTag("vault_create_submit_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = VermilionAccent,
                  contentColor = VermilionOnAccent,
                  disabledContainerColor = VermilionAccent.copy(alpha = 0.42f),
                  disabledContentColor = VermilionOnAccent,
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
              ) {
                if (state.isBusy) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = VermilionOnAccent,
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Text("Generating RSA-2048...")
                } else {
                  Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                  Spacer(modifier = Modifier.width(8.dp))
                  Text(
                    text = "Generate & save offline",
                    style = MaterialTheme.typography.titleMedium.copy(
                      fontWeight = FontWeight.SemiBold,
                      fontSize = 15.5.sp,
                    ),
                  )
                }
              }
            }
          }
        }
      } else {
        item {
          Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PaperSurface),
            border = BorderStroke(1.dp, PaperBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              OutlinedButton(
                onClick = { importPicker.launch(arrayOf("*/*")) },
                enabled = !state.isBusy,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(50.dp)
                  .testTag("vault_import_pick_button"),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, PaperBorder),
              ) {
                Icon(Icons.Rounded.UploadFile, contentDescription = null, tint = InkPrimary, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = state.importedFileName ?: "Select .jks / .keystore / .p12",
                  color = InkPrimary,
                )
              }

              PasswordTextField(
                value = importStorePass,
                onValueChange = { importStorePass = it },
                label = "Store Password",
                modifier = Modifier.testTag("vault_import_store_pass_input"),
              )

              OutlinedTextField(
                value = importAlias,
                onValueChange = { importAlias = it },
                label = { Text("Key Alias (optional — auto-detected if blank)") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("vault_import_alias_input"),
              )

              PasswordTextField(
                value = importKeyPass,
                onValueChange = { importKeyPass = it },
                label = "Key Password (blank = same as Store Password)",
                imeAction = ImeAction.Done,
                modifier = Modifier.testTag("vault_import_key_pass_input"),
              )

              Button(
                onClick = {
                  val sp = importStorePass.toCharArray()
                  val kp = importKeyPass.toCharArray()
                  importStorePass = ""
                  importKeyPass = ""
                  onConfirmImport(sp, importAlias.trim(), kp)
                },
                enabled = !state.isBusy && state.importedTempFile != null && importStorePass.isNotEmpty(),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(54.dp)
                  .testTag("vault_import_submit_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = InkPrimary,
                  contentColor = InkOnDark,
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp),
              ) {
                Text("Validate & save to vault", fontWeight = FontWeight.SemiBold)
              }
            }
          }
        }
      }

      if (!state.statusMessage.isNullOrBlank()) {
        item {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = PineContainer,
            border = BorderStroke(1.dp, PineOffline.copy(alpha = 0.4f)),
            modifier = Modifier
              .fillMaxWidth()
              .testTag("vault_status_banner"),
          ) {
            Text(
              text = state.statusMessage,
              style = MaterialTheme.typography.bodySmall,
              color = PineOnContainer,
              modifier = Modifier.padding(14.dp),
            )
          }
        }
      }

      if (!state.errorMessage.isNullOrBlank()) {
        item {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = VermilionContainer,
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = state.errorMessage,
              style = MaterialTheme.typography.bodySmall,
              color = VermilionOnContainer,
              modifier = Modifier.padding(14.dp),
            )
          }
        }
      }

      if (state.entries.isNotEmpty()) {
        item {
          EditorialSectionKicker(text = "SAVED KEYSTORES (${state.entries.size})")
        }

        items(state.entries, key = { it.id }) { entry ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("vault_saved_card_${entry.id}"),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = PaperSurface),
            border = BorderStroke(1.dp, PaperBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
          ) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth(),
              ) {
                Icon(
                  imageVector = Icons.Outlined.Key,
                  contentDescription = null,
                  tint = InkPrimary,
                  modifier = Modifier.size(20.dp),
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                    text = entry.fileName,
                    style = MaterialTheme.typography.titleSmall.copy(
                      fontFamily = JetBrainsMonoFamily,
                      fontWeight = FontWeight.Medium,
                    ),
                    color = InkPrimary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Text(
                    text = "Alias: ${entry.alias} · ${entry.format.name}",
                    style = MaterialTheme.typography.bodySmall,
                    color = InkSecondary,
                  )
                }
                IconButton(
                  onClick = { onExportKeystore(entry) },
                  modifier = Modifier.testTag("vault_export_button_${entry.id}"),
                ) {
                  Icon(
                    imageVector = Icons.Rounded.Download,
                    contentDescription = "Export keystore",
                    tint = PineOffline,
                  )
                }
                IconButton(
                  onClick = { onDeleteKeystore(entry.id) },
                  modifier = Modifier.testTag("vault_delete_button_${entry.id}"),
                ) {
                  Icon(
                    imageVector = Icons.Outlined.Delete,
                    contentDescription = "Delete keystore",
                    tint = InkSecondary,
                  )
                }
              }
              Text(
                text = "SHA-256: ${entry.sha256Fingerprint}",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                color = InkSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }
      }

      item { Spacer(modifier = Modifier.height(24.dp)) }
    }
  }
}

@Composable
private fun VaultSegmentPill(
  label: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    onClick = onClick,
    modifier = modifier.height(46.dp),
    shape = RoundedCornerShape(11.dp),
    color = if (selected) InkPrimary else PaperSurface,
  ) {
    Box(contentAlignment = Alignment.Center) {
      Text(
        text = label,
        style = MaterialTheme.typography.titleSmall.copy(
          fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
        ),
        color = if (selected) InkOnDark else InkSecondary,
      )
    }
  }
}
