package com.shipsign.app.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object SplashRoute

@Serializable
object HomeRoute

@Serializable
object StartProjectRoute

@Serializable
object SourceBuildRoute

@Serializable
data class PackageUploadRoute(val expectedFormat: String = "APK")

@Serializable
data class ReviewAndSignRoute(
  val focusSection: String = "REVIEW",
)

@Serializable
object TaskCompleteRoute

@Serializable
object PreviousProjectsRoute

@Serializable
object KeystoreVaultRoute
