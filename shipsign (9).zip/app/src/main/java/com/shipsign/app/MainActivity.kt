package com.shipsign.app

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.ui.FoundationUiState
import com.shipsign.app.ui.ShipSignViewModel
import com.shipsign.app.ui.navigation.HomeRoute
import com.shipsign.app.ui.navigation.KeystoreVaultRoute
import com.shipsign.app.ui.navigation.PackageUploadRoute
import com.shipsign.app.ui.navigation.PreviousProjectsRoute
import com.shipsign.app.ui.navigation.ReviewAndSignRoute
import com.shipsign.app.ui.navigation.SourceBuildRoute
import com.shipsign.app.ui.navigation.SplashRoute
import com.shipsign.app.ui.navigation.StartProjectRoute
import com.shipsign.app.ui.navigation.TaskCompleteRoute
import com.shipsign.app.ui.screens.home.HomeScreen
import com.shipsign.app.ui.screens.keystore.KeystoreVaultScreen
import com.shipsign.app.ui.screens.pipeline.ReviewAndSignScreen
import com.shipsign.app.ui.screens.pipeline.TaskCompleteScreen
import com.shipsign.app.ui.screens.project.PackageUploadScreen
import com.shipsign.app.ui.screens.project.SourceBuildScreen
import com.shipsign.app.ui.screens.project.StartProjectScreen
import com.shipsign.app.ui.screens.projects.PreviousProjectsScreen
import com.shipsign.app.ui.screens.splash.SplashScreen
import com.shipsign.app.ui.theme.ShipSignTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

  private val shipSignViewModel: ShipSignViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
    )
    forwardOAuthDeepLink(intent)

    setContent {
      val uiState by shipSignViewModel.uiState.collectAsStateWithLifecycle()

      CompositionLocalProvider(
        LocalActivityResultRegistryOwner provides this@MainActivity,
        LocalOnBackPressedDispatcherOwner provides this@MainActivity,
      ) {
        ShipSignTheme(darkTheme = false) {
          ShipSignRootScaffold(
            viewModel = shipSignViewModel,
            uiState = uiState,
          )
        }
      }
    }
  }

  override fun onResume() {
    super.onResume()
    shipSignViewModel.onAppResumed()
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    forwardOAuthDeepLink(intent)
  }

  private fun forwardOAuthDeepLink(intent: Intent?) {
    val uri = intent?.data ?: return
    shipSignViewModel.onGitHubCallback(uri)
  }
}

@Composable
private fun ShipSignRootScaffold(
  viewModel: ShipSignViewModel,
  uiState: FoundationUiState,
) {
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentDestination = navBackStackEntry?.destination
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val activityContext = LocalContext.current

  val isSplash = currentDestination == null || currentDestination.hasRoute<SplashRoute>()

  LaunchedEffect(uiState.cloudBuild.pendingResumeNavigation, isSplash) {
    if (uiState.cloudBuild.pendingResumeNavigation && !isSplash) {
      viewModel.consumePendingResumeNavigation()
      if (currentDestination?.hasRoute<SourceBuildRoute>() != true) {
        navController.navigate(SourceBuildRoute) {
          launchSingleTop = true
        }
      }
    }
  }

  LaunchedEffect(uiState.pipeline.pendingNavigateToComplete) {
    if (uiState.pipeline.pendingNavigateToComplete) {
      viewModel.consumePendingNavigateToComplete()
      navController.navigate(TaskCompleteRoute) {
        popUpTo<HomeRoute> { inclusive = false }
        launchSingleTop = true
      }
    }
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = SplashRoute,
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      composable<SplashRoute> {
        SplashScreen(
          onSplashComplete = {
            navController.navigate(HomeRoute) {
              popUpTo<SplashRoute> { inclusive = true }
              launchSingleTop = true
            }
          },
        )
      }

      composable<HomeRoute> {
        HomeScreen(
          savedProjectCount = uiState.projectHistory.projects.size,
          savedKeystoreCount = uiState.keystoreVault.entries.size,
          onStartProject = {
            navController.navigate(StartProjectRoute)
          },
          onViewPreviousProjects = {
            navController.navigate(PreviousProjectsRoute)
          },
          onCreateKeystore = {
            navController.navigate(KeystoreVaultRoute)
          },
        )
      }

      composable<StartProjectRoute> {
        StartProjectScreen(
          onBack = { navController.popBackStack() },
          onSelectSourceZip = {
            navController.navigate(SourceBuildRoute)
          },
          onSelectAlreadyBuiltApk = {
            viewModel.clearInspectedTarget()
            navController.navigate(PackageUploadRoute(ResolvedBinaryType.APK.name))
          },
          onSelectAlreadyBuiltAab = {
            viewModel.clearInspectedTarget()
            navController.navigate(PackageUploadRoute(ResolvedBinaryType.AAB.name))
          },
        )
      }

      composable<SourceBuildRoute> {
        SourceBuildScreen(
          inspectorState = uiState.inspector,
          cloudBuildState = uiState.cloudBuild,
          showGitHubDisclosureDialog = uiState.showGitHubDisclosureDialog,
          onBack = { navController.popBackStack() },
          onConnectGitHub = { viewModel.requestGitHubConnect(activityContext) },
          onConnectWithPat = viewModel::connectWithPersonalAccessToken,
          onDisconnectGitHub = viewModel::disconnectGitHub,
          onConfirmGitHubDisclosure = { viewModel.acceptGitHubDisclosureAndConnect(activityContext) },
          onDismissGitHubDisclosure = viewModel::dismissGitHubDisclosure,
          onPickSourceZip = { uri ->
            viewModel.inspectPackageForBranch(uri, ResolvedBinaryType.SOURCE_CODE_PROJECT)
          },
          onClearSelectedFile = viewModel::clearInspectedTarget,
          onSelectFramework = viewModel::overrideSourceFramework,
          onSelectOutputFormat = viewModel::selectOutputFormat,
          onStartCloudBuild = viewModel::startCloudBuild,
          onCancelCloudBuild = viewModel::cancelCloudBuild,
          onSelectReadyTarget = viewModel::selectActiveBuildTarget,
          onClearCloudTraceNow = viewModel::clearCloudTraceNow,
          onKeepRepoForInspection = viewModel::keepRepoForInspection,
          onContinueToPipeline = {
            navController.navigate(ReviewAndSignRoute(focusSection = "REVIEW"))
          },
        )
      }

      composable<PackageUploadRoute> { backStackEntry ->
        val args = backStackEntry.toRoute<PackageUploadRoute>()
        val expected = runCatching { ResolvedBinaryType.valueOf(args.expectedFormat) }
          .getOrDefault(ResolvedBinaryType.APK)
        PackageUploadScreen(
          expectedType = expected,
          inspectorState = uiState.inspector,
          onBack = { navController.popBackStack() },
          onPickPackageUri = { uri ->
            viewModel.inspectPackageForBranch(uri, expected)
          },
          onClearSelected = viewModel::clearInspectedTarget,
          onContinueToPipeline = {
            navController.navigate(ReviewAndSignRoute(focusSection = "REVIEW"))
          },
        )
      }

      composable<ReviewAndSignRoute> { backStackEntry ->
        val args = backStackEntry.toRoute<ReviewAndSignRoute>()
        ReviewAndSignScreen(
          targetFile = uiState.inspector.targetFile,
          vaultKeystores = uiState.keystoreVault.entries,
          keystoreStudio = uiState.keystoreStudio,
          signingState = uiState.signingStudio,
          pipelineState = uiState.pipeline,
          focusSection = args.focusSection,
          onBack = { navController.popBackStack() },
          onPickKeystoreUri = viewModel::importKeystoreUri,
          onExecuteFinish = { customization, shouldConvert, signAction ->
            viewModel.executeFinishPipeline(
              customization = customization,
              shouldConvert = shouldConvert,
              signAction = signAction,
              onUnsignedComplete = {
                navController.navigate(TaskCompleteRoute) {
                  popUpTo<HomeRoute> { inclusive = false }
                  launchSingleTop = true
                }
              },
            )
          },
        )
      }

      composable<TaskCompleteRoute> {
        TaskCompleteScreen(
          completedProject = uiState.pipeline.completedProject,
          cloudBuildState = uiState.cloudBuild,
          onDownloadFinalFile = { entry ->
            viewModel.downloadSavedProject(entry) { msg ->
              scope.launch { snackbarHostState.showSnackbar(msg) }
            }
          },
          onClearCloudTraceNow = viewModel::clearCloudTraceNow,
          onKeepRepoForInspection = viewModel::keepRepoForInspection,
          onViewPreviousProjects = {
            navController.navigate(PreviousProjectsRoute) {
              popUpTo<HomeRoute> { inclusive = false }
              launchSingleTop = true
            }
          },
          onReturnHome = {
            navController.popBackStack<HomeRoute>(inclusive = false)
          },
          onShowMessage = { msg ->
            scope.launch { snackbarHostState.showSnackbar(msg) }
          },
        )
      }

      composable<PreviousProjectsRoute> {
        PreviousProjectsScreen(
          state = uiState.projectHistory,
          onBack = { navController.popBackStack() },
          onDownloadAgain = { entry ->
            viewModel.downloadSavedProject(entry) { msg ->
              scope.launch { snackbarHostState.showSnackbar(msg) }
            }
          },
          onSignLater = { entry ->
            viewModel.loadSavedProjectIntoPipeline(entry) {
              navController.navigate(ReviewAndSignRoute(focusSection = "SIGN"))
            }
          },
          onCustomizeLater = { entry ->
            viewModel.loadSavedProjectIntoPipeline(entry) {
              navController.navigate(ReviewAndSignRoute(focusSection = "CUSTOMIZE"))
            }
          },
          onClearCloudTrace = { entry ->
            viewModel.clearCloudTraceForProject(entry) { msg ->
              scope.launch { snackbarHostState.showSnackbar(msg) }
            }
          },
          onDeleteProject = { id ->
            viewModel.deleteSavedProject(id)
            scope.launch { snackbarHostState.showSnackbar("Project deleted from local vault.") }
          },
        )
      }

      composable<KeystoreVaultRoute> {
        KeystoreVaultScreen(
          state = uiState.keystoreVault,
          onBack = { navController.popBackStack() },
          onCreateNew = { request ->
            viewModel.createVaultKeystore(request) { entry ->
              scope.launch { snackbarHostState.showSnackbar("Created ${entry.fileName}") }
            }
          },
          onPickImportUri = viewModel::pickKeystoreForVaultImport,
          onConfirmImport = { sp, alias, kp ->
            viewModel.confirmVaultKeystoreImport(sp, alias, kp) { entry ->
              scope.launch { snackbarHostState.showSnackbar("Imported ${entry.fileName}") }
            }
          },
          onExportKeystore = { entry ->
            viewModel.exportVaultKeystore(entry) { msg ->
              scope.launch { snackbarHostState.showSnackbar(msg) }
            }
          },
          onDeleteKeystore = { id ->
            viewModel.deleteVaultKeystore(id)
            scope.launch { snackbarHostState.showSnackbar("Keystore removed from vault.") }
          },
        )
      }
    }
  }
}
