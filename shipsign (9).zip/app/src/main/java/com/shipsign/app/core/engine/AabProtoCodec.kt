package com.shipsign.app.core.engine

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets

data class RawProtoField(
  val tag: Int,
  val rawPayload: ByteArray,
)

data class ProtoXmlNamespace(
  val prefix: String = "",
  val uri: String = "",
  val unknownFields: List<RawProtoField> = emptyList(),
)

data class ProtoItem(
  val refId: Int? = null,
  val intDecimal: Int? = null,
  val intHex: Int? = null,
  val booleanValue: Boolean? = null,
  val strValue: String? = null,
  val rawItemBytes: ByteArray? = null,
)

data class ProtoXmlAttribute(
  val namespaceUri: String = "",
  val name: String = "",
  val value: String = "",
  val resourceId: Int = 0,
  val compiledItem: ProtoItem? = null,
  val unknownFields: List<RawProtoField> = emptyList(),
)

data class ProtoXmlElement(
  val namespaces: List<ProtoXmlNamespace> = emptyList(),
  val namespaceUri: String = "",
  val name: String = "",
  val attributes: List<ProtoXmlAttribute> = emptyList(),
  val children: List<ProtoXmlNode> = emptyList(),
  val unknownFields: List<RawProtoField> = emptyList(),
)

data class ProtoXmlNode(
  val element: ProtoXmlElement? = null,
  val text: String? = null,
  val unknownFields: List<RawProtoField> = emptyList(),
)

/**
 * Zero-dependency, lossless Protobuf wire-format codec for Android App Bundle (`.aab`) protobuf
 * structures (`aapt.pb.XmlNode`, `aapt.pb.ResourceTable`, and `android.bundle.BundleConfig`).
 *
 * Preserves unknown fields verbatim during read-modify-write so real Gradle/AAPT2 manifests retain
 * all source positions and compiled resource items cleanly.
 */
object AabProtoCodec {

  private const val WIRE_VARINT = 0
  private const val WIRE_64BIT = 1
  private const val WIRE_LENGTH_DELIMITED = 2
  private const val WIRE_32BIT = 5

  // --- XmlNode decoding & encoding ---

  fun parseXmlNode(bytes: ByteArray): ProtoXmlNode {
    val reader = ProtoReader(bytes)
    var element: ProtoXmlElement? = null
    var text: String? = null
    val unknown = mutableListOf<RawProtoField>()

    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      when {
        fieldNum == 1 && wireType == WIRE_LENGTH_DELIMITED -> {
          element = parseXmlElement(reader.readBytes())
        }
        fieldNum == 2 && wireType == WIRE_LENGTH_DELIMITED -> {
          text = reader.readString()
        }
        else -> {
          unknown.add(RawProtoField(tag, reader.readRawFieldPayload(wireType)))
        }
      }
    }
    return ProtoXmlNode(element = element, text = text, unknownFields = unknown)
  }

  fun encodeXmlNode(node: ProtoXmlNode): ByteArray {
    val out = ProtoWriter()
    if (node.element != null) {
      out.writeBytesField(1, encodeXmlElement(node.element))
    } else if (node.text != null) {
      out.writeStringField(2, node.text)
    }
    for (u in node.unknownFields) {
      out.writeRawField(u)
    }
    return out.toByteArray()
  }

  private fun parseXmlElement(bytes: ByteArray): ProtoXmlElement {
    val reader = ProtoReader(bytes)
    val namespaces = mutableListOf<ProtoXmlNamespace>()
    var namespaceUri = ""
    var name = ""
    val attributes = mutableListOf<ProtoXmlAttribute>()
    val children = mutableListOf<ProtoXmlNode>()
    val unknown = mutableListOf<RawProtoField>()

    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      when {
        fieldNum == 1 && wireType == WIRE_LENGTH_DELIMITED -> namespaces.add(parseXmlNamespace(reader.readBytes()))
        fieldNum == 2 && wireType == WIRE_LENGTH_DELIMITED -> namespaceUri = reader.readString()
        fieldNum == 3 && wireType == WIRE_LENGTH_DELIMITED -> name = reader.readString()
        fieldNum == 4 && wireType == WIRE_LENGTH_DELIMITED -> attributes.add(parseXmlAttribute(reader.readBytes()))
        fieldNum == 5 && wireType == WIRE_LENGTH_DELIMITED -> children.add(parseXmlNode(reader.readBytes()))
        else -> unknown.add(RawProtoField(tag, reader.readRawFieldPayload(wireType)))
      }
    }
    return ProtoXmlElement(
      namespaces = namespaces,
      namespaceUri = namespaceUri,
      name = name,
      attributes = attributes,
      children = children,
      unknownFields = unknown,
    )
  }

  private fun encodeXmlElement(el: ProtoXmlElement): ByteArray {
    val out = ProtoWriter()
    for (ns in el.namespaces) {
      out.writeBytesField(1, encodeXmlNamespace(ns))
    }
    if (el.namespaceUri.isNotEmpty()) {
      out.writeStringField(2, el.namespaceUri)
    }
    if (el.name.isNotEmpty()) {
      out.writeStringField(3, el.name)
    }
    for (attr in el.attributes) {
      out.writeBytesField(4, encodeXmlAttribute(attr))
    }
    for (child in el.children) {
      out.writeBytesField(5, encodeXmlNode(child))
    }
    for (u in el.unknownFields) {
      out.writeRawField(u)
    }
    return out.toByteArray()
  }

  private fun parseXmlNamespace(bytes: ByteArray): ProtoXmlNamespace {
    val reader = ProtoReader(bytes)
    var prefix = ""
    var uri = ""
    val unknown = mutableListOf<RawProtoField>()

    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      when {
        fieldNum == 1 && wireType == WIRE_LENGTH_DELIMITED -> prefix = reader.readString()
        fieldNum == 2 && wireType == WIRE_LENGTH_DELIMITED -> uri = reader.readString()
        else -> unknown.add(RawProtoField(tag, reader.readRawFieldPayload(wireType)))
      }
    }
    return ProtoXmlNamespace(prefix = prefix, uri = uri, unknownFields = unknown)
  }

  private fun encodeXmlNamespace(ns: ProtoXmlNamespace): ByteArray {
    val out = ProtoWriter()
    if (ns.prefix.isNotEmpty()) out.writeStringField(1, ns.prefix)
    if (ns.uri.isNotEmpty()) out.writeStringField(2, ns.uri)
    for (u in ns.unknownFields) out.writeRawField(u)
    return out.toByteArray()
  }

  private fun parseXmlAttribute(bytes: ByteArray): ProtoXmlAttribute {
    val reader = ProtoReader(bytes)
    var namespaceUri = ""
    var name = ""
    var value = ""
    var resourceId = 0
    var compiledItem: ProtoItem? = null
    val unknown = mutableListOf<RawProtoField>()

    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      when {
        fieldNum == 1 && wireType == WIRE_LENGTH_DELIMITED -> namespaceUri = reader.readString()
        fieldNum == 2 && wireType == WIRE_LENGTH_DELIMITED -> name = reader.readString()
        fieldNum == 3 && wireType == WIRE_LENGTH_DELIMITED -> value = reader.readString()
        fieldNum == 5 && wireType == WIRE_VARINT -> resourceId = reader.readVarint32()
        fieldNum == 6 && wireType == WIRE_LENGTH_DELIMITED -> compiledItem = parseItem(reader.readBytes())
        else -> unknown.add(RawProtoField(tag, reader.readRawFieldPayload(wireType)))
      }
    }
    return ProtoXmlAttribute(
      namespaceUri = namespaceUri,
      name = name,
      value = value,
      resourceId = resourceId,
      compiledItem = compiledItem,
      unknownFields = unknown,
    )
  }

  private fun encodeXmlAttribute(attr: ProtoXmlAttribute): ByteArray {
    val out = ProtoWriter()
    if (attr.namespaceUri.isNotEmpty()) out.writeStringField(1, attr.namespaceUri)
    if (attr.name.isNotEmpty()) out.writeStringField(2, attr.name)
    if (attr.value.isNotEmpty()) out.writeStringField(3, attr.value)
    if (attr.resourceId != 0) out.writeVarintField(5, attr.resourceId.toLong() and 0xFFFFFFFFL)
    if (attr.compiledItem != null) {
      out.writeBytesField(6, encodeItem(attr.compiledItem))
    }
    for (u in attr.unknownFields) out.writeRawField(u)
    return out.toByteArray()
  }

  private fun parseItem(bytes: ByteArray): ProtoItem {
    val reader = ProtoReader(bytes)
    var refId: Int? = null
    var intDecimal: Int? = null
    var intHex: Int? = null
    var booleanValue: Boolean? = null
    var strValue: String? = null

    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      when {
        fieldNum == 1 && wireType == WIRE_LENGTH_DELIMITED -> {
          val refReader = ProtoReader(reader.readBytes())
          while (!refReader.isAtEnd()) {
            val rTag = refReader.readVarint32()
            val rField = rTag ushr 3
            val rWire = rTag and 0x7
            if (rField == 2 && rWire == WIRE_VARINT) {
              refId = refReader.readVarint32()
            } else {
              refReader.skipField(rWire)
            }
          }
        }
        fieldNum == 2 && wireType == WIRE_LENGTH_DELIMITED -> {
          val strReader = ProtoReader(reader.readBytes())
          while (!strReader.isAtEnd()) {
            val sTag = strReader.readVarint32()
            val sField = sTag ushr 3
            val sWire = sTag and 0x7
            if (sField == 1 && sWire == WIRE_LENGTH_DELIMITED) {
              strValue = strReader.readString()
            } else {
              strReader.skipField(sWire)
            }
          }
        }
        fieldNum == 7 && wireType == WIRE_LENGTH_DELIMITED -> {
          val primReader = ProtoReader(reader.readBytes())
          while (!primReader.isAtEnd()) {
            val pTag = primReader.readVarint32()
            val pField = pTag ushr 3
            val pWire = pTag and 0x7
            when {
              pField == 6 && pWire == WIRE_VARINT -> intDecimal = primReader.readVarint32()
              pField == 7 && pWire == WIRE_VARINT -> intHex = primReader.readVarint32()
              pField == 8 && pWire == WIRE_VARINT -> booleanValue = primReader.readVarint64() != 0L
              else -> primReader.skipField(pWire)
            }
          }
        }
        else -> reader.skipField(wireType)
      }
    }
    return ProtoItem(
      refId = refId,
      intDecimal = intDecimal,
      intHex = intHex,
      booleanValue = booleanValue,
      strValue = strValue,
      rawItemBytes = bytes,
    )
  }

  private fun encodeItem(item: ProtoItem): ByteArray {
    if (item.rawItemBytes != null) return item.rawItemBytes
    val out = ProtoWriter()
    when {
      item.refId != null -> {
        val refWriter = ProtoWriter()
        refWriter.writeVarintField(2, item.refId.toLong() and 0xFFFFFFFFL)
        out.writeBytesField(1, refWriter.toByteArray())
      }
      item.strValue != null -> {
        val strWriter = ProtoWriter()
        strWriter.writeStringField(1, item.strValue)
        out.writeBytesField(2, strWriter.toByteArray())
      }
      item.intDecimal != null || item.intHex != null || item.booleanValue != null -> {
        val primWriter = ProtoWriter()
        if (item.intDecimal != null) {
          primWriter.writeVarintField(6, item.intDecimal.toLong())
        } else if (item.intHex != null) {
          primWriter.writeVarintField(7, item.intHex.toLong() and 0xFFFFFFFFL)
        } else if (item.booleanValue != null) {
          primWriter.writeVarintField(8, if (item.booleanValue) 1L else 0L)
        }
        out.writeBytesField(7, primWriter.toByteArray())
      }
    }
    return out.toByteArray()
  }

  // --- ResourceTable string resolver & minimal encoder ---

  fun resolveResourceTableString(tableBytes: ByteArray, resId: Int): String? {
    val targetPkg = (resId ushr 24) and 0xFF
    val targetType = (resId ushr 16) and 0xFF
    val targetEntry = resId and 0xFFFF

    val reader = ProtoReader(tableBytes)
    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      if (fieldNum == 2 && wireType == WIRE_LENGTH_DELIMITED) {
        val found = findInPackage(reader.readBytes(), targetPkg, targetType, targetEntry)
        if (!found.isNullOrBlank()) return found
      } else {
        reader.skipField(wireType)
      }
    }
    return null
  }

  private fun findInPackage(pkgBytes: ByteArray, targetPkg: Int, targetType: Int, targetEntry: Int): String? {
    val reader = ProtoReader(pkgBytes)
    var pkgId = -1
    val typeBlobs = mutableListOf<ByteArray>()
    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      when {
        fieldNum == 1 && wireType == WIRE_LENGTH_DELIMITED -> pkgId = readSingleVarintField1(reader.readBytes())
        fieldNum == 3 && wireType == WIRE_LENGTH_DELIMITED -> typeBlobs.add(reader.readBytes())
        else -> reader.skipField(wireType)
      }
    }
    if (pkgId != targetPkg) return null
    for (typeBlob in typeBlobs) {
      val found = findInType(typeBlob, targetType, targetEntry)
      if (!found.isNullOrBlank()) return found
    }
    return null
  }

  private fun findInType(typeBytes: ByteArray, targetType: Int, targetEntry: Int): String? {
    val reader = ProtoReader(typeBytes)
    var typeId = -1
    val entryBlobs = mutableListOf<ByteArray>()
    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      when {
        fieldNum == 1 && wireType == WIRE_LENGTH_DELIMITED -> typeId = readSingleVarintField1(reader.readBytes())
        fieldNum == 3 && wireType == WIRE_LENGTH_DELIMITED -> entryBlobs.add(reader.readBytes())
        else -> reader.skipField(wireType)
      }
    }
    if (typeId != targetType) return null
    for (entryBlob in entryBlobs) {
      val found = findInEntry(entryBlob, targetEntry)
      if (!found.isNullOrBlank()) return found
    }
    return null
  }

  private fun findInEntry(entryBytes: ByteArray, targetEntry: Int): String? {
    val reader = ProtoReader(entryBytes)
    var entryId = -1
    val configValBlobs = mutableListOf<ByteArray>()
    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      when {
        fieldNum == 1 && wireType == WIRE_LENGTH_DELIMITED -> entryId = readSingleVarintField1(reader.readBytes())
        fieldNum == 6 && wireType == WIRE_LENGTH_DELIMITED -> configValBlobs.add(reader.readBytes())
        else -> reader.skipField(wireType)
      }
    }
    if (entryId != targetEntry) return null
    for (cvBlob in configValBlobs) {
      val cvReader = ProtoReader(cvBlob)
      while (!cvReader.isAtEnd()) {
        val tag = cvReader.readVarint32()
        val fieldNum = tag ushr 3
        val wireType = tag and 0x7
        if (fieldNum == 2 && wireType == WIRE_LENGTH_DELIMITED) {
          val valReader = ProtoReader(cvReader.readBytes())
          while (!valReader.isAtEnd()) {
            val vTag = valReader.readVarint32()
            val vField = vTag ushr 3
            val vWire = vTag and 0x7
            if (vField == 4 && vWire == WIRE_LENGTH_DELIMITED) {
              val item = parseItem(valReader.readBytes())
              if (!item.strValue.isNullOrBlank()) return item.strValue
            } else {
              valReader.skipField(vWire)
            }
          }
        } else {
          cvReader.skipField(wireType)
        }
      }
    }
    return null
  }

  private fun readSingleVarintField1(bytes: ByteArray): Int {
    val reader = ProtoReader(bytes)
    while (!reader.isAtEnd()) {
      val tag = reader.readVarint32()
      val fieldNum = tag ushr 3
      val wireType = tag and 0x7
      if (fieldNum == 1 && wireType == WIRE_VARINT) {
        return reader.readVarint32()
      } else {
        reader.skipField(wireType)
      }
    }
    return -1
  }

  fun encodeMinimalResourceTable(packageName: String, packageId: Int = 0x7F): ByteArray {
    val pkgIdMsg = ProtoWriter().apply {
      writeVarintField(1, packageId.toLong() and 0xFFFFFFFFL)
    }.toByteArray()

    val pkgMsg = ProtoWriter().apply {
      writeBytesField(1, pkgIdMsg)
      writeStringField(2, packageName)
    }.toByteArray()

    return ProtoWriter().apply {
      writeBytesField(2, pkgMsg)
    }.toByteArray()
  }

  fun encodeBundleConfig(bundletoolVersion: String = "1.18.3"): ByteArray {
    val bundletoolMsg = ProtoWriter().apply {
      writeStringField(2, bundletoolVersion)
    }.toByteArray()

    return ProtoWriter().apply {
      writeBytesField(1, bundletoolMsg)
      // field 7: BundleType.REGULAR = 0 (default in proto3, written explicitly for older parsers)
      writeVarintField(7, 0L)
    }.toByteArray()
  }

  // --- Low-level Protobuf Wire Reader & Writer ---

  private class ProtoReader(private val data: ByteArray) {
    private var pos = 0

    fun isAtEnd(): Boolean = pos >= data.size

    fun readVarint64(): Long {
      var result = 0L
      var shift = 0
      while (shift < 64 && pos < data.size) {
        val b = data[pos++].toInt() and 0xFF
        result = result or ((b.toLong() and 0x7FL) shl shift)
        if ((b and 0x80) == 0) return result
        shift += 7
      }
      return result
    }

    fun readVarint32(): Int = readVarint64().toInt()

    fun readBytes(): ByteArray {
      val len = readVarint32().coerceAtLeast(0)
      val end = (pos + len).coerceAtMost(data.size)
      val slice = data.copyOfRange(pos, end)
      pos = end
      return slice
    }

    fun readString(): String = String(readBytes(), StandardCharsets.UTF_8)

    fun skipField(wireType: Int) {
      when (wireType) {
        WIRE_VARINT -> readVarint64()
        WIRE_64BIT -> pos = (pos + 8).coerceAtMost(data.size)
        WIRE_LENGTH_DELIMITED -> {
          val len = readVarint32().coerceAtLeast(0)
          pos = (pos + len).coerceAtMost(data.size)
        }
        WIRE_32BIT -> pos = (pos + 4).coerceAtMost(data.size)
        else -> pos = data.size
      }
    }

    fun readRawFieldPayload(wireType: Int): ByteArray {
      val start = pos
      skipField(wireType)
      return data.copyOfRange(start, pos)
    }
  }

  private class ProtoWriter {
    private val out = ByteArrayOutputStream()

    fun writeVarint64(value: Long) {
      var v = value
      while (true) {
        if ((v and 0x7FL.inv()) == 0L) {
          out.write(v.toInt())
          return
        }
        out.write(((v.toInt() and 0x7F) or 0x80))
        v = v ushr 7
      }
    }

    fun writeTag(fieldNum: Int, wireType: Int) {
      writeVarint64(((fieldNum shl 3) or wireType).toLong() and 0xFFFFFFFFL)
    }

    fun writeVarintField(fieldNum: Int, value: Long) {
      writeTag(fieldNum, WIRE_VARINT)
      writeVarint64(value)
    }

    fun writeBytesField(fieldNum: Int, payload: ByteArray) {
      writeTag(fieldNum, WIRE_LENGTH_DELIMITED)
      writeVarint64(payload.size.toLong())
      out.write(payload)
    }

    fun writeStringField(fieldNum: Int, value: String) {
      writeBytesField(fieldNum, value.toByteArray(StandardCharsets.UTF_8))
    }

    fun writeRawField(raw: RawProtoField) {
      writeVarint64(raw.tag.toLong() and 0xFFFFFFFFL)
      out.write(raw.rawPayload)
    }

    fun toByteArray(): ByteArray = out.toByteArray()
  }
}
