package com.shipsign.app.core.github

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File

@Serializable
enum class BuildSessionStatus {
  UPLOADING,
  QUEUED,
  IN_PROGRESS,
  DOWNLOADING_SIGNING,
  COMPLETED_AWAITING_CLEANUP,
  FAILED_AWAITING_CLEANUP,
  CLEANED;

  val isActiveInCloud: Boolean
    get() = this == UPLOADING ||
      this == QUEUED ||
      this == IN_PROGRESS ||
      this == DOWNLOADING_SIGNING

  val isAwaitingCleanup: Boolean
    get() = this == COMPLETED_AWAITING_CLEANUP || this == FAILED_AWAITING_CLEANUP
}

@Serializable
data class PersistedBuildSession(
  val sessionId: String,
  val repoOwner: String,
  val repoName: String,
  val workflowFileName: String,
  val runId: Long? = null,
  val projectName: String,
  val packageId: String? = null,
  val framework: String,
  val buildTarget: String,
  val keystoreUri: String? = null,
  val startedAtEpochMs: Long,
  val status: BuildSessionStatus,
  val statusMessage: String = "",
  val errorMessage: String? = null,
  val keepForInspection: Boolean = false,
  val downloadedArtifactPaths: List<String> = emptyList(),
) {
  val repoFullName: String
    get() = when {
      repoOwner.isNotBlank() && repoName.isNotBlank() -> "$repoOwner/$repoName"
      repoName.isNotBlank() -> repoName
      else -> ""
    }

  val outputFormat: BuildOutputFormat
    get() = runCatching { BuildOutputFormat.valueOf(buildTarget) }
      .getOrDefault(BuildOutputFormat.APK_ONLY)
}

/**
 * Persists active or uncleaned GitHub Actions cloud build session metadata inside AES-256
 * [EncryptedSharedPreferences] so minimizing or closing ShipSign never loses track of a
 * running cloud build or a temporary private repository awaiting user-confirmed cleanup.
 *
 * Strictly zero keystores, zero passwords, and zero GitHub tokens are stored here.
 */
object BuildSessionStore {

  private const val PREFS_NAME = "shipsign_build_session_encrypted"
  private const val KEY_ACTIVE_SESSION_JSON = "active_build_session_json"

  private val json = Json {
    ignoreUnknownKeys = true
    encodeDefaults = true
  }

  private val _sessionFlow = MutableStateFlow<PersistedBuildSession?>(null)
  val sessionFlow: StateFlow<PersistedBuildSession?> = _sessionFlow.asStateFlow()

  @Volatile private var cachedPrefs: SharedPreferences? = null

  private fun prefs(context: Context): SharedPreferences {
    cachedPrefs?.let { return it }
    synchronized(this) {
      cachedPrefs?.let { return it }
      val appCtx = context.applicationContext
      val instance = try {
        val masterKey = MasterKey.Builder(appCtx)
          .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
          .build()
        EncryptedSharedPreferences.create(
          appCtx,
          PREFS_NAME,
          masterKey,
          EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
          EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
        )
      } catch (_: Exception) {
        // Fallback only for JVM test runners (Robolectric) without AndroidKeyStore hardware
        appCtx.getSharedPreferences("${PREFS_NAME}_fallback", Context.MODE_PRIVATE)
      }
      cachedPrefs = instance
      return instance
    }
  }

  fun saveSession(context: Context, session: PersistedBuildSession) {
    val serialized = json.encodeToString(PersistedBuildSession.serializer(), session)
    prefs(context).edit().putString(KEY_ACTIVE_SESSION_JSON, serialized).commit()
    _sessionFlow.value = session
  }

  fun loadSession(context: Context): PersistedBuildSession? {
    val raw = prefs(context).getString(KEY_ACTIVE_SESSION_JSON, null)
    if (raw.isNullOrBlank()) {
      _sessionFlow.value = null
      return null
    }
    val parsed = runCatching {
      json.decodeFromString(PersistedBuildSession.serializer(), raw)
    }.getOrNull()
    if (parsed == null) {
      clearSession(context)
      return null
    }
    _sessionFlow.value = parsed
    return parsed
  }

  fun updateSession(
    context: Context,
    transform: (PersistedBuildSession) -> PersistedBuildSession,
  ): PersistedBuildSession? {
    val current = _sessionFlow.value ?: loadSession(context) ?: return null
    val updated = transform(current)
    saveSession(context, updated)
    return updated
  }

  fun markKeepForInspection(context: Context): PersistedBuildSession? =
    updateSession(context) { it.copy(keepForInspection = true) }

  fun clearSession(context: Context) {
    prefs(context).edit().remove(KEY_ACTIVE_SESSION_JSON).commit()
    _sessionFlow.value = null
  }

  /**
   * Returns true when a cloud build is actively running OR downloaded unsigned artifacts
   * are waiting in the ephemeral session directory for the user to finish offline signing.
   */
  fun hasProtectedBuildArtifacts(context: Context): Boolean {
    val session = _sessionFlow.value ?: loadSession(context) ?: return false
    if (session.status.isActiveInCloud) return true
    if (session.status == BuildSessionStatus.COMPLETED_AWAITING_CLEANUP) {
      return session.downloadedArtifactPaths.any { path ->
        path.isNotBlank() && File(path).exists()
      }
    }
    return false
  }
}
