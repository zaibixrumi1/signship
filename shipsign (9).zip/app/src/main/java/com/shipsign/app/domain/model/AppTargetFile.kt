package com.shipsign.app.domain.model

import java.io.File

enum class InputCategory {
  STUDIO_SOURCE_ZIP,
  BUILT_APK,
  PLAY_STORE_AAB,
}

enum class InputKind {
  PREBUILT_PACKAGE,
  SOURCE_ARCHIVE,
  INVALID,
}

enum class ResolvedBinaryType {
  APK,
  AAB,
  SOURCE_CODE_PROJECT,
  INVALID,
}

enum class ProjectFramework(
  val displayName: String,
  val containerTag: String,
) {
  NATIVE_ANDROID("Native Android", "android"),
  FLUTTER("Flutter", "flutter"),
  REACT_NATIVE("React Native", "web"),
  CAPACITOR_CORDOVA("Capacitor / Cordova", "web"),
  GODOT("Godot Engine", "android"),
  UNKNOWN("Unknown", "android"),
}

enum class ProjectStack {
  ANDROID_GRADLE,
  FLUTTER,
  CAPACITOR_WEB,
  REACT_NATIVE,
  GODOT,
  UNKNOWN;

  fun toFramework(): ProjectFramework = when (this) {
    ANDROID_GRADLE -> ProjectFramework.NATIVE_ANDROID
    FLUTTER -> ProjectFramework.FLUTTER
    CAPACITOR_WEB -> ProjectFramework.CAPACITOR_CORDOVA
    REACT_NATIVE -> ProjectFramework.REACT_NATIVE
    GODOT -> ProjectFramework.GODOT
    UNKNOWN -> ProjectFramework.UNKNOWN
  }

  companion object {
    fun fromFramework(framework: ProjectFramework): ProjectStack = when (framework) {
      ProjectFramework.NATIVE_ANDROID -> ANDROID_GRADLE
      ProjectFramework.FLUTTER -> FLUTTER
      ProjectFramework.CAPACITOR_CORDOVA -> CAPACITOR_WEB
      ProjectFramework.REACT_NATIVE -> REACT_NATIVE
      ProjectFramework.GODOT -> GODOT
      ProjectFramework.UNKNOWN -> UNKNOWN
    }
  }
}

data class SourceProjectMetadata(
  val framework: ProjectFramework,
  val projectRootPrefix: String = "",
  val hasGradleWrapper: Boolean = false,
  val gradleVersion: String? = null,
  val hasFirebasePlugin: Boolean = false,
  val hasGoogleServicesJson: Boolean = false,
  val hasEnvExample: Boolean = false,
  val applicationId: String? = null,
  val strippedMetadataCount: Int = 0,
) {
  val containerTag: String
    get() = framework.containerTag
}

data class PackageMetadataInfo(
  val appName: String,
  val packageId: String,
  val versionCode: Long,
  val versionName: String,
  val format: ResolvedBinaryType,
  val isSigned: Boolean,
  val sha256Fingerprint: String? = null,
  val sha1Fingerprint: String? = null,
  val minSdk: Int? = null,
  val targetSdk: Int? = null,
)

data class AppTargetFile(
  val sessionFile: File,
  val originalName: String,
  val sizeBytes: Long,
  val binaryType: ResolvedBinaryType,
  val isAlreadySigned: Boolean,
  val detectedStack: ProjectStack?,
  val sourceMetadata: SourceProjectMetadata? = null,
  val packageInfo: PackageMetadataInfo? = null,
) {
  val inputKind: InputKind
    get() = when (binaryType) {
      ResolvedBinaryType.APK, ResolvedBinaryType.AAB -> InputKind.PREBUILT_PACKAGE
      ResolvedBinaryType.SOURCE_CODE_PROJECT -> InputKind.SOURCE_ARCHIVE
      ResolvedBinaryType.INVALID -> InputKind.INVALID
    }
}
