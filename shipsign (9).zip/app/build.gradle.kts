import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy
import java.util.Properties

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.kotlin.serialization)
  alias(libs.plugins.secrets)
  alias(libs.plugins.google.services)
}

android {
  namespace = "com.shipsign.app"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    applicationId = "com.shipsign.app"
    minSdk = 26
    targetSdk = 36
    versionCode = 1
    versionName = "1.0.0"

    fun readPropFileValue(file: java.io.File, key: String): String? {
      if (!file.exists() || !file.isFile) return null
      val props = Properties()
      file.inputStream().use { props.load(it) }
      return props.getProperty(key)?.trim()?.removeSurrounding("\"")?.removeSurrounding("'")?.trim()
    }

    fun resolveCredential(key: String, defaultValue: String, placeholder: String): String {
      val candidates = listOf(
        readPropFileValue(rootProject.file("local.properties"), key),
        readPropFileValue(rootProject.file(".env"), key),
        System.getenv(key)?.trim(),
      )
      return candidates
        .firstOrNull { !it.isNullOrBlank() && it != placeholder }
        ?.trim()
        ?: defaultValue
    }

    fun escapeBuildConfig(value: String): String =
      value.replace("\\", "\\\\").replace("\"", "\\\"")

    val ghClientId = escapeBuildConfig(
      resolveCredential(
        key = "GITHUB_CLIENT_ID",
        defaultValue = "Iv23li9uobnY1r29Wel9",
        placeholder = "YOUR_GITHUB_CLIENT_ID",
      )
    )
    val ghClientSecret = escapeBuildConfig(
      resolveCredential(
        key = "GITHUB_CLIENT_SECRET",
        defaultValue = "",
        placeholder = "YOUR_GITHUB_CLIENT_SECRET",
      )
    )
    buildConfigField("String", "GITHUB_CLIENT_ID", "\"$ghClientId\"")
    buildConfigField("String", "GITHUB_CLIENT_SECRET", "\"$ghClientSecret\"")
    buildConfigField("String", "GITHUB_OAUTH_CLIENT_ID", "\"$ghClientId\"")

    ndk {
      abiFilters += listOf("arm64-v8a", "armeabi-v7a")
    }

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  // Do not remove or modify these signingConfigs. They are necessary for building, installing,
  // and updating Android apps in AI Studio.
  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("KEYSTORE_PATH") ?: "${rootDir}/my-upload-key.jks"
      storeFile = file(keystorePath)
      storePassword = System.getenv("STORE_PASSWORD")
      keyAlias = "upload"
      keyPassword = System.getenv("KEY_PASSWORD")
    }
    create("debugConfig") {
      storeFile = file("${rootDir}/debug.keystore")
      storePassword = "android"
      keyAlias = "androiddebugkey"
      keyPassword = "android"
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      isShrinkResources = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("release")
    }
    debug {
      // Do not remove or modify this signingConfig assignment. It is necessary for Android apps in
      // AI Studio.
      signingConfig = signingConfigs.getByName("debugConfig")
    }
  }

  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }

  buildFeatures {
    compose = true
    buildConfig = true
  }

  packaging {
    resources {
      excludes += setOf(
        "META-INF/LICENSE*",
        "META-INF/NOTICE*",
        "META-INF/DEPENDENCIES",
        "META-INF/INDEX.LIST",
        "META-INF/AL2.0",
        "META-INF/LGPL2.1",
        "META-INF/*.SF",
        "META-INF/*.DSA",
        "META-INF/*.RSA",
        "META-INF/versions/*/OSGI-INF/MANIFEST.MF",
        "META-INF/io.netty.versions.properties",
        "protobuf.meta",
        "google/protobuf/*.proto",
        "kotlin/internal/*.kotlin_builtins"
      )
    }
  }

  testOptions { unitTests { isIncludeAndroidResources = true } }

  val sdkDirPath = System.getenv("ANDROID_SDK_ROOT") ?: System.getenv("ANDROID_HOME")
  val hasCmakeAndNdk = sdkDirPath != null &&
    file("$sdkDirPath/cmake").exists() &&
    file("$sdkDirPath/ndk").exists()
  if (hasCmakeAndNdk) {
    externalNativeBuild {
      cmake {
        path = file("src/main/cpp/CMakeLists.txt")
      }
    }
  }

  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

secrets {
  propertiesFileName = ".env"
  defaultPropertiesFileName = ".env.example"
  ignoreList.add("FIREBASE_APPCHECK_DEBUG_TOKEN")
  ignoreList.add("GITHUB_CLIENT_ID")
  ignoreList.add("GITHUB_CLIENT_SECRET")
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.browser)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.lifecycle.process)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.security.crypto)

  // Cryptography, APK Signing, and AAB Bundle Processing
  implementation(libs.bouncycastle.bcprov)
  implementation(libs.bouncycastle.bcpkix)
  implementation(libs.android.apksig)
  implementation(libs.android.bundletool)

  // Networking & Serialization
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation(libs.kotlinx.serialization.json)
  implementation(libs.okhttp)
  implementation(libs.logging.interceptor)

  // Testing
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
}

configurations.matching { it.name.contains("UnitTest", ignoreCase = true) }.configureEach {
  resolutionStrategy.force("com.google.guava:guava:32.0.1-jre")
}
