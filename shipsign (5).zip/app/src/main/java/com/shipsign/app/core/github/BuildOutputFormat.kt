package com.shipsign.app.core.github

enum class BuildOutputFormat(
  val workflowFileName: String,
  val artifactName: String,
  val displayLabel: String,
) {
  APK_ONLY("shipsign-build-apk.yml", "ShipSign-APK", "APK Only"),
  AAB_ONLY("shipsign-build-aab.yml", "ShipSign-AAB", "AAB Only"),
  BOTH("shipsign-build-both.yml", "ShipSign-APK-and-AAB", "APK + AAB"),
}
