package com.shipsign.app.core.github

import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.SourceProjectMetadata

/**
 * Generates exact, framework-targeted GitHub Actions workflows based on on-device
 * [SourceProjectMetadata] detected by [com.shipsign.app.core.engine.ZipInspectorEngine].
 *
 * Container routing on `ghcr.io/zaibixrumi1/shipsign-builder`:
 * - [ProjectFramework.NATIVE_ANDROID], [ProjectFramework.GODOT] -> `:android`
 * - [ProjectFramework.FLUTTER] -> `:flutter`
 * - [ProjectFramework.REACT_NATIVE], [ProjectFramework.CAPACITOR_CORDOVA] -> `:web`
 *
 * Dedicated workflow mapping:
 * - [BuildOutputFormat.APK_ONLY] -> `.github/workflows/shipsign-build-apk.yml` (`ShipSign-APK`)
 * - [BuildOutputFormat.AAB_ONLY] -> `.github/workflows/shipsign-build-aab.yml` (`ShipSign-AAB`)
 * - [BuildOutputFormat.BOTH] -> `.github/workflows/shipsign-build-both.yml` (`ShipSign-APK-and-AAB`)
 *
 * Security Guarantee:
 * - Zero user keystores or signing passwords ever touch GitHub.
 * - Produces unsigned binaries only for offline on-device signing.
 */
object WorkflowTemplateGenerator {

  const val CONTAINER_IMAGE_BASE = "ghcr.io/zaibixrumi1/shipsign-builder"

  fun containerImageFor(framework: ProjectFramework): String =
    "$CONTAINER_IMAGE_BASE:${framework.containerTag}"

  fun workflowPathFor(format: BuildOutputFormat): String =
    ".github/workflows/${format.workflowFileName}"

  fun generateWorkflow(
    metadata: SourceProjectMetadata,
    format: BuildOutputFormat,
  ): String {
    require(metadata.framework != ProjectFramework.UNKNOWN) {
      "Cannot generate GitHub workflow for an unclassified project framework."
    }
    return when (format) {
      BuildOutputFormat.APK_ONLY -> generateApkOnlyWorkflow(metadata)
      BuildOutputFormat.AAB_ONLY -> generateAabOnlyWorkflow(metadata)
      BuildOutputFormat.BOTH -> generateBothWorkflow(metadata)
    }
  }

  fun generateApkOnlyWorkflow(metadata: SourceProjectMetadata): String =
    assembleFrameworkWorkflow(
      metadata = metadata,
      workflowName = "ShipSign Build (${metadata.framework.displayName} · APK)",
      gradleReleaseTasks = "assembleRelease",
      gradleDebugTasks = "assembleDebug",
      flutterPathACmd = "flutter build apk --release --target-platform android-arm64",
      flutterPathBCmd = "flutter build apk --debug --target-platform android-arm64",
      flutterPathCCmd = "flutter build apk --debug",
      godotExportCmd = godotApkExportCommands(),
      artifactName = BuildOutputFormat.APK_ONLY.artifactName,
      artifactPaths = listOf("**/*.apk"),
    )

  fun generateAabOnlyWorkflow(metadata: SourceProjectMetadata): String =
    assembleFrameworkWorkflow(
      metadata = metadata,
      workflowName = "ShipSign Build (${metadata.framework.displayName} · AAB)",
      gradleReleaseTasks = "bundleRelease",
      gradleDebugTasks = "bundleDebug",
      flutterPathACmd = "flutter build appbundle --release",
      flutterPathBCmd = "flutter build appbundle --debug",
      flutterPathCCmd = "flutter build appbundle --debug",
      godotExportCmd = godotAabExportCommands(),
      artifactName = BuildOutputFormat.AAB_ONLY.artifactName,
      artifactPaths = listOf("**/*.aab"),
    )

  fun generateBothWorkflow(metadata: SourceProjectMetadata): String =
    assembleFrameworkWorkflow(
      metadata = metadata,
      workflowName = "ShipSign Build (${metadata.framework.displayName} · APK + AAB)",
      gradleReleaseTasks = "assembleRelease bundleRelease",
      gradleDebugTasks = "assembleDebug bundleDebug",
      flutterPathACmd = "flutter build apk --release --target-platform android-arm64 && flutter build appbundle --release",
      flutterPathBCmd = "flutter build apk --debug --target-platform android-arm64 && flutter build appbundle --debug",
      flutterPathCCmd = "flutter build apk --debug && flutter build appbundle --debug",
      godotExportCmd = godotApkExportCommands() + "\n" + godotAabExportCommands(),
      artifactName = BuildOutputFormat.BOTH.artifactName,
      artifactPaths = listOf("**/*.apk", "**/*.aab"),
    )

  private fun assembleFrameworkWorkflow(
    metadata: SourceProjectMetadata,
    workflowName: String,
    gradleReleaseTasks: String,
    gradleDebugTasks: String,
    flutterPathACmd: String,
    flutterPathBCmd: String,
    flutterPathCCmd: String,
    godotExportCmd: String,
    artifactName: String,
    artifactPaths: List<String>,
  ): String {
    val framework = metadata.framework
    val containerImage = containerImageFor(framework)

    return buildString {
      appendLine("name: $workflowName")
      appendLine("on:")
      appendLine("  workflow_dispatch:")
      appendLine()
      appendLine("jobs:")
      appendLine("  build:")
      appendLine("    runs-on: ubuntu-latest")
      appendLine("    container:")
      appendLine("      image: $containerImage")
      appendLine("    steps:")
      appendLine("      - uses: actions/checkout@v6")
      appendLine()

      when (framework) {
        ProjectFramework.FLUTTER -> {
          append(flutterSelfHealStep())
          appendLine()
          append(flutterBuildCascadeSteps(flutterPathACmd, flutterPathBCmd, flutterPathCCmd))
        }
        ProjectFramework.REACT_NATIVE -> {
          append(webSelfHealStep(isCapacitor = false))
          appendLine()
          append(gradleBuildCascadeSteps(gradleReleaseTasks, gradleDebugTasks))
        }
        ProjectFramework.CAPACITOR_CORDOVA -> {
          append(webSelfHealStep(isCapacitor = true))
          appendLine()
          append(gradleBuildCascadeSteps(gradleReleaseTasks, gradleDebugTasks))
        }
        ProjectFramework.GODOT -> {
          append(godotBuildStep(godotExportCmd))
        }
        ProjectFramework.NATIVE_ANDROID, ProjectFramework.UNKNOWN -> {
          append(nativeAndroidSelfHealStep())
          appendLine()
          append(gradleBuildCascadeSteps(gradleReleaseTasks, gradleDebugTasks))
        }
      }

      appendLine()
      appendLine("      - name: Upload Built Packages")
      appendLine("        uses: actions/upload-artifact@v7")
      appendLine("        with:")
      appendLine("          name: $artifactName")
      if (artifactPaths.size == 1) {
        appendLine("          path: ${artifactPaths.first()}")
      } else {
        appendLine("          path: |")
        artifactPaths.forEach { pattern ->
          appendLine("            $pattern")
        }
      }
    }
  }

  private fun nativeAndroidSelfHealStep(): String = buildString {
    appendLine("      - id: prepare")
    appendLine("        name: Self-Heal Native Android Project")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          SDK_DIR=\"\${ANDROID_HOME:-/opt/android-sdk-linux}\"")
    appendLine("          GRADLE_FILE=\$(find . -maxdepth 4 -not -path '*/.*' \\( -name 'settings.gradle' -o -name 'settings.gradle.kts' -o -name 'build.gradle' -o -name 'build.gradle.kts' \\) | head -n 1)")
    appendLine("          GRADLE_DIR=\".\"")
    appendLine("          if [ -n \"\$GRADLE_FILE\" ]; then")
    appendLine("            GRADLE_DIR=\$(dirname \"\$GRADLE_FILE\")")
    appendLine("            [ \"\$(basename \"\$GRADLE_DIR\")\" = \"app\" ] && GRADLE_DIR=\$(dirname \"\$GRADLE_DIR\")")
    appendLine("          fi")
    appendLine("          ABS_PROJECT_DIR=\$(cd \"\$GRADLE_DIR\" && pwd)")
    appendLine("          echo \"PROJECT_DIR=\$ABS_PROJECT_DIR\" >> \"\$GITHUB_ENV\"")
    appendLine("          echo \"GRADLE_DIR=\$ABS_PROJECT_DIR\" >> \"\$GITHUB_ENV\"")
    appendLine("          cd \"\$ABS_PROJECT_DIR\"")
    append(gradleSelfHealBody())
  }

  private fun flutterSelfHealStep(): String = buildString {
    appendLine("      - id: prepare")
    appendLine("        name: Self-Heal Flutter Project")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          export PATH=\"/opt/flutter/bin:\$PATH\"")
    appendLine("          SDK_DIR=\"\${ANDROID_HOME:-/opt/android-sdk-linux}\"")
    appendLine("          PUBSPEC=\$(find . -maxdepth 4 -not -path '*/.*' -name 'pubspec.yaml' | head -n 1)")
    appendLine("          PROJECT_DIR=\$(dirname \"\${PUBSPEC:-./pubspec.yaml}\")")
    appendLine("          ABS_PROJECT_DIR=\$(cd \"\$PROJECT_DIR\" && pwd)")
    appendLine("          echo \"PROJECT_DIR=\$ABS_PROJECT_DIR\" >> \"\$GITHUB_ENV\"")
    appendLine("          cd \"\$ABS_PROJECT_DIR\"")
    appendLine("          [ -f \".env.example\" ] && [ ! -f \".env\" ] && cp .env.example .env")
    appendLine("          flutter pub get")
    appendLine("          mkdir -p android")
    appendLine("          printf \"sdk.dir=%s\\nflutter.sdk=%s\\n\" \"\$SDK_DIR\" \"\${FLUTTER_HOME:-/opt/flutter}\" > android/local.properties")
    appendLine("          cd \"\$ABS_PROJECT_DIR/android\"")
    append(gradleSelfHealBody(includeLocalProperties = false))
    appendLine("          [ ! -f \"\$ABS_PROJECT_DIR/debug.keystore\" ] && cp debug.keystore \"\$ABS_PROJECT_DIR/debug.keystore\"")
  }

  private fun webSelfHealStep(isCapacitor: Boolean): String = buildString {
    appendLine("      - id: prepare")
    appendLine("        name: Self-Heal ${if (isCapacitor) "Capacitor / Cordova" else "React Native"} Project")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          SDK_DIR=\"\${ANDROID_HOME:-/opt/android-sdk-linux}\"")
    appendLine("          PKG_JSON=\$(find . -maxdepth 4 -not -path '*/.*' -not -path '*/node_modules/*' -name 'package.json' | head -n 1)")
    appendLine("          WEB_DIR=\$(dirname \"\${PKG_JSON:-./package.json}\")")
    appendLine("          cd \"\$WEB_DIR\"")
    appendLine("          [ -f \".env.example\" ] && [ ! -f \".env\" ] && cp .env.example .env")
    appendLine("          npm install --legacy-peer-deps")
    if (isCapacitor) {
      appendLine("          npm run build || true")
      appendLine("          npx cap sync android || true")
    }
    appendLine("          mkdir -p android")
    appendLine("          ABS_PROJECT_DIR=\$(cd android && pwd)")
    appendLine("          echo \"PROJECT_DIR=\$ABS_PROJECT_DIR\" >> \"\$GITHUB_ENV\"")
    appendLine("          echo \"GRADLE_DIR=\$ABS_PROJECT_DIR\" >> \"\$GITHUB_ENV\"")
    appendLine("          cd \"\$ABS_PROJECT_DIR\"")
    append(gradleSelfHealBody())
  }

  private fun gradleSelfHealBody(
    includeLocalProperties: Boolean = true,
  ): String = buildString {
    val indent = "          "
    appendLine("${indent}[ -f \".env.example\" ] && [ ! -f \".env\" ] && cp .env.example .env")
    if (includeLocalProperties) {
      appendLine("${indent}printf \"sdk.dir=%s\\n\" \"\$SDK_DIR\" > local.properties")
    }
    appendLine("${indent}if [ ! -f \"debug.keystore\" ]; then")
    appendLine("${indent}  keytool -genkeypair -v -keystore debug.keystore -storetype JKS \\")
    appendLine("${indent}    -keyalg RSA -keysize 2048 -validity 10000 \\")
    appendLine("${indent}    -alias androiddebugkey -storepass android -keypass android \\")
    appendLine("${indent}    -dname \"CN=Android Debug,O=Android,C=US\" >/dev/null 2>&1")
    appendLine("${indent}fi")
    appendLine("${indent}if grep -rq \"google-services\" . 2>/dev/null && [ ! -f \"app/google-services.json\" ] && [ -d \"app\" ]; then")
    appendLine("${indent}  APP_ID=\$(grep -oE 'applicationId\\s*=?\\s*\"[^\"]+\"' app/build.gradle* 2>/dev/null | head -n 1 | cut -d'\"' -f2)")
    appendLine("${indent}  APP_ID=\${APP_ID:-com.shipsign.placeholder}")
    appendLine("${indent}  cat << EOF > app/google-services.json")
    appendLine("${indent}{")
    appendLine("${indent}  \"project_info\": { \"project_number\": \"100000000000\", \"project_id\": \"shipsign-ci\", \"storage_bucket\": \"shipsign-ci.appspot.com\" },")
    appendLine("${indent}  \"client\": [{ \"client_info\": { \"mobilesdk_app_id\": \"1:100000000000:android:0000000000000000\", \"android_client_info\": { \"package_name\": \"\$APP_ID\" } }, \"oauth_client\": [], \"api_key\": [{ \"current_key\": \"AIzaSyDummyKeyForCiCompilationOnly00000\" }] }]")
    appendLine("${indent}}")
    appendLine("${indent}EOF")
    appendLine("${indent}fi")
    appendLine("${indent}if [ -f \"./gradlew\" ]; then")
    appendLine("${indent}  sed -i 's/\\r\$//' gradlew && chmod +x gradlew")
    appendLine("${indent}  echo \"GRADLE_BIN=./gradlew\" >> \"\$GITHUB_ENV\"")
    appendLine("${indent}else")
    appendLine("${indent}  echo \"GRADLE_BIN=gradle\" >> \"\$GITHUB_ENV\"")
    appendLine("${indent}fi")
    appendLine("${indent}cat << 'EOF' > /tmp/shipsign-init.gradle")
    appendLine("${indent}allprojects {")
    appendLine("${indent}    afterEvaluate { project ->")
    appendLine("${indent}        if (project.extensions.findByName(\"android\") != null) {")
    appendLine("${indent}            def androidExt = project.extensions.getByName(\"android\")")
    appendLine("${indent}            androidExt.signingConfigs.all { sc ->")
    appendLine("${indent}                if (sc.storeFile == null || !sc.storeFile.exists()) {")
    appendLine("${indent}                    sc.storeFile = new File(\"\${System.getenv('PROJECT_DIR')}/debug.keystore\")")
    appendLine("${indent}                    sc.storePassword = \"android\"")
    appendLine("${indent}                    sc.keyAlias = \"androiddebugkey\"")
    appendLine("${indent}                    sc.keyPassword = \"android\"")
    appendLine("${indent}                }")
    appendLine("${indent}            }")
    appendLine("${indent}            try {")
    appendLine("${indent}                androidExt.lint.checkReleaseBuilds = false")
    appendLine("${indent}                androidExt.lint.abortOnError = false")
    appendLine("${indent}            } catch (Exception ignored) {}")
    appendLine("${indent}        }")
    appendLine("${indent}    }")
    appendLine("${indent}}")
    appendLine("${indent}EOF")
  }

  private fun gradleBuildCascadeSteps(
    gradleReleaseTasks: String,
    gradleDebugTasks: String,
  ): String = buildString {
    appendLine("      - id: path_a")
    appendLine("        name: Build Path A — Fast ARM64 Release")
    appendLine("        continue-on-error: true")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          cd \"\$GRADLE_DIR\"")
    appendLine("          \$GRADLE_BIN $gradleReleaseTasks --init-script /tmp/shipsign-init.gradle -Pandroid.injected.build.abi=arm64-v8a -x lint -x lintVitalRelease -x lintVitalAnalyzeRelease -x test --build-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\"")
    appendLine()
    appendLine("      - id: path_b")
    appendLine("        name: Build Path B — Fallback ARM64 Debug")
    appendLine("        if: steps.path_a.outcome != 'success'")
    appendLine("        continue-on-error: true")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          cd \"\$GRADLE_DIR\"")
    appendLine("          \$GRADLE_BIN $gradleDebugTasks --init-script /tmp/shipsign-init.gradle -Pandroid.injected.build.abi=arm64-v8a -x lint -x test --build-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\"")
    appendLine()
    appendLine("      - id: path_c")
    appendLine("        name: Build Path C — Universal ABI Fallback")
    appendLine("        if: steps.path_a.outcome != 'success' && steps.path_b.outcome != 'success'")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          cd \"\$GRADLE_DIR\"")
    appendLine("          \$GRADLE_BIN $gradleDebugTasks --init-script /tmp/shipsign-init.gradle -x lint -x test --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\"")
  }

  private fun flutterBuildCascadeSteps(
    flutterPathACmd: String,
    flutterPathBCmd: String,
    flutterPathCCmd: String,
  ): String = buildString {
    appendLine("      - id: path_a")
    appendLine("        name: Build Path A — Fast ARM64 Release")
    appendLine("        continue-on-error: true")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          export PATH=\"/opt/flutter/bin:\$PATH\"")
    appendLine("          cd \"\$PROJECT_DIR\"")
    appendLine("          $flutterPathACmd")
    appendLine()
    appendLine("      - id: path_b")
    appendLine("        name: Build Path B — Fallback ARM64 Debug")
    appendLine("        if: steps.path_a.outcome != 'success'")
    appendLine("        continue-on-error: true")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          export PATH=\"/opt/flutter/bin:\$PATH\"")
    appendLine("          cd \"\$PROJECT_DIR\"")
    appendLine("          $flutterPathBCmd")
    appendLine()
    appendLine("      - id: path_c")
    appendLine("        name: Build Path C — Universal ABI Fallback")
    appendLine("        if: steps.path_a.outcome != 'success' && steps.path_b.outcome != 'success'")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          export PATH=\"/opt/flutter/bin:\$PATH\"")
    appendLine("          cd \"\$PROJECT_DIR\"")
    appendLine("          $flutterPathCCmd")
  }

  private fun godotBuildStep(exportCommands: String): String = buildString {
    appendLine("      - id: path_a")
    appendLine("        name: Build Godot Android Package")
    appendLine("        run: |")
    appendLine("          set -e")
    appendLine("          GODOT_FILE=\$(find . -maxdepth 4 -not -path '*/.*' -name 'project.godot' | head -n 1)")
    appendLine("          PROJECT_DIR=\$(dirname \"\${GODOT_FILE:-./project.godot}\")")
    appendLine("          cd \"\$PROJECT_DIR\"")
    appendLine("          [ -f \".env.example\" ] && [ ! -f \".env\" ] && cp .env.example .env")
    appendLine("          printf \"sdk.dir=%s\\n\" \"\${ANDROID_HOME:-/opt/android-sdk-linux}\" > local.properties")
    appendLine("          if [ ! -f \"debug.keystore\" ]; then")
    appendLine("            keytool -genkeypair -v -keystore debug.keystore -storetype JKS \\")
    appendLine("              -keyalg RSA -keysize 2048 -validity 10000 \\")
    appendLine("              -alias androiddebugkey -storepass android -keypass android \\")
    appendLine("              -dname \"CN=Android Debug,O=Android,C=US\" >/dev/null 2>&1")
    appendLine("          fi")
    appendLine("          if [ ! -f \"export_presets.cfg\" ]; then")
    appendLine("            cat << 'EOF' > export_presets.cfg")
    appendLine("          [preset.0]")
    appendLine("          name=\"Android\"")
    appendLine("          platform=\"Android\"")
    appendLine("          runnable=true")
    appendLine("          export_filter=\"all_resources\"")
    appendLine("          [preset.0.options]")
    appendLine("          architectures/arm64-v8a=true")
    appendLine("          architectures/armeabi-v7a=true")
    appendLine("          package/unique_name=\"com.shipsign.godotapp\"")
    appendLine("          package/export_format=0")
    appendLine("          EOF")
    appendLine("          fi")
    appendLine("          set_godot_export_format() {")
    appendLine("            if grep -q '^package/export_format=' export_presets.cfg; then")
    appendLine("              sed -i \"s|^package/export_format=.*|package/export_format=\$1|\" export_presets.cfg")
    appendLine("            else")
    appendLine("              printf \"\\npackage/export_format=%s\\n\" \"\$1\" >> export_presets.cfg")
    appendLine("            fi")
    appendLine("          }")
    appendLine(exportCommands)
  }

  private fun godotApkExportCommands(): String = buildString {
    appendLine("          mkdir -p build/outputs/apk/release")
    appendLine("          set_godot_export_format 0")
    append("          godot --headless --export-release \"Android\" build/outputs/apk/release/app-release-unsigned.apk")
  }

  private fun godotAabExportCommands(): String = buildString {
    appendLine("          mkdir -p build/outputs/bundle/release")
    appendLine("          set_godot_export_format 1")
    append("          godot --headless --export-release \"Android\" build/outputs/bundle/release/app-release.aab")
  }
}
