package com.shipsign.app.ui

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.shipsign.app.core.engine.ErrorTranslator
import com.shipsign.app.core.engine.KeystoreGenerator
import com.shipsign.app.core.engine.SignatureScanner
import com.shipsign.app.core.engine.SigningEngine
import com.shipsign.app.core.engine.SigningProgressEvent
import com.shipsign.app.core.engine.TranslatedError
import com.shipsign.app.core.engine.ZipInspectorEngine
import com.shipsign.app.core.github.BuildOutputFormat
import com.shipsign.app.core.github.CloudBuildStage
import com.shipsign.app.core.github.CloudBuildState
import com.shipsign.app.core.github.GitHubBuildModule
import com.shipsign.app.core.github.GitHubOAuthManager
import com.shipsign.app.core.security.AppPreferences
import com.shipsign.app.core.security.KeystoreDetector
import com.shipsign.app.core.security.ZeroTraceAuditResult
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.core.security.ZeroTraceSnapshot
import com.shipsign.app.core.storage.SafFileBridge
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ImportedKeystoreConfig
import com.shipsign.app.domain.model.InputCategory
import com.shipsign.app.domain.model.InputKind
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.domain.model.SigningOptions
import com.shipsign.app.domain.model.SigningResult
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.File
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.Security
import java.util.Locale

data class SecurityProviderInfo(
  val slot: Int,
  val name: String,
  val version: String,
  val info: String,
  val isBouncyCastle: Boolean,
)

data class CryptoDiagnosticsState(
  val bouncyCastleSlot: Int = -1,
  val bouncyCastleVersion: String = "",
  val providers: List<SecurityProviderInfo> = emptyList(),
  val selfTestPassed: Boolean? = null,
  val isTesting: Boolean = false,
)

data class InspectorUiState(
  val selectedCategory: InputCategory = InputCategory.BUILT_APK,
  val selectedOutputFormat: BuildOutputFormat = BuildOutputFormat.APK_ONLY,
  val targetFile: AppTargetFile? = null,
  val availableBuildTargets: List<AppTargetFile> = emptyList(),
  val pendingAdvanceToKeystore: Boolean = false,
  val isProcessing: Boolean = false,
  val signatureJustStripped: Boolean = false,
  val lastExportedFileName: String? = null,
  val errorMessage: String? = null,
)

data class VerifiedKeystoreSummary(
  val format: KeystoreFormat,
  val alias: String,
  val subjectDn: String,
  val sha256Fingerprint: String,
)

data class KeystoreStudioUiState(
  val tempKeystoreFile: File? = null,
  val importedFileName: String? = null,
  val detectedFormat: KeystoreFormat = KeystoreFormat.UNKNOWN,
  val verifiedSummary: VerifiedKeystoreSummary? = null,
  val hasUnlockedCredentials: Boolean = false,
  val generatedKeystoreFile: File? = null,
  val generatedFileName: String? = null,
  val generatedFormat: KeystoreFormat? = null,
  val generatedDownloaded: Boolean = false,
  val isBusy: Boolean = false,
  val errorMessage: String? = null,
)

data class SigningStudioUiState(
  val options: SigningOptions = SigningOptions(),
  val isSigning: Boolean = false,
  val logs: List<String> = emptyList(),
  val result: SigningResult? = null,
  val translatedError: TranslatedError? = null,
)

data class CloudBuildUiState(
  val isConnected: Boolean = false,
  val isAuthorizing: Boolean = false,
  val connectedUsername: String? = null,
  val connectedAvatarUrl: String? = null,
  val installationId: String? = null,
  val isActive: Boolean = false,
  val currentStage: CloudBuildStage? = null,
  val statusText: String = "",
  val elapsedSeconds: Int = 0,
  val buildState: CloudBuildState = CloudBuildState.Idle,
  val needsRepoAccessGrant: Boolean = false,
  val repoAccessMessage: String? = null,
  val translatedError: TranslatedError? = null,
)

data class FoundationUiState(
  val hasAcceptedGitHubDisclosure: Boolean = false,
  val showGitHubDisclosureDialog: Boolean = false,
  val wipeTimeoutSec: Int = AppPreferences.DEFAULT_WIPE_TIMEOUT_SEC,
  val lastAuditResult: ZeroTraceAuditResult? = null,
  val isAuditing: Boolean = false,
  val cryptoDiagnostics: CryptoDiagnosticsState = CryptoDiagnosticsState(),
  val inspector: InspectorUiState = InspectorUiState(),
  val keystoreStudio: KeystoreStudioUiState = KeystoreStudioUiState(),
  val signingStudio: SigningStudioUiState = SigningStudioUiState(),
  val cloudBuild: CloudBuildUiState = CloudBuildUiState(),
)

class ShipSignViewModel(application: Application) : AndroidViewModel(application) {

  val zeroTraceSnapshot: StateFlow<ZeroTraceSnapshot> = ZeroTraceManager.snapshot

  private val _uiState = MutableStateFlow(
    buildInitialState(application)
  )
  val uiState: StateFlow<FoundationUiState> = _uiState.asStateFlow()

  @Volatile private var activeStorePassChars: CharArray? = null
  @Volatile private var activeKeyPassChars: CharArray? = null
  @Volatile private var activeKeyAlias: String? = null
  @Volatile private var generatedStorePassChars: CharArray? = null
  @Volatile private var generatedKeyPassChars: CharArray? = null
  @Volatile private var generatedKeyAlias: String? = null

  private var cloudBuildJob: Job? = null
  private var elapsedTimerJob: Job? = null

  init {
    ZeroTraceManager.createOrGetSessionDir(application)
    refreshCryptoProviders()
  }

  private fun buildInitialState(application: Application): FoundationUiState {
    val storedSession = GitHubOAuthManager.getSavedSession(application)
    return FoundationUiState(
      hasAcceptedGitHubDisclosure = AppPreferences.hasAcceptedGitHubDisclosure(application),
      wipeTimeoutSec = AppPreferences.getBackgroundWipeTimeoutSec(application),
      cloudBuild = if (storedSession != null) {
        CloudBuildUiState(
          isConnected = true,
          connectedUsername = storedSession.username,
          connectedAvatarUrl = storedSession.avatarUrl,
          installationId = storedSession.installationId,
        )
      } else {
        CloudBuildUiState()
      },
    )
  }

  override fun onCleared() {
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    wipeActiveSigningCredentials()
    wipeGeneratedCredentials()
    super.onCleared()
  }

  // --- Step 1: Input Selection, Deep Inspection & Signature Scanner ---

  fun selectInputCategory(category: InputCategory) {
    _uiState.update { it.copy(inspector = it.inspector.copy(selectedCategory = category)) }
  }

  fun selectOutputFormat(format: BuildOutputFormat) {
    _uiState.update { it.copy(inspector = it.inspector.copy(selectedOutputFormat = format)) }
  }

  fun selectActiveBuildTarget(target: AppTargetFile) {
    _uiState.update { state ->
      if (state.signingStudio.isSigning) return@update state
      state.copy(
        inspector = state.inspector.copy(targetFile = target),
        signingStudio = state.signingStudio.copy(
          translatedError = null,
          logs = emptyList(),
        ),
      )
    }
  }

  fun consumePendingAdvanceToKeystore() {
    _uiState.update { it.copy(inspector = it.inspector.copy(pendingAdvanceToKeystore = false)) }
  }

  fun inspectPickedUri(uri: Uri) {
    if (_uiState.value.inspector.isProcessing) return
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    _uiState.update {
      it.copy(
        inspector = it.inspector.copy(
          isProcessing = true,
          pendingAdvanceToKeystore = false,
          signatureJustStripped = false,
          lastExportedFileName = null,
          errorMessage = null,
        ),
        signingStudio = it.signingStudio.copy(
          result = null,
          logs = emptyList(),
          translatedError = null,
        ),
        cloudBuild = it.cloudBuild.copy(
          isActive = false,
          currentStage = null,
          statusText = "",
          elapsedSeconds = 0,
          buildState = CloudBuildState.Idle,
          needsRepoAccessGrant = false,
          translatedError = null,
        ),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      runCatching {
        deleteInspectorFiles(_uiState.value.inspector)
        ZipInspectorEngine.inspectUri(appCtx, uri)
      }.onSuccess { resolved ->
        val inferredCategory = when (resolved.binaryType) {
          ResolvedBinaryType.APK -> InputCategory.BUILT_APK
          ResolvedBinaryType.AAB -> InputCategory.PLAY_STORE_AAB
          ResolvedBinaryType.SOURCE_CODE_PROJECT -> InputCategory.STUDIO_SOURCE_ZIP
          ResolvedBinaryType.INVALID -> _uiState.value.inspector.selectedCategory
        }
        val isCleanPrebuilt = resolved.inputKind == InputKind.PREBUILT_PACKAGE && !resolved.isAlreadySigned
        _uiState.update {
          it.copy(
            inspector = it.inspector.copy(
              selectedCategory = inferredCategory,
              targetFile = if (resolved.inputKind == InputKind.INVALID) null else resolved,
              availableBuildTargets = if (resolved.inputKind == InputKind.PREBUILT_PACKAGE) {
                listOf(resolved)
              } else {
                emptyList()
              },
              pendingAdvanceToKeystore = isCleanPrebuilt,
              isProcessing = false,
              errorMessage = if (resolved.inputKind == InputKind.INVALID) {
                "Unsupported archive. No APK, AAB, Android, Flutter, React Native, Capacitor, or Godot project found."
              } else {
                null
              },
            )
          )
        }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            inspector = it.inspector.copy(
              targetFile = null,
              availableBuildTargets = emptyList(),
              pendingAdvanceToKeystore = false,
              isProcessing = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun stripTargetSignature() {
    val currentTarget = _uiState.value.inspector.targetFile ?: return
    if (_uiState.value.inspector.isProcessing) return
    if (currentTarget.binaryType != ResolvedBinaryType.APK &&
      currentTarget.binaryType != ResolvedBinaryType.AAB
    ) {
      return
    }

    _uiState.update {
      it.copy(
        inspector = it.inspector.copy(
          isProcessing = true,
          errorMessage = null,
          lastExportedFileName = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val suffix = if (currentTarget.binaryType == ResolvedBinaryType.AAB) ".aab" else ".apk"
      val cleanOut: File = ZeroTraceManager.allocateTempFile(appCtx, "unsigned", suffix)

      runCatching {
        SignatureScanner.stripExistingSignature(currentTarget.sessionFile, cleanOut)
        ZeroTraceManager.secureDeleteFile(currentTarget.sessionFile)
        val stillSigned = SignatureScanner.hasExistingSignature(cleanOut)
        currentTarget.copy(
          sessionFile = cleanOut,
          sizeBytes = cleanOut.length(),
          isAlreadySigned = stillSigned,
        )
      }.onSuccess { updatedTarget ->
        _uiState.update {
          val updatedList = it.inspector.availableBuildTargets.map { candidate ->
            if (candidate.sessionFile == currentTarget.sessionFile) updatedTarget else candidate
          }
          it.copy(
            inspector = it.inspector.copy(
              targetFile = updatedTarget,
              availableBuildTargets = updatedList,
              isProcessing = false,
              signatureJustStripped = !updatedTarget.isAlreadySigned,
            )
          )
        }
      }.onFailure { err ->
        ZeroTraceManager.secureDeleteFile(cleanOut)
        _uiState.update {
          it.copy(
            inspector = it.inspector.copy(
              isProcessing = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun clearInspectedTarget() {
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    viewModelScope.launch(Dispatchers.IO) {
      deleteInspectorFiles(_uiState.value.inspector)
      _uiState.update {
        it.copy(
          inspector = InspectorUiState(
            selectedCategory = it.inspector.selectedCategory,
            selectedOutputFormat = it.inspector.selectedOutputFormat,
          ),
          signingStudio = SigningStudioUiState(options = it.signingStudio.options),
          cloudBuild = it.cloudBuild.copy(
            isActive = false,
            currentStage = null,
            statusText = "",
            elapsedSeconds = 0,
            buildState = CloudBuildState.Idle,
            needsRepoAccessGrant = false,
            translatedError = null,
          ),
        )
      }
    }
  }

  // --- Step 1B: Verified GitHub App OAuth (PKCE S256) & Ephemeral Cloud Build ---

  fun requestGitHubConnect(activityContext: Context) {
    if (_uiState.value.hasAcceptedGitHubDisclosure) {
      connectGitHub(activityContext)
    } else {
      _uiState.update { it.copy(showGitHubDisclosureDialog = true) }
    }
  }

  fun acceptGitHubDisclosureAndConnect(activityContext: Context) {
    AppPreferences.markGitHubDisclosureAccepted(getApplication())
    _uiState.update {
      it.copy(
        hasAcceptedGitHubDisclosure = true,
        showGitHubDisclosureDialog = false,
      )
    }
    connectGitHub(activityContext)
  }

  fun dismissGitHubDisclosure() {
    _uiState.update { it.copy(showGitHubDisclosureDialog = false) }
  }

  fun connectGitHub(context: Context) {
    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isAuthorizing = true,
          needsRepoAccessGrant = false,
          translatedError = null,
        )
      )
    }
    GitHubOAuthManager.startOAuthFlow(context)
  }

  fun onGitHubCallback(uri: Uri) {
    if (!GitHubOAuthManager.isGitHubCallbackUri(uri)) return

    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isAuthorizing = true,
          translatedError = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val result = GitHubOAuthManager.handleAuthCallback(context = appCtx, uri = uri)
      result.onSuccess { session ->
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isConnected = true,
              isAuthorizing = false,
              connectedUsername = session.username,
              connectedAvatarUrl = session.avatarUrl,
              installationId = session.installationId,
              needsRepoAccessGrant = false,
              translatedError = null,
            )
          )
        }
      }.onFailure { err ->
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isAuthorizing = false,
              translatedError = ErrorTranslator.translate(err),
            )
          )
        }
      }
    }
  }

  fun handleOAuthCallbackUri(uri: Uri) = onGitHubCallback(uri)

  fun disconnectGitHub() {
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    cloudBuildJob = null
    GitHubOAuthManager.disconnect(getApplication())
    _uiState.update { state ->
      state.copy(cloudBuild = CloudBuildUiState())
    }
  }

  fun startCloudBuild() = startGitHubCloudBuild()

  fun startGitHubCloudBuild() {
    val sourceProject = _uiState.value.inspector.targetFile
    val metadata = sourceProject?.sourceMetadata
    if (sourceProject == null ||
      sourceProject.inputKind != InputKind.SOURCE_ARCHIVE ||
      metadata == null ||
      metadata.framework == ProjectFramework.UNKNOWN
    ) {
      _uiState.update { state ->
        state.copy(
          cloudBuild = state.cloudBuild.copy(
            translatedError = TranslatedError(
              title = "Unrecognized Project",
              message = "Select a valid Android, Flutter, React Native, Capacitor, or Godot source .zip before building.",
            )
          )
        )
      }
      return
    }
    if (_uiState.value.cloudBuild.isActive) return

    val appCtx = getApplication<Application>()
    val session = GitHubOAuthManager.getSavedSession(appCtx)
    if (session == null) {
      _uiState.update { state ->
        state.copy(
          cloudBuild = state.cloudBuild.copy(
            isConnected = false,
            connectedUsername = null,
            translatedError = TranslatedError(
              title = "GitHub Not Connected",
              message = "Connect GitHub before starting a cloud build.",
            ),
          )
        )
      }
      return
    }

    val targetFormat = _uiState.value.inspector.selectedOutputFormat
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()

    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isActive = true,
          currentStage = CloudBuildStage.PREPARING_ARCHIVE,
          statusText = CloudBuildStage.PREPARING_ARCHIVE.label,
          elapsedSeconds = 0,
          buildState = CloudBuildState.Idle,
          needsRepoAccessGrant = false,
          repoAccessMessage = null,
          translatedError = null,
        )
      )
    }

    val startMs = System.currentTimeMillis()
    elapsedTimerJob = viewModelScope.launch {
      while (isActive) {
        delay(1_000L)
        val sec = ((System.currentTimeMillis() - startMs) / 1_000L).toInt()
        _uiState.update { state ->
          if (state.cloudBuild.isActive) {
            state.copy(cloudBuild = state.cloudBuild.copy(elapsedSeconds = sec))
          } else {
            state
          }
        }
      }
    }

    cloudBuildJob = viewModelScope.launch(Dispatchers.IO) {
      val tokenChars = session.accessToken.toCharArray()
      try {
        GitHubBuildModule.buildUnsignedBinary(
          context = appCtx,
          sourceProject = sourceProject,
          token = tokenChars,
          targetFormat = targetFormat,
          wipeTokenOnCompletion = true,
        ).collect { buildState ->
          handleCloudBuildState(buildState, previousSourceFile = sourceProject.sessionFile)
        }
      } catch (e: CancellationException) {
        throw e
      } catch (e: Exception) {
        elapsedTimerJob?.cancel()
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = false,
              buildState = CloudBuildState.Failed(e),
              translatedError = ErrorTranslator.translate(e),
            )
          )
        }
      } finally {
        elapsedTimerJob?.cancel()
        ZeroTraceManager.wipeCharArray(tokenChars)
      }
    }
  }

  private fun handleCloudBuildState(
    buildState: CloudBuildState,
    previousSourceFile: File?,
  ) {
    when (buildState) {
      is CloudBuildState.StageProgress -> {
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = true,
              currentStage = buildState.stage,
              statusText = buildState.statusText,
              buildState = buildState,
            )
          )
        }
      }
      is CloudBuildState.RepositoryAccessRequired -> {
        elapsedTimerJob?.cancel()
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = false,
              buildState = buildState,
              needsRepoAccessGrant = true,
              repoAccessMessage = buildState.message,
              translatedError = null,
            )
          )
        }
      }
      is CloudBuildState.ReadyForOfflineSigning -> {
        elapsedTimerJob?.cancel()
        val retainedFiles = buildState.availableTargets.map { it.sessionFile }.toSet()
        if (previousSourceFile != null && previousSourceFile !in retainedFiles) {
          ZeroTraceManager.secureDeleteFile(previousSourceFile)
        }
        _uiState.update { state ->
          state.copy(
            inspector = state.inspector.copy(
              targetFile = buildState.targetFile,
              availableBuildTargets = buildState.availableTargets,
              signatureJustStripped = false,
              errorMessage = null,
            ),
            cloudBuild = state.cloudBuild.copy(
              isActive = false,
              currentStage = null,
              statusText = "",
              buildState = buildState,
              translatedError = null,
            ),
          )
        }
      }
      is CloudBuildState.Failed -> {
        elapsedTimerJob?.cancel()
        _uiState.update { state ->
          state.copy(
            cloudBuild = state.cloudBuild.copy(
              isActive = false,
              needsRepoAccessGrant = false,
              buildState = buildState,
              translatedError = ErrorTranslator.translate(buildState.error),
            )
          )
        }
      }
      CloudBuildState.Idle -> Unit
    }
  }

  fun cancelCloudBuild() {
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    cloudBuildJob = null
    _uiState.update { state ->
      state.copy(
        cloudBuild = state.cloudBuild.copy(
          isActive = false,
          currentStage = null,
          statusText = "",
          elapsedSeconds = 0,
          buildState = CloudBuildState.Idle,
          needsRepoAccessGrant = false,
          translatedError = null,
        )
      )
    }
  }

  // --- Step 2A: Import Existing Keystore & 1-Tap Ephemeral Debug Key ---

  fun importKeystoreUri(uri: Uri) {
    if (_uiState.value.keystoreStudio.isBusy) return
    wipeActiveSigningCredentials()
    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          isBusy = true,
          verifiedSummary = null,
          hasUnlockedCredentials = false,
          errorMessage = null,
        ),
        signingStudio = it.signingStudio.copy(translatedError = null),
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      _uiState.value.keystoreStudio.tempKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }

      runCatching {
        val sessionDir = ZeroTraceManager.createOrGetSessionDir(appCtx)
        val copied = SafFileBridge.copyUriToSession(appCtx, uri, sessionDir)
        val detected = KeystoreDetector.detectFormat(copied.file)
        copied to detected
      }.onSuccess { (copied, detected) ->
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              tempKeystoreFile = copied.file,
              importedFileName = copied.displayName,
              detectedFormat = detected,
              isBusy = false,
            )
          )
        }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              tempKeystoreFile = null,
              importedFileName = null,
              detectedFormat = KeystoreFormat.UNKNOWN,
              isBusy = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun verifyImportedKeystore(
    storePassword: CharArray,
    keyAlias: String,
    keyPassword: CharArray,
    onVerifiedSuccess: () -> Unit = {},
  ) {
    val studio = _uiState.value.keystoreStudio
    val tempFile = studio.tempKeystoreFile
    if (tempFile == null || studio.isBusy) {
      ZeroTraceManager.wipeCharArray(storePassword)
      ZeroTraceManager.wipeCharArray(keyPassword)
      return
    }

    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          isBusy = true,
          verifiedSummary = null,
          hasUnlockedCredentials = false,
          errorMessage = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val storeCopyForSession = storePassword.copyOf()
      val rawKeyCopy = if (keyPassword.isEmpty()) storePassword.copyOf() else keyPassword.copyOf()
      val trimmedAlias = keyAlias.trim()

      val config = ImportedKeystoreConfig(
        tempKeystoreFile = tempFile,
        detectedFormat = studio.detectedFormat,
        storePassword = storePassword,
        keyAlias = trimmedAlias,
        keyPassword = if (keyPassword.isEmpty()) storePassword.copyOf() else keyPassword,
      )

      try {
        val validated = KeystoreDetector.validateKeystoreCredentials(config)
        val leafCert = validated.certificateChain.first()
        val sha256 = MessageDigest.getInstance("SHA-256").digest(leafCert.encoded)
        val fingerprint = sha256.joinToString(":") { b -> String.format(Locale.US, "%02X", b) }
        ZeroTraceManager.wipeByteArray(sha256)

        wipeActiveSigningCredentials()
        activeStorePassChars = storeCopyForSession
        activeKeyPassChars = rawKeyCopy
        activeKeyAlias = validated.alias

        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              hasUnlockedCredentials = true,
              verifiedSummary = VerifiedKeystoreSummary(
                format = validated.format,
                alias = validated.alias,
                subjectDn = leafCert.subjectX500Principal.name,
                sha256Fingerprint = fingerprint,
              ),
            )
          )
        }
        viewModelScope.launch(Dispatchers.Main) {
          onVerifiedSuccess()
        }
      } catch (e: Exception) {
        ZeroTraceManager.wipeCharArray(storeCopyForSession)
        ZeroTraceManager.wipeCharArray(rawKeyCopy)
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              verifiedSummary = null,
              hasUnlockedCredentials = false,
              errorMessage = ErrorTranslator.translate(e).message,
            )
          )
        }
      } finally {
        ZeroTraceManager.wipeCharArray(storePassword)
        ZeroTraceManager.wipeCharArray(keyPassword)
        ZeroTraceManager.wipeCharArray(config.keyPassword)
      }
    }
  }

  /**
   * Generates a 1-tap offline ephemeral Android Debug Keystore (`androiddebugkey` / `android`)
   * inside the Zero-Trace sandbox for fast local test-signing without leaving any key on disk.
   */
  fun activateEphemeralDebugKeystore(onReady: () -> Unit = {}) {
    if (_uiState.value.keystoreStudio.isBusy) return
    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          isBusy = true,
          errorMessage = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val sessionDir = ZeroTraceManager.createOrGetSessionDir(appCtx)
      _uiState.value.keystoreStudio.tempKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }

      val storePass = "android".toCharArray()
      val keyPass = "android".toCharArray()
      var debugFile: File? = null
      try {
        debugFile = KeystoreGenerator.generateKeystore(
          request = KeystoreCreateRequest(
            format = KeystoreFormat.PKCS12,
            fileName = "ephemeral_debug",
            storePassword = storePass.copyOf(),
            keyAlias = "androiddebugkey",
            keyPassword = keyPass.copyOf(),
            validityDays = 365,
            commonName = "Android Debug",
            organizationalUnit = "ShipSign Ephemeral",
            organization = "Android",
            cityLocality = "",
            stateProvince = "",
            countryCode = "US",
          ),
          sessionDir = sessionDir,
        )

        val validated = KeystoreDetector.validateKeystoreCredentials(
          ImportedKeystoreConfig(
            tempKeystoreFile = debugFile,
            detectedFormat = KeystoreFormat.PKCS12,
            storePassword = storePass.copyOf(),
            keyAlias = "androiddebugkey",
            keyPassword = keyPass.copyOf(),
          )
        )
        val leafCert = validated.certificateChain.first()
        val sha256 = MessageDigest.getInstance("SHA-256").digest(leafCert.encoded)
        val fingerprint = sha256.joinToString(":") { b -> String.format(Locale.US, "%02X", b) }
        ZeroTraceManager.wipeByteArray(sha256)

        wipeActiveSigningCredentials()
        activeStorePassChars = storePass.copyOf()
        activeKeyPassChars = keyPass.copyOf()
        activeKeyAlias = validated.alias

        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              tempKeystoreFile = debugFile,
              importedFileName = debugFile.name,
              detectedFormat = KeystoreFormat.PKCS12,
              isBusy = false,
              hasUnlockedCredentials = true,
              verifiedSummary = VerifiedKeystoreSummary(
                format = KeystoreFormat.PKCS12,
                alias = validated.alias,
                subjectDn = leafCert.subjectX500Principal.name,
                sha256Fingerprint = fingerprint,
              ),
            )
          )
        }
        viewModelScope.launch(Dispatchers.Main) {
          onReady()
        }
      } catch (e: Exception) {
        debugFile?.let { ZeroTraceManager.secureDeleteFile(it) }
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(e).message,
            )
          )
        }
      } finally {
        ZeroTraceManager.wipeCharArray(storePass)
        ZeroTraceManager.wipeCharArray(keyPass)
      }
    }
  }

  // --- Step 2B: Create New Keystore ---

  fun generateKeystoreInSession(
    request: KeystoreCreateRequest,
    onGenerated: () -> Unit = {},
  ) {
    if (_uiState.value.keystoreStudio.isBusy) {
      ZeroTraceManager.wipeCharArray(request.storePassword)
      ZeroTraceManager.wipeCharArray(request.keyPassword)
      return
    }

    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          isBusy = true,
          generatedFileName = null,
          generatedFormat = null,
          generatedDownloaded = false,
          errorMessage = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val sessionDir = ZeroTraceManager.createOrGetSessionDir(appCtx)
      _uiState.value.keystoreStudio.generatedKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      wipeGeneratedCredentials()

      val storePassForSession = request.storePassword.copyOf()
      val keyPassForSession = if (request.keyPassword.isEmpty()) {
        request.storePassword.copyOf()
      } else {
        request.keyPassword.copyOf()
      }
      val aliasForSession = request.keyAlias.trim().lowercase(Locale.ROOT)
      var generatedFile: File? = null

      try {
        generatedFile = KeystoreGenerator.generateKeystore(request, sessionDir)
        generatedStorePassChars = storePassForSession
        generatedKeyPassChars = keyPassForSession
        generatedKeyAlias = aliasForSession

        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              generatedKeystoreFile = generatedFile,
              generatedFileName = generatedFile.name,
              generatedFormat = request.format,
              generatedDownloaded = false,
            )
          )
        }
        viewModelScope.launch(Dispatchers.Main) {
          onGenerated()
        }
      } catch (e: Exception) {
        generatedFile?.let { ZeroTraceManager.secureDeleteFile(it) }
        ZeroTraceManager.wipeCharArray(storePassForSession)
        ZeroTraceManager.wipeCharArray(keyPassForSession)
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(e).message,
            )
          )
        }
      } finally {
        ZeroTraceManager.wipeCharArray(request.storePassword)
        ZeroTraceManager.wipeCharArray(request.keyPassword)
      }
    }
  }

  fun downloadGeneratedKeystoreToDownloads() {
    val studio = _uiState.value.keystoreStudio
    val generatedFile = studio.generatedKeystoreFile ?: return
    val format = studio.generatedFormat ?: return
    if (studio.isBusy) return

    _uiState.update {
      it.copy(keystoreStudio = it.keystoreStudio.copy(isBusy = true, errorMessage = null))
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val mimeType = if (format == KeystoreFormat.PKCS12) {
        "application/x-pkcs12"
      } else {
        "application/octet-stream"
      }
      runCatching {
        SafFileBridge.exportFileToDownloads(
          context = appCtx,
          sourceFile = generatedFile,
          outputFileName = generatedFile.name,
          mimeType = mimeType,
        )
      }.onSuccess {
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              generatedDownloaded = true,
            )
          )
        }
      }.onFailure { err ->
        _uiState.update {
          it.copy(
            keystoreStudio = it.keystoreStudio.copy(
              isBusy = false,
              errorMessage = ErrorTranslator.translate(err).message,
            )
          )
        }
      }
    }
  }

  fun promoteGeneratedKeystoreForSigning(onReady: () -> Unit) {
    val studio = _uiState.value.keystoreStudio
    val file = studio.generatedKeystoreFile ?: return
    val format = studio.generatedFormat ?: return
    val storeChars = generatedStorePassChars ?: return
    val keyChars = generatedKeyPassChars ?: storeChars.copyOf()
    val alias = generatedKeyAlias ?: "upload"

    val appCtx = getApplication<Application>()
    viewModelScope.launch(Dispatchers.IO) {
      val signingCopy = ZeroTraceManager.allocateTempFile(
        appCtx,
        "signing_ks",
        if (format == KeystoreFormat.PKCS12) ".p12" else ".jks",
      )
      file.copyTo(signingCopy, overwrite = true)

      val validated = KeystoreDetector.validateKeystoreCredentials(
        ImportedKeystoreConfig(
          tempKeystoreFile = signingCopy,
          detectedFormat = format,
          storePassword = storeChars.copyOf(),
          keyAlias = alias,
          keyPassword = keyChars.copyOf(),
        )
      )
      val leafCert = validated.certificateChain.first()
      val sha256 = MessageDigest.getInstance("SHA-256").digest(leafCert.encoded)
      val fingerprint = sha256.joinToString(":") { b -> String.format(Locale.US, "%02X", b) }
      ZeroTraceManager.wipeByteArray(sha256)

      wipeActiveSigningCredentials()
      activeStorePassChars = storeChars.copyOf()
      activeKeyPassChars = keyChars.copyOf()
      activeKeyAlias = validated.alias

      ZeroTraceManager.secureDeleteFile(file)
      wipeGeneratedCredentials()

      _uiState.update {
        it.copy(
          keystoreStudio = it.keystoreStudio.copy(
            tempKeystoreFile = signingCopy,
            importedFileName = studio.generatedFileName ?: signingCopy.name,
            detectedFormat = format,
            hasUnlockedCredentials = true,
            verifiedSummary = VerifiedKeystoreSummary(
              format = format,
              alias = validated.alias,
              subjectDn = leafCert.subjectX500Principal.name,
              sha256Fingerprint = fingerprint,
            ),
            generatedKeystoreFile = null,
            generatedFileName = null,
            generatedFormat = null,
            generatedDownloaded = false,
          )
        )
      }
      viewModelScope.launch(Dispatchers.Main) {
        onReady()
      }
    }
  }

  fun discardGeneratedKeystoreCache() {
    val fileToShred = _uiState.value.keystoreStudio.generatedKeystoreFile
    wipeGeneratedCredentials()
    _uiState.update {
      it.copy(
        keystoreStudio = it.keystoreStudio.copy(
          generatedKeystoreFile = null,
          generatedFileName = null,
          generatedFormat = null,
          generatedDownloaded = false,
        )
      )
    }
    if (fileToShred != null) {
      viewModelScope.launch(Dispatchers.IO) {
        ZeroTraceManager.secureDeleteFile(fileToShred)
      }
    }
  }

  fun clearKeystoreSandbox() {
    wipeActiveSigningCredentials()
    wipeGeneratedCredentials()
    viewModelScope.launch(Dispatchers.IO) {
      _uiState.value.keystoreStudio.tempKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      _uiState.value.keystoreStudio.generatedKeystoreFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      _uiState.update {
        it.copy(keystoreStudio = KeystoreStudioUiState())
      }
    }
  }

  // --- Step 3: Signing & Result ---

  fun updateSigningOptions(transform: (SigningOptions) -> SigningOptions) {
    _uiState.update {
      it.copy(
        signingStudio = it.signingStudio.copy(
          options = transform(it.signingStudio.options)
        )
      )
    }
  }

  fun startSigningWithActiveCredentials() {
    val storeChars = activeStorePassChars?.copyOf() ?: return
    val keyChars = activeKeyPassChars?.copyOf() ?: storeChars.copyOf()
    val alias = activeKeyAlias ?: return
    startSigning(
      storePassword = storeChars,
      keyAlias = alias,
      keyPassword = keyChars,
    )
  }

  fun startSigning(
    storePassword: CharArray,
    keyAlias: String,
    keyPassword: CharArray,
  ) {
    val target = _uiState.value.inspector.targetFile
    val ksFile = _uiState.value.keystoreStudio.tempKeystoreFile
    if (target == null || ksFile == null || _uiState.value.signingStudio.isSigning) {
      ZeroTraceManager.wipeCharArray(storePassword)
      ZeroTraceManager.wipeCharArray(keyPassword)
      return
    }

    val effectiveKeyPass = if (keyPassword.isEmpty()) storePassword.copyOf() else keyPassword
    val ksConfig = ImportedKeystoreConfig(
      tempKeystoreFile = ksFile,
      detectedFormat = _uiState.value.keystoreStudio.detectedFormat,
      storePassword = storePassword,
      keyAlias = keyAlias.trim(),
      keyPassword = effectiveKeyPass,
    )

    _uiState.update {
      it.copy(
        signingStudio = it.signingStudio.copy(
          isSigning = true,
          logs = emptyList(),
          result = null,
          translatedError = null,
        )
      )
    }

    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      try {
        SigningEngine.signEvents(
          context = appCtx,
          target = target,
          keystoreConfig = ksConfig,
          options = _uiState.value.signingStudio.options,
        ).collect { event ->
          when (event) {
            is SigningProgressEvent.Log -> {
              _uiState.update { state ->
                state.copy(
                  signingStudio = state.signingStudio.copy(
                    logs = state.signingStudio.logs + event.line,
                  )
                )
              }
            }
            is SigningProgressEvent.Completed -> {
              wipeActiveSigningCredentials()
              wipeGeneratedCredentials()
              ZeroTraceManager.nukeCurrentSession(appCtx)
              _uiState.update { state ->
                state.copy(
                  inspector = InspectorUiState(
                    selectedCategory = state.inspector.selectedCategory,
                    selectedOutputFormat = state.inspector.selectedOutputFormat,
                  ),
                  keystoreStudio = KeystoreStudioUiState(),
                  signingStudio = state.signingStudio.copy(
                    isSigning = false,
                    result = event.result,
                    logs = event.result.logs,
                  ),
                )
              }
            }
          }
        }
      } catch (e: Exception) {
        wipeActiveSigningCredentials()
        ZeroTraceManager.nukeCurrentSession(appCtx)
        _uiState.update { state ->
          state.copy(
            inspector = InspectorUiState(
              selectedCategory = state.inspector.selectedCategory,
              selectedOutputFormat = state.inspector.selectedOutputFormat,
            ),
            keystoreStudio = KeystoreStudioUiState(),
            signingStudio = state.signingStudio.copy(
              isSigning = false,
              translatedError = ErrorTranslator.translate(e),
            ),
          )
        }
      } finally {
        ZeroTraceManager.wipeCharArray(storePassword)
        ZeroTraceManager.wipeCharArray(keyPassword)
        ZeroTraceManager.wipeCharArray(effectiveKeyPass)
      }
    }
  }

  /** Copies an already-exported signed output URI to a user-selected SAF destination URI. */
  fun copySignedOutputToUri(sourceUri: Uri, destUri: Uri, onComplete: (Boolean) -> Unit) {
    viewModelScope.launch(Dispatchers.IO) {
      val appCtx = getApplication<Application>()
      val buffer = ByteArray(64 * 1024)
      val success = runCatching {
        val resolver = appCtx.contentResolver
        val inputStream = if (sourceUri.scheme.equals("file", ignoreCase = true) && sourceUri.path != null) {
          File(sourceUri.path!!).inputStream()
        } else {
          resolver.openInputStream(sourceUri)
        } ?: error("Unable to open signed binary stream")
        inputStream.use { input ->
          resolver.openOutputStream(destUri, "w")?.use { output ->
            while (true) {
              val read = input.read(buffer)
              if (read == -1) break
              output.write(buffer, 0, read)
            }
            output.flush()
          } ?: error("Unable to write to chosen destination")
        }
        true
      }.getOrDefault(false)
      ZeroTraceManager.wipeByteArray(buffer)
      viewModelScope.launch(Dispatchers.Main) {
        onComplete(success)
      }
    }
  }

  // --- Vault & Crypto Core Actions ---

  fun runZeroTraceAudit() {
    if (_uiState.value.isAuditing) return
    _uiState.update { it.copy(isAuditing = true) }
    viewModelScope.launch(Dispatchers.IO) {
      val result = ZeroTraceManager.runZeroTraceSelfTest(getApplication())
      _uiState.update { it.copy(isAuditing = false, lastAuditResult = result) }
    }
  }

  fun nukeCurrentSession() {
    cloudBuildJob?.cancel()
    elapsedTimerJob?.cancel()
    cloudBuildJob = null
    wipeActiveSigningCredentials()
    wipeGeneratedCredentials()
    viewModelScope.launch(Dispatchers.IO) {
      ZeroTraceManager.nukeCurrentSession(getApplication())
      _uiState.update { state ->
        state.copy(
          lastAuditResult = null,
          inspector = InspectorUiState(),
          keystoreStudio = KeystoreStudioUiState(),
          signingStudio = SigningStudioUiState(),
          cloudBuild = state.cloudBuild.copy(
            isActive = false,
            currentStage = null,
            statusText = "",
            elapsedSeconds = 0,
            buildState = CloudBuildState.Idle,
            needsRepoAccessGrant = false,
            translatedError = null,
          ),
        )
      }
    }
  }

  @Suppress("DEPRECATION")
  fun refreshCryptoProviders() {
    val allProviders = Security.getProviders()
    var bcSlot = -1
    var bcVersion = ""
    val mapped = allProviders.mapIndexed { index, provider ->
      val slot = index + 1
      val isBc = provider.name.equals(BouncyCastleProvider.PROVIDER_NAME, ignoreCase = true)
      if (isBc && bcSlot == -1) {
        bcSlot = slot
        bcVersion = provider.version.toString()
      }
      SecurityProviderInfo(
        slot = slot,
        name = provider.name,
        version = provider.version.toString(),
        info = provider.info,
        isBouncyCastle = isBc,
      )
    }
    _uiState.update { state ->
      state.copy(
        cryptoDiagnostics = state.cryptoDiagnostics.copy(
          bouncyCastleSlot = bcSlot,
          bouncyCastleVersion = bcVersion,
          providers = mapped,
        )
      )
    }
  }

  fun verifySigningCapabilities() {
    if (_uiState.value.cryptoDiagnostics.isTesting) return
    _uiState.update {
      it.copy(cryptoDiagnostics = it.cryptoDiagnostics.copy(isTesting = true))
    }
    viewModelScope.launch(Dispatchers.Default) {
      val passed = runCatching {
        val sha256 = MessageDigest.getInstance("SHA-256", BouncyCastleProvider.PROVIDER_NAME)
        val digest = sha256.digest(byteArrayOf(1, 2, 3, 4))
        ZeroTraceManager.wipeByteArray(digest)

        val ecGen = KeyPairGenerator.getInstance("EC", BouncyCastleProvider.PROVIDER_NAME)
        ecGen.initialize(256)
        ecGen.generateKeyPair()

        val rsaGen = KeyPairGenerator.getInstance("RSA", BouncyCastleProvider.PROVIDER_NAME)
        rsaGen.initialize(2048)
        rsaGen.generateKeyPair()

        Class.forName("com.android.apksig.ApkSigner")
        Class.forName("com.android.tools.build.bundletool.commands.BuildApksCommand")
        true
      }.getOrDefault(false)

      _uiState.update {
        it.copy(
          cryptoDiagnostics = it.cryptoDiagnostics.copy(
            isTesting = false,
            selfTestPassed = passed,
          )
        )
      }
    }
  }

  private fun wipeActiveSigningCredentials() {
    activeStorePassChars?.let { ZeroTraceManager.wipeCharArray(it) }
    activeKeyPassChars?.let { ZeroTraceManager.wipeCharArray(it) }
    activeStorePassChars = null
    activeKeyPassChars = null
    activeKeyAlias = null
  }

  private fun deleteInspectorFiles(inspector: InspectorUiState) {
    val files = buildSet {
      inspector.targetFile?.sessionFile?.let { add(it) }
      inspector.availableBuildTargets.forEach { add(it.sessionFile) }
    }
    files.forEach { ZeroTraceManager.secureDeleteFile(it) }
  }

  private fun wipeGeneratedCredentials() {
    generatedStorePassChars?.let { ZeroTraceManager.wipeCharArray(it) }
    generatedKeyPassChars?.let { ZeroTraceManager.wipeCharArray(it) }
    generatedStorePassChars = null
    generatedKeyPassChars = null
    generatedKeyAlias = null
  }
}
