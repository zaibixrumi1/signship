# ShipSign R8 / ProGuard Rules

-keepattributes *Annotation*,Signature,InnerClasses,EnclosingMethod

# BouncyCastle JCA Provider & PKIX
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**

# Android apksig & bundletool
-keep class com.android.apksig.** { *; }
-dontwarn com.android.apksig.**
-keep class com.android.tools.build.bundletool.** { *; }
-dontwarn com.android.tools.build.bundletool.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**

# kotlinx.serialization & ShipSign navigation routes
-keepattributes RuntimeVisibleAnnotations,AnnotationDefault
-keepclassmembers class kotlinx.serialization.json.** {
    *** Companion;
}
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.shipsign.app.ui.navigation.**$$serializer { *; }
-keepclassmembers class com.shipsign.app.ui.navigation.** {
    *** Companion;
}
-keepclasseswithmembers class com.shipsign.app.ui.navigation.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# JNI native methods & ShipSign core classes
-keepclasseswithmembernames class * {
    native <methods>;
}
-keep class com.shipsign.app.** { *; }

# Strip debug/verbose logs in release builds for zero-trace hygiene
-assumenosideeffects class android.util.Log {
    public static boolean isLoggable(java.lang.String, int);
    public static int v(...);
    public static int d(...);
    public static int i(...);
    public static int w(...);
}
