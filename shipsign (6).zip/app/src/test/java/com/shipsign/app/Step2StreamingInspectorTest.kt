package com.shipsign.app

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.shipsign.app.core.engine.SignatureScanner
import com.shipsign.app.core.engine.ZipInspectorEngine
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.core.storage.SafFileBridge
import com.shipsign.app.domain.model.InputKind
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ProjectStack
import com.shipsign.app.domain.model.ResolvedBinaryType
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Step2StreamingInspectorTest {

  private lateinit var context: Context
  private lateinit var sessionDir: File

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    ZeroTraceManager.nukeAllSync(context)
    sessionDir = ZeroTraceManager.createOrGetSessionDir(context)
  }

  @After
  fun tearDown() {
    ZeroTraceManager.nukeAllSync(context)
  }

  @Test
  fun `zip inspector detects direct APK and AAB binaries`() {
    val apkFile = File(sessionDir, "sample.apk")
    createZip(apkFile, mapOf("AndroidManifest.xml" to "<manifest/>".toByteArray(), "classes.dex" to byteArrayOf(1, 2)))

    val apkTarget = ZipInspectorEngine.inspectFile(apkFile, "sample.apk", sessionDir)
    assertEquals(ResolvedBinaryType.APK, apkTarget.binaryType)
    assertEquals(InputKind.PREBUILT_PACKAGE, apkTarget.inputKind)
    assertNull(apkTarget.detectedStack)
    assertFalse(apkTarget.isAlreadySigned)

    val protoZip = File(sessionDir, "proto_pkg.zip")
    createZip(protoZip, mapOf("AndroidManifest.xml" to "<manifest/>".toByteArray(), "resources.pb" to byteArrayOf(1, 2)))
    val protoTarget = ZipInspectorEngine.inspectFile(protoZip, "proto_pkg.zip", sessionDir)
    assertEquals(InputKind.PREBUILT_PACKAGE, protoTarget.inputKind)
    assertEquals(ResolvedBinaryType.APK, protoTarget.binaryType)

    val aabFile = File(sessionDir, "sample.aab")
    createZip(aabFile, mapOf("base/manifest/AndroidManifest.xml" to "<manifest/>".toByteArray()))

    val aabTarget = ZipInspectorEngine.inspectFile(aabFile, "sample.aab", sessionDir)
    assertEquals(ResolvedBinaryType.AAB, aabTarget.binaryType)
    assertEquals(InputKind.PREBUILT_PACKAGE, aabTarget.inputKind)
    assertNull(aabTarget.detectedStack)
  }

  @Test
  fun `zip inspector extracts inner APK from wrapper zip`() {
    val innerApkBytes = ByteArrayOutputStream().also { baos ->
      ZipOutputStream(baos).use { zos ->
        zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
        zos.write("<manifest/>".toByteArray())
        zos.closeEntry()
        zos.putNextEntry(ZipEntry("META-INF/CERT.SF"))
        zos.write("Signature-Version: 1.0".toByteArray())
        zos.closeEntry()
      }
    }.toByteArray()

    val wrapperZip = File(sessionDir, "release_bundle.zip")
    createZip(wrapperZip, mapOf("output/app-release.apk" to innerApkBytes))

    val resolved = ZipInspectorEngine.inspectFile(wrapperZip, "release_bundle.zip", sessionDir)
    assertEquals(ResolvedBinaryType.APK, resolved.binaryType)
    assertEquals("app-release.apk", resolved.originalName)
    assertTrue(resolved.isAlreadySigned)
    assertTrue(resolved.sessionFile.exists())
  }

  @Test
  fun `zip inspector classifies flutter capacitor react-native godot and native android stacks`() {
    val flutterZip = File(sessionDir, "flutter_proj.zip")
    createZip(flutterZip, mapOf("my_app/pubspec.yaml" to "name: test".toByteArray()))
    val flutterRes = ZipInspectorEngine.inspectFile(flutterZip, "flutter_proj.zip", sessionDir)
    assertEquals(ProjectStack.FLUTTER, flutterRes.detectedStack)
    assertEquals(ProjectFramework.FLUTTER, flutterRes.sourceMetadata?.framework)

    val capZip = File(sessionDir, "cap_proj.zip")
    createZip(capZip, mapOf("capacitor.config.ts" to "export default {}".toByteArray()))
    val capRes = ZipInspectorEngine.inspectFile(capZip, "cap_proj.zip", sessionDir)
    assertEquals(ProjectStack.CAPACITOR_WEB, capRes.detectedStack)
    assertEquals(ProjectFramework.CAPACITOR_CORDOVA, capRes.sourceMetadata?.framework)

    val rnZip = File(sessionDir, "rn_proj.zip")
    createZip(rnZip, mapOf("package.json" to """{"dependencies":{"react-native":"0.76.0"}}""".toByteArray()))
    val rnRes = ZipInspectorEngine.inspectFile(rnZip, "rn_proj.zip", sessionDir)
    assertEquals(ProjectStack.REACT_NATIVE, rnRes.detectedStack)
    assertEquals(ProjectFramework.REACT_NATIVE, rnRes.sourceMetadata?.framework)

    val godotZip = File(sessionDir, "godot_proj.zip")
    createZip(godotZip, mapOf("game/project.godot" to "config_version=5".toByteArray()))
    val godotRes = ZipInspectorEngine.inspectFile(godotZip, "godot_proj.zip", sessionDir)
    assertEquals(ProjectStack.GODOT, godotRes.detectedStack)
    assertEquals(ProjectFramework.GODOT, godotRes.sourceMetadata?.framework)
    assertEquals("game/", godotRes.sourceMetadata?.projectRootPrefix)

    val gradleZip = File(sessionDir, "gradle_proj.zip")
    createZip(gradleZip, mapOf("build.gradle.kts" to "plugins {}".toByteArray()))
    val gradleRes = ZipInspectorEngine.inspectFile(gradleZip, "gradle_proj.zip", sessionDir)
    assertEquals(InputKind.SOURCE_ARCHIVE, gradleRes.inputKind)
    assertEquals(ProjectStack.ANDROID_GRADLE, gradleRes.detectedStack)
    assertEquals(ProjectFramework.NATIVE_ANDROID, gradleRes.sourceMetadata?.framework)
    assertEquals("android", gradleRes.sourceMetadata?.framework?.containerTag)
    assertEquals("flutter", flutterRes.sourceMetadata?.framework?.containerTag)
    assertEquals("web", rnRes.sourceMetadata?.framework?.containerTag)
    assertEquals("web", capRes.sourceMetadata?.framework?.containerTag)
  }

  @Test
  fun `zip inspector inspectUri rejects unrecognized archives and ignores node_modules or git markers`() {
    val invalidZip = File(context.cacheDir, "unrecognized_test.zip")
    try {
      createZip(
        invalidZip,
        mapOf(
          "README.md" to "# Not a mobile project".toByteArray(),
          "notes/script.js" to "console.log('hi')".toByteArray(),
          "node_modules/some_pkg/package.json" to """{"name":"ignored"}""".toByteArray(),
          ".git/config" to "[core]".toByteArray(),
        ),
      )
      val resolved = ZipInspectorEngine.inspectUri(context, Uri.fromFile(invalidZip))
      assertEquals(InputKind.INVALID, resolved.inputKind)
      assertEquals(ResolvedBinaryType.INVALID, resolved.binaryType)
      assertNull(resolved.sourceMetadata)
    } finally {
      invalidZip.delete()
    }
  }

  @Test
  fun `zip inspector extracts deep nested metadata and sanitizes IDE artifacts and secrets`() {
    val nestedZip = File(sessionDir, "deep_android.zip")
    createZip(
      nestedZip,
      mapOf(
        "outer/workspace/my_app/settings.gradle.kts" to """rootProject.name = "MyApp"""".toByteArray(),
        "outer/workspace/my_app/gradlew" to "#!/bin/sh\necho ok".toByteArray(),
        "outer/workspace/my_app/gradle/wrapper/gradle-wrapper.properties" to
          "distributionUrl=https\\://services.gradle.org/distributions/gradle-8.11.1-bin.zip".toByteArray(),
        "outer/workspace/my_app/app/build.gradle.kts" to """
          plugins { id("com.google.gms.google-services") }
          android {
            defaultConfig {
              applicationId = "com.acme.shipdemo"
            }
          }
        """.trimIndent().toByteArray(),
        "outer/workspace/my_app/.env.example" to "API_BASE=https://api.example.com".toByteArray(),
        // IDE/AI metadata & sensitive artifacts to strip
        "outer/workspace/my_app/metadata.json" to """{"name":"Test"}""".toByteArray(),
        "outer/workspace/my_app/applet_access_history.json" to "[]".toByteArray(),
        "outer/workspace/my_app/.cursor/rules.md" to "rules".toByteArray(),
        "outer/workspace/my_app/.idx/dev.nix" to "{}".toByteArray(),
        "__MACOSX/outer/._file" to byteArrayOf(1, 2, 3),
        "outer/workspace/my_app/.DS_Store" to byteArrayOf(0, 1),
        "outer/workspace/my_app/app/release.jks" to byteArrayOf(0xFE.toByte(), 0xED.toByte()),
        "outer/workspace/my_app/key.properties" to "storePassword=SECRET".toByteArray(),
        "../evil_traversal.sh" to "rm -rf /".toByteArray(),
      ),
    )

    val inspected = ZipInspectorEngine.inspectFile(nestedZip, "deep_android.zip", sessionDir)
    assertEquals(ResolvedBinaryType.SOURCE_CODE_PROJECT, inspected.binaryType)
    val meta = inspected.sourceMetadata
    assertNotNull(meta)
    assertEquals(ProjectFramework.NATIVE_ANDROID, meta!!.framework)
    assertEquals("outer/workspace/my_app/", meta.projectRootPrefix)
    assertTrue(meta.hasGradleWrapper)
    assertEquals("8.11.1", meta.gradleVersion)
    assertTrue(meta.hasFirebasePlugin)
    assertFalse(meta.hasGoogleServicesJson)
    assertTrue(meta.hasEnvExample)
    assertEquals("com.acme.shipdemo", meta.applicationId)
    assertEquals(6, meta.strippedMetadataCount)

    val sanitizedDest = File(sessionDir, "sanitized_out.zip")
    val sanitized = ZipInspectorEngine.sanitizeProjectArchive(
      sourceZip = nestedZip,
      destZip = sanitizedDest,
      projectRootPrefix = meta.projectRootPrefix,
    )
    assertTrue(sanitized.includedFileCount >= 5)
    assertTrue(sanitized.strippedEntryCount >= 9)

    ZipFile(sanitizedDest).use { zip ->
      assertNotNull(zip.getEntry("settings.gradle.kts"))
      assertNotNull(zip.getEntry("app/build.gradle.kts"))
      assertNotNull(zip.getEntry(".env.example"))
      assertNull(zip.getEntry("metadata.json"))
      assertNull(zip.getEntry("applet_access_history.json"))
      assertNull(zip.getEntry(".cursor/rules.md"))
      assertNull(zip.getEntry(".idx/dev.nix"))
      assertNull(zip.getEntry(".DS_Store"))
      assertNull(zip.getEntry("app/release.jks"))
      assertNull(zip.getEntry("key.properties"))
      assertNull(zip.getEntry("../evil_traversal.sh"))
    }
  }

  @Test
  fun `signature scanner detects and strips both v1 and v2 APK signing block`() {
    val signedApk = File(sessionDir, "signed_v1_v2.apk")
    createZip(
      signedApk,
      mapOf(
        "AndroidManifest.xml" to "<manifest/>".toByteArray(),
        "classes.dex" to byteArrayOf(1, 2, 3, 4),
        "META-INF/MANIFEST.MF" to "Manifest-Version: 1.0\r\n".toByteArray(),
        "META-INF/CERT.SF" to "Signature-Version: 1.0\r\n".toByteArray(),
        "META-INF/CERT.RSA" to byteArrayOf(0x30, 0x82.toByte()),
      ),
    )
    injectSyntheticApkSigBlockV2(signedApk)

    assertTrue(SignatureScanner.hasExistingSignature(signedApk))

    val cleanApk = File(sessionDir, "stripped.apk")
    assertTrue(SignatureScanner.stripExistingSignature(signedApk, cleanApk))
    assertFalse(SignatureScanner.hasExistingSignature(cleanApk))

    ZipFile(cleanApk).use { zip ->
      assertTrue(zip.getEntry("AndroidManifest.xml") != null)
      assertTrue(zip.getEntry("classes.dex") != null)
      assertNull(zip.getEntry("META-INF/MANIFEST.MF"))
      assertNull(zip.getEntry("META-INF/CERT.SF"))
      assertNull(zip.getEntry("META-INF/CERT.RSA"))
    }
  }

  @Test
  fun `saf file bridge streams file uri into session dir`() {
    val source = File(context.cacheDir, "test_source.apk")
    source.writeBytes(byteArrayOf(5, 6, 7, 8, 9))
    try {
      val copied = SafFileBridge.copyUriToSession(
        context = context,
        uri = Uri.fromFile(source),
        sessionDir = sessionDir,
        targetName = "streamed_target.apk",
      )
      assertEquals("streamed_target.apk", copied.displayName)
      assertEquals(5L, copied.sizeBytes)
      assertTrue(copied.file.exists())
    } finally {
      source.delete()
    }
  }

  private fun createZip(dest: File, entries: Map<String, ByteArray>) {
    ZipOutputStream(FileOutputStream(dest)).use { zos ->
      entries.forEach { (name, bytes) ->
        zos.putNextEntry(ZipEntry(name))
        zos.write(bytes)
        zos.closeEntry()
      }
    }
  }

  /** Inserts a synthetic 48-byte v2 APK Signing Block immediately before the Central Directory. */
  private fun injectSyntheticApkSigBlockV2(apkFile: File) {
    val raw = apkFile.readBytes()
    val eocdPos = raw.size - 22
    val cdOffset = ByteBuffer.wrap(raw, eocdPos + 16, 4).order(ByteOrder.LITTLE_ENDIAN).int
    val magic = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)
    val blockSize = 48
    val block = ByteArray(blockSize)
    System.arraycopy(magic, 0, block, blockSize - 16, 16)

    val updated = ByteArray(raw.size + blockSize)
    System.arraycopy(raw, 0, updated, 0, cdOffset)
    System.arraycopy(block, 0, updated, cdOffset, blockSize)
    System.arraycopy(raw, cdOffset, updated, cdOffset + blockSize, raw.size - cdOffset)

    val newCdOffset = cdOffset + blockSize
    val newEocdPos = eocdPos + blockSize
    ByteBuffer.wrap(updated, newEocdPos + 16, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(newCdOffset)

    RandomAccessFile(apkFile, "rw").use { raf ->
      raf.setLength(0L)
      raf.write(updated)
    }
  }
}
