package com.shipsign.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.shipsign.app.core.engine.KeystoreGenerator
import com.shipsign.app.core.security.KeystoreDetector
import com.shipsign.app.core.security.WrongAliasException
import com.shipsign.app.core.security.WrongPasswordException
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.domain.model.ImportedKeystoreConfig
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyStore

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class Step3KeystoreTest {

  private lateinit var context: Context
  private lateinit var sessionDir: File

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    ZeroTraceManager.nukeAllSync(context)
    sessionDir = ZeroTraceManager.createOrGetSessionDir(context)
  }

  @After
  fun tearDown() {
    ZeroTraceManager.nukeAllSync(context)
  }

  @Test
  fun `keystore detector recognizes JKS PKCS12 and BKS magic headers`() {
    val jksMagicFile = File(sessionDir, "magic.jks")
    jksMagicFile.writeBytes(
      ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).putInt(0xFEEDFEED.toInt()).putInt(2).array()
    )
    assertEquals(KeystoreFormat.JKS, KeystoreDetector.detectFormat(jksMagicFile))

    val p12MagicFile = File(sessionDir, "magic.p12")
    p12MagicFile.writeBytes(byteArrayOf(0x30, 0x82.toByte(), 0x05, 0x00, 0x02, 0x01, 0x03, 0x30))
    assertEquals(KeystoreFormat.PKCS12, KeystoreDetector.detectFormat(p12MagicFile))

    val bksMagicFile = File(sessionDir, "magic.bks")
    bksMagicFile.writeBytes(
      ByteBuffer.allocate(16).order(ByteOrder.BIG_ENDIAN).putInt(2).putInt(20).array()
    )
    assertEquals(KeystoreFormat.BKS, KeystoreDetector.detectFormat(bksMagicFile))

    val unknownFile = File(sessionDir, "unknown.bin")
    unknownFile.writeBytes(byteArrayOf(0x50, 0x4B, 0x03, 0x04, 0x14, 0x00, 0x00, 0x00))
    assertEquals(KeystoreFormat.UNKNOWN, KeystoreDetector.detectFormat(unknownFile))
  }

  @Test
  fun `keystore generator builds Sun-compatible JKS with distinct passwords and wipes CharArrays`() {
    val storePass = "StoreSecret!1".toCharArray()
    val keyPass = "KeySecret!2".toCharArray()

    val request = KeystoreCreateRequest(
      format = KeystoreFormat.JKS,
      fileName = "release_upload",
      storePassword = storePass,
      keyAlias = "upload",
      keyPassword = keyPass,
      validityDays = 10000,
      commonName = "ShipSign Dev",
      organizationalUnit = "Security",
      organization = "ShipSign",
      cityLocality = "San Francisco",
      stateProvince = "CA",
      countryCode = "US",
    )

    val jksFile = KeystoreGenerator.generateKeystore(request, sessionDir)
    assertTrue(jksFile.exists())
    assertTrue(jksFile.name.endsWith(".jks"))
    assertEquals(KeystoreFormat.JKS, KeystoreDetector.detectFormat(jksFile))

    // Passwords must be wiped immediately after store()
    assertTrue(storePass.all { it == '\u0000' })
    assertTrue(keyPass.all { it == '\u0000' })

    // Verify our JKS binary loads cleanly with Sun's native JVM KeyStore.getInstance("JKS")
    val sunJks = KeyStore.getInstance("JKS")
    FileInputStream(jksFile).use { fis ->
      sunJks.load(fis, "StoreSecret!1".toCharArray())
    }
    assertTrue(sunJks.containsAlias("upload"))
    assertNotNull(sunJks.getKey("upload", "KeySecret!2".toCharArray()))

    // Verify KeystoreDetector credential check
    val validated = KeystoreDetector.validateKeystoreCredentials(
      ImportedKeystoreConfig(
        tempKeystoreFile = jksFile,
        detectedFormat = KeystoreFormat.JKS,
        storePassword = "StoreSecret!1".toCharArray(),
        keyAlias = "upload",
        keyPassword = "KeySecret!2".toCharArray(),
      )
    )
    assertEquals(KeystoreFormat.JKS, validated.format)
    assertEquals("upload", validated.alias)
    assertEquals("RSA", validated.privateKey.algorithm)
    assertTrue(validated.certificateChain.first().subjectX500Principal.name.contains("CN=ShipSign Dev"))
  }

  @Test
  fun `keystore generator builds PKCS12 and detector throws typed errors on bad credentials`() {
    val storePass = "PkcsStore99".toCharArray()
    val keyPass = "PkcsKey88".toCharArray()

    val request = KeystoreCreateRequest(
      format = KeystoreFormat.PKCS12,
      fileName = "play_upload.p12",
      storePassword = storePass,
      keyAlias = "release",
      keyPassword = keyPass,
      validityDays = 3650,
      commonName = "Play Upload",
      organizationalUnit = "Release",
      organization = "ShipSign",
      cityLocality = "San Francisco",
      stateProvince = "CA",
      countryCode = "US",
    )

    val p12File = KeystoreGenerator.generateKeystore(request, sessionDir)
    assertTrue(p12File.exists())
    assertEquals(KeystoreFormat.PKCS12, KeystoreDetector.detectFormat(p12File))
    assertTrue(storePass.all { it == '\u0000' })
    assertTrue(keyPass.all { it == '\u0000' })

    val validated = KeystoreDetector.validateKeystoreCredentials(
      ImportedKeystoreConfig(
        tempKeystoreFile = p12File,
        detectedFormat = KeystoreFormat.PKCS12,
        storePassword = "PkcsStore99".toCharArray(),
        keyAlias = "release",
        keyPassword = "PkcsKey88".toCharArray(),
      )
    )
    assertEquals(KeystoreFormat.PKCS12, validated.format)
    assertEquals("release", validated.alias)

    // Wrong store password -> WrongPasswordException
    var gotWrongPass = false
    try {
      KeystoreDetector.validateKeystoreCredentials(
        ImportedKeystoreConfig(
          tempKeystoreFile = p12File,
          detectedFormat = KeystoreFormat.PKCS12,
          storePassword = "WrongStorePassword".toCharArray(),
          keyAlias = "release",
          keyPassword = "PkcsKey88".toCharArray(),
        )
      )
    } catch (_: WrongPasswordException) {
      gotWrongPass = true
    }
    assertTrue(gotWrongPass)

    // Wrong alias -> WrongAliasException
    var gotWrongAlias = false
    try {
      KeystoreDetector.validateKeystoreCredentials(
        ImportedKeystoreConfig(
          tempKeystoreFile = p12File,
          detectedFormat = KeystoreFormat.PKCS12,
          storePassword = "PkcsStore99".toCharArray(),
          keyAlias = "nonexistent_alias",
          keyPassword = "PkcsKey88".toCharArray(),
        )
      )
    } catch (e: WrongAliasException) {
      gotWrongAlias = e.availableAliases.contains("release")
    }
    assertTrue(gotWrongAlias)
  }

  @Test
  fun `keystore detector validates BKS keystore with BouncyCastle provider`() {
    val request = KeystoreCreateRequest(
      format = KeystoreFormat.JKS,
      fileName = "seed_cert",
      storePassword = "seed".toCharArray(),
      keyAlias = "seed",
      keyPassword = "seed".toCharArray(),
      commonName = "BKS Seed",
      organizationalUnit = "",
      organization = "",
      cityLocality = "",
      stateProvince = "",
      countryCode = "US",
    )
    val seedJks = KeystoreGenerator.generateKeystore(request, sessionDir)
    val seedCreds = KeystoreDetector.validateKeystoreCredentials(
      ImportedKeystoreConfig(seedJks, KeystoreFormat.JKS, "seed".toCharArray(), "seed", "seed".toCharArray())
    )

    val bksFile = File(sessionDir, "test_store.bks")
    val bks = KeyStore.getInstance("BKS", "BC")
    bks.load(null, null)
    bks.setKeyEntry("bks_alias", seedCreds.privateKey, "bksKeyPass".toCharArray(), seedCreds.certificateChain.toTypedArray())
    FileOutputStream(bksFile).use { fos ->
      bks.store(fos, "bksStorePass".toCharArray())
    }

    assertEquals(KeystoreFormat.BKS, KeystoreDetector.detectFormat(bksFile))
    val validatedBks = KeystoreDetector.validateKeystoreCredentials(
      ImportedKeystoreConfig(
        tempKeystoreFile = bksFile,
        detectedFormat = KeystoreFormat.BKS,
        storePassword = "bksStorePass".toCharArray(),
        keyAlias = "bks_alias",
        keyPassword = "bksKeyPass".toCharArray(),
      )
    )
    assertEquals(KeystoreFormat.BKS, validatedBks.format)
    assertEquals("bks_alias", validatedBks.alias)
  }
}
