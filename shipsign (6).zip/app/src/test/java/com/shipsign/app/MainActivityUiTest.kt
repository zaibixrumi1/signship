package com.shipsign.app

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.hasTestTag
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onAllNodesWithTag
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollToNode
import androidx.compose.ui.test.performTextInput
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36], qualifiers = "w411dp-h891dp-xxhdpi")
class MainActivityUiTest {

  @get:Rule
  val composeTestRule = createAndroidComposeRule<MainActivity>()

  @Test
  fun `launch MainActivity and verify Home, SelectFile, MakeKeystore, Ready auto-shred, Vault, and CryptoCore flows`() {
    composeTestRule.waitForIdle()

    // Unified Top Bar & Home Screen: Sign New App drop-zone, Make New Keystore card, Offline trust badge
    composeTestRule.onNodeWithTag("top_zero_trace_pill").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_sign_new_app_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_make_keystore_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("home_lazy_column")
      .performScrollToNode(hasTestTag("home_trust_badge"))
    composeTestRule.onNodeWithTag("home_trust_badge").assertIsDisplayed()

    // Navigate to Step 1: Minimalist Select File (3-step rail + single universal Drop Zone)
    composeTestRule.onNodeWithTag("home_lazy_column")
      .performScrollToNode(hasTestTag("home_sign_new_app_card"))
    composeTestRule.onNodeWithTag("home_sign_new_app_card").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("workflow_step_rail").assertIsDisplayed()
    composeTestRule.onNodeWithTag("select_drop_zone_card").assertIsDisplayed()

    // Back to Home
    composeTestRule.onNodeWithTag("top_back_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("home_make_keystore_card").assertIsDisplayed()

    // Navigate to Make New Keystore -> Format Selection (JKS vs PKCS12) -> 11-field Form
    composeTestRule.onNodeWithTag("home_make_keystore_card").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("format_select_jks_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("format_select_pkcs12_card").assertIsDisplayed()

    composeTestRule.onNodeWithTag("format_select_pkcs12_card").performClick()
    composeTestRule.waitForIdle()

    composeTestRule.onNodeWithTag("form_filename_field").assertIsDisplayed()
    composeTestRule.onNodeWithTag("form_store_password_field").performTextInput("StrongPass123!")

    composeTestRule.onNodeWithTag("keystore_form_list")
      .performScrollToNode(hasTestTag("form_c_field"))
    composeTestRule.onNodeWithTag("form_c_field").assertIsDisplayed()
    composeTestRule.onNodeWithTag("form_c_field").performTextInput("US")

    composeTestRule.onNodeWithTag("keystore_form_list")
      .performScrollToNode(hasTestTag("form_generate_button"))
    composeTestRule.onNodeWithTag("form_generate_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("form_generate_button").performClick()

    // Wait for async RSA-2048 keystore generation to navigate to KeystoreReadyScreen
    composeTestRule.waitUntil(timeoutMillis = 15_000L) {
      composeTestRule.onAllNodesWithTag("keystore_ready_hero_card").fetchSemanticsNodes().isNotEmpty()
    }
    composeTestRule.onNodeWithTag("keystore_ready_list")
      .performScrollToNode(hasTestTag("ready_download_keystore_button"))
    composeTestRule.onNodeWithTag("ready_download_keystore_button").assertIsDisplayed()
    composeTestRule.onNodeWithTag("keystore_ready_list")
      .performScrollToNode(hasTestTag("ready_done_home_button"))
    composeTestRule.onNodeWithTag("ready_done_home_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("home_lazy_column")
      .performScrollToNode(hasTestTag("home_trust_badge"))
    composeTestRule.onNodeWithTag("home_trust_badge").assertIsDisplayed()

    // Open Zero-Trace Vault & CryptoCore from unified TopAppBar
    composeTestRule.onNodeWithTag("home_vault_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("vault_hero_card").assertIsDisplayed()
    composeTestRule.onNodeWithTag("active_session_id_text").assertIsDisplayed()

    composeTestRule.onNodeWithTag("vault_lazy_column")
      .performScrollToNode(hasTestTag("open_crypto_core_button"))
    composeTestRule.onNodeWithTag("open_crypto_core_button").performClick()
    composeTestRule.waitForIdle()
    composeTestRule.onNodeWithTag("bouncycastle_slot_card").assertIsDisplayed()
  }
}
