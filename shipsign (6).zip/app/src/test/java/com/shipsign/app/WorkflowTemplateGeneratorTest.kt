package com.shipsign.app

import com.shipsign.app.core.github.BuildOutputFormat
import com.shipsign.app.core.github.WorkflowTemplateGenerator
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.SourceProjectMetadata
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WorkflowTemplateGeneratorTest {

  @Test
  fun `android APK workflow uses single build job, strips foojay, writes printf init script, and uploads uncompressed APK`() {
    val yaml = WorkflowTemplateGenerator.generateApkWorkflow(
      SourceProjectMetadata(framework = ProjectFramework.NATIVE_ANDROID)
    )

    assertTrue(yaml.contains("image: ghcr.io/zaibixrumi1/shipsign-builder:android"))
    assertFalse(yaml.contains("detect:"))
    assertTrue(yaml.contains("uses: actions/checkout@v6"))
    assertTrue(yaml.contains("ZIP_FILE=\$(find . -maxdepth 2 -name \"*.zip\" | head -n 1)"))
    assertTrue(yaml.contains("unzip -q \"\$ZIP_FILE\" -d extracted_project"))
    assertTrue(yaml.contains("sed -i '/foojay-resolver-convention/d' settings.gradle settings.gradle.kts"))
    assertTrue(yaml.contains("printf '%s\\n' \\"))
    assertTrue(yaml.contains("'}' > /tmp/shipsign-init.gradle"))
    assertFalse(yaml.contains("cat <<"))
    assertFalse(yaml.contains("gradle wrapper"))
    assertFalse(yaml.contains("optimizeReleaseResources"))
    assertFalse(yaml.contains("ArtProfile"))
    assertFalse(yaml.contains("NativeSymbolTables"))
    assertTrue(
      yaml.contains(
        "\$GRADLE_BIN assembleRelease --init-script /tmp/shipsign-init.gradle -Pandroid.injected.build.abi=arm64-v8a -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\""
      )
    )
    assertTrue(yaml.contains("uses: actions/upload-artifact@v7"))
    assertTrue(yaml.contains("name: ShipSign-APK"))
    assertTrue(yaml.contains("compression-level: 0"))
    assertTrue(yaml.contains("path: \"**/*.apk\""))
  }

  @Test
  fun `android AAB workflow omits ABI restriction on Path A release bundleRelease`() {
    val yaml = WorkflowTemplateGenerator.generateAabWorkflow(
      SourceProjectMetadata(framework = ProjectFramework.NATIVE_ANDROID)
    )

    assertTrue(yaml.contains("image: ghcr.io/zaibixrumi1/shipsign-builder:android"))
    assertTrue(
      yaml.contains(
        "\$GRADLE_BIN bundleRelease --init-script /tmp/shipsign-init.gradle -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\""
      )
    )
    assertFalse(yaml.contains("bundleRelease --init-script /tmp/shipsign-init.gradle -Pandroid.injected.build.abi"))
    assertTrue(yaml.contains("name: ShipSign-AAB"))
    assertTrue(yaml.contains("compression-level: 0"))
    assertTrue(yaml.contains("path: \"**/*.aab\""))
  }

  @Test
  fun `web BOTH workflow runs Capacitor sync, sequential assembleRelease + bundleRelease, and uploads ShipSign-Bundle`() {
    val yaml = WorkflowTemplateGenerator.generateBothWorkflow(
      SourceProjectMetadata(framework = ProjectFramework.CAPACITOR_CORDOVA)
    )

    assertTrue(yaml.contains("image: ghcr.io/zaibixrumi1/shipsign-builder:web"))
    assertTrue(yaml.contains("npm install --legacy-peer-deps"))
    assertTrue(yaml.contains("\"@capacitor/core\""))
    assertTrue(yaml.contains("npx cap sync android"))
    assertTrue(yaml.contains("cd \"\$ROOT_DIR\""))
    assertTrue(
      yaml.contains(
        "\$GRADLE_BIN assembleRelease --init-script /tmp/shipsign-init.gradle -Pandroid.injected.build.abi=arm64-v8a -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\""
      )
    )
    assertTrue(
      yaml.contains(
        "\$GRADLE_BIN bundleRelease --init-script /tmp/shipsign-init.gradle -x lint -x test --no-build-cache --no-configuration-cache --parallel --no-daemon -Dorg.gradle.jvmargs=\"-Xmx4g -XX:+UseParallelGC\""
      )
    )
    assertTrue(yaml.contains("name: ShipSign-Bundle"))
    assertTrue(yaml.contains("compression-level: 0"))
    assertTrue(yaml.contains("**/*.apk"))
    assertTrue(yaml.contains("**/*.aab"))
  }

  @Test
  fun `flutter workflows target flutter container and emit release plus debug fallback paths`() {
    val apk = WorkflowTemplateGenerator.generateWorkflow(
      SourceProjectMetadata(framework = ProjectFramework.FLUTTER),
      BuildOutputFormat.APK_ONLY,
    )
    val both = WorkflowTemplateGenerator.generateWorkflow(
      SourceProjectMetadata(framework = ProjectFramework.FLUTTER),
      BuildOutputFormat.BOTH,
    )

    assertTrue(apk.contains("image: ghcr.io/zaibixrumi1/shipsign-builder:flutter"))
    assertTrue(apk.contains("flutter pub get && flutter build apk --release --target-platform android-arm64"))
    assertTrue(apk.contains("flutter pub get && flutter build apk --debug --target-platform android-arm64"))
    assertTrue(apk.contains("flutter pub get && flutter build apk --debug"))
    assertTrue(apk.contains("android/local.properties"))

    assertTrue(both.contains("flutter pub get && flutter build apk --release --target-platform android-arm64 && flutter build appbundle --release"))
    assertTrue(both.contains("name: ShipSign-Bundle"))
    assertTrue(both.contains("compression-level: 0"))
  }

  @Test(expected = IllegalArgumentException::class)
  fun `unknown framework is rejected before generating workflow`() {
    WorkflowTemplateGenerator.generateWorkflow(
      SourceProjectMetadata(framework = ProjectFramework.UNKNOWN),
      BuildOutputFormat.APK_ONLY,
    )
  }
}
