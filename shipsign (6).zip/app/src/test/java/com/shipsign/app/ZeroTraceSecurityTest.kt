package com.shipsign.app

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.shipsign.app.core.security.ZeroTraceManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ZeroTraceSecurityTest {

  @Test
  fun `read app name from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ShipSign", appName)
  }

  @Test
  fun `zero trace manager uses shipsign_ephemeral root, shreds file, and wipes char array`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("shipsign_ephemeral", ZeroTraceManager.getEphemeralRoot(context).name)

    val tempFile = ZeroTraceManager.allocateTempFile(context, "secret", ".tmp")
    tempFile.writeBytes(byteArrayOf(10, 20, 30, 40, 50))
    assertTrue(tempFile.exists())

    val secret = charArrayOf('p', 'a', 's', 's', '1', '2', '3')
    ZeroTraceManager.wipeCharArray(secret)
    assertTrue(secret.all { it == '\u0000' })

    val deleted = ZeroTraceManager.secureDeleteFile(tempFile)
    assertTrue(deleted)
    assertFalse(tempFile.exists())

    val audit = ZeroTraceManager.runZeroTraceSelfTest(context)
    assertTrue(audit.passed)
    assertEquals(0, audit.residualFilesFound)
  }
}
