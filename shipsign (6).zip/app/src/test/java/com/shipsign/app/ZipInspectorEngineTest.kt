package com.shipsign.app

import android.content.Context
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import com.shipsign.app.core.engine.ZipInspectorEngine
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.domain.model.InputKind
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ResolvedBinaryType
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ZipInspectorEngineTest {

  private lateinit var context: Context
  private lateinit var sessionDir: File

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    ZeroTraceManager.nukeAllSync(context)
    sessionDir = ZeroTraceManager.createOrGetSessionDir(context)
  }

  @After
  fun tearDown() {
    ZeroTraceManager.nukeAllSync(context)
  }

  @Test
  fun `inspectUriAsync classifies native android zip on Dispatchers IO and exposes android containerTag`() = runBlocking {
    val externalDir = File(context.cacheDir, "external_picker_test").apply { mkdirs() }
    val zipFile = File(externalDir, "native-app.zip")
    try {
      ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
        zos.putNextEntry(ZipEntry("MyApp/settings.gradle.kts"))
        zos.write("""rootProject.name = "MyApp"""".toByteArray())
        zos.closeEntry()
        zos.putNextEntry(ZipEntry("MyApp/app/build.gradle.kts"))
        zos.write("""android { defaultConfig { applicationId = "com.shipsign.sample" } }""".toByteArray())
        zos.closeEntry()
      }

      val result = ZipInspectorEngine.inspectUriAsync(context, Uri.fromFile(zipFile))
      assertEquals(InputKind.SOURCE_ARCHIVE, result.inputKind)
      assertEquals(ResolvedBinaryType.SOURCE_CODE_PROJECT, result.binaryType)
      assertNotNull(result.sourceMetadata)
      assertEquals(ProjectFramework.NATIVE_ANDROID, result.sourceMetadata?.framework)
      assertEquals("android", result.sourceMetadata?.containerTag)
      assertEquals("com.shipsign.sample", result.sourceMetadata?.applicationId)
    } finally {
      zipFile.delete()
      externalDir.deleteRecursively()
    }
  }

  @Test
  fun `inspectFileAsync classifies prebuilt APK and rejects random non-project archive`() = runBlocking {
    val apkFile = File(sessionDir, "release.apk")
    ZipOutputStream(FileOutputStream(apkFile)).use { zos ->
      zos.putNextEntry(ZipEntry("AndroidManifest.xml"))
      zos.write(byteArrayOf(0x03, 0x00, 0x08, 0x00, 0x10, 0x00, 0x00, 0x00))
      zos.closeEntry()
      zos.putNextEntry(ZipEntry("classes.dex"))
      zos.write(ByteArray(32) { 0x11 })
      zos.closeEntry()
    }

    val apkRes = ZipInspectorEngine.inspectFileAsync(apkFile, "release.apk", sessionDir)
    assertEquals(InputKind.PREBUILT_PACKAGE, apkRes.inputKind)
    assertEquals(ResolvedBinaryType.APK, apkRes.binaryType)

    val junkZip = File(sessionDir, "junk.zip")
    ZipOutputStream(FileOutputStream(junkZip)).use { zos ->
      zos.putNextEntry(ZipEntry("notes/hello.txt"))
      zos.write("nothing buildable".toByteArray())
      zos.closeEntry()
    }

    val junkRes = ZipInspectorEngine.inspectFileAsync(junkZip, "junk.zip", sessionDir)
    assertEquals(InputKind.INVALID, junkRes.inputKind)
    assertEquals(ResolvedBinaryType.INVALID, junkRes.binaryType)
  }
}
