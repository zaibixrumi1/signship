#include <jni.h>
#include <android/log.h>
#include <cstdint>
#include <cstring>
#include <fstream>
#include <string>
#include <vector>

#define LOG_TAG "ShipSignZipAlign"
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

namespace {

constexpr uint32_t kLfhSignature = 0x04034B50u;
constexpr uint32_t kCdhSignature = 0x02014B50u;
constexpr uint32_t kEocdSignature = 0x06054B50u;
constexpr uint16_t kMethodStored = 0u;
constexpr uint16_t kFlagDataDescriptor = 0x0008u;

inline uint16_t readU16(const uint8_t* p) {
    return static_cast<uint16_t>(p[0]) | (static_cast<uint16_t>(p[1]) << 8);
}

inline uint32_t readU32(const uint8_t* p) {
    return static_cast<uint32_t>(p[0]) |
           (static_cast<uint32_t>(p[1]) << 8) |
           (static_cast<uint32_t>(p[2]) << 16) |
           (static_cast<uint32_t>(p[3]) << 24);
}

inline void writeU16(uint8_t* p, uint16_t v) {
    p[0] = static_cast<uint8_t>(v & 0xFFu);
    p[1] = static_cast<uint8_t>((v >> 8) & 0xFFu);
}

inline void writeU32(uint8_t* p, uint32_t v) {
    p[0] = static_cast<uint8_t>(v & 0xFFu);
    p[1] = static_cast<uint8_t>((v >> 8) & 0xFFu);
    p[2] = static_cast<uint8_t>((v >> 16) & 0xFFu);
    p[3] = static_cast<uint8_t>((v >> 24) & 0xFFu);
}

bool endsWithSo(const std::string& name) {
    if (name.size() < 3) return false;
    const size_t n = name.size();
    return (name[n - 3] == '.') &&
           (name[n - 2] == 's' || name[n - 2] == 'S') &&
           (name[n - 1] == 'o' || name[n - 1] == 'O');
}

bool streamCopy(std::ifstream& in, std::ofstream& out, uint64_t bytes) {
    constexpr size_t kBufSize = 65536;
    std::vector<char> buf(kBufSize);
    uint64_t remaining = bytes;
    while (remaining > 0) {
        const size_t chunk = static_cast<size_t>(
            remaining < kBufSize ? remaining : static_cast<uint64_t>(kBufSize));
        if (!in.read(buf.data(), static_cast<std::streamsize>(chunk))) {
            return false;
        }
        if (!out.write(buf.data(), static_cast<std::streamsize>(chunk))) {
            return false;
        }
        remaining -= chunk;
    }
    return true;
}

int alignZipStream(
    const std::string& inputPath,
    const std::string& outputPath,
    int defaultAlignment,
    bool pageAlignSharedLibs
) {
    std::ifstream in(inputPath, std::ios::binary | std::ios::ate);
    if (!in.is_open()) {
        LOGE("Failed to open input APK");
        return -1;
    }
    const std::streamoff fileSizeOff = in.tellg();
    if (fileSizeOff < 22) {
        return -2;
    }
    const uint64_t fileSize = static_cast<uint64_t>(fileSizeOff);

    // Find EOCD near tail
    const uint64_t tailSize = fileSize < 65557ULL ? fileSize : 65557ULL;
    const uint64_t tailStart = fileSize - tailSize;
    std::vector<uint8_t> tail(static_cast<size_t>(tailSize));
    in.seekg(static_cast<std::streamoff>(tailStart), std::ios::beg);
    if (!in.read(reinterpret_cast<char*>(tail.data()), static_cast<std::streamsize>(tailSize))) {
        return -3;
    }

    int64_t eocdPos = -1;
    for (int64_t i = static_cast<int64_t>(tailSize) - 22; i >= 0; --i) {
        if (readU32(&tail[static_cast<size_t>(i)]) == kEocdSignature) {
            const uint16_t commentLen = readU16(&tail[static_cast<size_t>(i + 20)]);
            if (static_cast<uint64_t>(i + 22 + commentLen) == tailSize) {
                eocdPos = i;
                break;
            }
        }
    }
    if (eocdPos < 0) {
        return -4;
    }

    const uint8_t* eocd = &tail[static_cast<size_t>(eocdPos)];
    const uint16_t entryCount = readU16(eocd + 10);
    const uint32_t cdSize = readU32(eocd + 12);
    const uint32_t cdOffset = readU32(eocd + 16);
    if (static_cast<uint64_t>(cdOffset) + static_cast<uint64_t>(cdSize) > fileSize) {
        return -5;
    }

    // Read Central Directory (metadata only, never full APK payload)
    std::vector<uint8_t> cdBuf(cdSize);
    in.seekg(static_cast<std::streamoff>(cdOffset), std::ios::beg);
    if (!in.read(reinterpret_cast<char*>(cdBuf.data()), static_cast<std::streamsize>(cdSize))) {
        return -6;
    }

    std::ofstream out(outputPath, std::ios::binary | std::ios::trunc);
    if (!out.is_open()) {
        return -7;
    }

    std::vector<uint8_t> newCd;
    newCd.reserve(cdSize);
    uint64_t outCursor = 0;
    size_t cdCursor = 0;

    for (uint16_t idx = 0; idx < entryCount; ++idx) {
        if (cdCursor + 46 > cdBuf.size() || readU32(&cdBuf[cdCursor]) != kCdhSignature) {
            return -8;
        }
        uint8_t cdHeader[46];
        std::memcpy(cdHeader, &cdBuf[cdCursor], 46);

        const uint16_t flags = readU16(cdHeader + 8);
        const uint16_t method = readU16(cdHeader + 10);
        const uint32_t compSize = readU32(cdHeader + 20);
        const uint16_t nameLen = readU16(cdHeader + 28);
        const uint16_t cdExtraLen = readU16(cdHeader + 30);
        const uint16_t cdCommentLen = readU16(cdHeader + 32);
        const uint32_t oldLfhOffset = readU32(cdHeader + 42);

        if (cdCursor + 46 + nameLen + cdExtraLen + cdCommentLen > cdBuf.size()) {
            return -9;
        }

        std::string entryName(
            reinterpret_cast<const char*>(&cdBuf[cdCursor + 46]),
            nameLen
        );

        // Read original Local File Header
        uint8_t lfh[30];
        in.seekg(static_cast<std::streamoff>(oldLfhOffset), std::ios::beg);
        if (!in.read(reinterpret_cast<char*>(lfh), 30) || readU32(lfh) != kLfhSignature) {
            return -10;
        }
        const uint16_t lfhNameLen = readU16(lfh + 26);
        const uint16_t lfhExtraLen = readU16(lfh + 28);

        std::vector<uint8_t> lfhName(lfhNameLen);
        if (lfhNameLen > 0 && !in.read(reinterpret_cast<char*>(lfhName.data()), lfhNameLen)) {
            return -11;
        }
        std::vector<uint8_t> lfhExtra(lfhExtraLen);
        if (lfhExtraLen > 0 && !in.read(reinterpret_cast<char*>(lfhExtra.data()), lfhExtraLen)) {
            return -12;
        }

        uint32_t reqAlign = 0;
        if (method == kMethodStored && compSize > 0) {
            if (pageAlignSharedLibs && endsWithSo(entryName)) {
                reqAlign = 16384u;
            } else if (defaultAlignment > 1) {
                reqAlign = static_cast<uint32_t>(defaultAlignment);
            }
        }

        uint16_t newLfhExtraLen = lfhExtraLen;
        uint32_t padBytes = 0;
        if (reqAlign > 1) {
            const uint64_t unpaddedDataPos = outCursor + 30ULL + lfhNameLen + lfhExtraLen;
            const uint32_t rem = static_cast<uint32_t>(unpaddedDataPos % reqAlign);
            if (rem != 0) {
                padBytes = reqAlign - rem;
                if (static_cast<uint32_t>(lfhExtraLen) + padBytes <= 65535u) {
                    newLfhExtraLen = static_cast<uint16_t>(lfhExtraLen + padBytes);
                } else {
                    padBytes = 0;
                }
            }
        }

        const uint32_t newLfhOffset = static_cast<uint32_t>(outCursor);
        writeU16(lfh + 28, newLfhExtraLen);
        out.write(reinterpret_cast<const char*>(lfh), 30);
        if (lfhNameLen > 0) {
            out.write(reinterpret_cast<const char*>(lfhName.data()), lfhNameLen);
        }
        if (lfhExtraLen > 0) {
            out.write(reinterpret_cast<const char*>(lfhExtra.data()), lfhExtraLen);
        }
        if (padBytes > 0) {
            std::vector<char> zeros(padBytes, 0);
            out.write(zeros.data(), static_cast<std::streamsize>(padBytes));
        }

        // Stream compressed/stored payload + optional data descriptor
        uint64_t payloadBytes = compSize;
        if ((flags & kFlagDataDescriptor) != 0) {
            // Check 16-byte or 12-byte data descriptor after payload
            if (!streamCopy(in, out, payloadBytes)) return -13;
            uint8_t ddPeek[4];
            if (!in.read(reinterpret_cast<char*>(ddPeek), 4)) return -14;
            out.write(reinterpret_cast<const char*>(ddPeek), 4);
            const bool hasSig = (readU32(ddPeek) == 0x08074B50u);
            const uint64_t restDd = hasSig ? 12ULL : 8ULL;
            if (!streamCopy(in, out, restDd)) return -15;
            outCursor += 30ULL + lfhNameLen + newLfhExtraLen + payloadBytes + 4ULL + restDd;
        } else {
            if (!streamCopy(in, out, payloadBytes)) return -16;
            outCursor += 30ULL + lfhNameLen + newLfhExtraLen + payloadBytes;
        }

        // Update Central Directory header offset
        writeU32(cdHeader + 42, newLfhOffset);
        newCd.insert(newCd.end(), cdHeader, cdHeader + 46);
        const size_t metaTailLen = nameLen + cdExtraLen + cdCommentLen;
        newCd.insert(
            newCd.end(),
            cdBuf.begin() + static_cast<std::ptrdiff_t>(cdCursor + 46),
            cdBuf.begin() + static_cast<std::ptrdiff_t>(cdCursor + 46 + metaTailLen)
        );
        cdCursor += 46 + metaTailLen;
    }

    const uint32_t newCdOffset = static_cast<uint32_t>(outCursor);
    const uint32_t newCdSize = static_cast<uint32_t>(newCd.size());
    out.write(reinterpret_cast<const char*>(newCd.data()), static_cast<std::streamsize>(newCd.size()));

    // Write updated EOCD
    std::vector<uint8_t> newEocd(eocd, eocd + 22 + readU16(eocd + 20));
    writeU32(newEocd.data() + 12, newCdSize);
    writeU32(newEocd.data() + 16, newCdOffset);
    out.write(reinterpret_cast<const char*>(newEocd.data()), static_cast<std::streamsize>(newEocd.size()));
    out.flush();

    return out.good() ? 0 : -17;
}

}  // namespace

extern "C" JNIEXPORT jint JNICALL
Java_com_shipsign_app_core_engine_ZipAlignEngine_nativeAlignApk(
    JNIEnv* env,
    jobject /* this */,
    jstring inputPath,
    jstring outputPath,
    jint alignment,
    jboolean pageAlignSharedLibs
) {
    if (inputPath == nullptr || outputPath == nullptr) {
        return -100;
    }
    const char* rawIn = env->GetStringUTFChars(inputPath, nullptr);
    const char* rawOut = env->GetStringUTFChars(outputPath, nullptr);
    if (rawIn == nullptr || rawOut == nullptr) {
        if (rawIn != nullptr) env->ReleaseStringUTFChars(inputPath, rawIn);
        if (rawOut != nullptr) env->ReleaseStringUTFChars(outputPath, rawOut);
        return -101;
    }

    std::string inStr(rawIn);
    std::string outStr(rawOut);
    env->ReleaseStringUTFChars(inputPath, rawIn);
    env->ReleaseStringUTFChars(outputPath, rawOut);

    return alignZipStream(inStr, outStr, static_cast<int>(alignment), pageAlignSharedLibs == JNI_TRUE);
}
