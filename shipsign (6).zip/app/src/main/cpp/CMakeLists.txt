cmake_minimum_required(VERSION 3.22.1)
project("shipsign_zipalign" LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_library(
    shipsign_zipalign
    SHARED
    zipalign_jni.cpp
)

find_library(
    log-lib
    log
)

target_link_libraries(
    shipsign_zipalign
    ${log-lib}
)
