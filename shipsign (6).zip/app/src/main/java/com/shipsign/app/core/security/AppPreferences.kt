package com.shipsign.app.core.security

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Persisted GitHub App OAuth 2.0 PKCE session stored exclusively inside hardware-backed
 * AES-256 [EncryptedSharedPreferences] so users do not re-authenticate before each cloud build.
 */
data class GitHubAuthSession(
  val accessToken: String,
  val installationId: String?,
  val username: String,
  val avatarUrl: String?,
)

/**
 * Stores UI preferences (one-time GitHub disclosure flag, background auto-wipe delay),
 * ephemeral OAuth PKCE state/verifier during Chrome Custom Tabs round-trips, and the
 * optional GitHub OAuth session inside AES-256 [EncryptedSharedPreferences].
 *
 * Strictly zero keystores, zero signing passwords, and zero file history are ever written to
 * preferences.
 */
object AppPreferences {

  private const val PREFS_NAME = "shipsign_ui_prefs_encrypted"
  private const val KEY_WIPE_TIMEOUT_SEC = "bg_wipe_timeout_sec"
  private const val KEY_GITHUB_DISCLOSURE_ACCEPTED = "github_disclosure_accepted"
  private const val KEY_GH_ACCESS_TOKEN = "gh_oauth_access_token"
  private const val KEY_GH_INSTALLATION_ID = "gh_oauth_installation_id"
  private const val KEY_GH_USERNAME = "gh_oauth_username"
  private const val KEY_GH_AVATAR_URL = "gh_oauth_avatar_url"
  private const val KEY_GH_PENDING_STATE = "gh_oauth_pending_state"
  private const val KEY_GH_PENDING_VERIFIER = "gh_oauth_pending_code_verifier"

  const val DEFAULT_WIPE_TIMEOUT_SEC = 15

  @Volatile private var cachedPrefs: SharedPreferences? = null

  private fun prefs(context: Context): SharedPreferences {
    cachedPrefs?.let { return it }
    synchronized(this) {
      cachedPrefs?.let { return it }
      val appCtx = context.applicationContext
      val instance =
        try {
          val masterKey =
            MasterKey.Builder(appCtx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
          EncryptedSharedPreferences.create(
            appCtx,
            PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
          )
        } catch (_: Exception) {
          // Fallback only for JVM test runners (Robolectric) without AndroidKeyStore hardware
          appCtx.getSharedPreferences("${PREFS_NAME}_fallback", Context.MODE_PRIVATE)
        }
      cachedPrefs = instance
      return instance
    }
  }

  fun hasAcceptedGitHubDisclosure(context: Context): Boolean =
    prefs(context).getBoolean(KEY_GITHUB_DISCLOSURE_ACCEPTED, false)

  fun markGitHubDisclosureAccepted(context: Context) {
    prefs(context).edit().putBoolean(KEY_GITHUB_DISCLOSURE_ACCEPTED, true).apply()
  }

  fun getBackgroundWipeTimeoutSec(context: Context): Int {
    val value = prefs(context).getInt(KEY_WIPE_TIMEOUT_SEC, DEFAULT_WIPE_TIMEOUT_SEC)
    return when (value) {
      0,
      15,
      30 -> value
      else -> DEFAULT_WIPE_TIMEOUT_SEC
    }
  }

  fun setBackgroundWipeTimeoutSec(context: Context, seconds: Int) {
    val valid =
      when (seconds) {
        0,
        15,
        30 -> seconds
        else -> DEFAULT_WIPE_TIMEOUT_SEC
      }
    prefs(context).edit().putInt(KEY_WIPE_TIMEOUT_SEC, valid).apply()
  }

  fun savePendingOAuthPkce(context: Context, state: String, codeVerifier: String) {
    prefs(context)
      .edit()
      .putString(KEY_GH_PENDING_STATE, state)
      .putString(KEY_GH_PENDING_VERIFIER, codeVerifier)
      .commit()
  }

  fun consumePendingOAuthPkce(context: Context): Pair<String, String>? {
    val p = prefs(context)
    val state = p.getString(KEY_GH_PENDING_STATE, null)?.takeIf { it.isNotBlank() }
    val verifier = p.getString(KEY_GH_PENDING_VERIFIER, null)?.takeIf { it.isNotBlank() }
    p.edit()
      .remove(KEY_GH_PENDING_STATE)
      .remove(KEY_GH_PENDING_VERIFIER)
      .apply()
    return if (state != null && verifier != null) state to verifier else null
  }

  fun clearPendingOAuthPkce(context: Context) {
    prefs(context)
      .edit()
      .remove(KEY_GH_PENDING_STATE)
      .remove(KEY_GH_PENDING_VERIFIER)
      .apply()
  }

  fun saveGitHubAuthSession(context: Context, session: GitHubAuthSession) {
    prefs(context)
      .edit()
      .putString(KEY_GH_ACCESS_TOKEN, session.accessToken)
      .putString(KEY_GH_INSTALLATION_ID, session.installationId)
      .putString(KEY_GH_USERNAME, session.username)
      .putString(KEY_GH_AVATAR_URL, session.avatarUrl)
      .apply()
  }

  fun getGitHubAuthSession(context: Context): GitHubAuthSession? {
    val p = prefs(context)
    val token = p.getString(KEY_GH_ACCESS_TOKEN, null)?.takeIf { it.isNotBlank() } ?: return null
    val username = p.getString(KEY_GH_USERNAME, null)?.takeIf { it.isNotBlank() } ?: return null
    return GitHubAuthSession(
      accessToken = token,
      installationId = p.getString(KEY_GH_INSTALLATION_ID, null)?.takeIf { it.isNotBlank() },
      username = username,
      avatarUrl = p.getString(KEY_GH_AVATAR_URL, null)?.takeIf { it.isNotBlank() },
    )
  }

  fun clearGitHubAuthSession(context: Context) {
    prefs(context)
      .edit()
      .remove(KEY_GH_ACCESS_TOKEN)
      .remove(KEY_GH_INSTALLATION_ID)
      .remove(KEY_GH_USERNAME)
      .remove(KEY_GH_AVATAR_URL)
      .remove(KEY_GH_PENDING_STATE)
      .remove(KEY_GH_PENDING_VERIFIER)
      .apply()
  }
}
