package com.shipsign.app.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.inputmethod.EditorInfo
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.ExperimentalComposeUiApi
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.InterceptPlatformTextInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.PlatformTextInputMethodRequest
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.shipsign.app.R

val StandardCardShape = RoundedCornerShape(16.dp)

/**
 * Crisp 28.dp ShipSign geometric shield-signature vector emblem drawn in the existing palette.
 */
@Composable
fun ShipSignEmblem(
  modifier: Modifier = Modifier,
  size: Dp = 28.dp,
) {
  val primary = MaterialTheme.colorScheme.primary
  val container = MaterialTheme.colorScheme.primaryContainer
  val onContainer = MaterialTheme.colorScheme.onPrimaryContainer

  Box(
    modifier = modifier
      .size(size)
      .clip(RoundedCornerShape(8.dp))
      .background(container)
      .border(1.dp, primary.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
    contentAlignment = Alignment.Center,
  ) {
    Canvas(modifier = Modifier.size(size * 0.65f)) {
      val w = this.size.width
      val h = this.size.height
      val shieldPath = Path().apply {
        moveTo(w * 0.5f, h * 0.06f)
        lineTo(w * 0.90f, h * 0.24f)
        lineTo(w * 0.84f, h * 0.68f)
        lineTo(w * 0.5f, h * 0.94f)
        lineTo(w * 0.16f, h * 0.68f)
        lineTo(w * 0.10f, h * 0.24f)
        close()
      }
      drawPath(
        path = shieldPath,
        color = primary,
        style = Stroke(width = w * 0.11f, cap = StrokeCap.Round, join = StrokeJoin.Round),
      )
      val checkPath = Path().apply {
        moveTo(w * 0.33f, h * 0.50f)
        lineTo(w * 0.46f, h * 0.64f)
        lineTo(w * 0.68f, h * 0.38f)
      }
      drawPath(
        path = checkPath,
        color = onContainer,
        style = Stroke(width = w * 0.12f, cap = StrokeCap.Round, join = StrokeJoin.Round),
      )
    }
  }
}

/**
 * Unified flagship Top App Bar:
 * - Left: optional back button + 28.dp ShipSign emblem + Space Grotesk title
 * - Right: compact "ZERO TRACE" shield pill + two 40.dp tonal icon buttons (Vault Key, CryptoCore CPU)
 *   evenly spaced by 8.dp with 48.dp touch targets and WindowInsets.statusBars padding.
 */
@Composable
fun ShipSignUnifiedTopBar(
  title: String,
  showBack: Boolean,
  isVaultActive: Boolean,
  isCryptoCoreActive: Boolean,
  onBack: () -> Unit,
  onOpenVault: () -> Unit,
  onOpenCryptoCore: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier.fillMaxWidth(),
    color = MaterialTheme.colorScheme.background,
  ) {
    Column(modifier = Modifier.windowInsetsPadding(WindowInsets.statusBars)) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .height(60.dp)
          .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        if (showBack) {
          IconButton(
            onClick = onBack,
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("top_back_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = stringResource(R.string.cd_back),
              tint = MaterialTheme.colorScheme.onBackground,
            )
          }
        } else {
          Spacer(modifier = Modifier.width(4.dp))
        }

        ShipSignEmblem(size = 28.dp)
        Spacer(modifier = Modifier.width(10.dp))

        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )

        // Compact ZERO TRACE shield pill
        Surface(
          shape = RoundedCornerShape(999.dp),
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
          modifier = Modifier.testTag("top_zero_trace_pill"),
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Shield,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.size(12.dp),
            )
            Text(
              text = stringResource(R.string.badge_zero_trace),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
              maxLines = 1,
            )
          }
        }

        Spacer(modifier = Modifier.width(8.dp))

        TonalTopBarIconButton(
          icon = Icons.Filled.Key,
          contentDescription = stringResource(R.string.cd_vault),
          selected = isVaultActive,
          onClick = onOpenVault,
          testTag = "home_vault_button",
        )

        Spacer(modifier = Modifier.width(4.dp))

        TonalTopBarIconButton(
          icon = Icons.Filled.Memory,
          contentDescription = stringResource(R.string.cd_crypto_core),
          selected = isCryptoCoreActive,
          onClick = onOpenCryptoCore,
          testTag = "top_crypto_core_button",
        )
      }
      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f))
    }
  }
}

@Composable
private fun TonalTopBarIconButton(
  icon: ImageVector,
  contentDescription: String,
  selected: Boolean,
  onClick: () -> Unit,
  testTag: String,
) {
  IconButton(
    onClick = onClick,
    modifier = Modifier
      .size(48.dp)
      .testTag(testTag),
  ) {
    Box(
      modifier = Modifier
        .size(40.dp)
        .clip(RoundedCornerShape(12.dp))
        .background(
          if (selected) {
            MaterialTheme.colorScheme.primaryContainer
          } else {
            MaterialTheme.colorScheme.surface
          }
        )
        .border(
          width = 1.dp,
          color = if (selected) {
            MaterialTheme.colorScheme.primary
          } else {
            MaterialTheme.colorScheme.outlineVariant
          },
          shape = RoundedCornerShape(12.dp),
        ),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = icon,
        contentDescription = contentDescription,
        tint = if (selected) {
          MaterialTheme.colorScheme.onPrimaryContainer
        } else {
          MaterialTheme.colorScheme.onSurfaceVariant
        },
        modifier = Modifier.size(20.dp),
      )
    }
  }
}

/**
 * Connected 3-step horizontal workflow rail displayed directly below the TopAppBar on the
 * signing flow: 1. Input -> 2. Keystore -> 3. Sign & Export.
 *
 * @param activeStep 1 = Input, 2 = Keystore, 3 = Sign & Export
 */
@Composable
fun WorkflowStepRail(
  activeStep: Int,
  modifier: Modifier = Modifier,
) {
  val steps = listOf(
    Triple(1, stringResource(R.string.rail_step_input), Icons.Filled.FolderZip),
    Triple(2, stringResource(R.string.rail_step_keystore), Icons.Filled.Key),
    Triple(3, stringResource(R.string.rail_step_sign), Icons.Filled.Draw),
  )

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("workflow_step_rail"),
    color = MaterialTheme.colorScheme.surface,
  ) {
    Column {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        steps.forEachIndexed { idx, (stepNum, label, icon) ->
          val completed = stepNum < activeStep
          val active = stepNum == activeStep

          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp),
            modifier = Modifier.width(84.dp),
          ) {
            Box(
              modifier = Modifier
                .size(32.dp)
                .clip(CircleShape)
                .background(
                  when {
                    completed -> MaterialTheme.colorScheme.primary
                    active -> MaterialTheme.colorScheme.primaryContainer
                    else -> MaterialTheme.colorScheme.surfaceContainerLow
                  }
                )
                .border(
                  width = if (active) 1.5.dp else 1.dp,
                  color = when {
                    completed || active -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.outlineVariant
                  },
                  shape = CircleShape,
                ),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = if (completed) Icons.Filled.Check else icon,
                contentDescription = null,
                tint = when {
                  completed -> MaterialTheme.colorScheme.onPrimary
                  active -> MaterialTheme.colorScheme.onPrimaryContainer
                  else -> MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.size(18.dp),
              )
            }
            Text(
              text = "$stepNum. $label",
              style = MaterialTheme.typography.labelSmall,
              color = when {
                active -> MaterialTheme.colorScheme.onSurface
                completed -> MaterialTheme.colorScheme.primary
                else -> MaterialTheme.colorScheme.onSurfaceVariant
              },
              textAlign = TextAlign.Center,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }

          if (idx < steps.lastIndex) {
            Box(
              modifier = Modifier
                .weight(1f)
                .padding(bottom = 18.dp)
                .height(2.dp)
                .background(
                  if (stepNum < activeStep) {
                    MaterialTheme.colorScheme.primary
                  } else {
                    MaterialTheme.colorScheme.outlineVariant
                  }
                ),
            )
          }
        }
      }
      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f))
    }
  }
}

/**
 * Security-hardened password field with leading 20.dp icon, toggleable visibility eye button
 * (>= 48.dp touch target), disabled keyboard auto-correct, and `IME_FLAG_NO_PERSONALIZED_LEARNING`.
 */
@OptIn(ExperimentalComposeUiApi::class)
@Composable
fun PasswordTextField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  modifier: Modifier = Modifier,
  leadingIcon: ImageVector = Icons.Filled.Lock,
  imeAction: ImeAction = ImeAction.Next,
  supportingText: String? = null,
) {
  var passwordVisible by remember { mutableStateOf(false) }

  InterceptPlatformTextInput(
    interceptor = { request, nextHandler ->
      val hardenedRequest = PlatformTextInputMethodRequest { outAttributes ->
        val connection = request.createInputConnection(outAttributes)
        outAttributes.imeOptions =
          outAttributes.imeOptions or EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
        connection
      }
      nextHandler.startInputMethod(hardenedRequest)
    },
  ) {
    OutlinedTextField(
      value = value,
      onValueChange = onValueChange,
      label = { Text(label) },
      singleLine = true,
      shape = RoundedCornerShape(12.dp),
      leadingIcon = {
        Icon(
          imageVector = leadingIcon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(20.dp),
        )
      },
      visualTransformation = if (passwordVisible) {
        VisualTransformation.None
      } else {
        PasswordVisualTransformation()
      },
      keyboardOptions = KeyboardOptions(
        capitalization = KeyboardCapitalization.None,
        autoCorrectEnabled = false,
        keyboardType = KeyboardType.Password,
        imeAction = imeAction,
      ),
      trailingIcon = {
        IconButton(
          onClick = { passwordVisible = !passwordVisible },
          modifier = Modifier.minimumInteractiveComponentSize(),
        ) {
          Icon(
            imageVector = if (passwordVisible) {
              Icons.Filled.VisibilityOff
            } else {
              Icons.Filled.Visibility
            },
            contentDescription = stringResource(R.string.cd_toggle_password),
            modifier = Modifier.size(20.dp),
          )
        }
      },
      supportingText = supportingText?.let { hint ->
        {
          Text(
            text = hint,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      },
      modifier = modifier.fillMaxWidth(),
    )
  }
}

/**
 * Auto-scrolling dark monospace terminal box displaying live cryptographic step logs.
 */
@Composable
fun TerminalLogBox(
  title: String,
  logs: List<String>,
  modifier: Modifier = Modifier,
) {
  val listState = rememberLazyListState()
  LaunchedEffect(logs.size) {
    if (logs.isNotEmpty()) {
      listState.animateScrollToItem(logs.lastIndex)
    }
  }

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("terminal_log_box"),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surfaceContainerLow,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Terminal,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(16.dp),
        )
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.secondary,
        )
      }

      LazyColumn(
        state = listState,
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(min = 96.dp, max = 220.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        itemsIndexed(logs) { index, line ->
          Text(
            text = String.format("%02d > %s", index + 1, line),
            style = MaterialTheme.typography.labelSmall,
            color = if (line.contains("Verified", ignoreCase = true) ||
              line.contains("Complete", ignoreCase = true) ||
              line.contains("Success", ignoreCase = true)
            ) {
              MaterialTheme.colorScheme.onPrimaryContainer
            } else {
              MaterialTheme.colorScheme.onSurface
            },
          )
        }
      }
    }
  }
}

/**
 * Displays SHA-256 and SHA-1 certificate fingerprints in copyable JetBrains Mono boxes.
 */
@Composable
fun FingerprintCopyCard(
  sha1: String,
  sha256: String,
  onCopied: (label: String) -> Unit,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current

  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("fingerprint_copy_card"),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      FingerprintBoxRow(
        label = stringResource(R.string.step3_sha256_label),
        value = sha256,
        buttonTag = "copy_sha256_button",
        onCopy = {
          copyPlainText(context, "SHA-256", sha256)
          onCopied("SHA-256")
        },
      )
      FingerprintBoxRow(
        label = stringResource(R.string.step3_sha1_label),
        value = sha1,
        buttonTag = "copy_sha1_button",
        onCopy = {
          copyPlainText(context, "SHA-1", sha1)
          onCopied("SHA-1")
        },
      )
    }
  }
}

@Composable
private fun FingerprintBoxRow(
  label: String,
  value: String,
  buttonTag: String,
  onCopy: () -> Unit,
) {
  Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = label,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.secondary,
      )
      OutlinedButton(
        onClick = onCopy,
        modifier = Modifier
          .height(48.dp)
          .testTag(buttonTag),
        shape = RoundedCornerShape(10.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.ContentCopy,
          contentDescription = null,
          modifier = Modifier.size(16.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = stringResource(R.string.action_copy),
          style = MaterialTheme.typography.labelMedium,
        )
      }
    }
    Surface(
      modifier = Modifier.fillMaxWidth(),
      shape = RoundedCornerShape(10.dp),
      color = MaterialTheme.colorScheme.surfaceContainerLow,
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
      Text(
        text = value,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.padding(12.dp),
      )
    }
  }
}

private fun copyPlainText(context: Context, label: String, text: String) {
  val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
  cm.setPrimaryClip(ClipData.newPlainText(label, text))
}

/**
 * Shown once before initiating GitHub App OAuth (PKCE) to clarify the zero-keystore boundary.
 */
@Composable
fun GitHubDisclosureDialog(
  onConfirm: () -> Unit,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    modifier = Modifier.testTag("github_disclosure_dialog"),
    containerColor = MaterialTheme.colorScheme.surface,
    shape = StandardCardShape,
    icon = {
      Icon(
        imageVector = Icons.Filled.CloudQueue,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.secondary,
      )
    },
    title = {
      Text(
        text = stringResource(R.string.github_disclosure_title),
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
      )
    },
    text = {
      Text(
        text = stringResource(R.string.github_disclosure_body),
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    },
    confirmButton = {
      Button(
        onClick = onConfirm,
        modifier = Modifier
          .height(48.dp)
          .testTag("github_disclosure_confirm_button"),
        shape = RoundedCornerShape(12.dp),
      ) {
        Text(text = stringResource(R.string.github_disclosure_confirm))
      }
    },
    dismissButton = {
      TextButton(
        onClick = onDismiss,
        modifier = Modifier
          .height(48.dp)
          .testTag("github_disclosure_cancel_button"),
      ) {
        Text(text = stringResource(R.string.action_cancel))
      }
    },
  )
}
