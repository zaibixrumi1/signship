package com.shipsign.app.core.security

import android.content.Context
import android.os.Environment
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.io.FileOutputStream
import java.security.SecureRandom
import java.util.Arrays
import java.util.UUID
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

data class ZeroTraceSnapshot(
  val activeSessionId: String = "",
  val activeSessionPath: String = "",
  val filesWipedCount: Long = 0L,
  val bytesWipedTotal: Long = 0L,
  val lastWipeTimestampMs: Long? = null,
  val isSandboxClean: Boolean = true,
)

data class ZeroTraceAuditResult(
  val passed: Boolean,
  val bytesWrittenAndShredded: Int,
  val charsWipedCount: Int,
  val durationMs: Long,
  val residualFilesFound: Int,
)

/**
 * Enforces strict zero-trace ephemeral storage and memory hygiene.
 *
 * Every scratch file created during inspection, key generation, signing, or cloud packaging lives
 * strictly inside `cacheDir/shipsign_ephemeral/<sessionUuid>/`. Public exports in
 * `Downloads/ShipSign/` are never modified or deleted by wipe operations.
 */
object ZeroTraceManager {

  private const val EPHEMERAL_ROOT_DIR = "shipsign_ephemeral"
  private const val SHRED_BUFFER_BYTES = 64 * 1024
  const val PUBLIC_EXPORT_SUBDIR = "ShipSign"

  private val lock = ReentrantLock()
  private val secureRandom = SecureRandom()

  @Volatile private var currentSessionId: String? = null

  private val _snapshot = MutableStateFlow(ZeroTraceSnapshot())
  val snapshot: StateFlow<ZeroTraceSnapshot> = _snapshot.asStateFlow()

  fun getEphemeralRoot(context: Context): File {
    val root = File(context.applicationContext.cacheDir, EPHEMERAL_ROOT_DIR)
    if (!root.exists()) {
      root.mkdirs()
    }
    return root
  }

  /** Returns the public Downloads/ShipSign directory reference (never wiped by ZeroTraceManager). */
  fun getPublicDownloadsDir(): File {
    val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
    return File(downloads, PUBLIC_EXPORT_SUBDIR)
  }

  /**
   * Returns the active ephemeral session directory, creating a fresh UUID folder if none is active.
   */
  fun createOrGetSessionDir(context: Context): File =
    lock.withLock {
      val root = getEphemeralRoot(context)
      val sessionId = currentSessionId ?: UUID.randomUUID().toString().also { currentSessionId = it }
      val sessionDir = File(root, sessionId)
      if (!sessionDir.exists()) {
        sessionDir.mkdirs()
      }
      refreshSnapshotLocked(sessionDir)
      sessionDir
    }

  /** Allocates a unique scratch file inside the current ephemeral session directory. */
  fun allocateTempFile(context: Context, prefix: String, suffix: String): File =
    lock.withLock {
      val sessionDir = createOrGetSessionDir(context)
      val safePrefix = prefix.replace(Regex("[^a-zA-Z0-9._-]"), "_")
      val file = File(sessionDir, "${safePrefix}_${UUID.randomUUID().toString().take(8)}$suffix")
      refreshSnapshotLocked(sessionDir)
      file
    }

  /**
   * Overwrites the entire length of [file] with cryptographically strong random bytes, flushes to
   * storage where supported, and unlinks the file.
   */
  fun secureDeleteFile(file: File): Boolean {
    if (!file.exists()) return true
    if (file.isDirectory) return secureDeleteDirectory(file)

    val originalLength = file.length()
    var bytesOverwritten = 0L

    if (originalLength > 0L) {
      val buffer = ByteArray(SHRED_BUFFER_BYTES)
      try {
        FileOutputStream(file, false).use { fos ->
          var remaining = originalLength
          while (remaining > 0L) {
            val chunk = minOf(remaining, buffer.size.toLong()).toInt()
            secureRandom.nextBytes(buffer)
            fos.write(buffer, 0, chunk)
            remaining -= chunk
            bytesOverwritten += chunk
          }
          fos.flush()
          runCatching { fos.fd.sync() }
        }
      } catch (_: Exception) {
        // Proceed with unlink even if overwrite stream fails on a partially written file
      } finally {
        wipeByteArray(buffer)
      }
    }

    val deleted = file.delete()
    if (deleted || !file.exists()) {
      _snapshot.update { current ->
        current.copy(
          filesWipedCount = current.filesWipedCount + 1L,
          bytesWipedTotal = current.bytesWipedTotal + maxOf(originalLength, bytesOverwritten),
          lastWipeTimestampMs = System.currentTimeMillis(),
        )
      }
    }
    return !file.exists()
  }

  /** Post-order traversal shredding all regular files before deleting directories. */
  fun secureDeleteDirectory(dir: File): Boolean {
    if (!dir.exists()) return true
    var allCleared = true
    dir.walkBottomUp().forEach { entry ->
      if (entry.isFile) {
        if (!secureDeleteFile(entry)) {
          allCleared = false
        }
      } else if (entry.isDirectory) {
        if (!entry.delete() && entry.exists()) {
          allCleared = false
        }
      }
    }
    return allCleared && !dir.exists()
  }

  /** Zeroes out sensitive [CharArray] secrets (passwords, GitHub OAuth tokens) in RAM. */
  fun wipeCharArray(chars: CharArray?) {
    if (chars != null) {
      Arrays.fill(chars, '\u0000')
    }
  }

  /** Zeroes out sensitive [ByteArray] secrets (DER keys, digests, buffers) in RAM. */
  fun wipeByteArray(bytes: ByteArray?) {
    if (bytes != null) {
      Arrays.fill(bytes, 0.toByte())
    }
  }

  /**
   * Securely shreds only the current active session directory and rotates to a clean UUID session.
   */
  fun nukeCurrentSession(context: Context) {
    lock.withLock {
      val root = File(context.applicationContext.cacheDir, EPHEMERAL_ROOT_DIR)
      val activeId = currentSessionId
      if (activeId != null) {
        val activeDir = File(root, activeId)
        if (activeDir.exists()) {
          secureDeleteDirectory(activeDir)
        }
      }
      currentSessionId = UUID.randomUUID().toString()
      val newSessionDir = File(root, currentSessionId!!).apply { mkdirs() }
      _snapshot.update { current ->
        current.copy(
          activeSessionId = currentSessionId!!,
          activeSessionPath = newSessionDir.absolutePath,
          lastWipeTimestampMs = System.currentTimeMillis(),
          isSandboxClean = true,
        )
      }
    }
  }

  /**
   * Synchronously shreds EVERY file and folder inside `cacheDir/shipsign_ephemeral/` and resets
   * session state. Safe to invoke from `Application.onCreate`, `ProcessLifecycleOwner.onStop`, and
   * `Thread.UncaughtExceptionHandler`. Never touches `Downloads/ShipSign/`.
   */
  fun nukeAllSync(context: Context) {
    lock.withLock {
      val root = File(context.applicationContext.cacheDir, EPHEMERAL_ROOT_DIR)
      if (root.exists()) {
        root.listFiles()?.forEach { child ->
          secureDeleteDirectory(child)
        }
      } else {
        root.mkdirs()
      }
      val freshId = UUID.randomUUID().toString()
      currentSessionId = freshId
      val freshDir = File(root, freshId).apply { mkdirs() }
      _snapshot.update { current ->
        current.copy(
          activeSessionId = freshId,
          activeSessionPath = freshDir.absolutePath,
          lastWipeTimestampMs = System.currentTimeMillis(),
          isSandboxClean = true,
        )
      }
    }
  }

  /**
   * Performs a live cryptographic shred self-test inside the ephemeral sandbox: writes 4096 random
   * bytes and a sensitive CharArray, verifies disk presence, shreds both, and confirms zero trace.
   */
  fun runZeroTraceSelfTest(context: Context): ZeroTraceAuditResult =
    lock.withLock {
      val startNs = System.nanoTime()
      val sessionDir = createOrGetSessionDir(context)
      val probeFile = File(sessionDir, "zt_audit_${UUID.randomUUID().toString().take(8)}.tmp")
      val probeSecret = charArrayOf('S', 'h', 'i', 'p', 'S', 'i', 'g', 'n', '#', '9', '9')
      val payloadSize = 4096
      val randomPayload = ByteArray(payloadSize).apply { secureRandom.nextBytes(this) }

      return try {
        FileOutputStream(probeFile, false).use { it.write(randomPayload) }
        val existedBeforeShred = probeFile.exists() && probeFile.length() == payloadSize.toLong()
        val deleted = secureDeleteFile(probeFile)
        wipeCharArray(probeSecret)
        wipeByteArray(randomPayload)

        val secretZeroed = probeSecret.all { it == '\u0000' }
        val residual = sessionDir.listFiles()?.count { it.name == probeFile.name } ?: 0
        refreshSnapshotLocked(sessionDir)

        val durationMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
        ZeroTraceAuditResult(
          passed = existedBeforeShred && deleted && secretZeroed && residual == 0,
          bytesWrittenAndShredded = payloadSize,
          charsWipedCount = probeSecret.size,
          durationMs = durationMs,
          residualFilesFound = residual,
        )
      } catch (_: Exception) {
        secureDeleteFile(probeFile)
        wipeCharArray(probeSecret)
        wipeByteArray(randomPayload)
        val durationMs = ((System.nanoTime() - startNs) / 1_000_000L).coerceAtLeast(1L)
        ZeroTraceAuditResult(
          passed = false,
          bytesWrittenAndShredded = 0,
          charsWipedCount = probeSecret.size,
          durationMs = durationMs,
          residualFilesFound = sessionDir.listFiles()?.size ?: 0,
        )
      }
    }

  private fun refreshSnapshotLocked(sessionDir: File) {
    val fileCount = sessionDir.listFiles()?.size ?: 0
    _snapshot.update { current ->
      current.copy(
        activeSessionId = currentSessionId ?: "",
        activeSessionPath = sessionDir.absolutePath,
        isSandboxClean = fileCount == 0,
      )
    }
  }
}
