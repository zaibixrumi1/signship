package com.shipsign.app.core.security

import com.shipsign.app.domain.model.ImportedKeystoreConfig
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.domain.model.ValidatedKeystoreCredentials
import org.bouncycastle.jce.provider.BouncyCastleProvider
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyStore
import java.security.PrivateKey
import java.security.UnrecoverableKeyException
import java.security.cert.X509Certificate
import java.util.Locale

class WrongPasswordException(
  message: String,
  cause: Throwable? = null,
) : Exception(message, cause)

class WrongAliasException(
  message: String,
  val availableAliases: List<String> = emptyList(),
  cause: Throwable? = null,
) : Exception(message, cause)

class UnsupportedKeystoreException(
  message: String,
  cause: Throwable? = null,
) : Exception(message, cause)

/**
 * Inspects the magic header bytes of uploaded keystore files without loading the whole file into
 * RAM, and validates store password, alias, and key password independently.
 */
object KeystoreDetector {

  private const val HEADER_PEEK_SIZE = 16
  private const val JKS_MAGIC = 0xFEEDFEED.toInt()
  private const val BKS_SALT_LENGTH = 20

  /**
   * Reads only the first 16 bytes of [keystoreFile] to detect JKS, PKCS12, or BKS format.
   */
  fun detectFormat(keystoreFile: File): KeystoreFormat {
    if (!keystoreFile.exists() || !keystoreFile.isFile || keystoreFile.length() < 8L) {
      return KeystoreFormat.UNKNOWN
    }
    val header = ByteArray(HEADER_PEEK_SIZE)
    return try {
      val bytesRead = FileInputStream(keystoreFile).use { fis ->
        var total = 0
        while (total < header.size) {
          val n = fis.read(header, total, header.size - total)
          if (n == -1) break
          total += n
        }
        total
      }
      if (bytesRead < 8) return KeystoreFormat.UNKNOWN

      val bb = ByteBuffer.wrap(header, 0, bytesRead).order(ByteOrder.BIG_ENDIAN)
      val firstInt = bb.getInt(0)
      val secondInt = bb.getInt(4)

      when {
        firstInt == JKS_MAGIC -> KeystoreFormat.JKS
        header[0] == 0x30.toByte() -> KeystoreFormat.PKCS12
        (firstInt == 1 || firstInt == 2) && secondInt == BKS_SALT_LENGTH -> KeystoreFormat.BKS
        else -> KeystoreFormat.UNKNOWN
      }
    } catch (_: Exception) {
      KeystoreFormat.UNKNOWN
    } finally {
      ZeroTraceManager.wipeByteArray(header)
    }
  }

  /**
   * Opens the keystore with [ImportedKeystoreConfig.storePassword], verifies
   * [ImportedKeystoreConfig.keyAlias], and retrieves the private key independently with
   * [ImportedKeystoreConfig.keyPassword].
   *
   * Throws [WrongPasswordException], [WrongAliasException], or [UnsupportedKeystoreException].
   */
  fun validateKeystoreCredentials(config: ImportedKeystoreConfig): ValidatedKeystoreCredentials {
    val format = if (config.detectedFormat == KeystoreFormat.UNKNOWN) {
      detectFormat(config.tempKeystoreFile)
    } else {
      config.detectedFormat
    }

    if (format == KeystoreFormat.UNKNOWN) {
      throw UnsupportedKeystoreException("Unrecognized keystore header. Expected JKS, PKCS12, or BKS.")
    }

    if (format == KeystoreFormat.JKS) {
      return validateJksCredentials(config)
    }

    val keyStore = openKeyStoreInstance(format)
    try {
      FileInputStream(config.tempKeystoreFile).use { fis ->
        keyStore.load(fis, config.storePassword)
      }
    } catch (e: Exception) {
      if (isPasswordFailure(e)) {
        throw WrongPasswordException("Incorrect keystore store password", e)
      }
      throw UnsupportedKeystoreException("Unable to parse ${format.name} keystore: ${e.message}", e)
    }

    val aliases = keyStore.aliases().toList()
    val resolvedAlias = resolveAlias(keyStore, aliases, config.keyAlias)
      ?: throw WrongAliasException(
        message = "Alias '${config.keyAlias}' not found in keystore",
        availableAliases = aliases,
      )

    val recoveredKey = try {
      keyStore.getKey(resolvedAlias, config.keyPassword)
    } catch (e: UnrecoverableKeyException) {
      throw WrongPasswordException("Incorrect key password for alias '$resolvedAlias'", e)
    } catch (e: Exception) {
      if (isPasswordFailure(e)) {
        throw WrongPasswordException("Incorrect key password for alias '$resolvedAlias'", e)
      }
      throw UnsupportedKeystoreException("Failed to recover key for alias '$resolvedAlias'", e)
    }

    if (recoveredKey !is PrivateKey) {
      throw WrongAliasException(
        message = "Alias '$resolvedAlias' does not hold a private signing key",
        availableAliases = aliases,
      )
    }

    val chain = keyStore.getCertificateChain(resolvedAlias)
      ?.mapNotNull { it as? X509Certificate }
      .orEmpty()
      .ifEmpty {
        listOfNotNull(keyStore.getCertificate(resolvedAlias) as? X509Certificate)
      }

    if (chain.isEmpty()) {
      throw UnsupportedKeystoreException("No X.509 certificate chain found for alias '$resolvedAlias'")
    }

    return ValidatedKeystoreCredentials(
      format = format,
      alias = resolvedAlias,
      privateKey = recoveredKey,
      certificateChain = chain,
    )
  }

  private fun validateJksCredentials(config: ImportedKeystoreConfig): ValidatedKeystoreCredentials {
    val loaded = JksKeyStoreCodec.loadJks(config.tempKeystoreFile, config.storePassword)
    val resolvedAlias = loaded.resolveAlias(config.keyAlias)
      ?: throw WrongAliasException(
        message = "Alias '${config.keyAlias}' not found in JKS keystore",
        availableAliases = loaded.aliases,
      )
    val (privateKey, chain) = loaded.getPrivateKeyAndChain(resolvedAlias, config.keyPassword)
    if (chain.isEmpty()) {
      throw UnsupportedKeystoreException("No X.509 certificate chain found for alias '$resolvedAlias'")
    }
    return ValidatedKeystoreCredentials(
      format = KeystoreFormat.JKS,
      alias = resolvedAlias,
      privateKey = privateKey,
      certificateChain = chain,
    )
  }

  private fun openKeyStoreInstance(format: KeystoreFormat): KeyStore {
    return when (format) {
      KeystoreFormat.BKS -> {
        runCatching { KeyStore.getInstance("BKS", BouncyCastleProvider.PROVIDER_NAME) }
          .getOrElse {
            runCatching { KeyStore.getInstance("BKS") }
              .getOrElse { e -> throw UnsupportedKeystoreException("BKS KeyStore provider unavailable", e) }
          }
      }
      KeystoreFormat.PKCS12 -> {
        runCatching { KeyStore.getInstance("PKCS12") }
          .getOrElse {
            runCatching { KeyStore.getInstance("PKCS12", BouncyCastleProvider.PROVIDER_NAME) }
              .getOrElse { e -> throw UnsupportedKeystoreException("PKCS12 KeyStore provider unavailable", e) }
          }
      }
      KeystoreFormat.JKS -> KeyStore.getInstance("JKS")
      KeystoreFormat.UNKNOWN -> throw UnsupportedKeystoreException("Unknown keystore format")
    }
  }

  private fun resolveAlias(
    keyStore: KeyStore,
    aliases: List<String>,
    requestedAlias: String,
  ): String? {
    if (requestedAlias.isBlank()) return null
    if (keyStore.containsAlias(requestedAlias)) return requestedAlias
    val lower = requestedAlias.lowercase(Locale.ROOT)
    return aliases.firstOrNull { it.lowercase(Locale.ROOT) == lower }
  }

  private fun isPasswordFailure(error: Throwable): Boolean {
    var current: Throwable? = error
    while (current != null) {
      if (current is UnrecoverableKeyException) return true
      val msg = current.message?.lowercase(Locale.US).orEmpty()
      if (
        msg.contains("password") ||
          msg.contains("mac") ||
          msg.contains("hmac") ||
          msg.contains("tampered") ||
          msg.contains("checksum") ||
          msg.contains("integrity") ||
          msg.contains("unrecoverable") ||
          (current is IOException && msg.contains("keystore"))
      ) {
        return true
      }
      current = current.cause
    }
    return false
  }
}
