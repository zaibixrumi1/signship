package com.shipsign.app.core.engine

import com.shipsign.app.core.security.ZeroTraceManager
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FilterOutputStream
import java.io.OutputStream
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Aligns uncompressed (`STORED`) APK entries to 4-byte boundaries and `.so` native shared
 * libraries to 16KB (`16384` byte) page boundaries for Android 15/16 compatibility prior to
 * `apksigner` invocation.
 *
 * Uses the native NDK C++ JNI aligner when loaded on-device, falling back seamlessly to a
 * byte-exact streaming Kotlin ZIP aligner.
 */
object ZipAlignEngine {

  private const val DEFAULT_ALIGNMENT = 4
  private const val SHARED_LIB_PAGE_ALIGNMENT = 16_384
  private const val STREAM_BUFFER_SIZE = 64 * 1024

  private val nativeLoaded: Boolean by lazy {
    runCatching {
      System.loadLibrary("shipsign_zipalign")
      true
    }.getOrDefault(false)
  }

  external fun nativeAlignApk(
    inputPath: String,
    outputPath: String,
    alignment: Int,
    pageAlignSharedLibs: Boolean,
  ): Int

  fun alignApk(
    inputApk: File,
    outputApk: File,
    alignment: Int = DEFAULT_ALIGNMENT,
    pageAlignSharedLibs: Boolean = true,
  ): Boolean {
    if (!inputApk.exists() || !inputApk.isFile) {
      throw IllegalArgumentException("Input APK does not exist")
    }

    if (nativeLoaded) {
      val nativeCode = runCatching {
        nativeAlignApk(
          inputPath = inputApk.absolutePath,
          outputPath = outputApk.absolutePath,
          alignment = alignment,
          pageAlignSharedLibs = pageAlignSharedLibs,
        )
      }.getOrDefault(-1)

      if (nativeCode == 0 && outputApk.exists() && outputApk.length() > 0L) {
        return true
      }
      ZeroTraceManager.secureDeleteFile(outputApk)
    }

    return alignApkKotlinFallback(
      inputApk = inputApk,
      outputApk = outputApk,
      alignment = alignment,
      pageAlignSharedLibs = pageAlignSharedLibs,
    )
  }

  internal fun alignApkKotlinFallback(
    inputApk: File,
    outputApk: File,
    alignment: Int = DEFAULT_ALIGNMENT,
    pageAlignSharedLibs: Boolean = true,
  ): Boolean {
    val buffer = ByteArray(STREAM_BUFFER_SIZE)
    return try {
      ZipFile(inputApk).use { zipFile ->
        val countingOut = CountingOutputStream(BufferedOutputStream(FileOutputStream(outputApk, false), STREAM_BUFFER_SIZE))
        ZipOutputStream(countingOut).use { zos ->
          val entries = zipFile.entries()
          while (entries.hasMoreElements()) {
            val sourceEntry = entries.nextElement()
            val entryName = sourceEntry.name
            val nameBytes = entryName.toByteArray(Charsets.UTF_8)

            zos.flush()
            val locStartOffset = countingOut.bytesWritten

            val outEntry = ZipEntry(entryName).apply {
              if (sourceEntry.time > 0L) {
                time = sourceEntry.time
              }
              if (sourceEntry.isDirectory) {
                method = ZipEntry.STORED
                size = 0L
                compressedSize = 0L
                crc = 0L
              } else if (
                sourceEntry.method == ZipEntry.STORED &&
                  sourceEntry.size >= 0L &&
                  sourceEntry.compressedSize >= 0L &&
                  sourceEntry.crc >= 0L
              ) {
                method = ZipEntry.STORED
                size = sourceEntry.size
                compressedSize = sourceEntry.compressedSize
                crc = sourceEntry.crc

                val requiredAlign = when {
                  sourceEntry.size == 0L -> 1
                  pageAlignSharedLibs && entryName.lowercase(Locale.US).endsWith(".so") -> SHARED_LIB_PAGE_ALIGNMENT
                  alignment > 1 -> alignment
                  else -> 1
                }

                if (requiredAlign > 1) {
                  val unpaddedDataOffset = locStartOffset + 30L + nameBytes.size.toLong()
                  val remainder = (unpaddedDataOffset % requiredAlign).toInt()
                  val padBytes = if (remainder == 0) 0 else (requiredAlign - remainder)
                  extra = if (padBytes > 0) ByteArray(padBytes) else null
                } else {
                  extra = null
                }
              } else {
                method = ZipEntry.DEFLATED
                extra = null
              }
            }

            zos.putNextEntry(outEntry)
            if (!sourceEntry.isDirectory) {
              zipFile.getInputStream(sourceEntry).use { input ->
                while (true) {
                  val read = input.read(buffer)
                  if (read == -1) break
                  zos.write(buffer, 0, read)
                }
              }
            }
            zos.closeEntry()
            zos.flush()
          }
          zos.finish()
          zos.flush()
        }
      }
      true
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(outputApk)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  private class CountingOutputStream(out: OutputStream) : FilterOutputStream(out) {
    var bytesWritten: Long = 0L
      private set

    override fun write(b: Int) {
      out.write(b)
      bytesWritten += 1L
    }

    override fun write(b: ByteArray, off: Int, len: Int) {
      out.write(b, off, len)
      bytesWritten += len.toLong()
    }
  }
}
