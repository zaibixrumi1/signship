package com.shipsign.app.ui.screens.step1

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shipsign.app.R
import com.shipsign.app.core.github.BuildOutputFormat
import com.shipsign.app.core.github.CloudBuildStage
import com.shipsign.app.core.github.CloudBuildState
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.ui.CloudBuildUiState
import com.shipsign.app.ui.InspectorUiState
import com.shipsign.app.ui.components.GitHubDisclosureDialog
import com.shipsign.app.ui.components.StandardCardShape
import java.util.Locale

@Composable
fun SelectFileScreen(
  inspectorState: InspectorUiState,
  cloudBuildState: CloudBuildUiState,
  showGitHubDisclosureDialog: Boolean,
  onSelectCloudFormat: (BuildOutputFormat) -> Unit,
  onUriPicked: (Uri) -> Unit,
  onClearSelectedFile: () -> Unit,
  onStripExistingSignature: () -> Unit,
  onLeaveAlreadySigned: () -> Unit,
  onConnectGitHub: () -> Unit,
  onDisconnectGitHub: () -> Unit,
  onConfirmGitHubDisclosure: () -> Unit,
  onDismissGitHubDisclosure: () -> Unit,
  onStartCloudBuild: () -> Unit,
  onCancelCloudBuild: () -> Unit,
  onContinueToKeystore: () -> Unit,
  onConsumeAutoAdvance: () -> Unit = {},
  modifier: Modifier = Modifier,
) {
  val universalPicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument(),
  ) { uri ->
    if (uri != null) {
      onUriPicked(uri)
    }
  }

  val target = inspectorState.targetFile
  val isSignableBinary = target != null &&
    (target.binaryType == ResolvedBinaryType.APK || target.binaryType == ResolvedBinaryType.AAB)
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  LaunchedEffect(inspectorState.pendingAdvanceToKeystore) {
    if (inspectorState.pendingAdvanceToKeystore) {
      onConsumeAutoAdvance()
      onContinueToKeystore()
    }
  }

  if (showGitHubDisclosureDialog) {
    GitHubDisclosureDialog(
      onConfirm = onConfirmGitHubDisclosure,
      onDismiss = onDismissGitHubDisclosure,
    )
  }

  if (isSignableBinary && target!!.isAlreadySigned && !inspectorState.isProcessing) {
    AlreadySignedWarningDialog(
      fileName = target.originalName,
      onSignAgainWithMyKey = onStripExistingSignature,
      onLeaveIt = onLeaveAlreadySigned,
    )
  }

  Box(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .testTag("select_file_lazy_column"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Clean Universal Drop Zone Card
      item {
        DropZoneCard(
          enabled = !inspectorState.isProcessing && !cloudBuildState.isActive,
          onClick = { universalPicker.launch(arrayOf("*/*")) },
        )
      }

      item {
        AnimatedVisibility(visible = inspectorState.isProcessing) {
          Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = StandardCardShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          ) {
            Row(
              modifier = Modifier.padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
              Text(
                text = stringResource(R.string.step1_inspecting),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
              )
            }
          }
        }
      }

      item {
        AnimatedVisibility(visible = inspectorState.errorMessage != null) {
          inspectorState.errorMessage?.let { error ->
            Surface(
              modifier = Modifier
                .fillMaxWidth()
                .testTag("step1_error_banner"),
              shape = StandardCardShape,
              color = MaterialTheme.colorScheme.errorContainer,
            ) {
              Row(
                modifier = Modifier.padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = Icons.Filled.Warning,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.onErrorContainer,
                  modifier = Modifier.size(20.dp),
                )
                Text(
                  text = error,
                  style = MaterialTheme.typography.bodyMedium,
                  color = MaterialTheme.colorScheme.onErrorContainer,
                )
              }
            }
          }
        }
      }

      if (target != null && target.binaryType != ResolvedBinaryType.INVALID) {
        item {
          InspectionResultCard(
            target = target,
            canClear = !inspectorState.isProcessing && !cloudBuildState.isActive,
            onClear = onClearSelectedFile,
          )
        }

        if (target.binaryType == ResolvedBinaryType.SOURCE_CODE_PROJECT) {
          item {
            GitHubCloudBuildCard(
              selectedFormat = inspectorState.selectedOutputFormat,
              cloudBuildState = cloudBuildState,
              onSelectFormat = onSelectCloudFormat,
              onConnectGitHub = onConnectGitHub,
              onDisconnectGitHub = onDisconnectGitHub,
              onStartCloudBuild = onStartCloudBuild,
              onCancelBuild = onCancelCloudBuild,
            )
          }
        } else if (isSignableBinary && !target.isAlreadySigned) {
          item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
              AnimatedVisibility(visible = cloudBuildState.buildState is CloudBuildState.ReadyForOfflineSigning) {
                Surface(
                  modifier = Modifier
                    .fillMaxWidth()
                    .testTag("step1_cloud_ready_banner"),
                  shape = StandardCardShape,
                  color = MaterialTheme.colorScheme.primaryContainer,
                  border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
                ) {
                  Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    Icon(
                      imageVector = Icons.Filled.Verified,
                      contentDescription = null,
                      tint = MaterialTheme.colorScheme.onPrimaryContainer,
                      modifier = Modifier.size(20.dp),
                    )
                    Text(
                      text = stringResource(R.string.step1_cloud_ready),
                      style = MaterialTheme.typography.labelLarge,
                      color = MaterialTheme.colorScheme.onPrimaryContainer,
                    )
                  }
                }
              }

              Button(
                onClick = onContinueToKeystore,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(52.dp)
                  .testTag("step1_continue_keystore_button"),
                shape = RoundedCornerShape(12.dp),
              ) {
                Text(
                  text = stringResource(R.string.step1_continue_keystore),
                  style = MaterialTheme.typography.labelLarge,
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                  contentDescription = null,
                  modifier = Modifier.size(20.dp),
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun DropZoneCard(
  enabled: Boolean,
  onClick: () -> Unit,
) {
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .minimumInteractiveComponentSize()
      .testTag("select_drop_zone_card")
      .clickable(enabled = enabled, onClick = onClick),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Box(
        modifier = Modifier
          .size(56.dp)
          .background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.FileUpload,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.size(28.dp),
        )
      }

      Text(
        text = stringResource(R.string.step1_dropzone_title),
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.onSurface,
        textAlign = TextAlign.Center,
      )

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        listOf(".APK", ".AAB", ".ZIP").forEach { ext ->
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          ) {
            Text(
              text = ext,
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun InspectionResultCard(
  target: AppTargetFile,
  canClear: Boolean,
  onClear: () -> Unit,
) {
  val meta = target.sourceMetadata
  val fileIcon = when (target.binaryType) {
    ResolvedBinaryType.APK -> Icons.Filled.Android
    ResolvedBinaryType.AAB -> Icons.Filled.Inventory2
    else -> Icons.Filled.FolderZip
  }

  val frameworkValue = when (target.binaryType) {
    ResolvedBinaryType.APK -> "Android APK"
    ResolvedBinaryType.AAB -> "Play AAB"
    ResolvedBinaryType.SOURCE_CODE_PROJECT -> meta?.framework?.displayName
      ?: target.detectedStack?.toFramework()?.displayName
      ?: "Source ZIP"
    ResolvedBinaryType.INVALID -> "Invalid"
  }

  val packageIdValue = meta?.applicationId ?: "—"

  val sigLabel = if (target.binaryType == ResolvedBinaryType.SOURCE_CODE_PROJECT) {
    stringResource(R.string.step1_meta_wrapper)
  } else {
    stringResource(R.string.step1_meta_signature)
  }

  val sigValue = when (target.binaryType) {
    ResolvedBinaryType.SOURCE_CODE_PROJECT -> {
      val ver = meta?.gradleVersion
      when {
        meta?.hasGradleWrapper == true && ver != null -> "Gradle $ver"
        meta?.hasGradleWrapper == true -> "Gradle Wrapper"
        ver != null -> "Auto-Wrap $ver"
        else -> "Auto-Heal"
      }
    }
    else -> if (target.isAlreadySigned) {
      stringResource(R.string.step1_sig_signed)
    } else {
      stringResource(R.string.step1_sig_unsigned)
    }
  }

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("step1_file_summary_card"),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Icon(
          imageVector = fileIcon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(24.dp),
        )
        Text(
          text = target.originalName,
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = MaterialTheme.colorScheme.surfaceContainerLow,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
          Text(
            text = formatHumanBytes(target.sizeBytes),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.secondary,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          )
        }
        IconButton(
          onClick = onClear,
          enabled = canClear,
          modifier = Modifier
            .minimumInteractiveComponentSize()
            .testTag("clear_selected_file_button"),
        ) {
          Icon(
            imageVector = Icons.Filled.Close,
            contentDescription = stringResource(R.string.cd_clear_file),
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(20.dp),
          )
        }
      }

      HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        MetadataGridCell(
          icon = Icons.Filled.Layers,
          label = stringResource(R.string.step1_meta_framework),
          value = frameworkValue,
          modifier = Modifier.weight(1f),
        )
        MetadataGridCell(
          icon = Icons.Filled.Code,
          label = stringResource(R.string.step1_meta_package_id),
          value = packageIdValue,
          modifier = Modifier.weight(1f),
        )
        MetadataGridCell(
          icon = Icons.Filled.VerifiedUser,
          label = sigLabel,
          value = sigValue,
          isWarning = target.isAlreadySigned,
          modifier = Modifier.weight(1f),
        )
      }
    }
  }
}

@Composable
private fun MetadataGridCell(
  icon: ImageVector,
  label: String,
  value: String,
  modifier: Modifier = Modifier,
  isWarning: Boolean = false,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(10.dp),
    color = MaterialTheme.colorScheme.surfaceContainerLow,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.7f)),
  ) {
    Column(
      modifier = Modifier.padding(10.dp),
      verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
          modifier = Modifier.size(14.dp),
        )
        Text(
          text = label,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      Text(
        text = value,
        style = MaterialTheme.typography.labelMedium,
        color = if (isWarning) MaterialTheme.colorScheme.tertiary else MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun GitHubCloudBuildCard(
  selectedFormat: BuildOutputFormat,
  cloudBuildState: CloudBuildUiState,
  onSelectFormat: (BuildOutputFormat) -> Unit,
  onConnectGitHub: () -> Unit,
  onDisconnectGitHub: () -> Unit,
  onStartCloudBuild: () -> Unit,
  onCancelBuild: () -> Unit,
) {
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("step1_cloud_build_card"),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      if (!cloudBuildState.isConnected) {
        // Disconnected: minimal header + single 48dp Connect GitHub CTA
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Box(
            modifier = Modifier
              .size(40.dp)
              .background(MaterialTheme.colorScheme.secondaryContainer, RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.Code,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.secondary,
              modifier = Modifier.size(22.dp),
            )
          }
          Text(
            text = stringResource(R.string.step1_cloud_build_title),
            style = MaterialTheme.typography.titleMedium,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
          )
        }

        if (cloudBuildState.isAuthorizing) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
            Text(
              text = stringResource(R.string.step1_cloud_authorizing),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.secondary,
            )
          }
        }

        Button(
          onClick = onConnectGitHub,
          enabled = !cloudBuildState.isAuthorizing,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("github_connect_button"),
          shape = RoundedCornerShape(12.dp),
        ) {
          Icon(
            imageVector = Icons.Filled.Code,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.step1_cloud_connect_github),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      } else {
        // Connected: compact @username + green status dot + logout icon
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("github_connected_banner"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          Box(
            modifier = Modifier
              .size(10.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primary),
          )
          Text(
            text = "@${cloudBuildState.connectedUsername.orEmpty()}",
            style = MaterialTheme.typography.labelLarge,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
          )
          IconButton(
            onClick = onDisconnectGitHub,
            enabled = !cloudBuildState.isActive,
            modifier = Modifier
              .minimumInteractiveComponentSize()
              .testTag("github_disconnect_button"),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Logout,
              contentDescription = stringResource(R.string.cd_disconnect_github),
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp),
            )
          }
        }

        // 3-option segmented output selector: APK Only | AAB Only | APK + AAB
        val formats = listOf(
          BuildOutputFormat.APK_ONLY to stringResource(R.string.step1_format_apk),
          BuildOutputFormat.AAB_ONLY to stringResource(R.string.step1_format_aab),
          BuildOutputFormat.BOTH to stringResource(R.string.step1_format_both),
        )
        SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
          formats.forEachIndexed { index, (fmt, label) ->
            SegmentedButton(
              selected = selectedFormat == fmt,
              onClick = { if (!cloudBuildState.isActive) onSelectFormat(fmt) },
              shape = SegmentedButtonDefaults.itemShape(index = index, count = formats.size),
              modifier = Modifier.testTag("cloud_format_${fmt.name.lowercase(Locale.US)}"),
            ) {
              Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
            }
          }
        }

        if (cloudBuildState.isActive) {
          CloudBuildVerticalProgressTracker(
            currentStage = cloudBuildState.currentStage ?: CloudBuildStage.PREPARING_ARCHIVE,
            statusText = cloudBuildState.statusText,
            elapsedSeconds = cloudBuildState.elapsedSeconds,
          )

          OutlinedButton(
            onClick = onCancelBuild,
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("cloud_build_cancel_button"),
            shape = RoundedCornerShape(12.dp),
          ) {
            Text(text = stringResource(R.string.step1_cloud_cancel))
          }
        } else if (cloudBuildState.needsRepoAccessGrant) {
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("github_repo_access_card"),
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceContainerLow,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.tertiary),
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp),
              ) {
                Icon(
                  imageVector = Icons.Filled.AdminPanelSettings,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.tertiary,
                  modifier = Modifier.size(20.dp),
                )
                Text(
                  text = stringResource(R.string.step1_cloud_repo_access_title),
                  style = MaterialTheme.typography.titleSmall,
                  color = MaterialTheme.colorScheme.tertiary,
                )
              }
              Text(
                text = stringResource(R.string.step1_cloud_repo_access_desc),
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
              Button(
                onClick = onConnectGitHub,
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("github_grant_repo_access_button"),
                colors = ButtonDefaults.buttonColors(
                  containerColor = MaterialTheme.colorScheme.tertiary,
                  contentColor = MaterialTheme.colorScheme.onTertiary,
                ),
                shape = RoundedCornerShape(12.dp),
              ) {
                Icon(Icons.Filled.OpenInBrowser, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = stringResource(R.string.step1_cloud_grant_repo_access))
              }
            }
          }
        } else {
          Button(
            onClick = onStartCloudBuild,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("cloud_build_start_button"),
            shape = RoundedCornerShape(12.dp),
          ) {
            Icon(Icons.Filled.Build, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = stringResource(R.string.step1_cloud_build_action),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }

      cloudBuildState.translatedError?.let { err ->
        Surface(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.errorContainer,
        ) {
          Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
          ) {
            Text(
              text = err.title,
              style = MaterialTheme.typography.titleSmall,
              color = MaterialTheme.colorScheme.onErrorContainer,
            )
            Text(
              text = err.message,
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onErrorContainer,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun CloudBuildVerticalProgressTracker(
  currentStage: CloudBuildStage,
  statusText: String,
  elapsedSeconds: Int,
) {
  val visualSteps = listOf(
    "Preparing Archive",
    "Uploading Source",
    "Building Package",
    "Downloading",
  )

  val activeVisualIndex = when (currentStage) {
    CloudBuildStage.PREPARING_ARCHIVE, CloudBuildStage.CREATING_EPHEMERAL_REPO -> 0
    CloudBuildStage.PUSHING_SOURCES, CloudBuildStage.DISPATCHING_WORKFLOW -> 1
    CloudBuildStage.POLLING_BUILD -> 2
    CloudBuildStage.DOWNLOADING_AND_WIPING -> 3
  }

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("cloud_build_progress_card"),
    shape = RoundedCornerShape(12.dp),
    color = MaterialTheme.colorScheme.surfaceContainerLow,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.padding(14.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = statusText.ifBlank { currentStage.label },
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.secondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f),
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = formatElapsed(elapsedSeconds),
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
        )
      }

      visualSteps.forEachIndexed { idx, label ->
        val isCompleted = idx < activeVisualIndex
        val isActive = idx == activeVisualIndex

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          when {
            isCompleted -> {
              Icon(
                imageVector = Icons.Filled.CheckCircle,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(18.dp),
              )
            }
            isActive -> {
              CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.secondary,
              )
            }
            else -> {
              Icon(
                imageVector = Icons.Filled.RadioButtonUnchecked,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier.size(18.dp),
              )
            }
          }
          Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = when {
              isCompleted -> MaterialTheme.colorScheme.onSurface
              isActive -> MaterialTheme.colorScheme.onBackground
              else -> MaterialTheme.colorScheme.onSurfaceVariant
            },
          )
        }
      }
    }
  }
}

@Composable
private fun AlreadySignedWarningDialog(
  fileName: String,
  onSignAgainWithMyKey: () -> Unit,
  onLeaveIt: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onLeaveIt,
    modifier = Modifier.testTag("already_signed_dialog"),
    containerColor = MaterialTheme.colorScheme.surface,
    shape = StandardCardShape,
    icon = {
      Icon(
        imageVector = Icons.Filled.Warning,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.tertiary,
      )
    },
    title = {
      Text(
        text = stringResource(R.string.already_signed_title),
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.tertiary,
      )
    },
    text = {
      Text(
        text = "$fileName\n\n${stringResource(R.string.already_signed_body)}",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
      )
    },
    confirmButton = {
      Button(
        onClick = onSignAgainWithMyKey,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("already_signed_strip_button"),
        colors = ButtonDefaults.buttonColors(
          containerColor = MaterialTheme.colorScheme.tertiary,
          contentColor = MaterialTheme.colorScheme.onTertiary,
        ),
        shape = RoundedCornerShape(12.dp),
      ) {
        Text(text = stringResource(R.string.already_signed_strip_action))
      }
    },
    dismissButton = {
      TextButton(
        onClick = onLeaveIt,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("already_signed_leave_button"),
      ) {
        Text(text = stringResource(R.string.already_signed_leave_action))
      }
    },
  )
}

private fun formatElapsed(totalSec: Int): String {
  val m = totalSec / 60
  val s = totalSec % 60
  return String.format(Locale.US, "%02d:%02d", m, s)
}

private fun formatHumanBytes(bytes: Long): String {
  if (bytes < 1024L) return "$bytes B"
  val kb = bytes / 1024.0
  if (kb < 1024.0) return String.format(Locale.US, "%.1f KB", kb)
  val mb = kb / 1024.0
  return String.format(Locale.US, "%.2f MB", mb)
}
