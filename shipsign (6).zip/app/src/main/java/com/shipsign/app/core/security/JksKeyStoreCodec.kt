package com.shipsign.app.core.security

import org.bouncycastle.asn1.ASN1ObjectIdentifier
import org.bouncycastle.asn1.DERNull
import org.bouncycastle.asn1.pkcs.EncryptedPrivateKeyInfo
import org.bouncycastle.asn1.x509.AlgorithmIdentifier
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.security.KeyFactory
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.UnrecoverableKeyException
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Locale

/**
 * Pure-Kotlin implementation of the Sun/Oracle JKS v2 keystore binary format (`0xFEEDFEED`).
 *
 * Android's ART JCA runtime strips `sun.security.provider.JavaKeyStore`, so this codec ensures
 * full offline JKS reading, credential validation, and generation across Android 8.0–16+.
 */
internal object JksKeyStoreCodec {

  private const val JKS_MAGIC = 0xFEEDFEED.toInt()
  private const val JKS_VERSION_1 = 1
  private const val JKS_VERSION_2 = 2
  private const val TAG_PRIVATE_KEY = 1
  private const val TAG_TRUSTED_CERT = 2
  private const val KEY_PROTECTOR_OID = "1.3.6.1.4.1.42.2.17.1.1"
  private const val SALT_LEN = 20
  private const val DIGEST_LEN = 20
  private val JKS_WHITENING_SALT = "Mighty Aphrodite".toByteArray(Charsets.UTF_8)

  data class ParsedPrivateKeyEntry(
    val alias: String,
    val timestamp: Long,
    val encryptedKeyBytes: ByteArray,
    val certChain: List<X509Certificate>,
  )

  data class ParsedTrustedCertEntry(
    val alias: String,
    val timestamp: Long,
    val cert: X509Certificate,
  )

  data class LoadedJksStore(
    val aliases: List<String>,
    private val privateEntries: Map<String, ParsedPrivateKeyEntry>,
    private val trustedEntries: Map<String, ParsedTrustedCertEntry>,
  ) {
    fun resolveAlias(requestedAlias: String): String? {
      if (privateEntries.containsKey(requestedAlias) || trustedEntries.containsKey(requestedAlias)) {
        return requestedAlias
      }
      val lower = requestedAlias.lowercase(Locale.ROOT)
      return privateEntries.keys.firstOrNull { it.lowercase(Locale.ROOT) == lower }
        ?: trustedEntries.keys.firstOrNull { it.lowercase(Locale.ROOT) == lower }
    }

    fun getPrivateKeyAndChain(
      alias: String,
      keyPassword: CharArray,
    ): Pair<PrivateKey, List<X509Certificate>> {
      val resolved = resolveAlias(alias)
        ?: throw WrongAliasException("Alias '$alias' not found in JKS keystore", aliases)
      val entry = privateEntries[resolved]
        ?: throw WrongAliasException("Alias '$alias' is not a private key entry", aliases)
      val key = decryptKeyProtector(entry.encryptedKeyBytes, keyPassword)
      return key to entry.certChain
    }
  }

  fun loadJks(file: File, storePassword: CharArray): LoadedJksStore {
    val fileBytes = FileInputStream(file).use { it.readBytes() }
    val passwordBytes = charsToUtf16BeBytes(storePassword)
    try {
      if (fileBytes.size < 32) {
        throw UnsupportedKeystoreException("File is too small to be a valid JKS keystore")
      }
      val payloadLen = fileBytes.size - DIGEST_LEN
      val actualDigest = fileBytes.copyOfRange(payloadLen, fileBytes.size)
      val expectedDigest = computeStoreDigest(fileBytes, payloadLen, passwordBytes)
      if (!actualDigest.contentEquals(expectedDigest)) {
        throw WrongPasswordException("Incorrect JKS keystore password or tampered file")
      }

      val dis = DataInputStream(ByteArrayInputStream(fileBytes, 0, payloadLen))
      val magic = dis.readInt()
      if (magic != JKS_MAGIC) {
        throw UnsupportedKeystoreException("Invalid JKS magic header")
      }
      val version = dis.readInt()
      if (version != JKS_VERSION_1 && version != JKS_VERSION_2) {
        throw UnsupportedKeystoreException("Unsupported JKS version: $version")
      }

      val count = dis.readInt()
      if (count < 0 || count > 10_000) {
        throw UnsupportedKeystoreException("Invalid JKS entry count: $count")
      }

      val certFactory = CertificateFactory.getInstance("X.509")
      val privateEntries = LinkedHashMap<String, ParsedPrivateKeyEntry>()
      val trustedEntries = LinkedHashMap<String, ParsedTrustedCertEntry>()
      val aliases = ArrayList<String>(count)

      repeat(count) {
        val tag = dis.readInt()
        when (tag) {
          TAG_PRIVATE_KEY -> {
            val alias = dis.readUTF()
            val timestamp = dis.readLong()
            val keyLen = dis.readInt()
            if (keyLen <= 0 || keyLen > payloadLen) {
              throw IOException("Corrupt JKS key entry length")
            }
            val encKey = ByteArray(keyLen)
            dis.readFully(encKey)

            val chainLen = dis.readInt()
            if (chainLen < 0 || chainLen > 64) {
              throw IOException("Corrupt JKS certificate chain length")
            }
            val chain = ArrayList<X509Certificate>(chainLen)
            repeat(chainLen) {
              if (version == JKS_VERSION_2) {
                dis.readUTF() // certType e.g. "X.509"
              }
              val certSize = dis.readInt()
              if (certSize <= 0 || certSize > payloadLen) {
                throw IOException("Corrupt JKS certificate byte length")
              }
              val certBytes = ByteArray(certSize)
              dis.readFully(certBytes)
              val cert = certFactory.generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
              chain.add(cert)
            }
            aliases.add(alias)
            privateEntries[alias] = ParsedPrivateKeyEntry(alias, timestamp, encKey, chain)
          }

          TAG_TRUSTED_CERT -> {
            val alias = dis.readUTF()
            val timestamp = dis.readLong()
            if (version == JKS_VERSION_2) {
              dis.readUTF()
            }
            val certSize = dis.readInt()
            if (certSize <= 0 || certSize > payloadLen) {
              throw IOException("Corrupt JKS trusted certificate length")
            }
            val certBytes = ByteArray(certSize)
            dis.readFully(certBytes)
            val cert = certFactory.generateCertificate(ByteArrayInputStream(certBytes)) as X509Certificate
            aliases.add(alias)
            trustedEntries[alias] = ParsedTrustedCertEntry(alias, timestamp, cert)
          }

          else -> throw UnsupportedKeystoreException("Unknown JKS entry tag: $tag")
        }
      }

      return LoadedJksStore(aliases, privateEntries, trustedEntries)
    } finally {
      ZeroTraceManager.wipeByteArray(passwordBytes)
      ZeroTraceManager.wipeByteArray(fileBytes)
    }
  }

  fun writeJks(
    outputFile: File,
    alias: String,
    privateKey: PrivateKey,
    keyPassword: CharArray,
    certificateChain: Array<X509Certificate>,
    storePassword: CharArray,
  ) {
    val storePasswordBytes = charsToUtf16BeBytes(storePassword)
    val baos = ByteArrayOutputStream()
    val dos = DataOutputStream(baos)

    try {
      val encryptedKeyInfoBytes = encryptKeyProtector(privateKey, keyPassword)

      dos.writeInt(JKS_MAGIC)
      dos.writeInt(JKS_VERSION_2)
      dos.writeInt(1) // 1 private key entry

      dos.writeInt(TAG_PRIVATE_KEY)
      dos.writeUTF(alias.lowercase(Locale.ROOT))
      dos.writeLong(System.currentTimeMillis())
      dos.writeInt(encryptedKeyInfoBytes.size)
      dos.write(encryptedKeyInfoBytes)

      dos.writeInt(certificateChain.size)
      for (cert in certificateChain) {
        val certBytes = cert.encoded
        dos.writeUTF(cert.type)
        dos.writeInt(certBytes.size)
        dos.write(certBytes)
      }
      dos.flush()

      val payload = baos.toByteArray()
      val storeDigest = computeStoreDigest(payload, payload.size, storePasswordBytes)

      FileOutputStream(outputFile, false).use { fos ->
        fos.write(payload)
        fos.write(storeDigest)
        fos.flush()
      }
      ZeroTraceManager.wipeByteArray(payload)
      ZeroTraceManager.wipeByteArray(encryptedKeyInfoBytes)
    } finally {
      ZeroTraceManager.wipeByteArray(storePasswordBytes)
    }
  }

  private fun encryptKeyProtector(privateKey: PrivateKey, keyPassword: CharArray): ByteArray {
    val plainKey = privateKey.encoded
      ?: throw IOException("Private key encoding is null")
    val passwdBytes = charsToUtf16BeBytes(keyPassword)
    val salt = ByteArray(SALT_LEN).apply { SecureRandom().nextBytes(this) }

    try {
      val sha1 = MessageDigest.getInstance("SHA-1")
      val numRounds = (plainKey.size + DIGEST_LEN - 1) / DIGEST_LEN
      val xorKey = ByteArray(plainKey.size)
      var digest = salt
      var xorOffset = 0

      for (round in 0 until numRounds) {
        sha1.reset()
        sha1.update(passwdBytes)
        sha1.update(digest)
        digest = sha1.digest()
        val copyLen = minOf(DIGEST_LEN, plainKey.size - xorOffset)
        System.arraycopy(digest, 0, xorKey, xorOffset, copyLen)
        xorOffset += copyLen
      }

      val encrKey = ByteArray(plainKey.size)
      for (i in plainKey.indices) {
        encrKey[i] = (plainKey[i].toInt() xor xorKey[i].toInt()).toByte()
      }

      // Integrity digest over password + plaintext PKCS#8 key
      sha1.reset()
      sha1.update(passwdBytes)
      sha1.update(plainKey)
      val checkDigest = sha1.digest()

      val protectedData = ByteArray(SALT_LEN + encrKey.size + DIGEST_LEN)
      System.arraycopy(salt, 0, protectedData, 0, SALT_LEN)
      System.arraycopy(encrKey, 0, protectedData, SALT_LEN, encrKey.size)
      System.arraycopy(checkDigest, 0, protectedData, SALT_LEN + encrKey.size, DIGEST_LEN)

      val algId = AlgorithmIdentifier(ASN1ObjectIdentifier(KEY_PROTECTOR_OID), DERNull.INSTANCE)
      val epki = EncryptedPrivateKeyInfo(algId, protectedData)
      return epki.encoded
    } finally {
      ZeroTraceManager.wipeByteArray(plainKey)
      ZeroTraceManager.wipeByteArray(passwdBytes)
      ZeroTraceManager.wipeByteArray(salt)
    }
  }

  private fun decryptKeyProtector(encryptedInfoDer: ByteArray, keyPassword: CharArray): PrivateKey {
    val epki = EncryptedPrivateKeyInfo.getInstance(encryptedInfoDer)
    if (epki.encryptionAlgorithm.algorithm.id != KEY_PROTECTOR_OID) {
      throw UnsupportedKeystoreException("Unsupported JKS private key protection OID: ${epki.encryptionAlgorithm.algorithm.id}")
    }
    val protectedData = epki.encryptedData
    if (protectedData.size < SALT_LEN + DIGEST_LEN) {
      throw IOException("Corrupt JKS protected key payload")
    }

    val passwdBytes = charsToUtf16BeBytes(keyPassword)
    val salt = protectedData.copyOfRange(0, SALT_LEN)
    val encrKeyLen = protectedData.size - SALT_LEN - DIGEST_LEN
    val plainKey = ByteArray(encrKeyLen)

    try {
      val sha1 = MessageDigest.getInstance("SHA-1")
      val numRounds = (encrKeyLen + DIGEST_LEN - 1) / DIGEST_LEN
      val xorKey = ByteArray(encrKeyLen)
      var digest = salt
      var xorOffset = 0

      for (round in 0 until numRounds) {
        sha1.reset()
        sha1.update(passwdBytes)
        sha1.update(digest)
        digest = sha1.digest()
        val copyLen = minOf(DIGEST_LEN, encrKeyLen - xorOffset)
        System.arraycopy(digest, 0, xorKey, xorOffset, copyLen)
        xorOffset += copyLen
      }

      for (i in 0 until encrKeyLen) {
        plainKey[i] = (protectedData[SALT_LEN + i].toInt() xor xorKey[i].toInt()).toByte()
      }

      sha1.reset()
      sha1.update(passwdBytes)
      sha1.update(plainKey)
      val computedCheck = sha1.digest()
      val storedCheck = protectedData.copyOfRange(SALT_LEN + encrKeyLen, protectedData.size)

      if (!computedCheck.contentEquals(storedCheck)) {
        throw WrongPasswordException("Incorrect key password for JKS alias", UnrecoverableKeyException())
      }

      val spec = PKCS8EncodedKeySpec(plainKey)
      for (alg in listOf("RSA", "EC", "DSA")) {
        val recovered = runCatching { KeyFactory.getInstance(alg).generatePrivate(spec) }.getOrNull()
        if (recovered != null) return recovered
      }
      throw UnsupportedKeystoreException("Unsupported private key algorithm inside JKS entry")
    } finally {
      ZeroTraceManager.wipeByteArray(plainKey)
      ZeroTraceManager.wipeByteArray(passwdBytes)
      ZeroTraceManager.wipeByteArray(salt)
    }
  }

  private fun computeStoreDigest(
    payload: ByteArray,
    length: Int,
    passwordBytes: ByteArray,
  ): ByteArray {
    val sha1 = MessageDigest.getInstance("SHA-1")
    sha1.update(passwordBytes)
    sha1.update(JKS_WHITENING_SALT)
    sha1.update(payload, 0, length)
    return sha1.digest()
  }

  private fun charsToUtf16BeBytes(chars: CharArray): ByteArray {
    val bytes = ByteArray(chars.size * 2)
    for (i in chars.indices) {
      val code = chars[i].code
      bytes[i * 2] = (code ushr 8).toByte()
      bytes[i * 2 + 1] = (code and 0xFF).toByte()
    }
    return bytes
  }
}
