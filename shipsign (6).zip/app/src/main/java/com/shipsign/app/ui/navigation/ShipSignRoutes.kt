package com.shipsign.app.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object HomeRoute

@Serializable
data class SelectFileRoute(val initialCategoryName: String = "BUILT_APK")

@Serializable
object KeystoreChoiceRoute

@Serializable
object KeystoreImportRoute

@Serializable
object KeystoreFormatRoute

@Serializable
data class KeystoreFormRoute(val formatName: String = "JKS")

@Serializable
object KeystoreReadyRoute

@Serializable
object SignAndResultRoute

@Serializable
object VaultRoute

@Serializable
object CryptoCoreRoute
