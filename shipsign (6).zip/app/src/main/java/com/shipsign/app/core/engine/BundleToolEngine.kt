package com.shipsign.app.core.engine

import android.content.Context
import com.android.apksig.ApkSigner
import com.android.tools.build.bundletool.androidtools.Aapt2Command
import com.android.tools.build.bundletool.commands.BuildApksCommand
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.domain.model.ValidatedKeystoreCredentials
import java.io.File
import java.io.FileOutputStream
import java.nio.file.Path
import java.util.zip.ZipFile

/**
 * Converts a signed Android App Bundle (`.aab`) into a universal `.apk` using `bundletool`
 * (`BuildApksCommand` with `ApkBuildMode.UNIVERSAL`) inside the ephemeral sandbox, then
 * ZipAligns and signs the universal APK with `ApkSigner` using the user's keystore credentials.
 */
object BundleToolEngine {

  private const val STREAM_BUFFER_SIZE = 64 * 1024
  private const val UNIVERSAL_APK_ENTRY = "universal.apk"

  fun convertSignedAabToUniversalApk(
    context: Context,
    signedAab: File,
    outputUniversalApk: File,
    credentials: ValidatedKeystoreCredentials? = null,
  ): File {
    if (!signedAab.exists() || !signedAab.isFile) {
      throw IllegalArgumentException("Signed AAB file does not exist")
    }

    val tempApksArchive = ZeroTraceManager.allocateTempFile(context, "universal_bundle", ".apks")
    val rawUniversalApk = ZeroTraceManager.allocateTempFile(context, "universal_raw", ".apk")
    val alignedUniversalApk = ZeroTraceManager.allocateTempFile(context, "universal_aligned", ".apk")
    val buffer = ByteArray(STREAM_BUFFER_SIZE)

    try {
      BuildApksCommand.builder()
        .setBundlePath(signedAab.toPath())
        .setOutputFile(tempApksArchive.toPath())
        .setApkBuildMode(BuildApksCommand.ApkBuildMode.UNIVERSAL)
        .setOverwriteOutput(true)
        .setAapt2Command(createAndroidCompatibleAapt2Command(context))
        .build()
        .execute()

      ZipFile(tempApksArchive).use { apksZip ->
        val entry = apksZip.getEntry(UNIVERSAL_APK_ENTRY)
          ?: throw IllegalStateException("BundleTool did not produce $UNIVERSAL_APK_ENTRY")
        val targetOut = if (credentials != null) rawUniversalApk else outputUniversalApk
        apksZip.getInputStream(entry).use { input ->
          FileOutputStream(targetOut, false).use { output ->
            while (true) {
              val read = input.read(buffer)
              if (read == -1) break
              output.write(buffer, 0, read)
            }
            output.flush()
          }
        }
      }

      if (credentials != null) {
        ZipAlignEngine.alignApk(
          inputApk = rawUniversalApk,
          outputApk = alignedUniversalApk,
          alignment = 4,
          pageAlignSharedLibs = true,
        )
        val signerConfig = ApkSigner.SignerConfig.Builder(
          credentials.alias,
          credentials.privateKey,
          credentials.certificateChain,
        ).build()
        ApkSigner.Builder(listOf(signerConfig))
          .setInputApk(alignedUniversalApk)
          .setOutputApk(outputUniversalApk)
          .setCreatedBy("ShipSign")
          .setV1SigningEnabled(true)
          .setV2SigningEnabled(true)
          .setV3SigningEnabled(true)
          .build()
          .sign()
      }

      return outputUniversalApk
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(outputUniversalApk)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
      ZeroTraceManager.secureDeleteFile(tempApksArchive)
      ZeroTraceManager.secureDeleteFile(rawUniversalApk)
      ZeroTraceManager.secureDeleteFile(alignedUniversalApk)
    }
  }

  private fun createAndroidCompatibleAapt2Command(context: Context): Aapt2Command {
    val nativeLibAapt2 = File(context.applicationInfo.nativeLibraryDir, "libaapt2.so")
    if (nativeLibAapt2.exists() && nativeLibAapt2.canExecute()) {
      return Aapt2Command.createFromExecutablePath(nativeLibAapt2.toPath())
    }
    return object : Aapt2Command {
      override fun convertApkProtoToBinary(
        protoApk: Path,
        binaryApk: Path,
        convertOptions: Aapt2Command.ConvertOptions,
      ) {
        throw UnsupportedOperationException(
          "AAB-to-Universal-APK conversion requires aapt2 binary on this ABI; upload the signed .aab directly to Google Play or run GitHub Cloud Build for APK output."
        )
      }

      override fun optimizeToSparseResourceTables(originalApk: Path, outputApk: Path) {
        throw UnsupportedOperationException(
          "Resource table optimization requires aapt2 binary on this ABI."
        )
      }
    }
  }
}
