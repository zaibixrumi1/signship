package com.shipsign.app

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.LocalActivityResultRegistryOwner
import androidx.activity.compose.LocalOnBackPressedDispatcherOwner
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.shipsign.app.core.security.ZeroTraceSnapshot
import com.shipsign.app.domain.model.InputCategory
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.ui.FoundationUiState
import com.shipsign.app.ui.ShipSignViewModel
import com.shipsign.app.ui.components.ShipSignUnifiedTopBar
import com.shipsign.app.ui.components.WorkflowStepRail
import com.shipsign.app.ui.navigation.CryptoCoreRoute
import com.shipsign.app.ui.navigation.HomeRoute
import com.shipsign.app.ui.navigation.KeystoreChoiceRoute
import com.shipsign.app.ui.navigation.KeystoreFormRoute
import com.shipsign.app.ui.navigation.KeystoreFormatRoute
import com.shipsign.app.ui.navigation.KeystoreImportRoute
import com.shipsign.app.ui.navigation.KeystoreReadyRoute
import com.shipsign.app.ui.navigation.SelectFileRoute
import com.shipsign.app.ui.navigation.SignAndResultRoute
import com.shipsign.app.ui.navigation.VaultRoute
import com.shipsign.app.ui.screens.CryptoCoreScreen
import com.shipsign.app.ui.screens.VaultScreen
import com.shipsign.app.ui.screens.home.HomeScreen
import com.shipsign.app.ui.screens.step1.SelectFileScreen
import com.shipsign.app.ui.screens.step2.KeystoreChoiceScreen
import com.shipsign.app.ui.screens.step2.KeystoreFormScreen
import com.shipsign.app.ui.screens.step2.KeystoreFormatScreen
import com.shipsign.app.ui.screens.step2.KeystoreImportScreen
import com.shipsign.app.ui.screens.step2.KeystoreReadyScreen
import com.shipsign.app.ui.screens.step3.SignAndResultScreen
import com.shipsign.app.ui.theme.ShipSignTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

  private val shipSignViewModel: ShipSignViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    // Block screenshots, screen recording, and recents thumbnails of passwords or keys
    window.setFlags(
      WindowManager.LayoutParams.FLAG_SECURE,
      WindowManager.LayoutParams.FLAG_SECURE,
    )

    enableEdgeToEdge()
    forwardOAuthDeepLink(intent)

    setContent {
      val uiState by shipSignViewModel.uiState.collectAsStateWithLifecycle()
      val zeroTraceSnapshot by shipSignViewModel.zeroTraceSnapshot.collectAsStateWithLifecycle()

      CompositionLocalProvider(
        LocalActivityResultRegistryOwner provides this@MainActivity,
        LocalOnBackPressedDispatcherOwner provides this@MainActivity,
      ) {
        ShipSignTheme(darkTheme = true) {
          ShipSignRootScaffold(
            viewModel = shipSignViewModel,
            uiState = uiState,
            snapshot = zeroTraceSnapshot,
          )
        }
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    forwardOAuthDeepLink(intent)
  }

  private fun forwardOAuthDeepLink(intent: Intent?) {
    val uri = intent?.data ?: return
    shipSignViewModel.onGitHubCallback(uri)
  }
}

@Composable
private fun ShipSignRootScaffold(
  viewModel: ShipSignViewModel,
  uiState: FoundationUiState,
  snapshot: ZeroTraceSnapshot,
) {
  val navController = rememberNavController()
  val navBackStackEntry by navController.currentBackStackEntryAsState()
  val currentDestination = navBackStackEntry?.destination
  val snackbarHostState = remember { SnackbarHostState() }
  val scope = rememberCoroutineScope()
  val activityContext = LocalContext.current
  val nukedMessage = stringResource(R.string.session_nuked_snackbar)

  val isHome = currentDestination == null || currentDestination.hasRoute<HomeRoute>()
  val isCryptoCore = currentDestination?.hasRoute<CryptoCoreRoute>() == true
  val isVault = currentDestination?.hasRoute<VaultRoute>() == true

  val activeWorkflowStep: Int? = when {
    currentDestination?.hasRoute<SelectFileRoute>() == true -> 1
    currentDestination?.hasRoute<KeystoreChoiceRoute>() == true ||
      currentDestination?.hasRoute<KeystoreImportRoute>() == true ||
      currentDestination?.hasRoute<KeystoreFormatRoute>() == true ||
      currentDestination?.hasRoute<KeystoreFormRoute>() == true ||
      currentDestination?.hasRoute<KeystoreReadyRoute>() == true -> 2
    currentDestination?.hasRoute<SignAndResultRoute>() == true -> 3
    else -> null
  }

  val topBarTitle = when {
    isCryptoCore -> stringResource(R.string.crypto_title)
    isVault -> stringResource(R.string.vault_title)
    else -> stringResource(R.string.app_name)
  }

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    containerColor = MaterialTheme.colorScheme.background,
    contentWindowInsets = WindowInsets(0, 0, 0, 0),
    snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
    topBar = {
      Column {
        ShipSignUnifiedTopBar(
          title = topBarTitle,
          showBack = !isHome,
          isVaultActive = isVault,
          isCryptoCoreActive = isCryptoCore,
          onBack = { navController.popBackStack() },
          onOpenVault = {
            if (!isVault) navController.navigate(VaultRoute)
          },
          onOpenCryptoCore = {
            if (!isCryptoCore) navController.navigate(CryptoCoreRoute)
          },
        )
        if (activeWorkflowStep != null) {
          WorkflowStepRail(activeStep = activeWorkflowStep)
        }
      }
    },
  ) { innerPadding ->
    NavHost(
      navController = navController,
      startDestination = HomeRoute,
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      composable<HomeRoute> {
        HomeScreen(
          onSignNewApp = {
            navController.navigate(SelectFileRoute(InputCategory.BUILT_APK.name))
          },
          onMakeNewKeystore = {
            navController.navigate(KeystoreFormatRoute)
          },
        )
      }

      composable<SelectFileRoute> {
        SelectFileScreen(
          inspectorState = uiState.inspector,
          cloudBuildState = uiState.cloudBuild,
          showGitHubDisclosureDialog = uiState.showGitHubDisclosureDialog,
          onSelectCloudFormat = viewModel::selectOutputFormat,
          onUriPicked = viewModel::inspectPickedUri,
          onClearSelectedFile = viewModel::clearInspectedTarget,
          onStripExistingSignature = viewModel::stripTargetSignature,
          onLeaveAlreadySigned = {
            viewModel.nukeCurrentSession()
            navController.popBackStack<HomeRoute>(inclusive = false)
          },
          onConnectGitHub = { viewModel.requestGitHubConnect(activityContext) },
          onDisconnectGitHub = viewModel::disconnectGitHub,
          onConfirmGitHubDisclosure = { viewModel.acceptGitHubDisclosureAndConnect(activityContext) },
          onDismissGitHubDisclosure = viewModel::dismissGitHubDisclosure,
          onStartCloudBuild = viewModel::startCloudBuild,
          onCancelCloudBuild = viewModel::cancelCloudBuild,
          onContinueToKeystore = {
            navController.navigate(KeystoreChoiceRoute)
          },
          onConsumeAutoAdvance = viewModel::consumePendingAdvanceToKeystore,
        )
      }

      composable<KeystoreChoiceRoute> {
        KeystoreChoiceScreen(
          isBusy = uiState.keystoreStudio.isBusy,
          onImportExisting = {
            navController.navigate(KeystoreImportRoute)
          },
          onCreateNew = {
            navController.navigate(KeystoreFormatRoute)
          },
          onUseDebugKey = {
            viewModel.activateEphemeralDebugKeystore {
              navController.navigate(SignAndResultRoute)
            }
          },
        )
      }

      composable<KeystoreImportRoute> {
        KeystoreImportScreen(
          state = uiState.keystoreStudio,
          onPickKeystoreUri = viewModel::importKeystoreUri,
          onSwitchToGenerate = {
            navController.navigate(KeystoreFormatRoute) {
              popUpTo<KeystoreChoiceRoute>()
            }
          },
          onSwitchToDebugKey = {
            viewModel.activateEphemeralDebugKeystore {
              navController.navigate(SignAndResultRoute)
            }
          },
          onVerifyAndContinue = { storePass, alias, keyPass ->
            viewModel.verifyImportedKeystore(
              storePassword = storePass,
              keyAlias = alias,
              keyPassword = keyPass,
              onVerifiedSuccess = {
                navController.navigate(SignAndResultRoute)
              },
            )
          },
        )
      }

      composable<KeystoreFormatRoute> {
        KeystoreFormatScreen(
          isBusy = uiState.keystoreStudio.isBusy,
          onSwitchToExisting = {
            navController.navigate(KeystoreImportRoute) {
              popUpTo<KeystoreChoiceRoute>()
            }
          },
          onSwitchToDebugKey = {
            viewModel.activateEphemeralDebugKeystore {
              navController.navigate(SignAndResultRoute)
            }
          },
          onSelectFormat = { selectedFormat ->
            navController.navigate(KeystoreFormRoute(selectedFormat.name))
          },
        )
      }

      composable<KeystoreFormRoute> { backStackEntry ->
        val args = backStackEntry.toRoute<KeystoreFormRoute>()
        val format = runCatching { KeystoreFormat.valueOf(args.formatName) }
          .getOrDefault(KeystoreFormat.JKS)
        KeystoreFormScreen(
          format = format,
          isBusy = uiState.keystoreStudio.isBusy,
          errorMessage = uiState.keystoreStudio.errorMessage,
          onGenerateKeystore = { request ->
            viewModel.generateKeystoreInSession(
              request = request,
              onGenerated = {
                navController.navigate(KeystoreReadyRoute)
              },
            )
          },
        )
      }

      composable<KeystoreReadyRoute> {
        KeystoreReadyScreen(
          state = uiState.keystoreStudio,
          hasTargetBinaryToSign = uiState.inspector.targetFile != null,
          onDownloadKeystore = viewModel::downloadGeneratedKeystoreToDownloads,
          onProceedToSigning = {
            viewModel.promoteGeneratedKeystoreForSigning {
              navController.navigate(SignAndResultRoute)
            }
          },
          onDoneReturnHome = {
            viewModel.discardGeneratedKeystoreCache()
            navController.popBackStack<HomeRoute>(inclusive = false)
          },
          onAutoDeleteCacheOnLeave = viewModel::discardGeneratedKeystoreCache,
        )
      }

      composable<SignAndResultRoute> {
        SignAndResultScreen(
          targetFile = uiState.inspector.targetFile,
          availableTargets = uiState.inspector.availableBuildTargets,
          keystoreState = uiState.keystoreStudio,
          signingState = uiState.signingStudio,
          onSelectTarget = viewModel::selectActiveBuildTarget,
          onUpdateOptions = viewModel::updateSigningOptions,
          onSignNow = viewModel::startSigningWithActiveCredentials,
          onSaveCopyToUri = { sourceUri, destUri, cb ->
            viewModel.copySignedOutputToUri(sourceUri, destUri, cb)
          },
          onSignAnotherApp = {
            viewModel.nukeCurrentSession()
            navController.popBackStack<HomeRoute>(inclusive = false)
          },
          onShowSnackbar = { msg ->
            scope.launch { snackbarHostState.showSnackbar(msg) }
          },
        )
      }

      composable<VaultRoute> {
        VaultScreen(
          snapshot = snapshot,
          keystoreState = uiState.keystoreStudio,
          lastAuditResult = uiState.lastAuditResult,
          isAuditing = uiState.isAuditing,
          onRunAudit = viewModel::runZeroTraceAudit,
          onDeleteActiveKeystore = viewModel::clearKeystoreSandbox,
          onNukeSession = {
            viewModel.nukeCurrentSession()
            scope.launch { snackbarHostState.showSnackbar(nukedMessage) }
          },
          onOpenCryptoCore = { navController.navigate(CryptoCoreRoute) },
        )
      }

      composable<CryptoCoreRoute> {
        CryptoCoreScreen(
          diagnostics = uiState.cryptoDiagnostics,
          onVerifyCapabilities = viewModel::verifySigningCapabilities,
        )
      }
    }
  }
}
