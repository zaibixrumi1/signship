package com.shipsign.app.ui.screens.home

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddModerator
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.shipsign.app.R
import com.shipsign.app.ui.components.StandardCardShape

@Composable
fun HomeScreen(
  onSignNewApp: () -> Unit,
  onMakeNewKeystore: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val emerald = MaterialTheme.colorScheme.primary
  val secondary = MaterialTheme.colorScheme.secondary
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  Box(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(emerald.copy(alpha = 0.12f), Color.Transparent),
          center = Offset(size.width * 0.85f, size.height * 0.12f),
          radius = size.width * 0.8f,
        ),
        center = Offset(size.width * 0.85f, size.height * 0.12f),
        radius = size.width * 0.8f,
      )
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(secondary.copy(alpha = 0.08f), Color.Transparent),
          center = Offset(size.width * 0.15f, size.height * 0.88f),
          radius = size.width * 0.7f,
        ),
        center = Offset(size.width * 0.15f, size.height * 0.88f),
        radius = size.width * 0.7f,
      )
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .testTag("home_lazy_column"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 24.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        Text(
          text = stringResource(R.string.home_headline),
          style = MaterialTheme.typography.headlineMedium,
          color = MaterialTheme.colorScheme.onBackground,
        )
      }

      // Primary Drop-Zone Launch Card
      item {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .testTag("home_sign_new_app_card")
            .clickable(onClick = onSignNewApp),
          shape = StandardCardShape,
          color = MaterialTheme.colorScheme.surface,
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Box(
              modifier = Modifier
                .size(56.dp)
                .background(
                  color = MaterialTheme.colorScheme.primaryContainer,
                  shape = CircleShape,
                ),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.FileUpload,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.onPrimaryContainer,
                modifier = Modifier.size(28.dp),
              )
            }

            Text(
              text = stringResource(R.string.step1_dropzone_title),
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface,
              textAlign = TextAlign.Center,
            )

            Row(
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              FormatChip(label = ".APK")
              FormatChip(label = ".AAB")
              FormatChip(label = ".ZIP")
            }
          }
        }
      }

      // Secondary Action Card -> Generate Keystore
      item {
        SecondaryActionCard(
          title = stringResource(R.string.home_make_keystore_title),
          description = stringResource(R.string.home_make_keystore_desc),
          icon = Icons.Filled.AddModerator,
          accentColor = MaterialTheme.colorScheme.secondary,
          badgeTint = MaterialTheme.colorScheme.secondaryContainer,
          onClick = onMakeNewKeystore,
          testTag = "home_make_keystore_card",
        )
      }

      // Zero-Trace Offline Badge
      item {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("home_trust_badge"),
          shape = StandardCardShape,
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f)),
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.VerifiedUser,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.size(20.dp),
            )
            Text(
              text = stringResource(R.string.home_trust_badge),
              style = MaterialTheme.typography.labelLarge,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun FormatChip(label: String) {
  Surface(
    shape = RoundedCornerShape(8.dp),
    color = MaterialTheme.colorScheme.surfaceContainerLow,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = MaterialTheme.colorScheme.secondary,
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
    )
  }
}

@Composable
private fun SecondaryActionCard(
  title: String,
  description: String,
  icon: ImageVector,
  accentColor: Color,
  badgeTint: Color,
  onClick: () -> Unit,
  testTag: String,
) {
  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .minimumInteractiveComponentSize()
      .testTag(testTag)
      .clickable(onClick = onClick),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Box(
        modifier = Modifier
          .size(48.dp)
          .background(color = badgeTint, shape = RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = accentColor,
          modifier = Modifier.size(24.dp),
        )
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = description,
          style = MaterialTheme.typography.labelSmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(20.dp),
      )
    }
  }
}
