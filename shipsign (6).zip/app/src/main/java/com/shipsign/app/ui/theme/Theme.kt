package com.shipsign.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val ShipSignDarkColorScheme = darkColorScheme(
  primary = EmeraldAction,
  onPrimary = EmeraldOnAction,
  primaryContainer = EmeraldContainer,
  onPrimaryContainer = EmeraldOnContainer,
  secondary = TechBlueSecondary,
  onSecondary = TechBlueOnSecondary,
  secondaryContainer = TechBlueContainer,
  onSecondaryContainer = TechBlueOnContainer,
  tertiary = AmberWarning,
  onTertiary = AmberOnWarning,
  tertiaryContainer = AmberContainer,
  onTertiaryContainer = AmberOnContainer,
  error = CrimsonError,
  onError = EmeraldOnAction,
  errorContainer = CrimsonContainer,
  onErrorContainer = CrimsonOnContainer,
  background = ObsidianBackground,
  onBackground = TextPrimaryDark,
  surface = ObsidianCard,
  onSurface = TextPrimaryDark,
  surfaceVariant = ObsidianCardElevated,
  onSurfaceVariant = TextSecondaryDark,
  surfaceContainerLow = ObsidianConsole,
  surfaceContainer = ObsidianCard,
  surfaceContainerHigh = ObsidianCardElevated,
  outline = ObsidianBorder,
  outlineVariant = ObsidianBorder,
)

private val ShipSignLightColorScheme = lightColorScheme(
  primary = EmeraldAction,
  onPrimary = EmeraldOnAction,
  primaryContainer = EmeraldOnContainer,
  onPrimaryContainer = EmeraldContainer,
  secondary = TechBlueSecondary,
  onSecondary = LightSurface,
  secondaryContainer = TechBlueOnContainer,
  onSecondaryContainer = TechBlueContainer,
  tertiary = AmberWarning,
  onTertiary = AmberOnWarning,
  tertiaryContainer = AmberOnContainer,
  onTertiaryContainer = AmberContainer,
  error = CrimsonError,
  background = LightBg,
  onBackground = TextPrimaryLight,
  surface = LightSurface,
  onSurface = TextPrimaryLight,
  surfaceVariant = LightSurfaceVariant,
  onSurfaceVariant = TextSecondaryLight,
  outline = LightSurfaceVariant,
)

val ShipSignShapes = Shapes(
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(14.dp),
  large = RoundedCornerShape(20.dp),
  extraLarge = RoundedCornerShape(26.dp),
)

@Composable
fun ShipSignTheme(
  darkTheme: Boolean = true,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) ShipSignDarkColorScheme else ShipSignLightColorScheme

  MaterialTheme(
    colorScheme = colorScheme,
    typography = ShipSignTypography,
    shapes = ShipSignShapes,
    content = content,
  )
}
