package com.shipsign.app.core.engine

import com.shipsign.app.core.security.ZeroTraceManager
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Detects v1 (JAR) and v2/v3/v3.1 (APK Signature Scheme) blocks and strips existing signatures
 * by streaming ZIP entries cleanly to a new output file without loading binaries into RAM.
 */
object SignatureScanner {

  private const val STREAM_BUFFER_SIZE = 64 * 1024
  private const val EOCD_MIN_SIZE = 22
  private const val EOCD_MAX_COMMENT_LENGTH = 65_535
  private const val EOCD_SIGNATURE = 0x06054b50
  private val APK_SIG_BLOCK_MAGIC = "APK Sig Block 42".toByteArray(Charsets.US_ASCII)

  fun hasExistingSignature(file: File): Boolean {
    if (!file.exists() || !file.isFile || file.length() < EOCD_MIN_SIZE) return false
    if (hasApkSigningBlockMagic(file)) return true
    return hasV1SignatureEntries(file)
  }

  fun stripExistingSignature(signedFile: File, cleanOutputFile: File): Boolean {
    if (!signedFile.exists() || !signedFile.isFile) return false
    val buffer = ByteArray(STREAM_BUFFER_SIZE)

    return try {
      ZipFile(signedFile).use { zipFile ->
        ZipOutputStream(BufferedOutputStream(FileOutputStream(cleanOutputFile, false), STREAM_BUFFER_SIZE)).use { zos ->
          val entries = zipFile.entries()
          while (entries.hasMoreElements()) {
            val sourceEntry = entries.nextElement()
            if (isSignatureArtifact(sourceEntry.name)) {
              continue
            }

            val outEntry = ZipEntry(sourceEntry.name).apply {
              if (sourceEntry.time > 0L) {
                time = sourceEntry.time
              }
              if (sourceEntry.isDirectory) {
                method = ZipEntry.STORED
                size = 0L
                compressedSize = 0L
                crc = 0L
              } else if (
                sourceEntry.method == ZipEntry.STORED &&
                  sourceEntry.size >= 0L &&
                  sourceEntry.compressedSize >= 0L &&
                  sourceEntry.crc >= 0L
              ) {
                method = ZipEntry.STORED
                size = sourceEntry.size
                compressedSize = sourceEntry.compressedSize
                crc = sourceEntry.crc
              } else {
                method = ZipEntry.DEFLATED
              }
            }

            zos.putNextEntry(outEntry)
            if (!sourceEntry.isDirectory) {
              zipFile.getInputStream(sourceEntry).use { input ->
                while (true) {
                  val read = input.read(buffer)
                  if (read == -1) break
                  zos.write(buffer, 0, read)
                }
              }
            }
            zos.closeEntry()
          }
          zos.flush()
        }
      }
      true
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(cleanOutputFile)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  internal fun isSignatureArtifact(entryName: String): Boolean {
    val normalized = entryName.replace('\\', '/')
    val upper = normalized.uppercase(Locale.US)
    if (!upper.startsWith("META-INF/")) return false
    val leaf = upper.removePrefix("META-INF/")
    if (leaf.contains('/')) return false
    return leaf == "MANIFEST.MF" ||
      leaf.endsWith(".SF") ||
      leaf.endsWith(".RSA") ||
      leaf.endsWith(".DSA") ||
      leaf.endsWith(".EC")
  }

  private fun hasV1SignatureEntries(file: File): Boolean {
    return runCatching {
      ZipFile(file).use { zip ->
        val entries = zip.entries()
        while (entries.hasMoreElements()) {
          val name = entries.nextElement().name.replace('\\', '/').uppercase(Locale.US)
          if (name.startsWith("META-INF/")) {
            val leaf = name.removePrefix("META-INF/")
            if (!leaf.contains('/')) {
              if (
                leaf.endsWith(".SF") ||
                  leaf.endsWith(".RSA") ||
                  leaf.endsWith(".DSA") ||
                  leaf.endsWith(".EC")
              ) {
                return@use true
              }
            }
          }
        }
        false
      }
    }.getOrDefault(false)
  }

  private fun hasApkSigningBlockMagic(file: File): Boolean {
    return runCatching {
      RandomAccessFile(file, "r").use { raf ->
        val fileLen = raf.length()
        if (fileLen < EOCD_MIN_SIZE + 32L) return@use false

        val searchWindow = minOf(fileLen, (EOCD_MIN_SIZE + EOCD_MAX_COMMENT_LENGTH).toLong()).toInt()
        val tailOffset = fileLen - searchWindow
        val tailBytes = ByteArray(searchWindow)
        raf.seek(tailOffset)
        raf.readFully(tailBytes)

        val eocdIndex = findEocdOffsetInTail(tailBytes)
        if (eocdIndex < 0) return@use false

        val cdOffset = ByteBuffer
          .wrap(tailBytes, eocdIndex + 16, 4)
          .order(ByteOrder.LITTLE_ENDIAN)
          .int
          .toLong() and 0xFFFFFFFFL

        if (cdOffset < 32L || cdOffset > fileLen) return@use false

        val magicCandidate = ByteArray(APK_SIG_BLOCK_MAGIC.size)
        raf.seek(cdOffset - APK_SIG_BLOCK_MAGIC.size)
        raf.readFully(magicCandidate)
        magicCandidate.contentEquals(APK_SIG_BLOCK_MAGIC)
      }
    }.getOrDefault(false)
  }

  private fun findEocdOffsetInTail(tailBytes: ByteArray): Int {
    val maxStart = tailBytes.size - EOCD_MIN_SIZE
    for (i in maxStart downTo 0) {
      if (
        tailBytes[i] == (EOCD_SIGNATURE and 0xFF).toByte() &&
          tailBytes[i + 1] == ((EOCD_SIGNATURE ushr 8) and 0xFF).toByte() &&
          tailBytes[i + 2] == ((EOCD_SIGNATURE ushr 16) and 0xFF).toByte() &&
          tailBytes[i + 3] == ((EOCD_SIGNATURE ushr 24) and 0xFF).toByte()
      ) {
        val commentLength = ByteBuffer
          .wrap(tailBytes, i + 20, 2)
          .order(ByteOrder.LITTLE_ENDIAN)
          .short
          .toInt() and 0xFFFF
        if (i + EOCD_MIN_SIZE + commentLength == tailBytes.size) {
          return i
        }
      }
    }
    return -1
  }
}
