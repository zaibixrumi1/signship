package com.shipsign.app.core.github

import android.content.Context
import com.shipsign.app.core.engine.SignatureScanner
import com.shipsign.app.core.engine.ZipInspectorEngine
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.core.storage.SafFileBridge
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ResolvedBinaryType
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.security.SecureRandom
import java.util.Base64
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream

enum class CloudBuildStage(val stepIndex: Int, val label: String) {
  PREPARING_ARCHIVE(0, "Preparing Archive"),
  CREATING_EPHEMERAL_REPO(1, "Creating Repo"),
  PUSHING_SOURCES(2, "Uploading Source"),
  DISPATCHING_WORKFLOW(3, "Starting Workflow"),
  POLLING_BUILD(4, "Building Package"),
  DOWNLOADING_AND_WIPING(5, "Downloading"),
}

sealed interface CloudBuildState {
  data object Idle : CloudBuildState
  data class StageProgress(
    val stage: CloudBuildStage,
    val statusText: String,
    val repoFullName: String? = null,
    val runId: Long? = null,
    val elapsedSeconds: Int = 0,
  ) : CloudBuildState
  data class ReadyForOfflineSigning(
    val targetFile: AppTargetFile,
    val availableTargets: List<AppTargetFile> = listOf(targetFile),
    val repoDeleted: Boolean,
  ) : CloudBuildState
  data class RepositoryAccessRequired(
    val httpCode: Int,
    val message: String,
  ) : CloudBuildState
  data class Failed(
    val error: Throwable,
    val repoFullName: String? = null,
    val runId: Long? = null,
    val repoDeleted: Boolean = false,
  ) : CloudBuildState
}

open class GitHubCloudBuildException(
  message: String,
  val repoFullName: String? = null,
  val runId: Long? = null,
  cause: Throwable? = null,
) : Exception(message, cause)

typealias CloudBuildException = GitHubCloudBuildException

class GitHubRepoAccessRequiredException(
  val httpCode: Int,
  message: String,
) : GitHubCloudBuildException(message = message)

@Serializable
private data class CreateRepoRequest(
  @SerialName("name") val name: String,
  @SerialName("private") val isPrivate: Boolean = true,
  @SerialName("auto_init") val autoInit: Boolean = true,
  @SerialName("description") val description: String = "Ephemeral private ShipSign build sandbox",
)

@Serializable
private data class RepoDto(
  @SerialName("name") val name: String,
  @SerialName("full_name") val fullName: String,
  @SerialName("private") val isPrivate: Boolean = true,
  @SerialName("default_branch") val defaultBranch: String = "main",
)

@Serializable
private data class GitRefDto(
  @SerialName("ref") val ref: String,
  @SerialName("object") val obj: GitRefObjectDto,
)

@Serializable
private data class GitRefObjectDto(@SerialName("sha") val sha: String)

@Serializable
private data class GitBlobRequest(
  @SerialName("content") val content: String,
  @SerialName("encoding") val encoding: String = "base64",
)

@Serializable
private data class GitShaResponse(@SerialName("sha") val sha: String)

@Serializable
private data class GitTreeEntry(
  @SerialName("path") val path: String,
  @SerialName("mode") val mode: String,
  @SerialName("type") val type: String = "blob",
  @SerialName("sha") val sha: String,
)

@Serializable
private data class GitCreateTreeRequest(
  @SerialName("tree") val tree: List<GitTreeEntry>,
)

@Serializable
private data class GitCreateCommitRequest(
  @SerialName("message") val message: String,
  @SerialName("tree") val tree: String,
  @SerialName("parents") val parents: List<String>,
)

@Serializable
private data class GitUpdateRefRequest(
  @SerialName("sha") val sha: String,
  @SerialName("force") val force: Boolean = true,
)

@Serializable
private data class WorkflowDispatchRequest(
  @SerialName("ref") val ref: String,
)

@Serializable
private data class WorkflowRunsResponse(
  @SerialName("workflow_runs") val workflowRuns: List<WorkflowRunDto> = emptyList(),
)

@Serializable
private data class WorkflowRunDto(
  @SerialName("id") val id: Long,
  @SerialName("status") val status: String,
  @SerialName("conclusion") val conclusion: String? = null,
)

@Serializable
private data class WorkflowJobsResponse(
  @SerialName("jobs") val jobs: List<WorkflowJobDto> = emptyList(),
)

@Serializable
private data class WorkflowJobDto(
  @SerialName("id") val id: Long,
  @SerialName("name") val name: String = "",
  @SerialName("conclusion") val conclusion: String? = null,
)

@Serializable
private data class ArtifactsResponse(
  @SerialName("artifacts") val artifacts: List<ArtifactDto> = emptyList(),
)

@Serializable
private data class ArtifactDto(
  @SerialName("id") val id: Long,
  @SerialName("name") val name: String,
  @SerialName("expired") val expired: Boolean = false,
  @SerialName("archive_download_url") val archiveDownloadUrl: String,
)

private data class UploadSourceEntry(
  val path: String,
  val mode: String,
  val contentBase64: String,
)

/**
 * Ephemeral GitHub Actions Cloud Build Orchestrator supporting three dedicated modular workflows:
 * - [BuildOutputFormat.APK_ONLY] (`shipsign-build-apk.yml` -> `ShipSign-APK`)
 * - [BuildOutputFormat.AAB_ONLY] (`shipsign-build-aab.yml` -> `ShipSign-AAB`)
 * - [BuildOutputFormat.BOTH] (`shipsign-build-both.yml` -> `ShipSign-Bundle`)
 *
 * Fetches bounded failed job log excerpts on non-success conclusion and ALWAYS executes
 * `DELETE /repos/{owner}/{repo}` inside `finally` (`NonCancellable + Dispatchers.IO`).
 */
object GitHubBuildModule {

  private const val STREAM_BUFFER_SIZE = 64 * 1024
  private const val MAX_UPLOAD_BYTES_PER_FILE = 45L * 1024L * 1024L
  private const val DEFAULT_POLL_INTERVAL_MS = 5_000L
  private val JSON_MEDIA = "application/json; charset=utf-8".toMediaType()
  private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
  private val secureRandom = SecureRandom()

  private val defaultClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(30, TimeUnit.SECONDS)
      .readTimeout(60, TimeUnit.SECONDS)
      .writeTimeout(60, TimeUnit.SECONDS)
      .build()
  }

  fun buildUnsignedBinary(
    context: Context,
    sourceProject: AppTargetFile,
    token: CharArray,
    targetFormat: BuildOutputFormat = BuildOutputFormat.APK_ONLY,
    httpClient: OkHttpClient = defaultClient,
    apiBaseUrl: String = GitHubConfig.apiBaseUrl,
    pollIntervalMs: Long = DEFAULT_POLL_INTERVAL_MS,
    wipeTokenOnCompletion: Boolean = true,
  ): Flow<CloudBuildState> = flow {
    val apiBase = apiBaseUrl.trimEnd('/')
    val sessionDir = ZeroTraceManager.createOrGetSessionDir(context)
    val sanitizedTempZip = ZeroTraceManager.allocateTempFile(context, "sanitized_src", ".zip")
    var createdRepoFullName: String? = null
    var completedRunId: Long? = null
    var repoDeleted = false
    val startedAtMs = System.currentTimeMillis()
    val workflowPath = WorkflowTemplateGenerator.workflowPathFor(targetFormat)

    fun elapsedSec(): Int = ((System.currentTimeMillis() - startedAtMs) / 1_000L).toInt().coerceAtLeast(0)

    try {
      require(sourceProject.inputKind == com.shipsign.app.domain.model.InputKind.SOURCE_ARCHIVE) {
        "GitHub Cloud Build accepts SOURCE_ARCHIVE projects only"
      }
      val metadata = requireNotNull(sourceProject.sourceMetadata) {
        "On-device ZipInspectorEngine metadata is required before starting a cloud build"
      }
      require(metadata.framework != ProjectFramework.UNKNOWN) {
        "Unrecognized project framework. On-device inspection must identify a supported stack before touching GitHub."
      }
      require(token.isNotEmpty()) { "GitHub OAuth token is empty" }

      // Stage 1: Preparing Archive
      emit(
        CloudBuildState.StageProgress(
          stage = CloudBuildStage.PREPARING_ARCHIVE,
          statusText = CloudBuildStage.PREPARING_ARCHIVE.label,
          elapsedSeconds = elapsedSec(),
        )
      )
      val sanitized = ZipInspectorEngine.sanitizeProjectArchive(
        sourceZip = sourceProject.sessionFile,
        destZip = sanitizedTempZip,
        projectRootPrefix = metadata.projectRootPrefix,
      )
      val workflowYaml = WorkflowTemplateGenerator.generateWorkflow(metadata, targetFormat)
      val uploadEntries = buildUploadEntriesFromSanitizedZip(
        sanitizedZip = sanitized.sanitizedZip,
        workflowPath = workflowPath,
        workflowYaml = workflowYaml,
      )

      // Stage 2: Creating Ephemeral Private Repo
      val repoName = "shipsign-tmp-${System.currentTimeMillis()}-${(1000..9999).random()}"
      emit(
        CloudBuildState.StageProgress(
          stage = CloudBuildStage.CREATING_EPHEMERAL_REPO,
          statusText = CloudBuildStage.CREATING_EPHEMERAL_REPO.label,
          elapsedSeconds = elapsedSec(),
        )
      )
      val repo = createPrivateRepo(httpClient, apiBase, token, repoName)
      if (!repo.isPrivate) {
        throw GitHubCloudBuildException("Safety violation: GitHub refused private=true repository")
      }
      createdRepoFullName = repo.fullName
      val branch = repo.defaultBranch.ifBlank { "main" }

      // Stage 3: Uploading Source
      emit(
        CloudBuildState.StageProgress(
          stage = CloudBuildStage.PUSHING_SOURCES,
          statusText = CloudBuildStage.PUSHING_SOURCES.label,
          repoFullName = repo.fullName,
          elapsedSeconds = elapsedSec(),
        )
      )
      pushSingleAtomicCommit(
        httpClient = httpClient,
        apiBase = apiBase,
        token = token,
        repoFullName = repo.fullName,
        branch = branch,
        entries = uploadEntries,
      )

      // Stage 4: Starting Workflow
      emit(
        CloudBuildState.StageProgress(
          stage = CloudBuildStage.DISPATCHING_WORKFLOW,
          statusText = CloudBuildStage.DISPATCHING_WORKFLOW.label,
          repoFullName = repo.fullName,
          elapsedSeconds = elapsedSec(),
        )
      )
      dispatchWorkflow(
        httpClient = httpClient,
        apiBase = apiBase,
        token = token,
        repoFullName = repo.fullName,
        branch = branch,
        outputFormat = targetFormat,
      )

      // Stage 5: Building Package
      emit(
        CloudBuildState.StageProgress(
          stage = CloudBuildStage.POLLING_BUILD,
          statusText = CloudBuildStage.POLLING_BUILD.label,
          repoFullName = repo.fullName,
          elapsedSeconds = elapsedSec(),
        )
      )
      val run = pollWorkflowRunUntilComplete(
        httpClient = httpClient,
        apiBase = apiBase,
        token = token,
        repoFullName = repo.fullName,
        pollIntervalMs = pollIntervalMs,
        onTick = { runId, _ ->
          emit(
            CloudBuildState.StageProgress(
              stage = CloudBuildStage.POLLING_BUILD,
              statusText = CloudBuildStage.POLLING_BUILD.label,
              repoFullName = repo.fullName,
              runId = runId,
              elapsedSeconds = elapsedSec(),
            )
          )
        },
      )
      completedRunId = run.id
      if (!run.conclusion.equals("success", ignoreCase = true)) {
        val logExcerpt = fetchFailedJobLogExcerpt(
          httpClient = httpClient,
          apiBase = apiBase,
          token = token,
          repoFullName = repo.fullName,
          runId = run.id,
        )
        val detail = if (!logExcerpt.isNullOrBlank()) {
          "Build failed (${run.conclusion ?: "error"}): $logExcerpt"
        } else {
          "Build failed (${run.conclusion ?: "error"})."
        }
        throw GitHubCloudBuildException(
          message = detail,
          repoFullName = repo.fullName,
          runId = run.id,
        )
      }

      // Stage 6: Downloading & Wiping Repo
      emit(
        CloudBuildState.StageProgress(
          stage = CloudBuildStage.DOWNLOADING_AND_WIPING,
          statusText = CloudBuildStage.DOWNLOADING_AND_WIPING.label,
          repoFullName = repo.fullName,
          runId = run.id,
          elapsedSeconds = elapsedSec(),
        )
      )
      val verifiedTargets = downloadAndVerifyArtifacts(
        context = context,
        sessionDir = sessionDir,
        httpClient = httpClient,
        apiBase = apiBase,
        token = token,
        repoFullName = repo.fullName,
        runId = run.id,
        targetFormat = targetFormat,
      )

      repoDeleted = deletePrivateRepo(httpClient, apiBase, token, repo.fullName)
      createdRepoFullName = null

      emit(
        CloudBuildState.ReadyForOfflineSigning(
          targetFile = verifiedTargets.first(),
          availableTargets = verifiedTargets,
          repoDeleted = repoDeleted,
        )
      )
    } catch (e: CancellationException) {
      throw e
    } catch (e: GitHubRepoAccessRequiredException) {
      emit(
        CloudBuildState.RepositoryAccessRequired(
          httpCode = e.httpCode,
          message = e.message ?: "Repository access permission is required.",
        )
      )
    } catch (e: Exception) {
      val leftoverRepo = createdRepoFullName
      if (leftoverRepo != null) {
        repoDeleted = withContext(NonCancellable + Dispatchers.IO) {
          deletePrivateRepo(httpClient, apiBase, token, leftoverRepo)
        }
        createdRepoFullName = null
      }
      emit(
        CloudBuildState.Failed(
          error = e,
          repoFullName = leftoverRepo,
          runId = completedRunId,
          repoDeleted = repoDeleted,
        )
      )
    } finally {
      val pendingRepo = createdRepoFullName
      if (pendingRepo != null) {
        withContext(NonCancellable + Dispatchers.IO) {
          deletePrivateRepo(httpClient, apiBase, token, pendingRepo)
        }
      }
      ZeroTraceManager.secureDeleteFile(sanitizedTempZip)
      if (wipeTokenOnCompletion) {
        ZeroTraceManager.wipeCharArray(token)
      }
    }
  }.flowOn(Dispatchers.IO)

  private fun createPrivateRepo(
    httpClient: OkHttpClient,
    apiBase: String,
    token: CharArray,
    repoName: String,
  ): RepoDto {
    val payload = json.encodeToString(
      CreateRepoRequest.serializer(),
      CreateRepoRequest(name = repoName, isPrivate = true, autoInit = true),
    )
    val req = requestBuilder("$apiBase/user/repos", token)
      .post(payload.toRequestBody(JSON_MEDIA))
      .build()
    httpClient.newCall(req).execute().use { response ->
      val text = response.body?.string().orEmpty()
      if (response.code == 403 || response.code == 404) {
        throw GitHubRepoAccessRequiredException(
          httpCode = response.code,
          message = "Repository permission required (HTTP ${response.code}). Reconnect GitHub to grant access.",
        )
      }
      if (!response.isSuccessful) {
        throw GitHubCloudBuildException(
          message = "GitHub API HTTP ${response.code}: ${text.take(240)}",
        )
      }
      return json.decodeFromString(RepoDto.serializer(), text)
    }
  }

  private suspend fun pushSingleAtomicCommit(
    httpClient: OkHttpClient,
    apiBase: String,
    token: CharArray,
    repoFullName: String,
    branch: String,
    entries: List<UploadSourceEntry>,
  ) = coroutineScope {
    val headSha = awaitBranchHeadSha(httpClient, apiBase, token, repoFullName, branch)

    val semaphore = Semaphore(6)
    val treeEntries = entries.map { item ->
      async {
        semaphore.withPermit {
          currentCoroutineContext().ensureActive()
          val blobPayload = json.encodeToString(
            GitBlobRequest.serializer(),
            GitBlobRequest(content = item.contentBase64, encoding = "base64"),
          )
          val blobReq = requestBuilder("$apiBase/repos/$repoFullName/git/blobs", token)
            .post(blobPayload.toRequestBody(JSON_MEDIA))
            .build()
          val blobResp = json.decodeFromString(GitShaResponse.serializer(), executeJson(httpClient, blobReq))
          GitTreeEntry(
            path = item.path,
            mode = item.mode,
            type = "blob",
            sha = blobResp.sha,
          )
        }
      }
    }.awaitAll()

    val treePayload = json.encodeToString(
      GitCreateTreeRequest.serializer(),
      GitCreateTreeRequest(tree = treeEntries),
    )
    val treeReq = requestBuilder("$apiBase/repos/$repoFullName/git/trees", token)
      .post(treePayload.toRequestBody(JSON_MEDIA))
      .build()
    val treeSha = json.decodeFromString(GitShaResponse.serializer(), executeJson(httpClient, treeReq)).sha

    val commitPayload = json.encodeToString(
      GitCreateCommitRequest.serializer(),
      GitCreateCommitRequest(
        message = "chore: upload sanitized source & ShipSign build workflow",
        tree = treeSha,
        parents = listOf(headSha),
      ),
    )
    val commitReq = requestBuilder("$apiBase/repos/$repoFullName/git/commits", token)
      .post(commitPayload.toRequestBody(JSON_MEDIA))
      .build()
    val commitSha = json.decodeFromString(GitShaResponse.serializer(), executeJson(httpClient, commitReq)).sha

    val refPayload = json.encodeToString(
      GitUpdateRefRequest.serializer(),
      GitUpdateRefRequest(sha = commitSha, force = true),
    )
    val patchReq = requestBuilder("$apiBase/repos/$repoFullName/git/refs/heads/$branch", token)
      .patch(refPayload.toRequestBody(JSON_MEDIA))
      .build()
    executeJson(httpClient, patchReq)
  }

  private suspend fun awaitBranchHeadSha(
    httpClient: OkHttpClient,
    apiBase: String,
    token: CharArray,
    repoFullName: String,
    branch: String,
  ): String {
    var lastErr: Exception? = null
    repeat(5) { attempt ->
      currentCoroutineContext().ensureActive()
      try {
        val req = requestBuilder("$apiBase/repos/$repoFullName/git/refs/heads/$branch", token).get().build()
        val refDto = json.decodeFromString(GitRefDto.serializer(), executeJson(httpClient, req))
        return refDto.obj.sha
      } catch (e: Exception) {
        lastErr = e
        if (attempt < 4) delay(1_000L)
      }
    }
    throw lastErr ?: IOException("Unable to resolve $branch branch ref")
  }

  private fun dispatchWorkflow(
    httpClient: OkHttpClient,
    apiBase: String,
    token: CharArray,
    repoFullName: String,
    branch: String,
    outputFormat: BuildOutputFormat,
  ) {
    val payload = json.encodeToString(
      WorkflowDispatchRequest.serializer(),
      WorkflowDispatchRequest(ref = branch),
    )
    val req = requestBuilder(
      "$apiBase/repos/$repoFullName/actions/workflows/${outputFormat.workflowFileName}/dispatches",
      token,
    ).post(payload.toRequestBody(JSON_MEDIA)).build()
    httpClient.newCall(req).execute().use { response ->
      if (!response.isSuccessful) {
        val msg = response.body?.string().orEmpty()
        throw GitHubCloudBuildException(
          message = "Failed to trigger ${outputFormat.workflowFileName} (HTTP ${response.code}): ${msg.take(200)}",
          repoFullName = repoFullName,
        )
      }
    }
  }

  private suspend fun pollWorkflowRunUntilComplete(
    httpClient: OkHttpClient,
    apiBase: String,
    token: CharArray,
    repoFullName: String,
    pollIntervalMs: Long,
    onTick: suspend (Long?, String) -> Unit,
  ): WorkflowRunDto {
    val maxAttempts = 250
    repeat(maxAttempts) { attempt ->
      currentCoroutineContext().ensureActive()
      if (attempt > 0 && pollIntervalMs > 0L) {
        delay(pollIntervalMs)
      }
      currentCoroutineContext().ensureActive()

      val req = requestBuilder(
        "$apiBase/repos/$repoFullName/actions/runs?event=workflow_dispatch&per_page=5",
        token,
      ).get().build()
      val runsResp = json.decodeFromString(WorkflowRunsResponse.serializer(), executeJson(httpClient, req))
      val latest = runsResp.workflowRuns.firstOrNull()
      if (latest == null) {
        onTick(null, "queued")
      } else {
        onTick(latest.id, latest.status)
        if (latest.status.equals("completed", ignoreCase = true)) {
          return latest
        }
      }
    }
    throw GitHubCloudBuildException(
      message = "GitHub Actions build timed out waiting for completion.",
      repoFullName = repoFullName,
    )
  }

  private fun fetchFailedJobLogExcerpt(
    httpClient: OkHttpClient,
    apiBase: String,
    token: CharArray,
    repoFullName: String,
    runId: Long,
  ): String? = runCatching {
    val jobsReq = requestBuilder("$apiBase/repos/$repoFullName/actions/runs/$runId/jobs", token)
      .get()
      .build()
    val jobsResp = json.decodeFromString(
      WorkflowJobsResponse.serializer(),
      executeJson(httpClient, jobsReq),
    )
    val failedJob = jobsResp.jobs.firstOrNull { !it.conclusion.equals("success", ignoreCase = true) }
      ?: jobsResp.jobs.firstOrNull()
      ?: return@runCatching null

    val logsReq = requestBuilder("$apiBase/repos/$repoFullName/actions/jobs/${failedJob.id}/logs", token)
      .get()
      .build()
    httpClient.newCall(logsReq).execute().use { response ->
      if (!response.isSuccessful) return@runCatching null
      val bodyStream = response.body?.byteStream() ?: return@runCatching null
      val maxBytes = 256 * 1024
      val buf = ByteArray(8 * 1024)
      val out = ByteArrayOutputStream()
      var total = 0
      bodyStream.use { input ->
        while (total < maxBytes) {
          val toRead = minOf(buf.size, maxBytes - total)
          val read = input.read(buf, 0, toRead)
          if (read == -1) break
          out.write(buf, 0, read)
          total += read
        }
      }
      val rawLogs = out.toString(Charsets.UTF_8.name()).trim()
      if (rawLogs.isBlank()) return@runCatching null
      val lines = rawLogs.lineSequence()
        .map { it.trim() }
        .filter { it.isNotEmpty() }
        .toList()
      val errorLines = lines.filter { line ->
        val lower = line.lowercase(Locale.US)
        lower.contains("error:") ||
          lower.contains("failure:") ||
          lower.contains("exception") ||
          lower.contains("execution failed")
      }
      val snippet = (if (errorLines.isNotEmpty()) errorLines.takeLast(5) else lines.takeLast(6))
        .joinToString("\n")
      snippet.takeLast(500).trim()
    }
  }.getOrNull()

  private suspend fun downloadAndVerifyArtifacts(
    context: Context,
    sessionDir: File,
    httpClient: OkHttpClient,
    apiBase: String,
    token: CharArray,
    repoFullName: String,
    runId: Long,
    targetFormat: BuildOutputFormat,
  ): List<AppTargetFile> {
    val artifactZip = ZeroTraceManager.allocateTempFile(context, "gh_artifact", ".zip")
    val extractedTargets = mutableListOf<AppTargetFile>()
    try {
      val req = requestBuilder("$apiBase/repos/$repoFullName/actions/runs/$runId/artifacts", token).get().build()
      val artifacts = json.decodeFromString(ArtifactsResponse.serializer(), executeJson(httpClient, req)).artifacts
      val chosen = artifacts.firstOrNull { !it.expired && it.name == targetFormat.artifactName }
        ?: artifacts.firstOrNull { !it.expired }
        ?: throw GitHubCloudBuildException(
          message = "No downloadable ${targetFormat.artifactName} artifact found.",
          repoFullName = repoFullName,
          runId = runId,
        )

      streamDownload(
        httpClient = httpClient,
        url = chosen.archiveDownloadUrl,
        token = token,
        destFile = artifactZip,
        repoFullName = repoFullName,
        runId = runId,
      )

      val verifiedList = extractAndVerifyArtifactBinaries(
        context = context,
        sessionDir = sessionDir,
        artifactZip = artifactZip,
        repoFullName = repoFullName,
        runId = runId,
        targetFormat = targetFormat,
      )
      extractedTargets.addAll(verifiedList)
      return verifiedList
    } catch (e: Exception) {
      extractedTargets.forEach { ZeroTraceManager.secureDeleteFile(it.sessionFile) }
      if (e is GitHubCloudBuildException) throw e
      throw GitHubCloudBuildException(
        message = "Artifact download failed: ${e.message ?: "Unknown error"}",
        repoFullName = repoFullName,
        runId = runId,
        cause = e,
      )
    } finally {
      ZeroTraceManager.secureDeleteFile(artifactZip)
    }
  }

  private fun streamDownload(
    httpClient: OkHttpClient,
    url: String,
    token: CharArray,
    destFile: File,
    repoFullName: String,
    runId: Long,
  ) {
    val buffer = ByteArray(STREAM_BUFFER_SIZE)
    try {
      val req = requestBuilder(url, token).get().build()
      httpClient.newCall(req).execute().use { response ->
        if (!response.isSuccessful) {
          throw GitHubCloudBuildException(
            message = "Failed to download artifact ZIP (HTTP ${response.code})",
            repoFullName = repoFullName,
            runId = runId,
          )
        }
        val body = response.body ?: throw IOException("Empty artifact download stream")
        body.byteStream().use { input ->
          FileOutputStream(destFile, false).use { output ->
            while (true) {
              val read = input.read(buffer)
              if (read == -1) break
              output.write(buffer, 0, read)
            }
            output.flush()
          }
        }
      }
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(destFile)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  private fun extractAndVerifyArtifactBinaries(
    context: Context,
    sessionDir: File,
    artifactZip: File,
    repoFullName: String,
    runId: Long,
    targetFormat: BuildOutputFormat,
  ): List<AppTargetFile> {
    val buffer = ByteArray(STREAM_BUFFER_SIZE)
    val extractedFiles = mutableListOf<File>()
    val verifiedTargets = mutableListOf<AppTargetFile>()

    try {
      ZipFile(artifactZip).use { zipFile ->
        val fileEntries = zipFile.entries().toList().filter { !it.isDirectory }
        val apkEntry = fileEntries.firstOrNull { it.name.lowercase(Locale.US).endsWith(".apk") }
        val aabEntry = fileEntries.firstOrNull { it.name.lowercase(Locale.US).endsWith(".aab") }

        val entriesToExtract: List<ZipEntry> = when (targetFormat) {
          BuildOutputFormat.APK_ONLY -> listOfNotNull(apkEntry)
          BuildOutputFormat.AAB_ONLY -> listOfNotNull(aabEntry)
          BuildOutputFormat.BOTH -> listOfNotNull(apkEntry, aabEntry)
        }

        if (entriesToExtract.isEmpty()) {
          throw GitHubCloudBuildException(
            message = "Artifact ${targetFormat.artifactName} is missing ${targetFormat.displayLabel} output.",
            repoFullName = repoFullName,
            runId = runId,
          )
        }

        for (entry in entriesToExtract) {
          val safeName = SafFileBridge.sanitizeFileName(entry.name.substringAfterLast('/'))
          val rawOut = File(sessionDir, "cloud_raw_${randomHex8()}_$safeName")
          extractedFiles.add(rawOut)

          zipFile.getInputStream(entry).use { input ->
            FileOutputStream(rawOut, false).use { output ->
              while (true) {
                val read = input.read(buffer)
                if (read == -1) break
                output.write(buffer, 0, read)
              }
              output.flush()
            }
          }

          ZipFile(rawOut).use { innerZip ->
            if (innerZip.size() <= 0) {
              throw IOException("Downloaded binary archive is empty: $safeName")
            }
          }

          val inspected = ZipInspectorEngine.inspectFile(
            inputFile = rawOut,
            originalName = safeName,
            sessionDir = sessionDir,
          )
          if (inspected.binaryType != ResolvedBinaryType.APK && inspected.binaryType != ResolvedBinaryType.AAB) {
            throw GitHubCloudBuildException(
              message = "Downloaded file failed APK/AAB verification: $safeName",
              repoFullName = repoFullName,
              runId = runId,
            )
          }

          val cleanTarget = if (inspected.isAlreadySigned) {
            val suffix = if (inspected.binaryType == ResolvedBinaryType.AAB) ".aab" else ".apk"
            val stripped = ZeroTraceManager.allocateTempFile(context, "cloud_unsigned", suffix)
            extractedFiles.add(stripped)
            SignatureScanner.stripExistingSignature(inspected.sessionFile, stripped)
            ZeroTraceManager.secureDeleteFile(inspected.sessionFile)
            inspected.copy(
              sessionFile = stripped,
              sizeBytes = stripped.length(),
              isAlreadySigned = SignatureScanner.hasExistingSignature(stripped),
            )
          } else {
            inspected
          }
          verifiedTargets.add(cleanTarget)
        }
      }

      return verifiedTargets
    } catch (e: Exception) {
      extractedFiles.forEach { ZeroTraceManager.secureDeleteFile(it) }
      verifiedTargets.forEach { ZeroTraceManager.secureDeleteFile(it.sessionFile) }
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  private fun deletePrivateRepo(
    httpClient: OkHttpClient,
    apiBase: String,
    token: CharArray,
    repoFullName: String,
  ): Boolean {
    return runCatching {
      val req = requestBuilder("$apiBase/repos/$repoFullName", token).delete().build()
      httpClient.newCall(req).execute().use { response ->
        response.isSuccessful || response.code == 404
      }
    }.getOrDefault(false)
  }

  private fun buildUploadEntriesFromSanitizedZip(
    sanitizedZip: File,
    workflowPath: String,
    workflowYaml: String,
  ): List<UploadSourceEntry> {
    val result = mutableListOf<UploadSourceEntry>()
    val seenPaths = hashSetOf<String>()
    val buffer = ByteArray(STREAM_BUFFER_SIZE)
    val base64 = Base64.getEncoder()

    try {
      ZipInputStream(FileInputStream(sanitizedZip)).use { zis ->
        while (true) {
          val entry = zis.nextEntry ?: break
          if (entry.isDirectory) {
            zis.closeEntry()
            continue
          }
          val path = entry.name.replace('\\', '/').trimStart('/')
          if (path.isBlank() || path == workflowPath || !seenPaths.add(path)) {
            zis.closeEntry()
            continue
          }

          val baos = ByteArrayOutputStream()
          var total = 0L
          while (true) {
            val read = zis.read(buffer)
            if (read == -1) break
            total += read
            if (total > MAX_UPLOAD_BYTES_PER_FILE) {
              throw IllegalArgumentException("Source file exceeds 45MB GitHub blob limit: $path")
            }
            baos.write(buffer, 0, read)
          }
          val bytes = baos.toByteArray()
          val mode = if (path.endsWith("gradlew") || path.endsWith(".sh")) "100755" else "100644"
          result.add(
            UploadSourceEntry(
              path = path,
              mode = mode,
              contentBase64 = base64.encodeToString(bytes),
            )
          )
          ZeroTraceManager.wipeByteArray(bytes)
          zis.closeEntry()
        }
      }

      if (result.isEmpty()) {
        throw IllegalArgumentException("Source archive contains no buildable files.")
      }

      val workflowBytes = workflowYaml.toByteArray(Charsets.UTF_8)
      result.add(
        UploadSourceEntry(
          path = workflowPath,
          mode = "100644",
          contentBase64 = base64.encodeToString(workflowBytes),
        )
      )
      ZeroTraceManager.wipeByteArray(workflowBytes)
      return result
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  private fun executeJson(httpClient: OkHttpClient, request: Request): String {
    httpClient.newCall(request).execute().use { response ->
      val text = response.body?.string().orEmpty()
      if (!response.isSuccessful) {
        throw GitHubCloudBuildException(
          message = "GitHub API HTTP ${response.code}: ${text.take(240)}",
        )
      }
      return text
    }
  }

  private fun requestBuilder(url: String, token: CharArray): Request.Builder {
    val bearer = String(token)
    return Request.Builder()
      .url(url)
      .header("Accept", "application/vnd.github+json")
      .header("Authorization", "Bearer $bearer")
      .header("X-GitHub-Api-Version", "2022-11-28")
      .header("User-Agent", GitHubConfig.USER_AGENT)
  }

  private fun randomHex8(): String {
    val bytes = ByteArray(4)
    secureRandom.nextBytes(bytes)
    return bytes.joinToString("") { String.format(Locale.US, "%02x", it) }
  }
}
