package com.shipsign.app.domain.model

import java.io.File
import java.security.PrivateKey
import java.security.cert.X509Certificate

enum class KeystoreFormat {
  JKS,
  PKCS12,
  BKS,
  UNKNOWN,
}

data class ImportedKeystoreConfig(
  val tempKeystoreFile: File,
  val detectedFormat: KeystoreFormat,
  val storePassword: CharArray,
  val keyAlias: String,
  val keyPassword: CharArray,
) {
  override fun equals(other: Any?): Boolean {
    if (this === other) return true
    if (other !is ImportedKeystoreConfig) return false
    return tempKeystoreFile == other.tempKeystoreFile &&
      detectedFormat == other.detectedFormat &&
      storePassword.contentEquals(other.storePassword) &&
      keyAlias == other.keyAlias &&
      keyPassword.contentEquals(other.keyPassword)
  }

  override fun hashCode(): Int {
    var result = tempKeystoreFile.hashCode()
    result = 31 * result + detectedFormat.hashCode()
    result = 31 * result + storePassword.contentHashCode()
    result = 31 * result + keyAlias.hashCode()
    result = 31 * result + keyPassword.contentHashCode()
    return result
  }

  override fun toString(): String {
    return "ImportedKeystoreConfig(file=${tempKeystoreFile.name}, format=$detectedFormat, alias=$keyAlias, storePassword=***, keyPassword=***)"
  }
}

data class KeystoreCreateRequest(
  val format: KeystoreFormat,
  val fileName: String,
  val storePassword: CharArray,
  val keyAlias: String,
  val keyPassword: CharArray,
  val validityDays: Int = 10000,
  val commonName: String,
  val organizationalUnit: String,
  val organization: String,
  val cityLocality: String,
  val stateProvince: String,
  val countryCode: String,
) {
  override fun equals(other: Any?): Boolean {
    if (this === other) return true
    if (other !is KeystoreCreateRequest) return false
    return format == other.format &&
      fileName == other.fileName &&
      storePassword.contentEquals(other.storePassword) &&
      keyAlias == other.keyAlias &&
      keyPassword.contentEquals(other.keyPassword) &&
      validityDays == other.validityDays &&
      commonName == other.commonName &&
      organizationalUnit == other.organizationalUnit &&
      organization == other.organization &&
      cityLocality == other.cityLocality &&
      stateProvince == other.stateProvince &&
      countryCode == other.countryCode
  }

  override fun hashCode(): Int {
    var result = format.hashCode()
    result = 31 * result + fileName.hashCode()
    result = 31 * result + storePassword.contentHashCode()
    result = 31 * result + keyAlias.hashCode()
    result = 31 * result + keyPassword.contentHashCode()
    result = 31 * result + validityDays
    result = 31 * result + commonName.hashCode()
    result = 31 * result + organizationalUnit.hashCode()
    result = 31 * result + organization.hashCode()
    result = 31 * result + cityLocality.hashCode()
    result = 31 * result + stateProvince.hashCode()
    result = 31 * result + countryCode.hashCode()
    return result
  }

  override fun toString(): String {
    return "KeystoreCreateRequest(format=$format, fileName=$fileName, alias=$keyAlias, validityDays=$validityDays, CN=$commonName, storePassword=***, keyPassword=***)"
  }
}

data class ValidatedKeystoreCredentials(
  val format: KeystoreFormat,
  val alias: String,
  val privateKey: PrivateKey,
  val certificateChain: List<X509Certificate>,
)
