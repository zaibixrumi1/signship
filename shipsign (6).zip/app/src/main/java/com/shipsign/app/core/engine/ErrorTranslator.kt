package com.shipsign.app.core.engine

import com.android.apksig.apk.ApkFormatException
import com.shipsign.app.core.github.GitHubCloudBuildException
import com.shipsign.app.core.github.GitHubOAuthDeniedException
import com.shipsign.app.core.github.GitHubOAuthException
import com.shipsign.app.core.github.GitHubOAuthExpiredException
import com.shipsign.app.core.github.GitHubRepoAccessRequiredException
import com.shipsign.app.core.security.UnsupportedKeystoreException
import com.shipsign.app.core.security.WrongAliasException
import com.shipsign.app.core.security.WrongPasswordException
import java.io.IOException
import java.security.UnrecoverableKeyException
import java.util.Locale
import java.util.zip.ZipException

data class TranslatedError(
  val title: String,
  val message: String,
)

/**
 * Translates low-level cryptographic, ZIP, keystore, GitHub Cloud Build, and apksig exceptions
 * into clear, actionable international technical English messages.
 */
object ErrorTranslator {

  fun translate(throwable: Throwable): TranslatedError {
    val chain = generateSequence(throwable) { it.cause }.toList()
    val combinedMsg = chain.joinToString(" | ") { it.message.orEmpty() }.lowercase(Locale.US)

    if (
      chain.any { it is WrongPasswordException || it is UnrecoverableKeyException } ||
        combinedMsg.contains("keystore was tampered") ||
        combinedMsg.contains("incorrect password") ||
        combinedMsg.contains("wrong password") ||
        combinedMsg.contains("mac verify error") ||
        combinedMsg.contains("bad padding")
    ) {
      return TranslatedError(
        title = "Wrong Password",
        message = "The store or key password does not match this keystore. Verify Caps Lock and try again.",
      )
    }

    val aliasError = chain.filterIsInstance<WrongAliasException>().firstOrNull()
    if (aliasError != null) {
      val hint = if (aliasError.availableAliases.isNotEmpty()) {
        " Available aliases: ${aliasError.availableAliases.joinToString(", ")}."
      } else {
        ""
      }
      return TranslatedError(
        title = "Wrong Alias",
        message = "The key alias was not found inside this keystore.$hint",
      )
    }

    if (
      combinedMsg.contains("already signed") ||
        combinedMsg.contains("signature rollback") ||
        (combinedMsg.contains("v1 signature") && combinedMsg.contains("exists"))
    ) {
      return TranslatedError(
        title = "File Already Signed",
        message = "This APK/AAB already contains a signature block. Strip existing signatures before re-signing.",
      )
    }

    if (
      chain.any { it is UnsupportedKeystoreException } ||
        combinedMsg.contains("unrecognized keystore") ||
        combinedMsg.contains("unsupported keystore")
    ) {
      return TranslatedError(
        title = "Keystore Type Not Supported",
        message = "Use a valid Android JKS (.jks), PKCS12 (.p12 / .pfx), or BKS (.bks) keystore file.",
      )
    }

    if (
      chain.any { it is ZipException || it is ApkFormatException } ||
        combinedMsg.contains("corrupt") ||
        combinedMsg.contains("invalid zip") ||
        combinedMsg.contains("eocd") ||
        combinedMsg.contains("truncated") ||
        (chain.any { it is IOException } && combinedMsg.contains("central directory"))
    ) {
      return TranslatedError(
        title = "File Corrupted",
        message = "The selected APK, AAB, or ZIP archive appears incomplete or damaged. Re-export or re-download the file.",
      )
    }

    if (chain.any { it is GitHubOAuthExpiredException }) {
      return TranslatedError(
        title = "GitHub Authorization Expired",
        message = "The authorization code expired before exchange. Tap Connect GitHub to authorize again.",
      )
    }
    if (chain.any { it is GitHubOAuthDeniedException }) {
      return TranslatedError(
        title = "GitHub Authorization Cancelled",
        message = "Authorization was declined in GitHub. No tokens or repositories were created.",
      )
    }
    if (chain.any { it is GitHubOAuthException }) {
      return TranslatedError(
        title = "GitHub Connection Issue",
        message = throwable.message ?: "Unable to complete GitHub App authorization.",
      )
    }
    val repoAccessErr = chain.filterIsInstance<GitHubRepoAccessRequiredException>().firstOrNull()
    if (repoAccessErr != null) {
      return TranslatedError(
        title = "Repository Access Required",
        message = repoAccessErr.message ?: "Grant ShipSign repository permission in GitHub to build your project.",
      )
    }
    val cloudErr = chain.filterIsInstance<GitHubCloudBuildException>().firstOrNull()
    if (cloudErr != null) {
      return TranslatedError(
        title = "Cloud Build Failed",
        message = cloudErr.message ?: "GitHub Actions build failed. Any temporary repository has been cleaned up.",
      )
    }

    val rawDetail = throwable.message?.takeIf { it.isNotBlank() } ?: "Unexpected error"
    return TranslatedError(
      title = "Operation Failed",
      message = rawDetail,
    )
  }
}
