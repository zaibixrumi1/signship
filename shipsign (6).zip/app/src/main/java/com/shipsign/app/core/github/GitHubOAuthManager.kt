package com.shipsign.app.core.github

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.browser.customtabs.CustomTabsIntent
import com.shipsign.app.core.security.AppPreferences
import com.shipsign.app.core.security.GitHubAuthSession
import com.shipsign.app.core.security.ZeroTraceManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.FormBody
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Base64
import java.util.concurrent.TimeUnit

data class GitHubUserProfile(
  val username: String,
  val avatarUrl: String?,
)

data class GitHubSession(
  val accessToken: String,
  val installationId: String?,
  val profile: GitHubUserProfile,
) {
  val username: String get() = profile.username
  val avatarUrl: String? get() = profile.avatarUrl
}

data class PkceAuthRequest(
  val authorizeUrl: String,
  val state: String,
  val codeChallenge: String,
)

@Serializable
private data class OAuthTokenResponseDto(
  @SerialName("access_token") val accessToken: String? = null,
  @SerialName("token_type") val tokenType: String? = null,
  @SerialName("scope") val scope: String? = null,
  @SerialName("error") val error: String? = null,
  @SerialName("error_description") val errorDescription: String? = null,
)

@Serializable
private data class GitHubUserDto(
  @SerialName("login") val login: String,
  @SerialName("avatar_url") val avatarUrl: String? = null,
)

open class GitHubOAuthException(
  message: String,
  cause: Throwable? = null,
) : Exception(message, cause)

class GitHubOAuthExpiredException(
  message: String = "GitHub session expired. Please reconnect.",
) : GitHubOAuthException(message)

class GitHubOAuthDeniedException(
  message: String = "GitHub authorization was cancelled or denied.",
) : GitHubOAuthException(message)

class GitHubOAuthStateMismatchException(
  message: String = "OAuth state verification failed.",
) : GitHubOAuthException(message)

/**
 * Verified GitHub App OAuth 2.0 + PKCE (`S256`) manager for ShipSign (`signship-testing`).
 *
 * Flow:
 * 1. Generates 32-byte Base64URL `state` and 64-byte Base64URL `code_verifier` + SHA-256
 *    `code_challenge` (`S256`), persists them inside AES-256 [EncryptedSharedPreferences] so
 *    process recreation during Chrome Custom Tabs never loses the handshake.
 * 2. Opens Chrome Custom Tabs to `https://github.com/login/oauth/authorize` with callback
 *    `shipsign://github/callback`.
 * 3. Validates `state` in constant time, exchanges `code` + `code_verifier` (and BuildConfig
 *    `client_secret` when configured) for an uncapped opaque `access_token`, fetches `/user`,
 *    and stores [GitHubSession] in AES-256 [EncryptedSharedPreferences].
 */
object GitHubOAuthManager {

  private val json = Json { ignoreUnknownKeys = true }
  private val secureRandom = SecureRandom()
  private val base64UrlEncoder: Base64.Encoder = Base64.getUrlEncoder().withoutPadding()

  private val defaultClient: OkHttpClient by lazy {
    OkHttpClient.Builder()
      .connectTimeout(20, TimeUnit.SECONDS)
      .readTimeout(30, TimeUnit.SECONDS)
      .writeTimeout(30, TimeUnit.SECONDS)
      .build()
  }

  /**
   * Builds a fresh OAuth 2.0 PKCE (`S256`) authorization request and persists `state` +
   * `code_verifier` in [EncryptedSharedPreferences].
   */
  fun createAuthorizeRequest(
    context: Context,
    clientId: String = GitHubConfig.GITHUB_CLIENT_ID,
    redirectUri: String = GitHubConfig.REDIRECT_URI,
    oauthBaseUrl: String = GitHubConfig.oauthBaseUrl,
  ): PkceAuthRequest {
    val (state, challenge) = generateAndPersistPkceSession(context)
    val base = oauthBaseUrl.trimEnd('/')
    val url = "$base/login/oauth/authorize" +
      "?client_id=${urlEncode(clientId)}" +
      "&redirect_uri=${urlEncode(redirectUri)}" +
      "&state=${urlEncode(state)}" +
      "&code_challenge=${urlEncode(challenge)}" +
      "&code_challenge_method=S256"
    return PkceAuthRequest(authorizeUrl = url, state = state, codeChallenge = challenge)
  }

  /** Launches Chrome Custom Tabs for GitHub App OAuth 2.0 + PKCE (`S256`) authorization. */
  fun startOAuthFlow(context: Context): PkceAuthRequest {
    val req = createAuthorizeRequest(context)
    launchCustomTab(context, req.authorizeUrl)
    return req
  }

  fun isGitHubCallbackUri(uri: Uri?): Boolean {
    if (uri == null) return false
    val path = uri.path ?: return false
    return uri.scheme.equals(GitHubConfig.CALLBACK_SCHEME, ignoreCase = true) &&
      uri.host.equals(GitHubConfig.CALLBACK_HOST, ignoreCase = true) &&
      path.startsWith(GitHubConfig.CALLBACK_PATH)
  }

  /**
   * Handles the deep link redirect `shipsign://github/callback?code=...&state=...`.
   * Verifies `state` in constant time, exchanges `code` + `code_verifier` for an access token,
   * fetches `/user`, persists [GitHubSession] in AES-256 [EncryptedSharedPreferences], and
   * clears temporary PKCE state.
   */
  suspend fun handleAuthCallback(
    context: Context,
    uri: Uri,
    clientId: String = GitHubConfig.GITHUB_CLIENT_ID,
    clientSecret: String = GitHubConfig.GITHUB_CLIENT_SECRET,
    redirectUri: String = GitHubConfig.REDIRECT_URI,
    httpClient: OkHttpClient = defaultClient,
    oauthBaseUrl: String = GitHubConfig.oauthBaseUrl,
    apiBaseUrl: String = GitHubConfig.apiBaseUrl,
  ): Result<GitHubSession> = withContext(Dispatchers.IO) {
    try {
      if (!isGitHubCallbackUri(uri)) {
        throw GitHubOAuthException("Unrecognized OAuth callback URI.")
      }

      val oauthError = uri.getQueryParameter("error")
      if (!oauthError.isNullOrBlank()) {
        AppPreferences.clearPendingOAuthPkce(context)
        val description = uri.getQueryParameter("error_description")
        if (oauthError == "access_denied") {
          throw GitHubOAuthDeniedException(description ?: "GitHub authorization was cancelled or denied.")
        }
        throw GitHubOAuthException(description ?: "GitHub returned OAuth error: $oauthError")
      }

      val returnedState = uri.getQueryParameter("state")
      val code = uri.getQueryParameter("code")
      val installationId = uri.getQueryParameter("installation_id")?.takeIf { it.isNotBlank() }

      val (expectedState, storedVerifier) = AppPreferences.consumePendingOAuthPkce(context)
        ?: throw GitHubOAuthStateMismatchException(
          "No active GitHub authorization request found. Tap Connect GitHub to try again."
        )

      val verifierChars = storedVerifier.toCharArray()
      try {
        if (returnedState.isNullOrBlank() || !constantTimeEquals(expectedState, returnedState)) {
          throw GitHubOAuthStateMismatchException(
            "OAuth state verification failed. Please retry connecting GitHub."
          )
        }

        if (code.isNullOrBlank()) {
          throw GitHubOAuthException("GitHub did not return an authorization code.")
        }

        val tokenChars = exchangeCodeForToken(
          clientId = clientId,
          clientSecret = clientSecret,
          code = code,
          redirectUri = redirectUri,
          codeVerifier = verifierChars,
          httpClient = httpClient,
          oauthBaseUrl = oauthBaseUrl,
        )

        try {
          val profile = fetchUserProfile(
            token = tokenChars,
            httpClient = httpClient,
            apiBaseUrl = apiBaseUrl,
          )
          val opaqueAccessToken = String(tokenChars)
          val persisted = GitHubAuthSession(
            accessToken = opaqueAccessToken,
            installationId = installationId,
            username = profile.username,
            avatarUrl = profile.avatarUrl,
          )
          AppPreferences.saveGitHubAuthSession(context, persisted)
          Result.success(
            GitHubSession(
              accessToken = opaqueAccessToken,
              installationId = installationId,
              profile = profile,
            )
          )
        } finally {
          ZeroTraceManager.wipeCharArray(tokenChars)
        }
      } finally {
        ZeroTraceManager.wipeCharArray(verifierChars)
      }
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  /** Restores the persisted encrypted [GitHubSession] from [AppPreferences], if present. */
  fun getSavedSession(context: Context): GitHubSession? {
    val stored = AppPreferences.getGitHubAuthSession(context) ?: return null
    return GitHubSession(
      accessToken = stored.accessToken,
      installationId = stored.installationId,
      profile = GitHubUserProfile(
        username = stored.username,
        avatarUrl = stored.avatarUrl,
      ),
    )
  }

  /** Clears local encrypted OAuth session and any pending PKCE state. */
  fun disconnect(context: Context) {
    AppPreferences.clearGitHubAuthSession(context)
  }

  internal fun computeS256CodeChallenge(codeVerifier: CharArray): String {
    val verifierBytes = String(codeVerifier).toByteArray(Charsets.US_ASCII)
    return try {
      val digest = MessageDigest.getInstance("SHA-256").digest(verifierBytes)
      try {
        base64UrlEncoder.encodeToString(digest)
      } finally {
        ZeroTraceManager.wipeByteArray(digest)
      }
    } finally {
      ZeroTraceManager.wipeByteArray(verifierBytes)
    }
  }

  private fun generateAndPersistPkceSession(context: Context): Pair<String, String> {
    val stateBytes = ByteArray(32)
    val verifierBytes = ByteArray(64)
    secureRandom.nextBytes(stateBytes)
    secureRandom.nextBytes(verifierBytes)

    val state = base64UrlEncoder.encodeToString(stateBytes)
    val verifierString = base64UrlEncoder.encodeToString(verifierBytes)
    val verifierChars = verifierString.toCharArray()
    ZeroTraceManager.wipeByteArray(stateBytes)
    ZeroTraceManager.wipeByteArray(verifierBytes)

    return try {
      val challenge = computeS256CodeChallenge(verifierChars)
      AppPreferences.savePendingOAuthPkce(context, state = state, codeVerifier = verifierString)
      state to challenge
    } finally {
      ZeroTraceManager.wipeCharArray(verifierChars)
    }
  }

  private fun exchangeCodeForToken(
    clientId: String,
    clientSecret: String,
    code: String,
    redirectUri: String,
    codeVerifier: CharArray,
    httpClient: OkHttpClient,
    oauthBaseUrl: String,
  ): CharArray {
    val base = oauthBaseUrl.trimEnd('/')
    val formBuilder = FormBody.Builder()
      .add("client_id", clientId)
      .add("code", code)
      .add("redirect_uri", redirectUri)
      .add("code_verifier", String(codeVerifier))
    if (clientSecret.isNotBlank()) {
      formBuilder.add("client_secret", clientSecret)
    }

    val request = Request.Builder()
      .url("$base/login/oauth/access_token")
      .header("Accept", "application/json")
      .header("User-Agent", GitHubConfig.USER_AGENT)
      .post(formBuilder.build())
      .build()

    httpClient.newCall(request).execute().use { response ->
      val bodyBytes = response.body?.bytes() ?: ByteArray(0)
      val bodyStr = try {
        bodyBytes.toString(Charsets.UTF_8)
      } finally {
        ZeroTraceManager.wipeByteArray(bodyBytes)
      }

      if (!response.isSuccessful && bodyStr.isBlank()) {
        throw GitHubOAuthException("GitHub token exchange failed (HTTP ${response.code}).")
      }

      val payload = runCatching {
        json.decodeFromString(OAuthTokenResponseDto.serializer(), bodyStr)
      }.getOrElse { err ->
        throw GitHubOAuthException("Unexpected token response from GitHub.", err)
      }

      val token = payload.accessToken
      if (!token.isNullOrBlank()) {
        return token.toCharArray()
      }

      val errCode = payload.error
      val errDesc = payload.errorDescription ?: errCode ?: "Token exchange failed"
      when (errCode) {
        "expired_token", "bad_verification_code" -> throw GitHubOAuthExpiredException(errDesc)
        "access_denied" -> throw GitHubOAuthDeniedException(errDesc)
        else -> throw GitHubOAuthException("GitHub OAuth failed: $errDesc")
      }
    }
  }

  suspend fun fetchUserProfile(
    token: CharArray,
    httpClient: OkHttpClient = defaultClient,
    apiBaseUrl: String = GitHubConfig.apiBaseUrl,
  ): GitHubUserProfile = withContext(Dispatchers.IO) {
    require(token.isNotEmpty()) { "GitHub access token must not be empty" }
    val base = apiBaseUrl.trimEnd('/')
    val request = Request.Builder()
      .url("$base/user")
      .header("Accept", "application/vnd.github+json")
      .header("Authorization", "Bearer ${String(token)}")
      .header("X-GitHub-Api-Version", "2022-11-28")
      .header("User-Agent", GitHubConfig.USER_AGENT)
      .get()
      .build()

    httpClient.newCall(request).execute().use { response ->
      val bodyBytes = response.body?.bytes() ?: ByteArray(0)
      val bodyStr = try {
        bodyBytes.toString(Charsets.UTF_8)
      } finally {
        ZeroTraceManager.wipeByteArray(bodyBytes)
      }

      if (response.code == 401) {
        throw GitHubOAuthExpiredException("GitHub session expired. Please reconnect.")
      }
      if (!response.isSuccessful) {
        throw GitHubOAuthException(
          "Unable to verify GitHub profile (HTTP ${response.code}): ${bodyStr.take(200)}"
        )
      }

      val dto = runCatching {
        json.decodeFromString(GitHubUserDto.serializer(), bodyStr)
      }.getOrElse { err ->
        throw GitHubOAuthException("Invalid GitHub profile payload.", err)
      }
      GitHubUserProfile(username = dto.login, avatarUrl = dto.avatarUrl)
    }
  }

  private fun constantTimeEquals(expected: String, actual: String): Boolean {
    return MessageDigest.isEqual(
      expected.toByteArray(Charsets.UTF_8),
      actual.toByteArray(Charsets.UTF_8),
    )
  }

  private fun urlEncode(value: String): String = URLEncoder.encode(value, Charsets.UTF_8.name())

  private fun launchCustomTab(context: Context, url: String) {
    val uri = Uri.parse(url)
    runCatching {
      val customTabsIntent = CustomTabsIntent.Builder()
        .setShowTitle(true)
        .build()
      if (context !is android.app.Activity) {
        customTabsIntent.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
      }
      customTabsIntent.launchUrl(context, uri)
    }.onFailure {
      runCatching {
        val fallback = Intent(Intent.ACTION_VIEW, uri).apply {
          if (context !is android.app.Activity) {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
          }
        }
        context.startActivity(fallback)
      }
    }
  }
}
