package com.shipsign.app.core.storage

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import com.shipsign.app.core.security.ZeroTraceManager
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException

data class CopiedSessionFile(
  val file: File,
  val displayName: String,
  val sizeBytes: Long,
)

/**
 * Memory-safe 64KB streaming bridge between Android Storage Access Framework (SAF),
 * MediaStore Downloads, and ShipSign's ephemeral session sandbox.
 */
object SafFileBridge {

  private const val STREAM_BUFFER_SIZE = 64 * 1024

  fun resolveDisplayName(
    context: Context,
    uri: Uri,
    fallback: String = "artifact.bin",
  ): String {
    var resolvedName: String? = null
    if (uri.scheme.equals("content", ignoreCase = true)) {
      runCatching {
        context.contentResolver.query(
          uri,
          arrayOf(OpenableColumns.DISPLAY_NAME),
          null,
          null,
          null,
        )?.use { cursor ->
          if (cursor.moveToFirst()) {
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0) {
              resolvedName = cursor.getString(idx)
            }
          }
        }
      }
    }
    if (resolvedName.isNullOrBlank()) {
      resolvedName = uri.lastPathSegment?.substringAfterLast('/')
    }
    return sanitizeFileName(resolvedName ?: fallback)
  }

  /**
   * Streams [uri] via ContentResolver into [sessionDir] using a 64KB buffer.
   * Never loads the target file into memory.
   */
  fun copyUriToSession(
    context: Context,
    uri: Uri,
    sessionDir: File,
    targetName: String? = null,
  ): CopiedSessionFile {
    if (!sessionDir.exists()) {
      sessionDir.mkdirs()
    }
    val displayName = sanitizeFileName(targetName ?: resolveDisplayName(context, uri))
    val destinationFile = File(sessionDir, displayName)
    val buffer = ByteArray(STREAM_BUFFER_SIZE)
    var totalBytes = 0L

    try {
      val inputStream = context.contentResolver.openInputStream(uri)
        ?: throw IOException("Unable to open input stream for URI")

      inputStream.use { input ->
        FileOutputStream(destinationFile, false).use { output ->
          while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
            totalBytes += read
          }
          output.flush()
        }
      }

      return CopiedSessionFile(
        file = destinationFile,
        displayName = displayName,
        sizeBytes = totalBytes,
      )
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(destinationFile)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  /**
   * Exports a finalized signed/processed [sourceFile] to public `Downloads/ShipSign/`
   * using MediaStore on Android 10+ (API 29+) and public Downloads directory on Android 8–9.
   */
  fun exportFileToDownloads(
    context: Context,
    sourceFile: File,
    outputFileName: String,
    mimeType: String,
  ): Uri {
    if (!sourceFile.exists() || !sourceFile.isFile) {
      throw IOException("Source export file does not exist")
    }
    val safeName = sanitizeFileName(outputFileName)
    val buffer = ByteArray(STREAM_BUFFER_SIZE)

    try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val resolver = context.contentResolver
        val relativePath = "${Environment.DIRECTORY_DOWNLOADS}/${ZeroTraceManager.PUBLIC_EXPORT_SUBDIR}"
        val values = ContentValues().apply {
          put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
          put(MediaStore.MediaColumns.MIME_TYPE, mimeType)
          put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
          put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
          ?: throw IOException("MediaStore failed to create Downloads entry")

        try {
          val outStream = resolver.openOutputStream(itemUri)
            ?: throw IOException("MediaStore failed to open output stream")
          outStream.use { output ->
            FileInputStream(sourceFile).use { input ->
              while (true) {
                val read = input.read(buffer)
                if (read == -1) break
                output.write(buffer, 0, read)
              }
              output.flush()
            }
          }
          val publishValues = ContentValues().apply {
            put(MediaStore.MediaColumns.IS_PENDING, 0)
          }
          resolver.update(itemUri, publishValues, null, null)
          return itemUri
        } catch (e: Exception) {
          runCatching { resolver.delete(itemUri, null, null) }
          throw e
        }
      } else {
        @Suppress("DEPRECATION")
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val shipSignDir = File(downloadsDir, ZeroTraceManager.PUBLIC_EXPORT_SUBDIR)
        if (!shipSignDir.exists() && !shipSignDir.mkdirs()) {
          throw IOException("Unable to create public Downloads/ShipSign folder")
        }
        val destFile = resolveUniqueFile(shipSignDir, safeName)
        try {
          FileInputStream(sourceFile).use { input ->
            FileOutputStream(destFile, false).use { output ->
              while (true) {
                val read = input.read(buffer)
                if (read == -1) break
                output.write(buffer, 0, read)
              }
              output.flush()
            }
          }
          MediaScannerConnection.scanFile(
            context.applicationContext,
            arrayOf(destFile.absolutePath),
            arrayOf(mimeType),
            null,
          )
          return Uri.fromFile(destFile)
        } catch (e: Exception) {
          if (destFile.exists()) {
            destFile.delete()
          }
          throw e
        }
      }
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  private fun resolveUniqueFile(parent: File, fileName: String): File {
    var candidate = File(parent, fileName)
    if (!candidate.exists()) return candidate
    val dotIdx = fileName.lastIndexOf('.')
    val base = if (dotIdx > 0) fileName.substring(0, dotIdx) else fileName
    val ext = if (dotIdx > 0) fileName.substring(dotIdx) else ""
    var counter = 1
    while (candidate.exists()) {
      candidate = File(parent, "${base}_($counter)$ext")
      counter++
    }
    return candidate
  }

  fun sanitizeFileName(rawName: String): String {
    val leaf = rawName.substringAfterLast('/').substringAfterLast('\\').trim()
    val cleaned = leaf.replace(Regex("[^a-zA-Z0-9._-]"), "_")
    return if (cleaned.isBlank() || cleaned == "." || cleaned == "..") {
      "artifact.bin"
    } else {
      cleaned
    }
  }
}
