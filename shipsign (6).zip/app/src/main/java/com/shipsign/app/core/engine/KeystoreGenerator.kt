package com.shipsign.app.core.engine

import com.shipsign.app.core.security.JksKeyStoreCodec
import com.shipsign.app.core.security.UnsupportedKeystoreException
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.core.storage.SafFileBridge
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import org.bouncycastle.asn1.x500.X500NameBuilder
import org.bouncycastle.asn1.x500.style.BCStyle
import org.bouncycastle.asn1.x509.BasicConstraints
import org.bouncycastle.asn1.x509.Extension
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509ExtensionUtils
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.io.File
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.SecureRandom
import java.security.cert.X509Certificate
import java.util.Date
import java.util.Locale

/**
 * Replicates full `keytool -genkeypair` behavior offline using Bouncy Castle for both
 * `KeystoreFormat.JKS` and `KeystoreFormat.PKCS12`.
 *
 * Immediately wipes `storePassword` and `keyPassword` `CharArray` buffers after `store()`.
 */
object KeystoreGenerator {

  private const val RSA_KEY_SIZE = 2048
  private const val SIGNATURE_ALGORITHM = "SHA256withRSA"
  private const val MILLIS_PER_DAY = 86_400_000L

  fun generateKeystore(
    request: KeystoreCreateRequest,
    sessionDir: File,
  ): File {
    val secureRandom = SecureRandom()
    val safeName = SafFileBridge.sanitizeFileName(ensureExtension(request.fileName, request.format))
    val outputFile = File(sessionDir, safeName)

    try {
      require(request.format == KeystoreFormat.JKS || request.format == KeystoreFormat.PKCS12) {
        "KeystoreGenerator supports only JKS and PKCS12 formats (got ${request.format})"
      }
      require(request.keyAlias.isNotBlank()) { "Key alias must not be blank" }
      require(request.storePassword.isNotEmpty()) { "Store password must not be empty" }
      require(request.keyPassword.isNotEmpty()) { "Key password must not be empty" }
      require(request.validityDays > 0) { "Validity days must be positive" }

      if (!sessionDir.exists()) {
        sessionDir.mkdirs()
      }

      val keyPairGen = KeyPairGenerator.getInstance("RSA", BouncyCastleProvider.PROVIDER_NAME)
      keyPairGen.initialize(RSA_KEY_SIZE, secureRandom)
      val keyPair = keyPairGen.generateKeyPair()

      val dnBuilder = X500NameBuilder(BCStyle.INSTANCE)
      val cn = request.commonName.trim().ifEmpty { "ShipSign" }
      dnBuilder.addRDN(BCStyle.CN, cn)
      if (request.organizationalUnit.isNotBlank()) {
        dnBuilder.addRDN(BCStyle.OU, request.organizationalUnit.trim())
      }
      if (request.organization.isNotBlank()) {
        dnBuilder.addRDN(BCStyle.O, request.organization.trim())
      }
      if (request.cityLocality.isNotBlank()) {
        dnBuilder.addRDN(BCStyle.L, request.cityLocality.trim())
      }
      if (request.stateProvince.isNotBlank()) {
        dnBuilder.addRDN(BCStyle.ST, request.stateProvince.trim())
      }
      if (request.countryCode.isNotBlank()) {
        dnBuilder.addRDN(BCStyle.C, request.countryCode.trim().uppercase(Locale.US).take(2))
      }
      val subjectDn = dnBuilder.build()

      val notBefore = Date(System.currentTimeMillis() - 60_000L)
      val notAfter = Date(System.currentTimeMillis() + request.validityDays.toLong() * MILLIS_PER_DAY)
      val serial = BigInteger(64, secureRandom).abs().max(BigInteger.ONE)

      val certBuilder = JcaX509v3CertificateBuilder(
        subjectDn,
        serial,
        notBefore,
        notAfter,
        subjectDn,
        keyPair.public,
      )

      val extUtils = JcaX509ExtensionUtils()
      certBuilder.addExtension(
        Extension.subjectKeyIdentifier,
        false,
        extUtils.createSubjectKeyIdentifier(keyPair.public),
      )
      certBuilder.addExtension(
        Extension.basicConstraints,
        true,
        BasicConstraints(false),
      )

      val signer = JcaContentSignerBuilder(SIGNATURE_ALGORITHM)
        .setProvider(BouncyCastleProvider.PROVIDER_NAME)
        .build(keyPair.private)

      val certHolder = certBuilder.build(signer)
      val certificate: X509Certificate = JcaX509CertificateConverter()
        .setProvider(BouncyCastleProvider.PROVIDER_NAME)
        .getCertificate(certHolder)

      val normalizedAlias = request.keyAlias.trim().lowercase(Locale.ROOT)
      val chain = arrayOf(certificate)

      when (request.format) {
        KeystoreFormat.JKS -> {
          JksKeyStoreCodec.writeJks(
            outputFile = outputFile,
            alias = normalizedAlias,
            privateKey = keyPair.private,
            keyPassword = request.keyPassword,
            certificateChain = chain,
            storePassword = request.storePassword,
          )
        }

        KeystoreFormat.PKCS12 -> {
          val ks = runCatching { KeyStore.getInstance("PKCS12") }
            .getOrElse {
              runCatching { KeyStore.getInstance("PKCS12", BouncyCastleProvider.PROVIDER_NAME) }
                .getOrElse { e -> throw UnsupportedKeystoreException("PKCS12 provider unavailable", e) }
            }
          ks.load(null, null)
          ks.setKeyEntry(normalizedAlias, keyPair.private, request.keyPassword, chain)
          FileOutputStream(outputFile, false).use { fos ->
            ks.store(fos, request.storePassword)
            fos.flush()
          }
        }

        else -> throw UnsupportedKeystoreException("Unsupported format: ${request.format}")
      }

      return outputFile
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(outputFile)
      throw e
    } finally {
      ZeroTraceManager.wipeCharArray(request.storePassword)
      ZeroTraceManager.wipeCharArray(request.keyPassword)
    }
  }

  private fun ensureExtension(rawName: String, format: KeystoreFormat): String {
    val trimmed = rawName.trim().ifEmpty { "shipsign_upload" }
    return when (format) {
      KeystoreFormat.JKS -> if (trimmed.lowercase(Locale.US).endsWith(".jks")) trimmed else "$trimmed.jks"
      KeystoreFormat.PKCS12 -> {
        val lower = trimmed.lowercase(Locale.US)
        if (lower.endsWith(".p12") || lower.endsWith(".pfx")) trimmed else "$trimmed.p12"
      }
      else -> trimmed
    }
  }
}
