package com.shipsign.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shipsign.app.R
import com.shipsign.app.ui.CryptoDiagnosticsState
import com.shipsign.app.ui.SecurityProviderInfo
import com.shipsign.app.ui.components.StandardCardShape

@Composable
fun CryptoCoreScreen(
  diagnostics: CryptoDiagnosticsState,
  onVerifyCapabilities: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  Box(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = stringResource(R.string.crypto_title),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = stringResource(R.string.crypto_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      item {
        val slotVerified = diagnostics.bouncyCastleSlot == 1
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("bouncycastle_slot_card"),
          shape = StandardCardShape,
          color = if (slotVerified) {
            MaterialTheme.colorScheme.primaryContainer
          } else {
            MaterialTheme.colorScheme.errorContainer
          },
          border = BorderStroke(
            width = 1.dp,
            color = if (slotVerified) {
              MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
            } else {
              MaterialTheme.colorScheme.error
            },
          ),
        ) {
          Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Icon(
              imageVector = if (slotVerified) Icons.Filled.Key else Icons.Filled.Warning,
              contentDescription = null,
              tint = if (slotVerified) {
                MaterialTheme.colorScheme.onPrimaryContainer
              } else {
                MaterialTheme.colorScheme.onErrorContainer
              },
              modifier = Modifier.size(22.dp),
            )
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
              Text(
                text = stringResource(R.string.crypto_bc_slot_label),
                style = MaterialTheme.typography.labelSmall,
                color = if (slotVerified) {
                  MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                  MaterialTheme.colorScheme.onErrorContainer
                },
              )
              Text(
                text = if (slotVerified) {
                  stringResource(R.string.crypto_bc_verified, diagnostics.bouncyCastleVersion)
                } else {
                  stringResource(R.string.crypto_bc_mismatch, diagnostics.bouncyCastleSlot)
                },
                style = MaterialTheme.typography.titleSmall,
                color = if (slotVerified) {
                  MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                  MaterialTheme.colorScheme.onErrorContainer
                },
              )
            }
          }
        }
      }

      item {
        Button(
          onClick = onVerifyCapabilities,
          enabled = !diagnostics.isTesting,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("verify_crypto_capabilities_button"),
          shape = RoundedCornerShape(12.dp),
        ) {
          if (diagnostics.isTesting) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = MaterialTheme.colorScheme.onPrimary,
            )
            Spacer(modifier = Modifier.width(10.dp))
          } else {
            Icon(
              imageVector = Icons.Filled.Memory,
              contentDescription = null,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
          }
          Text(
            text = stringResource(R.string.crypto_run_selftest),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }

      item {
        AnimatedVisibility(visible = diagnostics.selfTestPassed != null) {
          val ok = diagnostics.selfTestPassed == true
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("crypto_selftest_result"),
            shape = StandardCardShape,
            color = if (ok) {
              MaterialTheme.colorScheme.secondaryContainer
            } else {
              MaterialTheme.colorScheme.errorContainer
            },
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          ) {
            Row(
              modifier = Modifier.padding(16.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              Icon(
                imageVector = if (ok) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                contentDescription = null,
                tint = if (ok) {
                  MaterialTheme.colorScheme.onSecondaryContainer
                } else {
                  MaterialTheme.colorScheme.onErrorContainer
                },
                modifier = Modifier.size(20.dp),
              )
              Text(
                text = stringResource(R.string.crypto_selftest_ok),
                style = MaterialTheme.typography.bodyMedium,
                color = if (ok) {
                  MaterialTheme.colorScheme.onSecondaryContainer
                } else {
                  MaterialTheme.colorScheme.onErrorContainer
                },
              )
            }
          }
        }
      }

      item {
        Text(
          text = stringResource(R.string.crypto_providers_header),
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.padding(top = 4.dp),
        )
      }

      items(diagnostics.providers, key = { "${it.slot}_${it.name}" }) { provider ->
        ProviderRow(provider = provider)
      }
    }
  }
}

@Composable
private fun ProviderRow(provider: SecurityProviderInfo) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = StandardCardShape,
    color = if (provider.isBouncyCastle) {
      MaterialTheme.colorScheme.surfaceContainerHigh
    } else {
      MaterialTheme.colorScheme.surfaceContainerLow
    },
    border = BorderStroke(
      width = 1.dp,
      color = if (provider.isBouncyCastle) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.6f)
      } else {
        MaterialTheme.colorScheme.outlineVariant
      },
    ),
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (provider.isBouncyCastle) {
          MaterialTheme.colorScheme.primaryContainer
        } else {
          MaterialTheme.colorScheme.surfaceVariant
        },
      ) {
        Text(
          text = "#${provider.slot}",
          style = MaterialTheme.typography.labelMedium,
          color = if (provider.isBouncyCastle) {
            MaterialTheme.colorScheme.onPrimaryContainer
          } else {
            MaterialTheme.colorScheme.onSurfaceVariant
          },
          modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
        )
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = "${provider.name} v${provider.version}",
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = provider.info,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}
