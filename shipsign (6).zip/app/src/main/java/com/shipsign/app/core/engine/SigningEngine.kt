package com.shipsign.app.core.engine

import android.content.Context
import android.net.Uri
import com.android.apksig.ApkSigner
import com.android.apksig.ApkVerifier
import com.shipsign.app.core.security.KeystoreDetector
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.core.storage.SafFileBridge
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ImportedKeystoreConfig
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.domain.model.SigningOptions
import com.shipsign.app.domain.model.SigningResult
import com.shipsign.app.domain.model.ValidatedKeystoreCredentials
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import org.bouncycastle.cert.jcajce.JcaCertStore
import org.bouncycastle.cms.CMSProcessableByteArray
import org.bouncycastle.cms.CMSSignedDataGenerator
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder
import org.bouncycastle.jce.provider.BouncyCastleProvider
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.util.Base64
import java.util.Locale
import java.util.jar.Attributes
import java.util.jar.Manifest
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

sealed interface SigningProgressEvent {
  data class Log(val line: String) : SigningProgressEvent
  data class Completed(val result: SigningResult) : SigningProgressEvent
}

/**
 * Offline APK (`apksig` v1/v2/v3/v4 + `ApkVerifier`) and AAB (`jarsigner`-compatible CMS/SHA-256)
 * signing engine with step-by-step progress log streaming and automatic ephemeral shredding.
 */
object SigningEngine {

  private const val STREAM_BUFFER_SIZE = 64 * 1024

  fun signWithLogs(
    context: Context,
    target: AppTargetFile,
    keystoreConfig: ImportedKeystoreConfig,
    options: SigningOptions,
    onResult: (SigningResult) -> Unit = {},
  ): Flow<String> = flow {
    val logs = mutableListOf<String>()
    suspend fun emitLog(message: String) {
      logs.add(message)
      emit(message)
    }

    val result = executeSigningInternal(
      context = context,
      target = target,
      keystoreConfig = keystoreConfig,
      options = options,
      emitLog = ::emitLog,
      logs = logs,
    )
    onResult(result)
  }.flowOn(Dispatchers.IO)

  fun signEvents(
    context: Context,
    target: AppTargetFile,
    keystoreConfig: ImportedKeystoreConfig,
    options: SigningOptions,
  ): Flow<SigningProgressEvent> = flow {
    val logs = mutableListOf<String>()
    suspend fun emitLog(message: String) {
      logs.add(message)
      emit(SigningProgressEvent.Log(message))
    }

    val result = executeSigningInternal(
      context = context,
      target = target,
      keystoreConfig = keystoreConfig,
      options = options,
      emitLog = ::emitLog,
      logs = logs,
    )
    emit(SigningProgressEvent.Completed(result))
  }.flowOn(Dispatchers.IO)

  private suspend fun executeSigningInternal(
    context: Context,
    target: AppTargetFile,
    keystoreConfig: ImportedKeystoreConfig,
    options: SigningOptions,
    emitLog: suspend (String) -> Unit,
    logs: List<String>,
  ): SigningResult {
    ZeroTraceManager.createOrGetSessionDir(context)
    val scratchFiles = mutableListOf<File>()

    try {
      require(
        target.binaryType == ResolvedBinaryType.APK || target.binaryType == ResolvedBinaryType.AAB,
      ) {
        "Only APK and AAB binaries can be signed (got ${target.binaryType})"
      }

      emitLog("Unlocking keystore & validating alias...")
      val credentials = KeystoreDetector.validateKeystoreCredentials(keystoreConfig)
      ZeroTraceManager.wipeCharArray(keystoreConfig.storePassword)
      ZeroTraceManager.wipeCharArray(keystoreConfig.keyPassword)

      var workingBinary = target.sessionFile
      if (SignatureScanner.hasExistingSignature(workingBinary)) {
        emitLog("Stripping existing signatures cleanly...")
        val stripped = ZeroTraceManager.allocateTempFile(
          context,
          "stripped",
          if (target.binaryType == ResolvedBinaryType.AAB) ".aab" else ".apk",
        )
        scratchFiles.add(stripped)
        SignatureScanner.stripExistingSignature(workingBinary, stripped)
        workingBinary = stripped
      }

      val baseName = target.originalName.substringBeforeLast('.').ifBlank { "app" }

      return if (target.binaryType == ResolvedBinaryType.APK) {
        signApkInternal(
          context = context,
          inputApk = workingBinary,
          baseName = baseName,
          credentials = credentials,
          options = options,
          scratchFiles = scratchFiles,
          emitLog = emitLog,
          logs = logs,
        )
      } else {
        signAabInternal(
          context = context,
          inputAab = workingBinary,
          baseName = baseName,
          credentials = credentials,
          options = options,
          scratchFiles = scratchFiles,
          emitLog = emitLog,
          logs = logs,
        )
      }
    } finally {
      ZeroTraceManager.wipeCharArray(keystoreConfig.storePassword)
      ZeroTraceManager.wipeCharArray(keystoreConfig.keyPassword)
      scratchFiles.forEach { ZeroTraceManager.secureDeleteFile(it) }
    }
  }

  private suspend fun signApkInternal(
    context: Context,
    inputApk: File,
    baseName: String,
    credentials: ValidatedKeystoreCredentials,
    options: SigningOptions,
    scratchFiles: MutableList<File>,
    emitLog: suspend (String) -> Unit,
    logs: List<String>,
  ): SigningResult {
    var apkToSign = inputApk
    if (options.zipAlignBeforeSign) {
      emitLog("Aligning APK (4-byte + 16KB ELF .so pages)...")
      val aligned = ZeroTraceManager.allocateTempFile(context, "aligned", ".apk")
      scratchFiles.add(aligned)
      ZipAlignEngine.alignApk(
        inputApk = inputApk,
        outputApk = aligned,
        alignment = 4,
        pageAlignSharedLibs = true,
      )
      apkToSign = aligned
    }

    val schemes = buildList {
      if (options.v1Enabled) add("v1")
      if (options.v2Enabled) add("v2")
      if (options.v3Enabled) add("v3")
      if (options.v4Enabled) add("v4")
    }.joinToString("/")
    emitLog("Signing APK with $schemes...")

    val signedApk = ZeroTraceManager.allocateTempFile(context, "signed", ".apk")
    scratchFiles.add(signedApk)
    val idsigFile = if (options.v4Enabled) {
      ZeroTraceManager.allocateTempFile(context, "signed", ".apk.idsig").also { scratchFiles.add(it) }
    } else {
      null
    }

    val signerConfig = ApkSigner.SignerConfig.Builder(
      credentials.alias,
      credentials.privateKey,
      credentials.certificateChain,
    ).build()

    val builder = ApkSigner.Builder(listOf(signerConfig))
      .setInputApk(apkToSign)
      .setOutputApk(signedApk)
      .setCreatedBy("ShipSign")
      .setV1SigningEnabled(options.v1Enabled)
      .setV2SigningEnabled(options.v2Enabled)
      .setV3SigningEnabled(options.v3Enabled)
      .setV4SigningEnabled(options.v4Enabled)

    if (idsigFile != null) {
      builder.setV4SignatureOutputFile(idsigFile)
    }

    builder.build().sign()

    emitLog("Verifying cryptographic signature integrity...")
    val verification = ApkVerifier.Builder(signedApk).build().verify()
    if (!verification.isVerified) {
      val reason = verification.errors.firstOrNull()?.toString() ?: "APK signature verification failed"
      throw SecurityException(reason)
    }

    val cert = verification.signerCertificates.firstOrNull() ?: credentials.certificateChain.first()
    val sha1 = formatCertFingerprint(cert, "SHA-1")
    val sha256 = formatCertFingerprint(cert, "SHA-256")

    val exportName = "${baseName}-signed.apk"
    emitLog("Exporting $exportName to Downloads/ShipSign...")
    val exportedUri: Uri = SafFileBridge.exportFileToDownloads(
      context = context,
      sourceFile = signedApk,
      outputFileName = exportName,
      mimeType = "application/vnd.android.package-archive",
    )

    return SigningResult(
      primarySignedUri = exportedUri,
      primaryFileName = exportName,
      companionApkUri = null,
      companionApkFileName = null,
      sha1Fingerprint = sha1,
      sha256Fingerprint = sha256,
      logs = logs.toList(),
    )
  }

  private suspend fun signAabInternal(
    context: Context,
    inputAab: File,
    baseName: String,
    credentials: ValidatedKeystoreCredentials,
    options: SigningOptions,
    scratchFiles: MutableList<File>,
    emitLog: suspend (String) -> Unit,
    logs: List<String>,
  ): SigningResult {
    emitLog("Signing AAB entries with SHA256withRSA / CMS PKCS#7...")
    val signedAab = ZeroTraceManager.allocateTempFile(context, "signed", ".aab")
    scratchFiles.add(signedAab)

    signJarArchiveWithBouncyCastle(
      inputFile = inputAab,
      outputFile = signedAab,
      credentials = credentials,
    )

    val cert = credentials.certificateChain.first()
    val sha1 = formatCertFingerprint(cert, "SHA-1")
    val sha256 = formatCertFingerprint(cert, "SHA-256")

    val exportAabName = "${baseName}-signed.aab"
    emitLog("Exporting $exportAabName to Downloads/ShipSign...")
    val aabUri = SafFileBridge.exportFileToDownloads(
      context = context,
      sourceFile = signedAab,
      outputFileName = exportAabName,
      mimeType = "application/octet-stream",
    )

    var companionUri: Uri? = null
    var companionName: String? = null
    if (options.convertAabToApk) {
      emitLog("Converting signed AAB to universal APK via BundleTool...")
      val universalApk = ZeroTraceManager.allocateTempFile(context, "universal", ".apk")
      scratchFiles.add(universalApk)
      BundleToolEngine.convertSignedAabToUniversalApk(
        context = context,
        signedAab = signedAab,
        outputUniversalApk = universalApk,
        credentials = credentials,
      )
      val outUniversalName = "${baseName}-signed-universal.apk"
      emitLog("Exporting $outUniversalName to Downloads/ShipSign...")
      companionUri = SafFileBridge.exportFileToDownloads(
        context = context,
        sourceFile = universalApk,
        outputFileName = outUniversalName,
        mimeType = "application/vnd.android.package-archive",
      )
      companionName = outUniversalName
    }

    return SigningResult(
      primarySignedUri = aabUri,
      primaryFileName = exportAabName,
      companionApkUri = companionUri,
      companionApkFileName = companionName,
      sha1Fingerprint = sha1,
      sha256Fingerprint = sha256,
      logs = logs.toList(),
    )
  }

  internal fun signJarArchiveWithBouncyCastle(
    inputFile: File,
    outputFile: File,
    credentials: ValidatedKeystoreCredentials,
  ) {
    val buffer = ByteArray(STREAM_BUFFER_SIZE)
    val base64 = Base64.getEncoder()
    val sha256 = MessageDigest.getInstance("SHA-256")
    val manifest = Manifest().apply {
      mainAttributes[Attributes.Name.MANIFEST_VERSION] = "1.0"
      mainAttributes[Attributes.Name("Created-By")] = "ShipSign"
    }

    try {
      ZipFile(inputFile).use { zipFile ->
        ZipOutputStream(BufferedOutputStream(FileOutputStream(outputFile, false), STREAM_BUFFER_SIZE)).use { zos ->
          val entries = zipFile.entries()
          while (entries.hasMoreElements()) {
            val sourceEntry = entries.nextElement()
            if (SignatureScanner.isSignatureArtifact(sourceEntry.name)) continue

            val outEntry = ZipEntry(sourceEntry.name).apply {
              if (sourceEntry.time > 0L) time = sourceEntry.time
              if (sourceEntry.isDirectory) {
                method = ZipEntry.STORED
                size = 0L
                compressedSize = 0L
                crc = 0L
              } else {
                method = ZipEntry.DEFLATED
              }
            }

            zos.putNextEntry(outEntry)
            if (!sourceEntry.isDirectory) {
              sha256.reset()
              zipFile.getInputStream(sourceEntry).use { input ->
                while (true) {
                  val read = input.read(buffer)
                  if (read == -1) break
                  sha256.update(buffer, 0, read)
                  zos.write(buffer, 0, read)
                }
              }
              val digestB64 = base64.encodeToString(sha256.digest())
              val attrs = Attributes().apply {
                putValue("SHA-256-Digest", digestB64)
              }
              manifest.entries[sourceEntry.name] = attrs
            }
            zos.closeEntry()
          }

          val manifestBytes = ByteArrayOutputStream().also { manifest.write(it) }.toByteArray()
          writeRawZipEntry(zos, "META-INF/MANIFEST.MF", manifestBytes)

          val sfBytes = buildSignatureFileBytes(manifestBytes, manifest, sha256, base64)
          writeRawZipEntry(zos, "META-INF/CERT.SF", sfBytes)

          val sigAlg = selectJarSignatureAlgorithm(credentials.privateKey.algorithm)
          val sigExt = selectJarSignatureExtension(credentials.privateKey.algorithm)
          val cmsBytes = buildCmsSignatureBlock(sfBytes, sigAlg, credentials)
          writeRawZipEntry(zos, "META-INF/CERT.$sigExt", cmsBytes)

          zos.finish()
          zos.flush()
        }
      }
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(outputFile)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  private fun buildSignatureFileBytes(
    manifestBytes: ByteArray,
    manifest: Manifest,
    sha256: MessageDigest,
    base64: Base64.Encoder,
  ): ByteArray {
    val sfManifest = Manifest().apply {
      mainAttributes[Attributes.Name.SIGNATURE_VERSION] = "1.0"
      mainAttributes[Attributes.Name("Created-By")] = "ShipSign"
      sha256.reset()
      mainAttributes[Attributes.Name("SHA-256-Digest-Manifest")] =
        base64.encodeToString(sha256.digest(manifestBytes))
    }

    val sfOut = ByteArrayOutputStream()
    sfManifest.write(sfOut)

    val manifestText = manifestBytes.toString(Charsets.UTF_8)
    val sections = manifestText.split("\r\n\r\n")
    for (section in sections) {
      val trimmed = section.trim()
      if (trimmed.isEmpty() || trimmed.startsWith("Manifest-Version:", ignoreCase = true)) continue
      val firstLine = trimmed.lineSequence().firstOrNull().orEmpty()
      if (!firstLine.startsWith("Name: ")) continue
      val entryName = firstLine.removePrefix("Name: ")
      if (!manifest.entries.containsKey(entryName)) continue

      val sectionWithBreak = "$section\r\n\r\n".toByteArray(Charsets.UTF_8)
      sha256.reset()
      val sectionDigest = base64.encodeToString(sha256.digest(sectionWithBreak))

      val blockBytes = buildString {
        append("Name: ").append(entryName).append("\r\n")
        append("SHA-256-Digest: ").append(sectionDigest).append("\r\n\r\n")
      }.toByteArray(Charsets.UTF_8)
      sfOut.write(blockBytes)
    }

    return sfOut.toByteArray()
  }

  private fun buildCmsSignatureBlock(
    sfBytes: ByteArray,
    signatureAlgorithm: String,
    credentials: ValidatedKeystoreCredentials,
  ): ByteArray {
    val certStore = JcaCertStore(credentials.certificateChain)
    val digestProvider = JcaDigestCalculatorProviderBuilder()
      .setProvider(BouncyCastleProvider.PROVIDER_NAME)
      .build()
    val contentSigner = JcaContentSignerBuilder(signatureAlgorithm)
      .setProvider(BouncyCastleProvider.PROVIDER_NAME)
      .build(credentials.privateKey)
    val signerInfoGenerator = JcaSignerInfoGeneratorBuilder(digestProvider)
      .setDirectSignature(true)
      .build(contentSigner, credentials.certificateChain.first())

    val cmsGen = CMSSignedDataGenerator()
    cmsGen.addCertificates(certStore)
    cmsGen.addSignerInfoGenerator(signerInfoGenerator)

    val signedData = cmsGen.generate(CMSProcessableByteArray(sfBytes), false)
    return signedData.encoded
  }

  private fun writeRawZipEntry(zos: ZipOutputStream, name: String, data: ByteArray) {
    val entry = ZipEntry(name).apply { method = ZipEntry.DEFLATED }
    zos.putNextEntry(entry)
    zos.write(data)
    zos.closeEntry()
  }

  private fun selectJarSignatureAlgorithm(keyAlgorithm: String): String {
    return when (keyAlgorithm.uppercase(Locale.US)) {
      "EC", "ECDSA" -> "SHA256withECDSA"
      "DSA" -> "SHA256withDSA"
      else -> "SHA256withRSA"
    }
  }

  private fun selectJarSignatureExtension(keyAlgorithm: String): String {
    return when (keyAlgorithm.uppercase(Locale.US)) {
      "EC", "ECDSA" -> "EC"
      "DSA" -> "DSA"
      else -> "RSA"
    }
  }

  fun formatCertFingerprint(certificate: X509Certificate, algorithm: String): String {
    val digest = MessageDigest.getInstance(algorithm).digest(certificate.encoded)
    return digest.joinToString(":") { byte -> String.format(Locale.US, "%02X", byte) }
  }
}
