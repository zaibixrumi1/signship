package com.shipsign.app.ui.screens.step2

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AddModerator
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.BugReport
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shipsign.app.R
import com.shipsign.app.domain.model.KeystoreCreateRequest
import com.shipsign.app.domain.model.KeystoreFormat
import com.shipsign.app.ui.KeystoreStudioUiState
import com.shipsign.app.ui.components.PasswordTextField
import com.shipsign.app.ui.components.StandardCardShape

private enum class KeystoreMode {
  EXISTING,
  GENERATE,
  DEBUG,
}

@Composable
private fun KeystoreModeSegmentedRow(
  selectedMode: KeystoreMode?,
  enabled: Boolean,
  onSelectExisting: () -> Unit,
  onSelectGenerate: () -> Unit,
  onSelectDebug: () -> Unit,
) {
  val items = listOf(
    Triple(KeystoreMode.EXISTING, stringResource(R.string.step2_mode_existing), onSelectExisting),
    Triple(KeystoreMode.GENERATE, stringResource(R.string.step2_mode_generate), onSelectGenerate),
    Triple(KeystoreMode.DEBUG, stringResource(R.string.step2_mode_debug), onSelectDebug),
  )

  SingleChoiceSegmentedButtonRow(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("keystore_mode_segmented_row"),
  ) {
    items.forEachIndexed { idx, (mode, label, action) ->
      SegmentedButton(
        selected = selectedMode == mode,
        onClick = { if (enabled) action() },
        enabled = enabled,
        shape = SegmentedButtonDefaults.itemShape(index = idx, count = items.size),
        modifier = Modifier.testTag("keystore_mode_${mode.name.lowercase()}"),
      ) {
        Text(
          text = label,
          style = MaterialTheme.typography.labelMedium,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
fun KeystoreChoiceScreen(
  isBusy: Boolean,
  onImportExisting: () -> Unit,
  onCreateNew: () -> Unit,
  onUseDebugKey: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  Box(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .testTag("keystore_choice_list"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = stringResource(R.string.step2_choice_title),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = stringResource(R.string.step2_choice_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      item {
        KeystoreModeSegmentedRow(
          selectedMode = null,
          enabled = !isBusy,
          onSelectExisting = onImportExisting,
          onSelectGenerate = onCreateNew,
          onSelectDebug = onUseDebugKey,
        )
      }

      item {
        ChoiceCard(
          title = stringResource(R.string.step2_import_card_title),
          description = stringResource(R.string.step2_import_card_desc),
          icon = Icons.Filled.Key,
          isPrimary = true,
          enabled = !isBusy,
          onClick = onImportExisting,
          testTag = "choice_import_keystore_card",
        )
      }

      item {
        ChoiceCard(
          title = stringResource(R.string.step2_create_card_title),
          description = stringResource(R.string.step2_create_card_desc),
          icon = Icons.Filled.AddModerator,
          isPrimary = false,
          enabled = !isBusy,
          onClick = onCreateNew,
          testTag = "choice_create_keystore_card",
        )
      }

      item {
        ChoiceCard(
          title = stringResource(R.string.step2_debug_card_title),
          description = stringResource(R.string.step2_debug_card_desc),
          icon = Icons.Filled.BugReport,
          isPrimary = false,
          enabled = !isBusy,
          isLoading = isBusy,
          onClick = onUseDebugKey,
          testTag = "choice_debug_key_card",
        )
      }
    }
  }
}

@Composable
fun KeystoreImportScreen(
  state: KeystoreStudioUiState,
  onPickKeystoreUri: (Uri) -> Unit,
  onSwitchToGenerate: () -> Unit,
  onSwitchToDebugKey: () -> Unit,
  onVerifyAndContinue: (storePass: CharArray, alias: String, keyPass: CharArray) -> Unit,
  modifier: Modifier = Modifier,
) {
  var storePassword by remember { mutableStateOf("") }
  var keyAlias by remember { mutableStateOf("") }
  var keyPassword by remember { mutableStateOf("") }
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  DisposableEffect(Unit) {
    onDispose {
      storePassword = ""
      keyPassword = ""
    }
  }

  val keystorePicker = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.OpenDocument(),
  ) { uri ->
    if (uri != null) {
      onPickKeystoreUri(uri)
    }
  }

  Box(
    modifier = modifier
      .fillMaxSize()
      .imePadding(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .testTag("keystore_import_list"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        KeystoreModeSegmentedRow(
          selectedMode = KeystoreMode.EXISTING,
          enabled = !state.isBusy,
          onSelectExisting = {},
          onSelectGenerate = onSwitchToGenerate,
          onSelectDebug = onSwitchToDebugKey,
        )
      }

      item {
        Text(
          text = stringResource(R.string.step2_import_title),
          style = MaterialTheme.typography.headlineSmall,
          color = MaterialTheme.colorScheme.onBackground,
        )
      }

      item {
        Button(
          onClick = { keystorePicker.launch(arrayOf("*/*")) },
          enabled = !state.isBusy,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("import_pick_keystore_button"),
          shape = RoundedCornerShape(12.dp),
        ) {
          Icon(Icons.Filled.FileOpen, contentDescription = null, modifier = Modifier.size(20.dp))
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = stringResource(R.string.step2_import_pick),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }

      item {
        AnimatedVisibility(visible = state.errorMessage != null) {
          state.errorMessage?.let { error ->
            ErrorBanner(message = error)
          }
        }
      }

      if (state.importedFileName != null) {
        item {
          Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = StandardCardShape,
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          ) {
            Column(
              modifier = Modifier.padding(16.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Column(
                  modifier = Modifier.weight(1f),
                  verticalArrangement = Arrangement.spacedBy(6.dp),
                ) {
                  Text(
                    text = state.importedFileName,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                  )
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (state.detectedFormat != KeystoreFormat.UNKNOWN) {
                      MaterialTheme.colorScheme.primaryContainer
                    } else {
                      MaterialTheme.colorScheme.tertiaryContainer
                    },
                  ) {
                    Text(
                      text = stringResource(R.string.step2_detected_badge, state.detectedFormat.name),
                      style = MaterialTheme.typography.labelMedium,
                      color = if (state.detectedFormat != KeystoreFormat.UNKNOWN) {
                        MaterialTheme.colorScheme.onPrimaryContainer
                      } else {
                        MaterialTheme.colorScheme.onTertiaryContainer
                      },
                      modifier = Modifier
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                        .testTag("detected_format_badge"),
                    )
                  }
                }
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(10.dp)),
                  contentAlignment = Alignment.Center,
                ) {
                  Icon(
                    imageVector = Icons.Filled.Key,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(20.dp),
                  )
                }
              }

              PasswordTextField(
                value = storePassword,
                onValueChange = { storePassword = it },
                label = stringResource(R.string.step2_field_store_password),
                leadingIcon = Icons.Filled.Lock,
                modifier = Modifier.testTag("import_store_password_field"),
              )

              IconOutlinedField(
                value = keyAlias,
                onValueChange = { keyAlias = it },
                label = stringResource(R.string.step2_field_alias),
                leadingIcon = Icons.Filled.Badge,
                keyboardOptions = KeyboardOptions(
                  capitalization = KeyboardCapitalization.None,
                  autoCorrectEnabled = false,
                  imeAction = ImeAction.Next,
                ),
                testTag = "import_alias_field",
              )

              PasswordTextField(
                value = keyPassword,
                onValueChange = { keyPassword = it },
                label = stringResource(R.string.step2_field_key_password),
                leadingIcon = Icons.Filled.VpnKey,
                imeAction = ImeAction.Done,
                supportingText = if (state.detectedFormat == KeystoreFormat.PKCS12) {
                  stringResource(R.string.step2_pkcs12_hint)
                } else {
                  null
                },
                modifier = Modifier.testTag("import_key_password_field"),
              )

              if (state.detectedFormat == KeystoreFormat.PKCS12) {
                Row(
                  verticalAlignment = Alignment.CenterVertically,
                  horizontalArrangement = Arrangement.spacedBy(8.dp),
                  modifier = Modifier.testTag("pkcs12_same_password_note"),
                ) {
                  Icon(
                    imageVector = Icons.Filled.Info,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.size(16.dp),
                  )
                  Text(
                    text = stringResource(R.string.step2_pkcs12_hint),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary,
                  )
                }
              }

              Button(
                onClick = {
                  val storeChars = storePassword.toCharArray()
                  val keyChars = keyPassword.toCharArray()
                  storePassword = ""
                  keyPassword = ""
                  onVerifyAndContinue(storeChars, keyAlias, keyChars)
                },
                enabled = !state.isBusy && keyAlias.isNotBlank() && storePassword.isNotEmpty(),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(52.dp)
                  .testTag("import_verify_continue_button"),
                shape = RoundedCornerShape(12.dp),
              ) {
                if (state.isBusy) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = MaterialTheme.colorScheme.onPrimary,
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                } else {
                  Icon(
                    imageVector = Icons.Filled.VerifiedUser,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                }
                Text(
                  text = stringResource(R.string.step2_verify_continue),
                  style = MaterialTheme.typography.labelLarge,
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun KeystoreFormatScreen(
  isBusy: Boolean,
  onSwitchToExisting: () -> Unit,
  onSwitchToDebugKey: () -> Unit,
  onSelectFormat: (KeystoreFormat) -> Unit,
  modifier: Modifier = Modifier,
) {
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  Box(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .testTag("keystore_format_list"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        KeystoreModeSegmentedRow(
          selectedMode = KeystoreMode.GENERATE,
          enabled = !isBusy,
          onSelectExisting = onSwitchToExisting,
          onSelectGenerate = {},
          onSelectDebug = onSwitchToDebugKey,
        )
      }

      item {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = stringResource(R.string.step2_format_title),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = stringResource(R.string.step2_format_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      item {
        ChoiceCard(
          title = stringResource(R.string.step2_format_jks_title),
          description = stringResource(R.string.step2_format_jks_desc),
          icon = Icons.Filled.Key,
          isPrimary = true,
          enabled = !isBusy,
          onClick = { onSelectFormat(KeystoreFormat.JKS) },
          testTag = "format_select_jks_card",
        )
      }

      item {
        ChoiceCard(
          title = stringResource(R.string.step2_format_p12_title),
          description = stringResource(R.string.step2_format_p12_desc),
          icon = Icons.Filled.AddModerator,
          isPrimary = false,
          enabled = !isBusy,
          onClick = { onSelectFormat(KeystoreFormat.PKCS12) },
          testTag = "format_select_pkcs12_card",
        )
      }
    }
  }
}

@Composable
fun KeystoreFormScreen(
  format: KeystoreFormat,
  isBusy: Boolean,
  errorMessage: String?,
  onGenerateKeystore: (KeystoreCreateRequest) -> Unit,
  modifier: Modifier = Modifier,
) {
  var fileName by remember { mutableStateOf("release_upload") }
  var storePassword by remember { mutableStateOf("") }
  var keyAlias by remember { mutableStateOf("upload") }
  var keyPassword by remember { mutableStateOf("") }
  var validityDays by remember { mutableStateOf("10000") }
  var commonName by remember { mutableStateOf("") }
  var organizationalUnit by remember { mutableStateOf("") }
  var organization by remember { mutableStateOf("") }
  var cityLocality by remember { mutableStateOf("") }
  var stateProvince by remember { mutableStateOf("") }
  var countryCode by remember { mutableStateOf("") }
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  DisposableEffect(Unit) {
    onDispose {
      storePassword = ""
      keyPassword = ""
    }
  }

  val canGenerate = !isBusy &&
    fileName.isNotBlank() &&
    storePassword.length >= 6 &&
    keyAlias.isNotBlank() &&
    validityDays.toIntOrNull()?.let { it > 0 } == true

  Box(
    modifier = modifier
      .fillMaxSize()
      .imePadding(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .testTag("keystore_form_list"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
          Text(
            text = stringResource(R.string.step2_form_title, format.name),
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.onBackground,
          )
          Text(
            text = stringResource(R.string.step2_form_subtitle),
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      if (errorMessage != null) {
        item { ErrorBanner(message = errorMessage) }
      }

      item {
        IconOutlinedField(
          value = fileName,
          onValueChange = { fileName = it },
          label = stringResource(R.string.field_filename),
          leadingIcon = Icons.Filled.Description,
          keyboardOptions = KeyboardOptions(autoCorrectEnabled = false, imeAction = ImeAction.Next),
          testTag = "form_filename_field",
        )
      }

      item {
        PasswordTextField(
          value = storePassword,
          onValueChange = { storePassword = it },
          label = stringResource(R.string.field_store_password),
          leadingIcon = Icons.Filled.Lock,
          modifier = Modifier.testTag("form_store_password_field"),
        )
      }

      item {
        IconOutlinedField(
          value = keyAlias,
          onValueChange = { keyAlias = it },
          label = stringResource(R.string.field_alias),
          leadingIcon = Icons.Filled.Badge,
          keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.None,
            autoCorrectEnabled = false,
            imeAction = ImeAction.Next,
          ),
          testTag = "form_alias_field",
        )
      }

      item {
        PasswordTextField(
          value = keyPassword,
          onValueChange = { keyPassword = it },
          label = stringResource(R.string.field_key_password),
          leadingIcon = Icons.Filled.VpnKey,
          supportingText = if (format == KeystoreFormat.PKCS12) {
            stringResource(R.string.step2_pkcs12_hint)
          } else {
            null
          },
          modifier = Modifier.testTag("form_key_password_field"),
        )
      }

      item {
        IconOutlinedField(
          value = validityDays,
          onValueChange = { input -> validityDays = input.filter { it.isDigit() } },
          label = stringResource(R.string.field_validity),
          leadingIcon = Icons.Filled.CalendarToday,
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Next),
          testTag = "form_validity_field",
        )
      }

      item {
        IconOutlinedField(
          value = commonName,
          onValueChange = { commonName = it },
          label = stringResource(R.string.field_cn),
          leadingIcon = Icons.Filled.Person,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          testTag = "form_cn_field",
        )
      }

      item {
        IconOutlinedField(
          value = organizationalUnit,
          onValueChange = { organizationalUnit = it },
          label = stringResource(R.string.field_ou),
          leadingIcon = Icons.Filled.Group,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          testTag = "form_ou_field",
        )
      }

      item {
        IconOutlinedField(
          value = organization,
          onValueChange = { organization = it },
          label = stringResource(R.string.field_o),
          leadingIcon = Icons.Filled.Business,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          testTag = "form_o_field",
        )
      }

      item {
        IconOutlinedField(
          value = cityLocality,
          onValueChange = { cityLocality = it },
          label = stringResource(R.string.field_l),
          leadingIcon = Icons.Filled.LocationCity,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          testTag = "form_l_field",
        )
      }

      item {
        IconOutlinedField(
          value = stateProvince,
          onValueChange = { stateProvince = it },
          label = stringResource(R.string.field_st),
          leadingIcon = Icons.Filled.Map,
          keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
          testTag = "form_st_field",
        )
      }

      item {
        IconOutlinedField(
          value = countryCode,
          onValueChange = { countryCode = it.filter { ch -> ch.isLetter() }.take(2).uppercase() },
          label = stringResource(R.string.field_c),
          leadingIcon = Icons.Filled.Public,
          keyboardOptions = KeyboardOptions(
            capitalization = KeyboardCapitalization.Characters,
            autoCorrectEnabled = false,
            imeAction = ImeAction.Done,
          ),
          testTag = "form_c_field",
        )
      }

      item {
        Spacer(modifier = Modifier.height(4.dp))

        Button(
          onClick = {
            val storeChars = storePassword.toCharArray()
            val keyChars = (if (keyPassword.isEmpty()) storePassword else keyPassword).toCharArray()
            storePassword = ""
            keyPassword = ""
            onGenerateKeystore(
              KeystoreCreateRequest(
                format = format,
                fileName = fileName,
                storePassword = storeChars,
                keyAlias = keyAlias,
                keyPassword = keyChars,
                validityDays = validityDays.toIntOrNull()?.coerceAtLeast(1) ?: 10000,
                commonName = commonName,
                organizationalUnit = organizationalUnit,
                organization = organization,
                cityLocality = cityLocality,
                stateProvince = stateProvince,
                countryCode = countryCode,
              )
            )
          },
          enabled = canGenerate,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("form_generate_button"),
          shape = RoundedCornerShape(12.dp),
        ) {
          if (isBusy) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = MaterialTheme.colorScheme.onPrimary,
            )
            Spacer(modifier = Modifier.width(10.dp))
          } else {
            Icon(Icons.Filled.AddModerator, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
          }
          Text(
            text = stringResource(R.string.step2_generate_action),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }
    }
  }
}

@Composable
fun KeystoreReadyScreen(
  state: KeystoreStudioUiState,
  hasTargetBinaryToSign: Boolean,
  onDownloadKeystore: () -> Unit,
  onProceedToSigning: () -> Unit,
  onDoneReturnHome: () -> Unit,
  onAutoDeleteCacheOnLeave: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  DisposableEffect(Unit) {
    onDispose {
      onAutoDeleteCacheOnLeave()
    }
  }

  Box(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .testTag("keystore_ready_list"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        Surface(
          modifier = Modifier
            .fillMaxWidth()
            .testTag("keystore_ready_hero_card"),
          shape = StandardCardShape,
          color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.7f),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
        ) {
          Column(
            modifier = Modifier.padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.CheckCircle,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.size(32.dp),
            )
            Text(
              text = stringResource(R.string.step2_ready_title),
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            Text(
              text = stringResource(R.string.step2_ready_subtitle),
              style = MaterialTheme.typography.bodyMedium,
              color = MaterialTheme.colorScheme.onPrimaryContainer,
            )
            state.generatedFileName?.let { name ->
              Text(
                text = "$name (${state.generatedFormat?.name ?: ""})",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onPrimaryContainer,
              )
            }
          }
        }
      }

      if (state.errorMessage != null) {
        item { ErrorBanner(message = state.errorMessage) }
      }

      item {
        Button(
          onClick = onDownloadKeystore,
          enabled = !state.isBusy && state.generatedKeystoreFile != null,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("ready_download_keystore_button"),
          shape = RoundedCornerShape(12.dp),
        ) {
          if (state.isBusy) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = MaterialTheme.colorScheme.onPrimary,
            )
          } else {
            Icon(Icons.Filled.Download, contentDescription = null, modifier = Modifier.size(20.dp))
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = stringResource(R.string.step2_download_button),
            style = MaterialTheme.typography.labelLarge,
          )
        }
      }

      item {
        AnimatedVisibility(visible = state.generatedDownloaded && state.generatedFileName != null) {
          Surface(
            modifier = Modifier
              .fillMaxWidth()
              .testTag("ready_downloaded_badge"),
            shape = StandardCardShape,
            color = MaterialTheme.colorScheme.secondaryContainer,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
          ) {
            Text(
              text = stringResource(
                R.string.step2_downloaded_badge,
                state.generatedFileName.orEmpty(),
              ),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
              modifier = Modifier.padding(16.dp),
            )
          }
        }
      }

      if (hasTargetBinaryToSign && state.generatedKeystoreFile != null) {
        item {
          OutlinedButton(
            onClick = onProceedToSigning,
            enabled = !state.isBusy,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("ready_proceed_sign_button"),
            shape = RoundedCornerShape(12.dp),
          ) {
            Icon(Icons.Filled.Draw, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = stringResource(R.string.step2_use_for_signing))
          }
        }
      }

      item {
        TextButton(
          onClick = onDoneReturnHome,
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("ready_done_home_button"),
        ) {
          Text(text = stringResource(R.string.step2_done_home))
        }
      }
    }
  }
}

@Composable
private fun IconOutlinedField(
  value: String,
  onValueChange: (String) -> Unit,
  label: String,
  leadingIcon: ImageVector,
  keyboardOptions: KeyboardOptions,
  testTag: String,
) {
  OutlinedTextField(
    value = value,
    onValueChange = onValueChange,
    label = { Text(label) },
    singleLine = true,
    shape = RoundedCornerShape(12.dp),
    leadingIcon = {
      Icon(
        imageVector = leadingIcon,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(20.dp),
      )
    },
    keyboardOptions = keyboardOptions,
    modifier = Modifier
      .fillMaxWidth()
      .testTag(testTag),
  )
}

@Composable
private fun ChoiceCard(
  title: String,
  description: String,
  icon: ImageVector,
  isPrimary: Boolean,
  enabled: Boolean = true,
  isLoading: Boolean = false,
  onClick: () -> Unit,
  testTag: String,
) {
  val accent = if (isPrimary) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
  val badge = if (isPrimary) {
    MaterialTheme.colorScheme.primaryContainer
  } else {
    MaterialTheme.colorScheme.secondaryContainer
  }

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .minimumInteractiveComponentSize()
      .testTag(testTag)
      .clickable(enabled = enabled, onClick = onClick),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(
      width = 1.dp,
      color = if (isPrimary) {
        MaterialTheme.colorScheme.primary.copy(alpha = 0.55f)
      } else {
        MaterialTheme.colorScheme.outlineVariant
      },
    ),
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .background(color = badge, shape = RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center,
      ) {
        if (isLoading) {
          CircularProgressIndicator(
            modifier = Modifier.size(20.dp),
            strokeWidth = 2.dp,
            color = accent,
          )
        } else {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = accent,
            modifier = Modifier.size(22.dp),
          )
        }
      }
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleMedium,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
      Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(20.dp),
      )
    }
  }
}

@Composable
private fun ErrorBanner(message: String) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.errorContainer,
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Icon(
        imageVector = Icons.Filled.Warning,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.onErrorContainer,
        modifier = Modifier.size(20.dp),
      )
      Text(
        text = message,
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onErrorContainer,
      )
    }
  }
}
