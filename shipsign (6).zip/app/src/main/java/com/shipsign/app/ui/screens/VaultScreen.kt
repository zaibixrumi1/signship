package com.shipsign.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhonelinkLock
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material.icons.outlined.CloudOff
import androidx.compose.material.icons.outlined.FolderOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.shipsign.app.R
import com.shipsign.app.core.security.ZeroTraceAuditResult
import com.shipsign.app.core.security.ZeroTraceSnapshot
import com.shipsign.app.ui.KeystoreStudioUiState
import com.shipsign.app.ui.components.StandardCardShape
import java.text.DateFormat
import java.util.Date

@Composable
fun VaultScreen(
  snapshot: ZeroTraceSnapshot,
  keystoreState: KeystoreStudioUiState,
  lastAuditResult: ZeroTraceAuditResult?,
  isAuditing: Boolean,
  onRunAudit: () -> Unit,
  onDeleteActiveKeystore: () -> Unit,
  onNukeSession: () -> Unit,
  onOpenCryptoCore: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

  Box(
    modifier = modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .widthIn(max = 600.dp)
        .testTag("vault_lazy_column"),
      contentPadding = PaddingValues(
        start = 16.dp,
        end = 16.dp,
        top = 16.dp,
        bottom = 24.dp + navBottom,
      ),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      item {
        ZeroTraceHeroCard(snapshot = snapshot)
      }

      // Active Ephemeral Keystore Card (40dp certificate badge + alias/DN + format pill + Delete button)
      if (keystoreState.tempKeystoreFile != null || keystoreState.verifiedSummary != null) {
        item {
          Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
              text = stringResource(R.string.vault_active_keystore_header),
              style = MaterialTheme.typography.titleMedium,
              color = MaterialTheme.colorScheme.onBackground,
            )
            ActiveKeystoreCard(
              keystoreState = keystoreState,
              onDelete = onDeleteActiveKeystore,
            )
          }
        }
      }

      item {
        TelemetryMetricsRow(snapshot = snapshot)
      }

      item {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Button(
            onClick = onRunAudit,
            enabled = !isAuditing,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("run_zero_trace_audit_button"),
            shape = RoundedCornerShape(12.dp),
          ) {
            if (isAuditing) {
              CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.onPrimary,
              )
              Spacer(modifier = Modifier.width(10.dp))
            } else {
              Icon(
                imageVector = Icons.Filled.VerifiedUser,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(10.dp))
            }
            Text(
              text = stringResource(R.string.action_run_audit),
              style = MaterialTheme.typography.labelLarge,
            )
          }

          OutlinedButton(
            onClick = onOpenCryptoCore,
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("open_crypto_core_button"),
            shape = RoundedCornerShape(12.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Security,
              contentDescription = null,
              modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = stringResource(R.string.crypto_title),
              style = MaterialTheme.typography.labelLarge,
            )
          }

          OutlinedButton(
            onClick = onNukeSession,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("nuke_session_button"),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.outlinedButtonColors(
              contentColor = MaterialTheme.colorScheme.error,
            ),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.65f)),
          ) {
            Icon(
              imageVector = Icons.Filled.DeleteSweep,
              contentDescription = null,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = stringResource(R.string.action_nuke_session),
              style = MaterialTheme.typography.labelLarge,
            )
          }
        }
      }

      item {
        AnimatedVisibility(visible = lastAuditResult != null) {
          lastAuditResult?.let { result ->
            AuditResultBanner(result = result)
          }
        }
      }

      item {
        Text(
          text = stringResource(R.string.posture_section_title),
          style = MaterialTheme.typography.titleLarge,
          color = MaterialTheme.colorScheme.onBackground,
          modifier = Modifier.padding(top = 4.dp),
        )
      }

      item {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          PostureRowCard(
            icon = Icons.Filled.PhonelinkLock,
            title = stringResource(R.string.posture_flag_secure),
            description = stringResource(R.string.posture_flag_secure_desc),
            accent = MaterialTheme.colorScheme.primary,
          )
          PostureRowCard(
            icon = Icons.Outlined.CloudOff,
            title = stringResource(R.string.posture_no_backup),
            description = stringResource(R.string.posture_no_backup_desc),
            accent = MaterialTheme.colorScheme.secondary,
          )
          PostureRowCard(
            icon = Icons.Outlined.FolderOff,
            title = stringResource(R.string.posture_no_storage_perm),
            description = stringResource(R.string.posture_no_storage_perm_desc),
            accent = MaterialTheme.colorScheme.primary,
          )
          PostureRowCard(
            icon = Icons.Filled.Security,
            title = stringResource(R.string.posture_lifecycle_hook),
            description = stringResource(R.string.posture_lifecycle_hook_desc),
            accent = MaterialTheme.colorScheme.tertiary,
          )
        }
      }
    }
  }
}

@Composable
private fun ActiveKeystoreCard(
  keystoreState: KeystoreStudioUiState,
  onDelete: () -> Unit,
) {
  val summary = keystoreState.verifiedSummary
  val aliasTitle = summary?.alias ?: keystoreState.importedFileName ?: "Ephemeral Keystore"
  val dnSubtitle = summary?.subjectDn ?: keystoreState.importedFileName.orEmpty()
  val formatLabel = (summary?.format ?: keystoreState.detectedFormat).name

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("vault_active_keystore_card"),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surface,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.WorkspacePremium,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.onPrimaryContainer,
          modifier = Modifier.size(22.dp),
        )
      }

      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Text(
            text = aliasTitle,
            style = MaterialTheme.typography.titleSmall,
            color = MaterialTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false),
          )
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = MaterialTheme.colorScheme.secondaryContainer,
          ) {
            Text(
              text = formatLabel,
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSecondaryContainer,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
            )
          }
        }
        if (dnSubtitle.isNotBlank()) {
          Text(
            text = dnSubtitle,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      IconButton(
        onClick = onDelete,
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .testTag("vault_delete_keystore_button"),
      ) {
        Icon(
          imageVector = Icons.Filled.Delete,
          contentDescription = stringResource(R.string.cd_delete_keystore),
          tint = MaterialTheme.colorScheme.error,
          modifier = Modifier.size(20.dp),
        )
      }
    }
  }
}

@Composable
private fun ZeroTraceHeroCard(snapshot: ZeroTraceSnapshot) {
  val primaryColor = MaterialTheme.colorScheme.primary
  val secondaryColor = MaterialTheme.colorScheme.secondary

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("vault_hero_card"),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surfaceContainer,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Box(modifier = Modifier.fillMaxWidth()) {
      Canvas(modifier = Modifier.matchParentSize()) {
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(primaryColor.copy(alpha = 0.14f), Color.Transparent),
            center = Offset(size.width * 0.85f, size.height * 0.2f),
            radius = size.width * 0.7f,
          ),
          center = Offset(size.width * 0.85f, size.height * 0.2f),
          radius = size.width * 0.7f,
        )
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(secondaryColor.copy(alpha = 0.09f), Color.Transparent),
            center = Offset(size.width * 0.12f, size.height * 0.9f),
            radius = size.width * 0.55f,
          ),
          center = Offset(size.width * 0.12f, size.height * 0.9f),
          radius = size.width * 0.55f,
        )
      }

      Column(
        modifier = Modifier.padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .background(
                color = MaterialTheme.colorScheme.primaryContainer,
                shape = RoundedCornerShape(12.dp),
              ),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.Shield,
              contentDescription = stringResource(R.string.vault_hero_title),
              tint = MaterialTheme.colorScheme.onPrimaryContainer,
              modifier = Modifier.size(22.dp),
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = stringResource(R.string.vault_hero_title),
              style = MaterialTheme.typography.titleLarge,
              color = MaterialTheme.colorScheme.onSurface,
            )
            Text(
              text = stringResource(R.string.subtitle_zero_trace),
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.primary,
            )
          }
        }

        Text(
          text = stringResource(R.string.vault_hero_subtitle),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MaterialTheme.colorScheme.background.copy(alpha = 0.75f),
          border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text(
              text = stringResource(R.string.label_session_id),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = snapshot.activeSessionId.ifEmpty { "—" },
              style = MaterialTheme.typography.labelMedium,
              color = MaterialTheme.colorScheme.secondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.testTag("active_session_id_text"),
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = stringResource(R.string.label_session_path),
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = snapshot.activeSessionPath.ifEmpty { "—" },
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurface,
              maxLines = 2,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TelemetryMetricsRow(snapshot: ZeroTraceSnapshot) {
  val lastWipeText =
    snapshot.lastWipeTimestampMs?.let { DateFormat.getTimeInstance(DateFormat.MEDIUM).format(Date(it)) }
      ?: stringResource(R.string.status_never_wiped)

  Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      MetricTile(
        label = stringResource(R.string.label_files_wiped),
        value = snapshot.filesWipedCount.toString(),
        icon = Icons.Filled.Lock,
        modifier = Modifier.weight(1f),
      )
      MetricTile(
        label = stringResource(R.string.label_bytes_wiped),
        value = "${snapshot.bytesWipedTotal} B",
        icon = Icons.Filled.Fingerprint,
        modifier = Modifier.weight(1f),
      )
    }

    Surface(
      modifier = Modifier.fillMaxWidth(),
      shape = StandardCardShape,
      color = MaterialTheme.colorScheme.surfaceContainerLow,
      border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
      Row(
        modifier = Modifier.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = stringResource(R.string.label_last_wipe),
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Text(
          text = lastWipeText,
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.primary,
        )
      }
    }
  }
}

@Composable
private fun MetricTile(
  label: String,
  value: String,
  icon: ImageVector,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier,
    shape = StandardCardShape,
    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainer),
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Column(
      modifier = Modifier.padding(16.dp),
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.secondary,
        modifier = Modifier.size(18.dp),
      )
      Text(
        text = value,
        style = MaterialTheme.typography.titleLarge,
        color = MaterialTheme.colorScheme.onSurface,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      Text(
        text = label,
        style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun AuditResultBanner(result: ZeroTraceAuditResult) {
  val containerColor = if (result.passed) {
    MaterialTheme.colorScheme.primaryContainer
  } else {
    MaterialTheme.colorScheme.errorContainer
  }
  val contentColor = if (result.passed) {
    MaterialTheme.colorScheme.onPrimaryContainer
  } else {
    MaterialTheme.colorScheme.onErrorContainer
  }

  Surface(
    modifier = Modifier
      .fillMaxWidth()
      .testTag("audit_result_banner"),
    shape = StandardCardShape,
    color = containerColor,
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalAlignment = Alignment.Top,
    ) {
      Icon(
        imageVector = Icons.Filled.CheckCircle,
        contentDescription = null,
        tint = contentColor,
        modifier = Modifier.size(20.dp),
      )
      Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(
          text = if (result.passed) {
            stringResource(R.string.audit_passed_title)
          } else {
            stringResource(R.string.audit_failed_title)
          },
          style = MaterialTheme.typography.titleSmall,
          color = contentColor,
        )
        Text(
          text = stringResource(
            R.string.audit_summary_format,
            result.bytesWrittenAndShredded,
            result.charsWipedCount,
          ),
          style = MaterialTheme.typography.bodyMedium,
          color = contentColor,
        )
      }
    }
  }
}

@Composable
private fun PostureRowCard(
  icon: ImageVector,
  title: String,
  description: String,
  accent: Color,
) {
  Surface(
    modifier = Modifier.fillMaxWidth(),
    shape = StandardCardShape,
    color = MaterialTheme.colorScheme.surfaceContainerLow,
    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      horizontalArrangement = Arrangement.spacedBy(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .background(accent.copy(alpha = 0.14f), RoundedCornerShape(10.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = accent,
          modifier = Modifier.size(20.dp),
        )
      }
      Column(
        modifier = Modifier.weight(1f),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleSmall,
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = description,
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}
