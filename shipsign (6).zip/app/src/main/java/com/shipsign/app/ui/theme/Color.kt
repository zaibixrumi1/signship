package com.shipsign.app.ui.theme

import androidx.compose.ui.graphics.Color

// ShipSign Dark Obsidian Developer Palette (Default)
val ObsidianBackground = Color(0xFF0D1117)
val ObsidianCard = Color(0xFF161B22)
val ObsidianCardElevated = Color(0xFF1F2630)
val ObsidianConsole = Color(0xFF090D12)
val ObsidianBorder = Color(0xFF30363D)

val EmeraldAction = Color(0xFF2EA043)
val EmeraldOnAction = Color(0xFFFFFFFF)
val EmeraldContainer = Color(0xFF123820)
val EmeraldOnContainer = Color(0xFF56D364)

val TechBlueSecondary = Color(0xFF58A6FF)
val TechBlueOnSecondary = Color(0xFF051D38)
val TechBlueContainer = Color(0xFF112C48)
val TechBlueOnContainer = Color(0xFFA5D6FF)

val AmberWarning = Color(0xFFD29922)
val AmberOnWarning = Color(0xFF231802)
val AmberContainer = Color(0xFF332509)
val AmberOnContainer = Color(0xFFF2CC60)

val CrimsonError = Color(0xFFF85149)
val CrimsonContainer = Color(0xFF421518)
val CrimsonOnContainer = Color(0xFFFFB4B0)

val TextPrimaryDark = Color(0xFFF0F6FC)
val TextSecondaryDark = Color(0xFF8B949E)

// Light Fallback (not default; Dark Mode is default per spec)
val LightBg = Color(0xFFF6F8FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEAECEF)
val TextPrimaryLight = Color(0xFF1F2328)
val TextSecondaryLight = Color(0xFF656D76)
