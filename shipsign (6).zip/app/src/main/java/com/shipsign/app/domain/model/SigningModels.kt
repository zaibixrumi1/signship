package com.shipsign.app.domain.model

import android.net.Uri

data class SigningOptions(
  val v1Enabled: Boolean = true,
  val v2Enabled: Boolean = true,
  val v3Enabled: Boolean = true,
  val v4Enabled: Boolean = true,
  val zipAlignBeforeSign: Boolean = true,
  val convertAabToApk: Boolean = false,
)

data class SigningResult(
  val primarySignedUri: Uri,
  val primaryFileName: String,
  val companionApkUri: Uri?,
  val companionApkFileName: String?,
  val sha1Fingerprint: String,
  val sha256Fingerprint: String,
  val logs: List<String>,
)
