package com.shipsign.app.core.engine

import android.content.Context
import android.net.Uri
import com.shipsign.app.core.security.ZeroTraceManager
import com.shipsign.app.core.storage.SafFileBridge
import com.shipsign.app.domain.model.AppTargetFile
import com.shipsign.app.domain.model.ProjectFramework
import com.shipsign.app.domain.model.ProjectStack
import com.shipsign.app.domain.model.ResolvedBinaryType
import com.shipsign.app.domain.model.SourceProjectMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

data class SanitizedArchiveResult(
  val sanitizedZip: File,
  val includedFileCount: Int,
  val strippedEntryCount: Int,
)

/**
 * On-device streaming inspector & sanitizer for `.apk`, `.aab`, and raw source `.zip` archives.
 *
 * - Inspects user-selected files locally on-device BEFORE any GitHub workflow or repo is created.
 * - Uses 64KB streaming buffers and 512KB metadata text cap without extracting raw untrusted trees.
 * - Classifies prebuilt binaries (`PREBUILT_PACKAGE`) vs supported source archives (`SOURCE_ARCHIVE`)
 *   up to folder depth 4 (`FLUTTER`, `REACT_NATIVE`, `CAPACITOR_CORDOVA`, `NATIVE_ANDROID`, `GODOT`),
 *   failing immediately on-device if no valid project marker is found.
 * - Streams clean, Zip-Slip-safe repacks stripping IDE metadata, `.DS_Store`, `__MACOSX/`, and
 *   accidental local signing secrets before cloud build upload.
 */
object ZipInspectorEngine {

  private const val STREAM_BUFFER_SIZE = 64 * 1024
  private const val MAX_METADATA_READ_BYTES = 512 * 1024
  private const val MAX_ROOT_DEPTH = 4

  private val GRADLE_VERSION_REGEX = Regex("""gradle-([0-9]+\.[0-9]+(?:\.[0-9]+)?)""")
  private val APP_ID_REGEX = Regex("""applicationId\s*=?\s*["']([^"']+)["']""")
  private val NAMESPACE_REGEX = Regex("""namespace\s*=?\s*["']([^"']+)["']""")
  private val MANIFEST_PKG_REGEX = Regex("""package\s*=\s*["']([^"']+)["']""")

  private val STRIPPED_EXACT_NAMES = setOf(
    "metadata.json",
    "applet_access_history.json",
    ".ds_store",
  )

  private val STRIPPED_DIR_SEGMENTS = setOf(
    ".idx",
    ".cursor",
    ".bolt",
    ".lovable",
    "__macosx",
  )

  private val IGNORED_SCAN_DIR_SEGMENTS = setOf(
    ".git",
    "node_modules",
    "__macosx",
    ".idx",
    ".cursor",
    ".bolt",
    ".lovable",
  )

  private val EXCLUDED_UPLOAD_DIR_SEGMENTS = setOf(
    ".git",
    ".gradle",
    "node_modules",
    ".dart_tool",
    "build",
  )

  private val EXCLUDED_SECRET_FILES = setOf(
    "key.properties",
    "signing.properties",
    ".env",
  )

  private val EXCLUDED_KEYSTORE_EXTS = setOf(
    ".jks",
    ".keystore",
    ".p12",
    ".pfx",
    ".bks",
  )

  /**
   * Streams a SAF [uri] into the active Zero-Trace ephemeral session folder and classifies it
   * on-device without touching GitHub. Always runs on [Dispatchers.IO].
   */
  suspend fun inspectUriAsync(context: Context, uri: Uri): AppTargetFile =
    withContext(Dispatchers.IO) { inspectUri(context, uri) }

  suspend fun inspectFileAsync(
    inputFile: File,
    originalName: String,
    sessionDir: File,
  ): AppTargetFile = withContext(Dispatchers.IO) {
    inspectFile(inputFile, originalName, sessionDir)
  }

  fun inspectUri(context: Context, uri: Uri): AppTargetFile {
    val sessionDir = ZeroTraceManager.createOrGetSessionDir(context)
    val copied = SafFileBridge.copyUriToSession(context, uri, sessionDir)
    return inspectFile(
      inputFile = copied.file,
      originalName = copied.displayName,
      sessionDir = sessionDir,
    )
  }

  fun inspectFile(
    inputFile: File,
    originalName: String,
    sessionDir: File,
  ): AppTargetFile {
    if (!inputFile.exists() || !inputFile.isFile || inputFile.length() == 0L) {
      return invalidTarget(inputFile, originalName)
    }

    return runCatching {
      ZipFile(inputFile).use { zipFile ->
        inspectWithZipFile(zipFile, inputFile, originalName, sessionDir)
      }
    }.getOrElse {
      runCatching {
        inspectWithZipInputStream(inputFile, originalName, sessionDir)
      }.getOrElse {
        invalidTarget(inputFile, originalName)
      }
    }
  }

  /**
   * Streams [sourceZip] into [destZip] using 64KB buffers while stripping IDE metadata,
   * sensitive signing files, build caches, and Zip-Slip traversal paths, normalizing
   * [projectRootPrefix] to archive root.
   */
  fun sanitizeProjectArchive(
    sourceZip: File,
    destZip: File,
    projectRootPrefix: String = "",
  ): SanitizedArchiveResult {
    val buffer = ByteArray(STREAM_BUFFER_SIZE)
    val seenPaths = hashSetOf<String>()
    var includedCount = 0
    var strippedCount = 0
    val normalizedRoot = projectRootPrefix.replace('\\', '/').trimStart('/').let {
      if (it.isNotEmpty() && !it.endsWith("/")) "$it/" else it
    }

    try {
      ZipInputStream(FileInputStream(sourceZip)).use { zis ->
        ZipOutputStream(FileOutputStream(destZip, false)).use { zos ->
          while (true) {
            val entry = zis.nextEntry ?: break
            if (entry.isDirectory) {
              zis.closeEntry()
              continue
            }
            val safeNormalized = normalizeZipPath(entry.name)
            if (safeNormalized == null) {
              strippedCount++
              zis.closeEntry()
              continue
            }

            if (isIdeOrAiMetadataPath(safeNormalized) || isExcludedBuildOrSecretPath(safeNormalized)) {
              strippedCount++
              zis.closeEntry()
              continue
            }

            val strippedRootPath = if (normalizedRoot.isNotEmpty() && safeNormalized.startsWith(normalizedRoot)) {
              safeNormalized.removePrefix(normalizedRoot)
            } else {
              safeNormalized
            }

            if (strippedRootPath.isBlank() ||
              isIdeOrAiMetadataPath(strippedRootPath) ||
              isExcludedBuildOrSecretPath(strippedRootPath)
            ) {
              strippedCount++
              zis.closeEntry()
              continue
            }

            if (!seenPaths.add(strippedRootPath)) {
              zis.closeEntry()
              continue
            }

            val outEntry = ZipEntry(strippedRootPath)
            zos.putNextEntry(outEntry)
            while (true) {
              val read = zis.read(buffer)
              if (read == -1) break
              zos.write(buffer, 0, read)
            }
            zos.closeEntry()
            includedCount++
            zis.closeEntry()
          }
          zos.flush()
        }
      }
      return SanitizedArchiveResult(
        sanitizedZip = destZip,
        includedFileCount = includedCount,
        strippedEntryCount = strippedCount,
      )
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(destZip)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  internal fun isIdeOrAiMetadataPath(normalizedPath: String): Boolean {
    val lower = normalizedPath.lowercase(Locale.US)
    val segments = lower.split('/').filter { it.isNotEmpty() }
    if (segments.isEmpty()) return true
    if (segments.any { it in STRIPPED_DIR_SEGMENTS }) return true
    val fileName = segments.last()
    return fileName in STRIPPED_EXACT_NAMES
  }

  internal fun isIgnoredForFrameworkScan(normalizedPath: String): Boolean {
    val lower = normalizedPath.lowercase(Locale.US)
    val segments = lower.split('/').filter { it.isNotEmpty() }
    if (segments.isEmpty()) return true
    return segments.any { it in IGNORED_SCAN_DIR_SEGMENTS }
  }

  internal fun isExcludedBuildOrSecretPath(normalizedPath: String): Boolean {
    val lower = normalizedPath.lowercase(Locale.US)
    val segments = lower.split('/').filter { it.isNotEmpty() }
    if (segments.isEmpty()) return true
    if (segments.any { it in EXCLUDED_UPLOAD_DIR_SEGMENTS }) return true
    val fileName = segments.last()
    if (fileName in EXCLUDED_SECRET_FILES) return true
    if (EXCLUDED_KEYSTORE_EXTS.any { fileName.endsWith(it) }) return true
    return false
  }

  private fun normalizeZipPath(rawName: String): String? {
    val cleaned = rawName.replace('\\', '/').trimStart('/')
    if (cleaned.isBlank()) return null
    val segments = cleaned.split('/')
    if (segments.any { it == ".." }) return null
    return segments.filter { it.isNotEmpty() && it != "." }.joinToString("/")
  }

  private fun inspectWithZipFile(
    zipFile: ZipFile,
    inputFile: File,
    originalName: String,
    sessionDir: File,
  ): AppTargetFile {
    var hasRootManifest = false
    var hasRootResourcesPb = false
    var hasBundleManifest = false
    var hasBundleConfig = false
    var hasDexOrResources = false
    var innerAabEntry: ZipEntry? = null
    var innerApkEntry: ZipEntry? = null

    val allFiles = mutableListOf<Pair<String, ZipEntry>>()
    var strippedMetadataCount = 0

    val entries = zipFile.entries()
    while (entries.hasMoreElements()) {
      val entry = entries.nextElement()
      if (entry.isDirectory) continue
      val normalized = normalizeZipPath(entry.name) ?: continue
      val lower = normalized.lowercase(Locale.US)
      val fileName = lower.substringAfterLast('/')

      if (isIdeOrAiMetadataPath(normalized)) {
        strippedMetadataCount++
        continue
      }

      if (lower == "androidmanifest.xml") hasRootManifest = true
      if (lower == "resources.pb") hasRootResourcesPb = true
      if (lower == "base/manifest/androidmanifest.xml" || lower == "base/resources.pb") {
        hasBundleManifest = true
      }
      if (lower == "bundleconfig.pb") hasBundleConfig = true
      if (lower == "resources.arsc" || lower == "resources.pb" || (lower.startsWith("classes") && lower.endsWith(".dex"))) {
        hasDexOrResources = true
      }

      if (fileName.endsWith(".aab") && innerAabEntry == null) {
        innerAabEntry = entry
      } else if (fileName.endsWith(".apk") && innerApkEntry == null) {
        innerApkEntry = entry
      }

      allFiles.add(normalized to entry)
    }

    if (hasBundleManifest || hasBundleConfig) {
      return AppTargetFile(
        sessionFile = inputFile,
        originalName = originalName,
        sizeBytes = inputFile.length(),
        binaryType = ResolvedBinaryType.AAB,
        isAlreadySigned = SignatureScanner.hasExistingSignature(inputFile),
        detectedStack = null,
      )
    }

    if ((hasRootManifest && (hasDexOrResources || originalName.lowercase(Locale.US).endsWith(".apk"))) || hasRootResourcesPb) {
      val binaryType = if (originalName.lowercase(Locale.US).endsWith(".aab") && !hasRootManifest) {
        ResolvedBinaryType.AAB
      } else {
        ResolvedBinaryType.APK
      }
      return AppTargetFile(
        sessionFile = inputFile,
        originalName = originalName,
        sizeBytes = inputFile.length(),
        binaryType = binaryType,
        isAlreadySigned = SignatureScanner.hasExistingSignature(inputFile),
        detectedStack = null,
      )
    }

    val binaryEntry = innerAabEntry ?: innerApkEntry
    if (binaryEntry != null) {
      val resolvedType = if (binaryEntry.name.lowercase(Locale.US).endsWith(".aab")) {
        ResolvedBinaryType.AAB
      } else {
        ResolvedBinaryType.APK
      }
      val extractedName = SafFileBridge.sanitizeFileName(binaryEntry.name.substringAfterLast('/'))
      val extractedFile = File(
        sessionDir,
        "extracted_${UUID.randomUUID().toString().take(8)}_$extractedName",
      )
      streamEntryToFile(zipFile, binaryEntry, extractedFile)
      return AppTargetFile(
        sessionFile = extractedFile,
        originalName = extractedName,
        sizeBytes = extractedFile.length(),
        binaryType = resolvedType,
        isAlreadySigned = SignatureScanner.hasExistingSignature(extractedFile),
        detectedStack = null,
      )
    }

    if (hasRootManifest) {
      return AppTargetFile(
        sessionFile = inputFile,
        originalName = originalName,
        sizeBytes = inputFile.length(),
        binaryType = ResolvedBinaryType.APK,
        isAlreadySigned = SignatureScanner.hasExistingSignature(inputFile),
        detectedStack = null,
      )
    }

    val metadata = analyzeSourceEntries(
      paths = allFiles.map { it.first },
      strippedMetadataCount = strippedMetadataCount,
      textReader = { path ->
        val entry = allFiles.firstOrNull { it.first == path }?.second
        entry?.let { readCappedEntryText(zipFile, it) }
      },
    )

    // Strict on-device gate: reject archives without any recognized project framework marker
    return if (metadata.framework != ProjectFramework.UNKNOWN) {
      AppTargetFile(
        sessionFile = inputFile,
        originalName = originalName,
        sizeBytes = inputFile.length(),
        binaryType = ResolvedBinaryType.SOURCE_CODE_PROJECT,
        isAlreadySigned = false,
        detectedStack = ProjectStack.fromFramework(metadata.framework),
        sourceMetadata = metadata,
      )
    } else {
      invalidTarget(inputFile, originalName)
    }
  }

  private fun inspectWithZipInputStream(
    inputFile: File,
    originalName: String,
    sessionDir: File,
  ): AppTargetFile {
    var hasRootManifest = false
    var hasRootResourcesPb = false
    var hasBundleManifest = false
    var hasBundleConfig = false
    var extractedBinaryFile: File? = null
    var extractedBinaryName: String? = null
    var extractedBinaryType: ResolvedBinaryType? = null
    var entryCount = 0
    var strippedMetadataCount = 0

    val allPaths = mutableListOf<String>()
    val capturedTexts = linkedMapOf<String, String>()
    val buffer = ByteArray(STREAM_BUFFER_SIZE)

    try {
      ZipInputStream(FileInputStream(inputFile)).use { zis ->
        while (true) {
          val entry = zis.nextEntry ?: break
          entryCount++
          if (entry.isDirectory) {
            zis.closeEntry()
            continue
          }
          val normalized = normalizeZipPath(entry.name)
          if (normalized == null) {
            zis.closeEntry()
            continue
          }
          if (isIdeOrAiMetadataPath(normalized)) {
            strippedMetadataCount++
            zis.closeEntry()
            continue
          }

          val lower = normalized.lowercase(Locale.US)
          val fileName = lower.substringAfterLast('/')

          if (lower == "androidmanifest.xml") hasRootManifest = true
          if (lower == "resources.pb") hasRootResourcesPb = true
          if (lower == "base/manifest/androidmanifest.xml" || lower == "base/resources.pb") {
            hasBundleManifest = true
          }
          if (lower == "bundleconfig.pb") hasBundleConfig = true

          allPaths.add(normalized)

          if ((fileName.endsWith(".aab") || fileName.endsWith(".apk")) && extractedBinaryFile == null) {
            val safeName = SafFileBridge.sanitizeFileName(normalized.substringAfterLast('/'))
            val dest = File(sessionDir, "extracted_${UUID.randomUUID().toString().take(8)}_$safeName")
            FileOutputStream(dest, false).use { fos ->
              while (true) {
                val read = zis.read(buffer)
                if (read == -1) break
                fos.write(buffer, 0, read)
              }
              fos.flush()
            }
            extractedBinaryFile = dest
            extractedBinaryName = safeName
            extractedBinaryType = if (fileName.endsWith(".aab")) ResolvedBinaryType.AAB else ResolvedBinaryType.APK
          } else if (shouldCaptureMetadataText(lower) && !isIgnoredForFrameworkScan(normalized)) {
            capturedTexts[normalized] = readCappedFromStream(zis)
          }

          zis.closeEntry()
        }
      }
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }

    if (entryCount == 0) {
      extractedBinaryFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      return invalidTarget(inputFile, originalName)
    }

    if (hasBundleManifest || hasBundleConfig) {
      extractedBinaryFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      return AppTargetFile(
        sessionFile = inputFile,
        originalName = originalName,
        sizeBytes = inputFile.length(),
        binaryType = ResolvedBinaryType.AAB,
        isAlreadySigned = SignatureScanner.hasExistingSignature(inputFile),
        detectedStack = null,
      )
    }

    if (hasRootManifest || hasRootResourcesPb) {
      extractedBinaryFile?.let { ZeroTraceManager.secureDeleteFile(it) }
      val binaryType = if (originalName.lowercase(Locale.US).endsWith(".aab") && !hasRootManifest) {
        ResolvedBinaryType.AAB
      } else {
        ResolvedBinaryType.APK
      }
      return AppTargetFile(
        sessionFile = inputFile,
        originalName = originalName,
        sizeBytes = inputFile.length(),
        binaryType = binaryType,
        isAlreadySigned = SignatureScanner.hasExistingSignature(inputFile),
        detectedStack = null,
      )
    }

    val innerFile = extractedBinaryFile
    val innerType = extractedBinaryType
    if (innerFile != null && innerType != null) {
      return AppTargetFile(
        sessionFile = innerFile,
        originalName = extractedBinaryName ?: innerFile.name,
        sizeBytes = innerFile.length(),
        binaryType = innerType,
        isAlreadySigned = SignatureScanner.hasExistingSignature(innerFile),
        detectedStack = null,
      )
    }

    val metadata = analyzeSourceEntries(
      paths = allPaths,
      strippedMetadataCount = strippedMetadataCount,
      textReader = { capturedTexts[it] },
    )

    return if (metadata.framework != ProjectFramework.UNKNOWN) {
      AppTargetFile(
        sessionFile = inputFile,
        originalName = originalName,
        sizeBytes = inputFile.length(),
        binaryType = ResolvedBinaryType.SOURCE_CODE_PROJECT,
        isAlreadySigned = false,
        detectedStack = ProjectStack.fromFramework(metadata.framework),
        sourceMetadata = metadata,
      )
    } else {
      invalidTarget(inputFile, originalName)
    }
  }

  private fun analyzeSourceEntries(
    paths: List<String>,
    strippedMetadataCount: Int,
    textReader: (String) -> String?,
  ): SourceProjectMetadata {
    val scanPaths = paths
      .filterNot { isIgnoredForFrameworkScan(it) }
      .map { it to it.lowercase(Locale.US) }

    fun findShallowest(predicate: (String) -> Boolean): Pair<String, String>? {
      return scanPaths
        .filter { (_, lower) -> depthOf(lower) <= MAX_ROOT_DEPTH && predicate(lower) }
        .minByOrNull { (_, lower) -> depthOf(lower) }
    }

    // 1. GODOT: project.godot
    val godotMatch = findShallowest { it == "project.godot" || it.endsWith("/project.godot") }
    // 2. FLUTTER: pubspec.yaml
    val pubspecMatch = findShallowest { it == "pubspec.yaml" || it.endsWith("/pubspec.yaml") }
    // 3. WEB / NODE-BASED: package.json or capacitor.config.*
    val packageJsonMatch = findShallowest { it == "package.json" || it.endsWith("/package.json") }
    val capacitorConfigMatch = findShallowest {
      fileNameOf(it) in setOf("capacitor.config.json", "capacitor.config.ts", "capacitor.config.js")
    }
    // 4. NATIVE ANDROID: settings.gradle(.kts) or build.gradle(.kts)
    val settingsGradleMatch = findShallowest {
      fileNameOf(it) == "settings.gradle" || fileNameOf(it) == "settings.gradle.kts"
    }
    val buildGradleMatch = findShallowest {
      (fileNameOf(it) == "build.gradle" || fileNameOf(it) == "build.gradle.kts") &&
        !it.contains("/build/")
    }

    val packageJsonText = packageJsonMatch?.first?.let { textReader(it) }?.lowercase(Locale.US)
    val hasAndroidDirUnder: (String) -> Boolean = { prefix ->
      val pLower = prefix.lowercase(Locale.US)
      scanPaths.any { (_, l) -> l.startsWith("${pLower}android/") }
    }

    val (framework, rootPrefix) = when {
      godotMatch != null -> {
        ProjectFramework.GODOT to parentPrefix(godotMatch.first)
      }
      pubspecMatch != null -> {
        ProjectFramework.FLUTTER to parentPrefix(pubspecMatch.first)
      }
      packageJsonMatch != null && packageJsonText != null &&
        (packageJsonText.contains("@capacitor/core") ||
          packageJsonText.contains("@capacitor/android") ||
          packageJsonText.contains("\"cordova\"") ||
          packageJsonText.contains("cordova-android")) -> {
        ProjectFramework.CAPACITOR_CORDOVA to parentPrefix(packageJsonMatch.first)
      }
      capacitorConfigMatch != null -> {
        ProjectFramework.CAPACITOR_CORDOVA to parentPrefix(capacitorConfigMatch.first)
      }
      packageJsonMatch != null -> {
        ProjectFramework.REACT_NATIVE to parentPrefix(packageJsonMatch.first)
      }
      settingsGradleMatch != null -> {
        ProjectFramework.NATIVE_ANDROID to parentPrefix(settingsGradleMatch.first)
      }
      buildGradleMatch != null -> {
        var prefix = parentPrefix(buildGradleMatch.first)
        if (prefix.endsWith("app/")) {
          prefix = prefix.removeSuffix("app/")
        }
        ProjectFramework.NATIVE_ANDROID to prefix
      }
      else -> ProjectFramework.UNKNOWN to ""
    }

    val gradleSearchPrefix = when {
      (framework == ProjectFramework.FLUTTER ||
        framework == ProjectFramework.REACT_NATIVE ||
        framework == ProjectFramework.CAPACITOR_CORDOVA) && hasAndroidDirUnder(rootPrefix) -> {
        "${rootPrefix}android/"
      }
      else -> rootPrefix
    }

    val gradlePrefixLower = gradleSearchPrefix.lowercase(Locale.US)
    val rootPrefixLower = rootPrefix.lowercase(Locale.US)

    val hasGradlew = scanPaths.any { (_, l) ->
      l == "${gradlePrefixLower}gradlew" || l == "${rootPrefixLower}gradlew" || l.endsWith("/gradlew")
    }
    val wrapperPropsPath = scanPaths.firstOrNull { (_, l) ->
      l == "${gradlePrefixLower}gradle/wrapper/gradle-wrapper.properties" ||
        l == "${rootPrefixLower}gradle/wrapper/gradle-wrapper.properties" ||
        l.endsWith("/gradle/wrapper/gradle-wrapper.properties")
    }?.first
    val wrapperPropsText = wrapperPropsPath?.let { textReader(it) }
    val gradleVersion = wrapperPropsText?.let { GRADLE_VERSION_REGEX.find(it)?.groupValues?.getOrNull(1) }
    val hasGradleWrapper = hasGradlew && wrapperPropsPath != null

    val gradleBuildFiles = scanPaths
      .filter { (_, l) ->
        (fileNameOf(l) == "build.gradle" || fileNameOf(l) == "build.gradle.kts") &&
          !l.contains("/build/")
      }
      .map { it.first }

    var hasFirebasePlugin = false
    var applicationId: String? = null

    for (gradlePath in gradleBuildFiles) {
      val content = textReader(gradlePath) ?: continue
      if (content.contains("google-services", ignoreCase = true)) {
        hasFirebasePlugin = true
      }
      val isAppModule = gradlePath.lowercase(Locale.US).endsWith("app/build.gradle") ||
        gradlePath.lowercase(Locale.US).endsWith("app/build.gradle.kts")
      if (applicationId == null && isAppModule) {
        applicationId = APP_ID_REGEX.find(content)?.groupValues?.getOrNull(1)
          ?: NAMESPACE_REGEX.find(content)?.groupValues?.getOrNull(1)
      }
    }

    if (applicationId == null) {
      val manifestPath = scanPaths.firstOrNull { (_, l) ->
        l.endsWith("app/src/main/androidmanifest.xml") || l.endsWith("/androidmanifest.xml")
      }?.first
      val manifestText = manifestPath?.let { textReader(it) }
      if (manifestText != null) {
        applicationId = MANIFEST_PKG_REGEX.find(manifestText)?.groupValues?.getOrNull(1)
      }
    }

    val hasGoogleServicesJson = scanPaths.any { (_, l) ->
      l == "${gradlePrefixLower}app/google-services.json" ||
        l == "${rootPrefixLower}app/google-services.json" ||
        l.endsWith("/app/google-services.json")
    }

    val hasEnvExampleFile = scanPaths.any { (_, l) ->
      l == "${rootPrefixLower}.env.example" || fileNameOf(l) == ".env.example"
    }

    return SourceProjectMetadata(
      framework = framework,
      projectRootPrefix = rootPrefix,
      hasGradleWrapper = hasGradleWrapper,
      gradleVersion = gradleVersion,
      hasFirebasePlugin = hasFirebasePlugin,
      hasGoogleServicesJson = hasGoogleServicesJson,
      hasEnvExample = hasEnvExampleFile,
      applicationId = applicationId,
      strippedMetadataCount = strippedMetadataCount,
    )
  }

  private fun shouldCaptureMetadataText(lowerPath: String): Boolean {
    val fileName = fileNameOf(lowerPath)
    return fileName == "package.json" ||
      fileName == "build.gradle" ||
      fileName == "build.gradle.kts" ||
      fileName == "gradle-wrapper.properties" ||
      fileName == "androidmanifest.xml"
  }

  private fun depthOf(normalizedPath: String): Int = normalizedPath.count { it == '/' }

  private fun fileNameOf(normalizedPath: String): String = normalizedPath.substringAfterLast('/')

  private fun parentPrefix(normalizedPath: String): String {
    val idx = normalizedPath.lastIndexOf('/')
    return if (idx >= 0) normalizedPath.substring(0, idx + 1) else ""
  }

  private fun invalidTarget(inputFile: File, originalName: String): AppTargetFile = AppTargetFile(
    sessionFile = inputFile,
    originalName = originalName,
    sizeBytes = inputFile.length(),
    binaryType = ResolvedBinaryType.INVALID,
    isAlreadySigned = false,
    detectedStack = null,
    sourceMetadata = null,
  )

  private fun streamEntryToFile(zipFile: ZipFile, entry: ZipEntry, outputFile: File) {
    val buffer = ByteArray(STREAM_BUFFER_SIZE)
    try {
      zipFile.getInputStream(entry).use { input ->
        FileOutputStream(outputFile, false).use { output ->
          while (true) {
            val read = input.read(buffer)
            if (read == -1) break
            output.write(buffer, 0, read)
          }
          output.flush()
        }
      }
    } catch (e: Exception) {
      ZeroTraceManager.secureDeleteFile(outputFile)
      throw e
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }

  private fun readCappedEntryText(zipFile: ZipFile, entry: ZipEntry): String? {
    return runCatching {
      zipFile.getInputStream(entry).use { input ->
        readCappedFromStream(input)
      }
    }.getOrNull()
  }

  private fun readCappedFromStream(input: InputStream): String {
    val baos = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    var total = 0
    try {
      while (total < MAX_METADATA_READ_BYTES) {
        val toRead = minOf(buffer.size, MAX_METADATA_READ_BYTES - total)
        val read = input.read(buffer, 0, toRead)
        if (read == -1) break
        baos.write(buffer, 0, read)
        total += read
      }
      return baos.toString(Charsets.UTF_8.name())
    } finally {
      ZeroTraceManager.wipeByteArray(buffer)
    }
  }
}
